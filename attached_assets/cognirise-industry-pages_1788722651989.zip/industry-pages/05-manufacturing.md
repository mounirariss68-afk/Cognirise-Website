# Manufacturing

> **Editor's notes (remove before publishing).** Evidence labels as on every page: **[company-reported]**, **[vendor-claimed]**, **[analyst-estimate]**, **[regulator/official]**, **[independent study]**. The organising fact of this page is a WEF number: in the January 2025 Global Lighthouse cohort, **77% of top use cases were analytical AI and 9% generative**. Every hard ROI figure on the page is vision, simulation or physics — not LLM. Items flagged ⚠ are the weakest figures. Deliberately excluded: the circulated "77% of AI vision projects never leave pilot" statistic (the publication that cites it calls it "widely cited, rarely examined"); any quantified Siemens Industrial Copilot time-saving (neither the thyssenkrupp nor the Schaeffler release contains one). GCC coverage is strong for Aramco, EGA, EDGE and Pearl GTL and thin elsewhere — SABIC, Ma'aden, Emirates Steel Arkan, Ducab, Strata and QAFCO should be targeted in a second pass.

**Working page title:** Manufacturing — Physical AI, machinery law, and the gap between the lighthouse and the long tail.

**Meta description (≤160 chars):** AI in manufacturing: what the lighthouse factories actually prove, why humanoids and lights-out are ahead of the data, and the use cases with measured results.

---

## 1. The state of the industry, from an AI perspective

Manufacturing is the industry with the longest history of *physical* AI proof — statistical process control, machine vision, robotics — and the shortest history of *enterprise* AI proof. The 2024–26 evidence shows a widening gap between a small élite of sites that have industrialised AI and a long tail that has barely started.

### Adoption is far shallower than the discourse

Only **29% of manufacturers use AI or machine learning at facility or network level**, and just 24% have deployed generative AI ([Deloitte 2025 Smart Manufacturing survey via Manufacturing Dive, May 2026](https://www.manufacturingdive.com/news/most-us-manufacturers-still-not-automating-ai-robotics/819725/) — independent study). Intrinsic's CTO estimates that *"80% of U.S. manufacturing facilities have zero automation."* Rockwell Automation's vendor survey of 1,560 manufacturers is more bullish yet still finds **only ~34% of operations incorporate AI**, and that just **43% of collected data is used effectively** ([Rockwell, 2026](https://www.prnewswire.com/news-releases/90-of-manufacturers-say-digital-transformation-is-now-essential-according-to-new-global-study-302775186.html) — vendor-claimed survey). McKinsey's read for industrials: two-thirds remain in pilots, and **only 39% report any effect on earnings — mostly under 5% of EBIT** ([BIC Magazine, 2025](https://www.bicmagazine.com/departments/maintenance-reliability/industrial-companies-struggle-to-scale-ai/) — analyst-estimate).

### Where value is documented — and how small that set is

The WEF/McKinsey Global Lighthouse Network reached **238 sites across 35+ countries by June 2026** ([WEF, Jun 2026](https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/) — regulator/official). Against hundreds of thousands of factories worldwide, that is a rounding error. Within it, the results are real and peer-reviewed: the September 2025 cohort averaged **+40% labour productivity, −48% lead time, −41% product defects, −28% energy consumption** ([WEF, Sep 2025](https://www.weforum.org/press/2025/09/global-lighthouse-network-2025-world-economic-forum-recognizes-12-new-sites-driving-holistic-transformation-in-manufacturing/)); the January 2025 cohort **+53% productivity, −26% conversion cost, −30% material waste**.

The January 2025 release also settles which AI matters: **77% of top-five use cases were enabled by analytical AI; only 9% by generative AI** ([WEF, Jan 2025](https://www.weforum.org/press/2025/01/global-lighthouse-network-2025-world-economic-forum-recognizes-companies-transforming-manufacturing-through-innovation/)).

### Robots keep arriving, unevenly

**542,000 industrial robots** were installed in 2024, the fourth year above 500,000; the operational stock is ~4.66 million; China alone took 54% of installations ([IFR *World Robotics 2025*](https://ifr.org/ifr-press-releases/news/global-robot-demand-in-factories-doubles-over-10-years) — independent study). Robot density per 10,000 manufacturing employees: Korea **1,220**, Singapore 818, Germany 449, Japan 446, US 307, global average 132 ([IFR, Apr 2026](https://ifr.org/ifr-press-releases/news/robot-density-surges-in-europe-asia-and-americas)).

### The workforce constraint is structural

US manufacturing needs **3.8 million new employees by 2033**, with **1.9 million roles at risk of going unfilled**; 65% of manufacturers name talent as their primary business challenge ([Deloitte / Manufacturing Institute, Apr 2024](https://themanufacturinginstitute.org/manufacturers-need-as-many-as-3-8-million-new-employees-by-2033/) — independent study).

### The reshoring boom that was supposed to fund automation has not arrived in the data

US manufacturing construction spending **peaked at $239bn in June 2024 and fell 21% through March 2026**; excluding electronics, growth was ~2.3% real; manufacturing employment fell 1% after the April 2025 tariffs. Meanwhile data-centre construction rose from $9.5bn to **$47bn** a month and hyperscaler capex passed $410bn ([IoT Analytics, 2026](https://iot-analytics.com/us-manufacturing-reshoring-boom-what-the-data-says/) — independent study). Capital went to data centres, not factories.

### Cyber risk is now a first-order operating risk

Ransomware attacks on industrial organisations rose **64%** in 2025; **manufacturing accounted for over two-thirds of all ransomware victims**; average dwell time in OT was **42 days** (5 days for organisations with full OT visibility) ([Dragos 2026 Year in Review, Feb 2026](https://www.dragos.com/resources/press-release/dragos-2026-year-in-review-new-ot-threats-ransomware) — independent study). The cleanest public benchmark for what an OT outage costs a metals producer remains Norsk Hydro's 2019 attack: **~$75m in one half-year** ([Computer Weekly, 2019](https://www.computerweekly.com/news/252467199/Norsk-Hydro-cyber-attack-could-cost-up-to-75m)).

### The data characteristic that makes manufacturing different

Manufacturing's dominant data asset is high-frequency, unlabelled, physically grounded time-series and image data locked in heterogeneous OT protocols — not text. That is why analytical AI outperforms generative AI 77% to 9% in lighthouse use-case mixes, and why the binding constraint is labelling and contextualisation, not model access. Bosch has committed **more than $2.7bn to AI by end-2027** and trained 65,000+ employees ([Bosch, Jun 2025](https://us.bosch-press.com/pressportal/us/en/press-release-27776.html) — company-reported); the capital is flowing, but into a very different kind of data.

---

## 2. The challenges of the AI era — specific to manufacturing

**Machinery safety law, not AI law, is the binding regulator on the line.** EU Regulation 2023/1230 applies from **20 January 2027** and explicitly covers AI *"where specific modules of AI using learning techniques ensure safety functions"*, with third-party conformity assessment for high-risk machinery ([EU-OSHA](https://osha.europa.eu/en/legislation/directive/regulation-20231230eu-machinery) — regulator/official). An AI model performing a safety function on a CE-marked machine cannot be silently updated. Continuous learning collides with CE marking — a problem no bank or telco faces. The EU AI Act's Annex I stacks on top, with its own moving deadline. ⚠ Verify revised Annex I dates against the Official Journal.

**The false-positive economics of visual inspection.** The mechanism named in industry reporting is trust collapse: *"Even a small percentage of false positives at production volume is sufficient to erode operator trust, and once that trust is lost, it is extremely difficult to recover"* ([Automotive Manufacturing Solutions](https://www.automotivemanufacturingsolutions.com/smart-factory/ai-vision-finds-its-footing-on-the-factory-floor/2644253)). At 1,400 vehicles a day, a 1% false-positive rate on a single station is 14 unnecessary interventions a day — enough for operators to switch the alert off.

**Predictive maintenance scales combinatorially, not linearly.** McKinsey's canonical analysis: plant-wide systems require model counts *"often exceeding triple digits"* and *"the highest-maturity, asset-wide PdM 4.0 systems are still rare today"* ([McKinsey, Jul 2021](https://www.mckinsey.com/capabilities/operations/our-insights/prediction-at-scale-how-industry-can-get-more-value-out-of-maintenance) — analyst-estimate; older, but the most precise public statement of the mechanism and unchallenged since). There is no foundation model that transfers across a compressor, a press and a furnace.

**Labour holds an explicit veto in unionised manufacturing.** The Korean Metal Workers' Union blocked Hyundai's humanoid deployment on 22 January 2026: *"Keep in mind that not a single robot can enter the workplace without labour-management agreement"* ([Tech Times, May 2026](https://www.techtimes.com/articles/317005/20260522/hyundai-commits-25000-atlas-robots-own-factories-union-blocks-deployment-without-labor-deal.htm) — press-reported). No consumer-internet AI programme carries this constraint.

**OT cyber exposure converts AI connectivity into balance-sheet risk.** Connecting lines to cloud AI expands the attack surface at exactly the moment manufacturing became the top ransomware target. ISA/IEC 62443 zone-and-conduit segmentation is the accepted control — and it is in direct tension with the flat, high-bandwidth data plumbing industrial AI wants.

**Data residency fragments the MES/IIoT cloud stack in the Gulf.** Saudi PDPL enforcement requires sensitive and personally identifiable data to be stored inside the Kingdom absent an exemption, under active enforcement since August 2025 ([US ITA](https://www.trade.gov/market-intelligence/saudi-arabia-ict-cross-border-data-transfer-rules-now-under-enforcement) — regulator-derived). For manufacturers this bites on operator-identifiable safety video, SOP-compliance vision, biometric access and shift data — exactly the highest-ROI shop-floor computer-vision cases.

**Latency and cost physics push AI to the edge, against the cloud vendors' grain.** Emirates Global Aluminium moved image and video analytics off public cloud onto on-premise edge infrastructure and reported an **86% cost reduction and 13× faster response**; its stated rationale was sovereignty as much as economics — *"fully disconnected, if necessary"* ([Microsoft customer story](https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates) — vendor-claimed, EGA-attributed).

---

## 3. What key players are doing

| Organisation | Deployment | Scale / outcome | Evidence |
|---|---|---|---|
| **BMW Group** | Figure 02 humanoid at Spartanburg (11 months, sheet-metal insertion); **AIQX** camera, sensor and acoustic in-line quality at Debrecen; **GenAI4Q** per-vehicle inspection catalogues at Regensburg | Figure 02: 90,000+ parts, 1,250+ hours, then decommissioned; successor Figure 03 reassigned to **logistics sequencing** — a step down in dexterity ambition. AIQX and GenAI4Q: **no performance metrics published** | [BMW](https://www.press.bmwgroup.com/global/article/detail/T0458778EN/bmw-group-advances-the-use-of-physical-ai-in-production-with-figure-03-project-in-spartanburg?language=en); [Figure](https://www.figure.ai/news/production-at-bmw), Nov 2025; [BMW GenAI4Q](https://www.press.bmwgroup.com/global/article/detail/T0449729EN/artificial-intelligence-as-a-quality-booster?language=en), Apr 2025 |
| **Siemens** | Industrial Copilot for Engineering at thyssenkrupp Automation Engineering and Schaeffler (demo); nine new copilots at CES 2026 | thyssenkrupp: qualitative only — *"in a much shorter time"*; Schaeffler: a demonstration, no deployment scale. PepsiCo cited at CES: **+20% throughput on initial deployment** [vendor-claimed] | [Siemens](https://press.siemens.com/global/en/pressrelease/siemens-industrial-copilot-expanded-adopted-thyssenkrupp), Nov 2024; [Siemens CES](https://news.siemens.com/en-us/siemens-unveils-technologies-to-accelerate-the-industrial-ai-revolution-at-ces-2026/), Jan 2026 |
| **Emirates Global Aluminium (UAE)** | 80+ AI use cases (McKinsey-supported); edge inference on-premise; Al Taweelah named End-to-End Value Chain Lighthouse | **>$123m combined impact**, self-funded; **−92% operator reaction time** on safety alerts; **+65% SOP compliance**; **−50% inbound logistics delays**; 3,000+ employees upskilled; edge: **−86% cost, 13× faster** | [McKinsey case study](https://www.mckinsey.com/capabilities/tech-and-ai/how-we-help-clients/rewired-in-action/emirates-global-aluminium-leading-the-industry-with-ai-driven-transformation) ⚠ consultant-reported; [Microsoft](https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates); [WEF](https://www.weforum.org/press/2025/01/global-lighthouse-network-2025-world-economic-forum-recognizes-companies-transforming-manufacturing-through-innovation/), Jan 2025 |
| **Unilever** | 40+ new digital twins over 18 months with Accenture | Raeford NC: **−20% waste, +10% capacity**; Poznań: up to −20% minor stoppages, **~−30% waste**; Gandhidham: **−30% quality defects over four years**; Cu Chi: 1–2% premium-ingredient saving | [company-reported](https://www.unilever.com/news/press-and-media/press-releases/2026/unilever-scales-digital-twins-across-global-manufacturing-network-with-accenture/), Jun 2026 |
| **GE Aerospace** | AI Blade Inspection Tool for GEnx HPT blades, extending to LEAP and GE9X | Inspection **3 hours → 1.5 hours (−50%)** with improved accuracy | [company-reported](https://www.geaerospace.com/news/press-releases/ge-aerospace-expanding-application-ai-blade-inspections-cfm-leap-and-ge9x-engines), Oct 2024 |
| **TSMC + NVIDIA** | cuLitho, cuEST, cuML, defect inspection, Omniverse "FabTwin" inside the fab | cuLitho **20–50%** better cost-effectiveness or cycle time; **50× faster chemistry simulation**; no headline yield number | [vendor-claimed, joint release](https://nvidianews.nvidia.com/news/nvidia-and-tsmc-bring-ai-into-fabs-to-advance-semiconductor-design-and-manufacturing), May 2026 |
| **Foxconn** | Digital-twin factory planning with NVIDIA; Houston AI-server plant validated in the twin before construction | **150× faster CFD**; **~50% reduction in factory-planning time**; Houston plant has **no operational data yet** | [vendor-claimed](https://www.nvidia.com/en-us/case-studies/foxconn-develops-physical-ai-enabled-smart-factories-with-digital-twins/) |
| **Mercedes-Benz** | Apptronik Apollo humanoids at Berlin-Marienfelde | Intralogistics and initial quality checks; low double-digit-million-euro investment; **initial testing phase** | [company-reported](https://group.mercedes-benz.com/company/production/procuction-network/mbdfc-humanoid-robots.html), Mar 2025 |
| **Hyundai / Boston Dynamics** | 30,000 humanoids a year by 2028, first at Metaplant America on parts sequencing | Union-blocked pending labour agreement; first deployment **2028** | [Axios](https://www.axios.com/2026/01/05/hyundai-humanoid-robots-boston-dynamics), Jan 2026 |
| **Tesla** | Optimus | Promised ~10,000 units in 2025; **zero doing "useful work" in factories** per Musk, Jan 2026; production pushed to late July/Aug 2026 | [Electrek](https://electrek.co/2026/04/22/tesla-optimus-production-fremont-model-sx-line/), Apr 2026 — press-reported company statements |
| **Bosch** | Multi-agent maintenance forecasting and personnel scheduling | Reduced unplanned downtime; *"several million euros"* **projected** | [company-reported](https://us.bosch-press.com/pressportal/us/en/press-release-27776.html), Jun 2025 |
| **Saudi Aramco** | Six facilities in the Global Lighthouse Network (Uthmaniyah, Khurais, Abqaiq, Yanbu, North Ghawar, Hawiyah NGL) | "The only global energy company represented by more than three facilities"; site-level metrics not published | [Aramco](https://www.aramco.com/en/news-media/news/2025/fifth-aramco-facility-receives-world-economic-forum-global-lighthouse-network-status), Jan 2025; [WEF](https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/), Jun 2026 |
| **QatarEnergy / Shell — Pearl GTL** | First Qatari Lighthouse site; 45+ digital solutions incl. predictive analytics and digital twins | Outcomes described qualitatively; **not quantified publicly** | [The Peninsula](https://thepeninsulaqatar.com/article/21/09/2025/qatarenergy-and-shells-pearl-gtl-recognised-by-world-economic-forum-as-global-lighthouse-site), Sep 2025 |
| **EDGE Group (UAE)** | 68 Industry 4.0 projects across 28 facilities; Group AI Accelerator | Production capacity doubled across 13 entities; 5,276 trained; >80% of systems UAE-manufactured; AED 596m in-country value in 2025 | [EDGE](https://edgegroup.ae/news/edge-charts-defence-manufacturing-progress-make-it-emirates-2026), May 2026 |

### The reversals worth knowing

**Tesla Optimus** is the sector's clearest gap between claim and delivery: 10,000 promised for 2025, zero doing useful factory work by January 2026 on the CEO's own account. Musk on predictability: *"It will move as fast as the least lucky, slowest, dumbest part in the entire 10,000."*

**BMW's humanoid programme** did not fail — but its trajectory ran *down* the dexterity ladder, from welding-adjacent sheet-metal work to logistics sequencing, when the next generation arrived.

**Alat (PIF, Saudi Arabia)** — launched as a $100bn advanced-manufacturing champion — **scrapped semiconductor manufacturing** in April 2026 and redeployed the team and capital to data-centre infrastructure, replacing its CEO ([EnterpriseAM, Apr 2026](https://enterpriseam.com/menaplus/2026/04/10/pif-pivots-alat-from-chip-manufacturing-to-data-center-buildout/) — press-reported). In the Gulf, industrial capital is repeatedly being re-optimised toward compute and away from hard manufacturing.

---

## 4. Myths versus reality

| The claim | What the evidence shows | Verdict |
|---|---|---|
| "Lighthouse factories prove industrial AI works at scale." | Real, peer-reviewed KPI gains for the sites that achieved them. But the network is 238 self-nominated, consultant-supported, disproportionately large-cap sites; failures are never in the denominator; McKinsey itself concedes *"many industrial organizations struggle to move beyond pilots."* | **Proven in pockets.** The deltas are real; they are not a base rate. |
| "Humanoid robots will be on production lines by 2026." | Figure 02: one robot, one station, then reassigned to logistics. Mercedes' Apollo: transport and initial checks, in testing. Hyundai: first deployment 2028, on sequencing, union-blocked. Tesla: zero. | **Contradicted for 2026 line work; unproven at production economics.** No published unit economics exist anywhere in this evidence base. |
| "Generative AI writes PLC code." | Siemens' copilot generates IEC structured text in TIA Portal and is in production at thyssenkrupp. The strongest documented value is *explaining legacy code*; experts stress IEC 61131-3's safety properties; most installed logic is graphical ladder; neither Siemens release published a time saving ([Control Design, Aug 2025](https://www.controldesign.com/control/plcs-pacs/article/55311461/)). | **Proven in pockets** (comprehension, boilerplate, HMI generation); **unproven** for authoring safety-relevant control logic. |
| "AI visual inspection replaces QC inspectors." | BMW AIQX runs in-line; GE halved inspection time with better accuracy. But false positives at volume are the binding constraint, and BMW's own GenAI4Q keeps the human inspector and augments the checklist. | **Proven in pockets as augmentation; contradicted as replacement.** |
| "Predictive maintenance pays for itself everywhere." | Bosch reports reduced downtime; PdM is standard in lighthouse mixes. McKinsey: plant-wide needs triple-digit model counts and asset-wide systems are "still rare." Payback = failure frequency × downtime cost × warning lead time; on cheap, low-criticality assets the model costs more than the failures. | **Proven in pockets** (high-criticality, high-downtime-cost rotating assets); **unproven** as a plant-wide programme. |
| "Digital twins equal ROI." | The best-quantified dataset on this page — Unilever's site-level twins — is entirely *process* twins tied to specific control decisions. Geometry-and-visualisation twins have no comparable published ROI. Foxconn's most-publicised twin is for a plant that does not yet exist. | **Proven at scale for process twins with closed-loop decisions; unproven for visualisation twins.** |
| "Lights-out factories are the destination." | Chinese "dark factory" demonstrations exist for narrow, high-volume, low-variance products. Plus One Robotics' CEO: *"The future will not be a fully lights-out, human-free operation"*; the realistic projection is *one* fully automated automotive plant by 2030 ([Quality Magazine, Mar 2026](https://www.qualitymag.com/articles/99453-the-dark-factory-myth)). Against 80% of US plants with zero automation. | **Contradicted as a general destination; proven in pockets for narrow lines.** |
| "Tariffs and reshoring are driving an automation supercycle." | Announcements are abundant; construction spend fell 21% from peak; employment fell 1%; PMI stayed below 50 through 2025; capital went to data centres. | **Contradicted (so far) in aggregate; proven in pockets in semiconductors.** |
| "Generative AI is the manufacturing AI story." | 77% analytical vs 9% generative in the lighthouse mix. Every hard number here — GE −50%, Unilever −30%, TSMC 50×, Foxconn 150× — is vision, simulation or physics. | **Contradicted.** GenAI's proven role is engineering copilot and knowledge retrieval, not operations. |
| "Industrial AI programmes are self-funding." | EGA: self-funded from inception, >$123m from 80+ use cases. McKinsey: only 39% of industrials report any EBIT effect, mostly under 5%. | **Proven in pockets.** EGA is an exceptionally well-run counterexample, not a base rate. |

---

## 5. The Cognirise point of view

**In manufacturing, start where the physics is. The AI that has earned its place on the shop floor sees, simulates and predicts; the AI that has not is the humanoid, the lights-out factory and the chatbot. Build the first with humans designed in, run it at the edge, and use generative AI where it belongs — on the engineer's knowledge, not the machine's safety function.**

The evidence is unusually one-sided. Seventy-seven per cent of lighthouse value is analytical. Every quantified return — GE's halved inspection time, Unilever's waste and defect reductions, TSMC's simulation speed-ups, EGA's safety and SOP compliance gains — comes from vision, physics or process models tied to a specific decision. The generative and humanoid programmes that dominate the headlines have published, between them, no unit economics at all. That is not an argument against ambition. It is an argument about sequence.

Five convictions follow.

**Vision and process twins first, because they are what pays.** In-line quality inspection, SOP and safety compliance vision, and process twins with closed-loop decisions have measured returns at named sites. They also share a failure mode: false positives at production volume destroy operator trust in weeks. We design the false-positive budget, the operator feedback loop and the trust-recovery path before the first camera goes up — and measure defect escape rate *and* nuisance-alert rate together, because a system operators switch off has a return of zero.

**Edge-first, sovereign by architecture.** EGA's move from public cloud to on-premise edge delivered 86% lower cost and 13× faster inference, and satisfied residency with an explicit "fully disconnected if necessary" design. Saudi PDPL and IEC 62443 segmentation point the same way. In the Gulf, sovereignty is not a compliance tax on industrial AI; done properly, it is the cheaper, faster architecture.

**Humans in the loop by design — and by law.** The Machinery Regulation, works councils and union agreements make the human's role a design input, not an afterthought. BMW's GenAI4Q gives the inspector a better checklist rather than removing the inspection. The Korean Metal Workers' Union can stop a 30,000-robot programme at the gate. Programmes that treat workforce agreement as a downstream change-management task will discover it is an upstream veto.

**Use generative AI on knowledge, not control.** The proven generative use in manufacturing is the engineering and knowledge copilot: explaining legacy PLC code when the author has left, drafting HMI screens, turning tribal knowledge in SOPs, shift logs and maintenance histories into a grounded, cited assistant. Authoring safety-relevant control logic is not yet the place for it — and machinery law says so. In the Gulf, that copilot must work in Arabic, English, Hindi, Urdu and Tagalog at the instruction layer, because that is who is on the floor.

**Localisation, not labour cost, is the regional driver — and industrial AI is competing with data centres for capital.** EDGE's 68 Industry 4.0 projects, 80% UAE-manufactured systems and 5,276 people trained show automation justified by in-country value and capability, with skills as a deliverable. Alat's pivot from chips to data centres shows the other side: every manufacturing AI proposal in the region is implicitly competing against a sovereign-compute business case. The manufacturing case wins when it is framed the same way — measured, localised, capacity-building, and funded by its own returns, as EGA's was.

### How this maps to Cognirise's service lines

| Service line | In manufacturing this means |
|---|---|
| **Agentic Enterprise Transformation** | Quality, maintenance and planning redesigned as human-plus-agent workflows — agentic maintenance-and-scheduling in the Bosch pattern — with OEE, defect escape and nuisance-alert rate as the measured outcomes. |
| **Data & AI Foundations** | Historian, MES and vision-data foundations contextualised and labelled for AI; IEC 62443-compliant zones and conduits; a data-residency design that keeps operator-identifiable video in-country. |
| **Engineering with AI** | Engineering and knowledge copilots over PLC code, HMI, SOPs and maintenance records — multilingual, on-premise capable — measured on engineer cycle time. |
| **Sovereign Agentic AI** | The EGA architecture as the regional reference: edge inference, disconnected-capable, PDPL-aligned; in-country-value and skills-building as explicit deliverables in the EDGE pattern. |
| **AI-Native Platforms** | A shop-floor front door on mobile — the 20+ apps, 1,500 users EGA pattern — that puts inspection plans, procedures and alerts in the operator's language and closes the loop back to the twin. |

Our operating principle — *value first, foundations behind value, transformation on proof* — has a manufacturing corollary: **start with the use case whose physics you can measure, and let the humanoid wait for its unit economics.**

---

## 6. High-impact use cases and what the evidence says about returns

| # | Use case | Type | Who has done it | Documented outcome | What to expect and measure | Prerequisites |
|---|---|---|---|---|---|---|
| 1 | **Process digital twin for yield and waste** | Analytical + simulation | Unilever (Raeford, Poznań, Gandhidham, Cu Chi) | **−20% waste, +10% capacity; ~−30% waste; −30% defects over four years; 1–2% ingredient saving** [company-reported, Jun 2026] | Waste, defects, capacity per site against baseline; Gandhidham accrued over four years — plan for compounding, not a step | Second-level historised tags; validated first-principles model; closed loop to control |
| 2 | **AI borescope and part inspection (MRO)** | Analytical (vision) | GE Aerospace | **3h → 1.5h (−50%)** with improved accuracy; extended GEnx → LEAP, GE9X [company-reported, Oct 2024] | Inspection hours; detection accuracy vs borescope standard; regulator acceptance | Large labelled defect-image corpus per stage |
| 3 | **In-line vision and acoustic quality (AIQX-type)** | Analytical | BMW Debrecen and Group | Deployed in-line; **no percentage published** | Defect escape rate *and* false-positive rate — both, always | Camera/sensor/mic infrastructure; edge inference; false-positive governance |
| 4 | **Edge inference for video and image analytics** | Analytical | EGA | **−86% cost vs public cloud; 13× faster response**; 2.9 PB video/yr; **3 months** concept → production [vendor-claimed] | Cost per inference; latency; deployment frequency | On-prem edge cluster; Kubernetes; OT segmentation |
| 5 | **Computer-vision SOP compliance and safety alerting** | Analytical | EGA | **−92% operator reaction time on safety alerts; +65% SOP compliance** [vendor/consultant-claimed ⚠] | Reaction time; compliance rate; incident rate | Work-cell camera coverage; **personal-data and works-council clearance** |
| 6 | **Computational lithography and process simulation** | Analytical + HPC | TSMC with NVIDIA | **20–50%** cost-effectiveness/cycle time; **50×** chemistry simulation [vendor-claimed, May 2026] | Simulation turnaround; process variation | GPU cluster; physics models; fab data pipeline |
| 7 | **Factory-planning twin (greenfield / line migration)** | Simulation | Foxconn; Siemens virtual validation | **~−50% planning time; 150× CFD**; Siemens claims up to 90% of issues found pre-build and **10–15% capex reduction** [vendor-claimed] | **Projected until the plant runs**; measure change orders and commissioning time post-build | USD asset libraries; CAD-to-simulation pipeline |
| 8 | **Engineering copilot for control code and HMI** | Generative | Siemens Industrial Copilot at thyssenkrupp | **No quantified saving published** by Siemens, thyssenkrupp or Schaeffler | Engineer hours per function block; legacy-code comprehension time; review-gate defect rate | TIA Portal/WinCC estate; repositories; review gate before download to PLC |
| 9 | **Agentic maintenance and labour scheduling** | Agentic | Bosch | Reduced unplanned downtime; *"several million euros"* **projected** [company-reported, Jun 2025] | Unplanned downtime; technician utilisation | CMMS/EAM integration; skills matrix; asset criticality model |
| 10 | **Throughput optimisation copilot in production ops** | Generative + analytical | PepsiCo via Siemens | **+20% throughput on initial deployment** [vendor-claimed, single site, no baseline disclosed ⚠] | OEE against a documented baseline | MES data model; line-level OEE history |
| 11 | **Per-unit generative inspection plans** | Generative | BMW GenAI4Q, Regensburg | **No metrics published**; 1,400 vehicles/day scope | Inspector time per vehicle; defects found per plan | Vehicle-order and production-pattern data; mobile app |
| 12 | **Shop-floor knowledge and SOP copilot (multilingual)** | Generative, grounded | EGA pattern (20+ mobile apps, 1,500 users; 3,000+ upskilled); no GCC Arabic-copilot performance data published | **No published performance figure** | Time-to-answer; SOP compliance; onboarding time | Digitised SOPs, shift logs and maintenance records; Arabic–English–Hindi–Urdu–Tagalog parity |
| 13 | **Humanoid intralogistics / parts sequencing** | Physical AI | Figure 03 at BMW; Apollo at Mercedes; Atlas at Hyundai (2028) | Figure 02: 90,000+ parts, 1,250+ hours — **no cost or throughput figure published** | Fund as R&D; measure parts per hour vs AMR baseline and mean time between interventions | Safety case under Machinery Regulation; union agreement; fleet ops |

**A note on returns.** Rows 1, 2, 4, 5 and 6 carry outcome numbers attached to running operations. Rows 3, 8, 11 and 12 are deployed but unquantified in public. Rows 7, 9, 10 and 13 are projected, single-site or vendor-claimed. A manufacturing AI roadmap should fund in that order and be honest about which rows are bets.

---

## 7. Case studies

*Structure to follow the shared case-study template (see `case-study-template.md`). Cognirise case studies for this industry to be added.*

---

## 8. Voices

> "Industrial AI is no longer a feature; it's a force that will reshape the next century." — **Roland Busch**, President & CEO, Siemens AG, January 2026

> "The future will not be a fully lights-out, human-free operation." — **Erik Nieves**, CEO, Plus One Robotics, March 2026

> "We want AI decisions about our plant to be done with as little outside exposure and with as little reliance on networks and the internet as possible—fully disconnected, if necessary." — **Emirates Global Aluminium**, Microsoft customer story

> "Keep in mind that not a single robot can enter the workplace without labour-management agreement." — **Korean Metal Workers' Union**, Hyundai Motor branch, January 2026

> "It will move as fast as the least lucky, slowest, dumbest part in the entire 10,000. It is impossible to predict these things." — **Elon Musk**, on Optimus production, April 2026

> "The true winners are not those that pilot the most technologies, but those that successfully scale their highest-value innovations." — **World Economic Forum**, Global Lighthouse Network, June 2026

---

## GCC snapshot (for a sidebar or regional tab)

- **Process lighthouses, world-class; discrete lighthouses, near-absent.** Aramco holds **six** Global Lighthouse sites (the only energy company with more than three); EGA Al Taweelah is an End-to-End Value Chain Lighthouse (Jan 2025) — an aluminium-industry first; QatarEnergy/Shell Pearl GTL joined in Sep 2025. That is the honest picture of regional capability.
- **EGA is the regional reference implementation:** >$123m impact from 80+ use cases, self-funded; edge inference on-premise at −86% cost and 13× speed; sovereignty as architecture.
- **EDGE Group** shows the regional driver: in-country value and capability localisation, not labour cost — 68 Industry 4.0 projects, capacity doubled at 13 entities, 5,276 trained, >80% UAE-manufactured, AED 596m in-country value in 2025 ([EDGE, May 2026](https://edgegroup.ae/news/edge-charts-defence-manufacturing-progress-make-it-emirates-2026)); Group AI Accelerator launched May 2025.
- **National strategies:** UAE Operation 300bn and MoIAT's Industry 4.0 programme (Industry 4.0 Index, Champions 4.0, Technology Transformation Program) ([MoIAT](https://moiat.gov.ae/en/programs/uae-industry-4-backup)); concrete cohorts such as MoIAT–Noventiq upgrading 20 national factories ([Zawya, Jan 2025](https://www.zawya.com/en/press-release/companies-news/make-it-in-the-emirates-2025-moiat-and-noventiq-partner-to-digitally-transform-20-uae-factories-with-industry-40-technologies-qxdas8iz)). Saudi: Vision 2030 NIDLP and the National Industrial Strategy, with SDAIA and NCA as the governance layer.
- **The capital-allocation risk:** Alat's April 2026 pivot from semiconductor manufacturing to data centres is the clearest regional warning — industrial-AI budgets compete with sovereign compute.
- **Residency:** Saudi PDPL requires in-Kingdom storage of sensitive and personally identifiable data absent an exemption — binding on safety video, SOP vision, biometric access and shift data.
- **Language:** a heavily multilingual, largely expatriate workforce in the UAE and Arabic-first HSE and quality documentation in KSA. SOP copilots need Arabic–English (and often Hindi/Urdu/Tagalog) parity at the instruction layer. No published GCC deployment reports Arabic shop-floor copilot performance yet.

---

## Sources

Primary sources used on this page (full 47-item index in `research/manufacturing-dossier.md`):

- WEF Global Lighthouse Network: 14 Jan 2025 — https://www.weforum.org/press/2025/01/global-lighthouse-network-2025-world-economic-forum-recognizes-companies-transforming-manufacturing-through-innovation/ ; 16 Sep 2025 — https://www.weforum.org/press/2025/09/global-lighthouse-network-2025-world-economic-forum-recognizes-12-new-sites-driving-holistic-transformation-in-manufacturing/ ; 22 Jun 2026 — https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/ ; McKinsey on the network, 13 Jul 2026 — https://www.mckinsey.com/capabilities/operations/our-insights/the-continuing-evolution-of-the-global-lighthouse-network
- Adoption: Manufacturing Dive on Deloitte survey, 26 May 2026 — https://www.manufacturingdive.com/news/most-us-manufacturers-still-not-automating-ai-robotics/819725/ ; Rockwell State of Smart Manufacturing, 2026 — https://www.prnewswire.com/news-releases/90-of-manufacturers-say-digital-transformation-is-now-essential-according-to-new-global-study-302775186.html ; McKinsey industrials via BIC Magazine, 2025 — https://www.bicmagazine.com/departments/maintenance-reliability/industrial-companies-struggle-to-scale-ai/ ; Deloitte 2026 Manufacturing Outlook — https://www.deloitte.com/us/en/insights/industry/manufacturing-industrial-products/manufacturing-industry-outlook.html
- IFR World Robotics 2025 — https://ifr.org/ifr-press-releases/news/global-robot-demand-in-factories-doubles-over-10-years ; robot density, 8 Apr 2026 — https://ifr.org/ifr-press-releases/news/robot-density-surges-in-europe-asia-and-americas
- Workforce: Deloitte / Manufacturing Institute, Apr 2024 — https://themanufacturinginstitute.org/manufacturers-need-as-many-as-3-8-million-new-employees-by-2033/
- Reshoring data: IoT Analytics, 2026 — https://iot-analytics.com/us-manufacturing-reshoring-boom-what-the-data-says/
- Cyber: Dragos 2026 Year in Review, 17 Feb 2026 — https://www.dragos.com/resources/press-release/dragos-2026-year-in-review-new-ot-threats-ransomware ; Norsk Hydro, Computer Weekly, 2019 — https://www.computerweekly.com/news/252467199/Norsk-Hydro-cyber-attack-could-cost-up-to-75m
- Regulation: EU Machinery Regulation 2023/1230, EU-OSHA — https://osha.europa.eu/en/legislation/directive/regulation-20231230eu-machinery ; EU AI Act Annex I summary — https://www.regulation-ai.eu/en/annex-i/ ; Saudi cross-border data rules, US ITA — https://www.trade.gov/market-intelligence/saudi-arabia-ict-cross-border-data-transfer-rules-now-under-enforcement
- BMW: Figure 03 at Spartanburg — https://www.press.bmwgroup.com/global/article/detail/T0458778EN/bmw-group-advances-the-use-of-physical-ai-in-production-with-figure-03-project-in-spartanburg?language=en ; Figure, 19 Nov 2025 — https://www.figure.ai/news/production-at-bmw ; GenAI4Q, 28 Apr 2025 — https://www.press.bmwgroup.com/global/article/detail/T0449729EN/artificial-intelligence-as-a-quality-booster?language=en ; Debrecen/AIQX, RCR Wireless, 9 Oct 2025 — https://www.rcrwireless.com/20251009/industry-4-0/bmw-ai-car-factory-hungary
- Siemens: thyssenkrupp, 12 Nov 2024 — https://press.siemens.com/global/en/pressrelease/siemens-industrial-copilot-expanded-adopted-thyssenkrupp ; Schaeffler — https://press.siemens.com/global/en/pressrelease/ai-industry-schaeffler-and-siemens-bring-industrial-copilot-shopfloor ; CES 2026, 14 Jan 2026 — https://news.siemens.com/en-us/siemens-unveils-technologies-to-accelerate-the-industrial-ai-revolution-at-ces-2026/ ; PLC code and gen AI, Control Design, 21 Aug 2025 — https://www.controldesign.com/control/plcs-pacs/article/55311461/
- EGA: McKinsey case study — https://www.mckinsey.com/capabilities/tech-and-ai/how-we-help-clients/rewired-in-action/emirates-global-aluminium-leading-the-industry-with-ai-driven-transformation ; Microsoft customer story — https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates
- Unilever, 16 Jun 2026 — https://www.unilever.com/news/press-and-media/press-releases/2026/unilever-scales-digital-twins-across-global-manufacturing-network-with-accenture/
- GE Aerospace, 23 Oct 2024 — https://www.geaerospace.com/news/press-releases/ge-aerospace-expanding-application-ai-blade-inspections-cfm-leap-and-ge9x-engines
- TSMC/NVIDIA, 31 May 2026 — https://nvidianews.nvidia.com/news/nvidia-and-tsmc-bring-ai-into-fabs-to-advance-semiconductor-design-and-manufacturing ; Foxconn/NVIDIA — https://www.nvidia.com/en-us/case-studies/foxconn-develops-physical-ai-enabled-smart-factories-with-digital-twins/
- Humanoids: Mercedes-Benz — https://group.mercedes-benz.com/company/production/procuction-network/mbdfc-humanoid-robots.html ; Hyundai, Axios, 5 Jan 2026 — https://www.axios.com/2026/01/05/hyundai-humanoid-robots-boston-dynamics ; union block, Tech Times, 22 May 2026 — https://www.techtimes.com/articles/317005/20260522/hyundai-commits-25000-atlas-robots-own-factories-union-blocks-deployment-without-labor-deal.htm ; Tesla Optimus, Electrek, 22 Apr 2026 — https://electrek.co/2026/04/22/tesla-optimus-production-fremont-model-sx-line/ ; dark-factory myth, Quality Magazine, 6 Mar 2026 — https://www.qualitymag.com/articles/99453-the-dark-factory-myth
- Bosch, 25 Jun 2025 — https://us.bosch-press.com/pressportal/us/en/press-release-27776.html
- Vision false positives, Automotive Manufacturing Solutions — https://www.automotivemanufacturingsolutions.com/smart-factory/ai-vision-finds-its-footing-on-the-factory-floor/2644253 ; McKinsey PdM at scale, 22 Jul 2021 — https://www.mckinsey.com/capabilities/operations/our-insights/prediction-at-scale-how-industry-can-get-more-value-out-of-maintenance
- GCC: Aramco lighthouse, 14 Jan 2025 — https://www.aramco.com/en/news-media/news/2025/fifth-aramco-facility-receives-world-economic-forum-global-lighthouse-network-status ; Pearl GTL, The Peninsula, 21 Sep 2025 — https://thepeninsulaqatar.com/article/21/09/2025/qatarenergy-and-shells-pearl-gtl-recognised-by-world-economic-forum-as-global-lighthouse-site ; EDGE, May 2026 — https://edgegroup.ae/news/edge-charts-defence-manufacturing-progress-make-it-emirates-2026 ; EDGE AI Accelerator, 19 May 2025 — https://edgegroup.ae/news/edge-launches-group-ai-accelerator-drive-excellence-ai-enhanced-solutions ; MoIAT Industry 4.0 — https://moiat.gov.ae/en/programs/uae-industry-4-backup ; MoIAT–Noventiq, Zawya, Jan 2025 — https://www.zawya.com/en/press-release/companies-news/make-it-in-the-emirates-2025-moiat-and-noventiq-partner-to-digitally-transform-20-uae-factories-with-industry-40-technologies-qxdas8iz ; Alat pivot, EnterpriseAM, 10 Apr 2026 — https://enterpriseam.com/menaplus/2026/04/10/pif-pivots-alat-from-chip-manufacturing-to-data-center-buildout/
