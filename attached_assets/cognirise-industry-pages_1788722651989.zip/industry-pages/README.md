# Cognirise Industry Pages — Content Pack

Prepared 6 September 2026. Five industry pages, a shared case-study template, and the underlying research dossiers.

## What is in the zip

```
industry-pages/
├── README.md                       ← this file
├── 01-financial-services.md        ← page copy, web-ready markdown
├── 02-telecoms.md
├── 03-travel-hospitality.md
├── 04-energy-resources.md
├── 05-manufacturing.md
├── case-study-template.md          ← shared structure for section 7 of every page
├── differentiation-map.md          ← how the five pages differ, at a glance (internal)
└── research/
    ├── BRIEF.md                    ← the research standard every dossier was held to
    ├── financial-services-dossier.md
    ├── telecoms-dossier.md
    ├── travel-hospitality-dossier.md
    ├── energy-resources-dossier.md
    └── manufacturing-dossier.md    ← full evidence base, source indexes, gaps & caveats
```

## Page structure (identical across industries)

1. **The state of the industry, from an AI perspective**
2. **The challenges of the AI era — specific to this industry**
3. **What key players are doing** (with documented reversals)
4. **Myths versus reality** (claim → evidence → verdict)
5. **The Cognirise point of view** (with service-line mapping)
6. **High-impact use cases and what the evidence says about returns**
7. **Case studies** (placeholder; template supplied)
8. **Voices** (usable quotes with name, title, date)
9. **GCC snapshot** (sidebar/tab material)
10. **Sources**

Your original brief listed four sections; sections 1 and 4 in your numbering are split here into 1–4 because "state / challenges / key players / myths" each carry enough weight to be scannable on their own. Collapse them in the CMS if you prefer.

## The sourcing standard

Every figure carries an inline link and one of five labels: **[company-reported]**, **[vendor-claimed]**, **[analyst-estimate]**, **[regulator/official]**, **[independent study]**. Where the public record is silent, the page says so instead of filling the gap. Numbers the research could *not* verify are named explicitly in each dossier's "Gaps & caveats" section — and several widely-circulated figures were deliberately excluded:

- "Shell cut downtime 20% with C3 AI" — no primary source; the 2022 release contains no ROI figure.
- "AI increases oil recovery by X%" — no credible public source; only cycle-time claims exist.
- "19% RevPAR uplift from AI revenue management" — vendor/affiliate sites only.
- "77% of AI vision projects never leave pilot" — the publication citing it calls it "widely cited, rarely examined."
- "Banks get 20–30% developer productivity from coding assistants" — no bank has published a measured figure; the only RCT points the other way.
- "BT is cutting 55,000 jobs because of AI" — contradicted by analysis of BT's own reporting.
- Quantified Siemens Industrial Copilot time savings — neither the thyssenkrupp nor Schaeffler release contains one.

## What each page flags for you (⚠ items)

Each page opens with an **Editor's note** listing its weakest figures. Before go-live, re-verify against the primary source:

| Page | Re-verify |
|---|---|
| Financial Services | EU AI Act Annex III deferral status (Digital Omnibus); self-reported hours-saved figures should stay labelled "perceived" |
| Telecoms | Vodafone Portugal 15%→60% (single market, no methodology, 2024); Orange €300m is a target not an outcome |
| Travel & Hospitality | SDAIA enforcement-decision count; Wyndham basis-point claims (most favourable in the hotel set, no independent check) |
| Energy & Resources | All E&MJ-sourced mining figures (article date not established — check against annual reports); Freeport's "$1.5–2bn saved" is avoided capex |
| Manufacturing | EGA's >$123m (consultant case study); Siemens/PepsiCo +20% (single site, no baseline); EU AI Act Annex I dates |

## Known coverage gaps (for a second research pass)

- **GCC financial services:** no regional bank publishes a quantified AI value figure; SAMA has no dedicated AI rulebook as of Sept 2026 — both are stated on the page as findings.
- **GCC telecoms:** no operator has published measured Arabic-dialect voice-AI outcomes — stated on the page as an opening.
- **Energy:** European utilities (National Grid, Enel, Iberdrola, Ørsted) and GCC entities beyond ADNOC/Aramco/DEWA (TAQA, EWEC, ACWA Power, Ma'aden, Kahramaa, Saudi Water Authority) are thin.
- **Manufacturing:** SABIC, Ma'aden, Emirates Steel Arkan, Ducab, Strata, QAFCO not covered to primary-source standard.
- **Travel:** cruise lines and Trip.com excluded for lack of primary-source outcome data.

## Cognirise voice and positioning

The POV sections are anchored in the five service lines and in the language of the Masdar and UAE federal voice decks: *value first, foundations behind value, transformation on proof*; *point solutions don't compound*; sovereign-capable; Arabic-first, bilingual by design; people-first; the Innovate → Demonstrate → Activate → Generate blueprint. Each page gives that principle an **industry-specific corollary** so the five POVs read as five arguments, not one argument five times — see `differentiation-map.md`.

## Suggested next steps

1. Review the five POV sections first — they are the most opinionated content and the part only you can sign off.
2. Decide whether the Editor's notes and ⚠ flags are stripped or converted into a footnoted "evidence standard" panel on the live site (a differentiator in itself, given the sector's sourcing habits).
3. Populate section 7 using `case-study-template.md`. The template's results table enforces the same baseline-and-verification discipline the industry pages use.
4. Commission the second research pass on the named gaps, especially GCC entities, before the pages are localised into Arabic.

## Verification pass

Twenty of the highest-stakes numeric claims across the five pages were re-checked against their primary sources on 6 September 2026 (BoE/FCA autonomy figures, HSBC AML, Mastercard fraud, METR developer RCT, American Smart Gating, IATA June 2026, IEA data-centre demand, LBNL interconnection queue, WEF 77%/9% split, GE Aerospace, Unilever twins, EU AI Act Annex III wording, Booking LLM referrals, Airbnb support cost, McKinsey telecom survey, SK Telecom AIDC, Virgin Media O2, ADNOC/AIQ $340m, the Shell/C3 release, and IFR robot data). **All twenty verified.** Two wordings were tightened as a result: the US interconnection queue is stated as ~2,060 GW with its components, and the IEA's 3% global-demand comparator is now cited to the accompanying news release rather than the executive summary.
