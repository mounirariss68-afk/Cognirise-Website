# Travel & Hospitality

> **Editor's notes (remove before publishing).** Evidence labels as on every page: **[company-reported]**, **[vendor-claimed]**, **[analyst-estimate]**, **[regulator/official]**, **[independent study]**. This page was written after IATA's June 2026 revision, which flipped the Middle East from the world's most profitable airline region to a projected loss — any earlier regional narrative is describing a different balance sheet. Items flagged ⚠ are the weakest figures. Deliberately excluded for lack of primary-source evidence: cruise-line AI outcomes, Trip.com TripGenie metrics, and the widely circulated "19% RevPAR uplift from AI revenue management" (vendor/affiliate sites only). Emirates, Riyadh Air and Accor have well-documented *programmes* and zero published *results*; the page says so rather than implying otherwise.

**Working page title:** Travel & Hospitality — A new front door, a two per cent margin, and the AI that has actually paid.

**Meta description (≤160 chars):** AI in airlines, hotels and travel distribution: the agentic-commerce shift, what has moved bookings (little) and costs (a lot), and the use cases with proof.

---

## 1. The state of the industry, from an AI perspective

Travel is the first consumer industry in which a general-purpose AI interface sits directly between the customer and the supplier — and it is one of the thinnest-margin industries on earth. That combination is what makes its AI story unlike banking or telecoms: the distribution layer is under attack at the same moment the operating margin is too small to absorb a failed transformation.

### The margin backdrop got worse in 2026

In December 2025 IATA forecast 2026 airline net profit of **$41bn on a 3.9% margin — $7.90 per passenger**. Director General Willie Walsh: *"Apple will earn more selling an iPhone cover than the $7.90 airlines will make"* ([IATA, Dec 2025](https://www.iata.org/en/pressroom/2025-releases/2025-12-09-01/) — regulator/official). Six months later IATA **halved** it: **$23bn, a 2.0% margin, $4.50 per passenger**, on regional conflict and jet fuel averaging ~$152 a barrel against $90 in 2025 ([IATA, Jun 2026](https://www.iata.org/en/pressroom/2026-releases/06-07-middle-east-disruptions-high-fuel-prices-halve-airline-industry-profitability/)). The Middle East flipped from a forecast **$6.8bn profit at 9.3% — the world's best** — to a **projected $4.3bn loss**.

The practical consequence: an AI programme costing 1% of revenue must return more than half the industry's entire net margin to be worth doing. Airline AI is judged against 2%, not 20%.

### Adoption is broad and shallow

Phocuswright's February 2026 survey of senior travel executives found **60%+ experimenting with or scaling agentic AI — but only 6% actively scaling** ([Phocuswright, Feb 2026](https://www.phocuswright.com/Travel-Research/Research-Updates/2026/61-of-travel-business-surveyed-experimenting-with-or-scaling-agentic-ai) — independent study). Skift's *State of Travel 2026*: **33% experimenting, 2% scaled**; only **6% of hotels appear in AI-generated search results** ([Skift via Open Jaw, Aug 2026](https://openjaw.com/newsroom/retail/2026/08/13/2026-state-of-travel-lack-of-ai-adoption-becoming-revenue-risk/)).

### Where value has shown up in financials: service cost, not revenue

- **Airbnb:** support cost per booking **down ~16% year on year**, with **~45% of customer issues resolved without human intervention** (Q2 2026); one-third of US/Canada support handled by AI as of February 2026 ([Skift, Aug 2026](https://skift.com/2026/08/18/travel-has-started-weighing-ais-worth/); [TechCrunch, Feb 2026](https://techcrunch.com/2026/02/13/airbnb-says-a-third-of-its-customer-support-is-now-handled-by-ai-in-the-u-s-and-canada/) — company-reported).
- **Booking Holdings:** customer-service cost per booking **declining at a double-digit rate**; absolute service costs fell in FY2025 despite 12% gross-bookings growth ([PhocusWire, Feb and Aug 2026](https://www.phocuswire.com/news/finance/booking-holdings-q2-2026-earnings) — company-reported).
- **Expedia Group:** more than **30% of 250m+ annual service interactions AI-powered**; Q1 2026 adjusted EBITDA up 83% to $542m, though management does not attribute it solely to AI ([PhocusWire, Apr 2026](https://www.phocuswire.com/news/finance/expedia-group-q1-2026-financial-earnings) — company-reported).
- **Air India:** the AI.g virtual agent handles **40,000 queries a day with 97% resolved without escalation**, 13m+ conversations, live within six months ([Microsoft customer story, Feb 2026](https://www.microsoft.com/en/customers/story/26047-air-india-azure-openai-in-foundry-models) — company-reported via vendor).

### Distribution: the disruption is real, but it has not moved bookings

**LLM referrals remain under 1% of Booking Holdings' room nights**, paid and unpaid combined. CFO Ewout Steenbergen, August 2026: *"That hasn't moved so much recently, so no material change over the last few months or quarters"* ([PhocusWire, Aug 2026](https://www.phocuswire.com/news/finance/booking-holdings-q2-2026-earnings) — company-reported). This is the single most important counter-fact to the "LLMs will eat the OTAs" thesis.

But the *search* layer is eroding. CEO Glenn Fogel: *"some of the changes that were made in the display at Google definitely put some pressure on SEO"* ([Skift, Aug 2026](https://skift.com/2026/08/04/booking-holdings-saw-pressure-from-googles-ai-overviews/)). Expedia calls answer engines its "fastest-growing channel." Wyndham reports **ChatGPT-app referrals converting 20% higher** than other web traffic ([Hotel Technology News, Jul 2026](https://hoteltechnologynews.com/2026/07/wyndham-scales-ai-guest-engagement-across-more-than-5000-hotel-properties/) — company-reported). On 27 August 2026 Google launched in-chat hotel booking inside AI Mode with Booking.com, Expedia, Hilton, IHG, Marriott, Wyndham and others as launch partners — and **withholds chat context and inspiration signals from them** ([Skift, Aug 2026](https://skift.com/2026/08/27/googles-agentic-hotel-booking-tool-comes-to-ai-mode/)).

### Trust is the gate, not capability

Expedia's own survey: **only 8% of travellers are comfortable with AI handling bookings** ([Skift, Apr 2026](https://skift.com/2026/04/14/expedia-ai-survey-travel-discovery-booking-8-percent/)). Wunderkind: **54% distrust AI-generated travel recommendations**; 50% are comfortable using AI to *compare* ([Skift, Jul 2026](https://skift.com/2026/07/23/travel-ai-trust-report/) — independent study). Skift finds AI trip-planning usage up **124% year on year**, with business travellers using it at twice the leisure rate. Discovery has shifted "from search-scroll-compare to ask-shortlist-decide"; booking has not followed.

### Workforce and data

**65% of US hotels report staffing shortages**, concentrated in housekeeping (38%) and front desk (26%); hotel employment remains ~10% below pre-pandemic ([AHLA/Hireology, survey Dec 2024–Jan 2025](https://www.ahla.com/news/65-surveyed-hotels-report-staffing-shortages) — independent study). The labour gap is in physical roles AI cannot fill. The data estate is fragmented by design — PMS, CRS, CRM, GDS, RMS and loyalty are separate systems, frequently per-property and franchise-owned. Expedia CPO Shilpa Ranganathan on why its chatbot failed: *"You can't put a tower on a foundation of sand"* ([Hospitality.today, 2026](https://www.hospitality.today/article/expedia-learned-where-ai-breaks-it-wasnt-the-model)). Marriott has earmarked up to 40% of its $1.0–1.1bn 2026 capex for digital transformation; CIO Naveen Manga calls 2026 *"a year for scale"* ([Hotel Dive, 2026](https://www.hoteldive.com/news/marriott-cio-talks-enterprisewide-ai-deployment-strategy/820467/)).

---

## 2. The challenges of the AI era — specific to travel & hospitality

**A 2% net margin cannot fund a speculative AI programme.** Airline AI spend competes directly with fuel hedging and fleet, which is why it clusters in provable-savings domains — gating, turnaround, crew, fuel — rather than experience. Hotels are different: brand-level franchisors fund technology centrally and recover it through fees. Wyndham has spent **$450m+ on technology since 2018**.

**The customer interface is being disintermediated by parties who own no inventory.** Google's AI Mode booking gives partners the transaction and keeps the intent. The strategic problem is the data asymmetry, not the commission.

**Personalised pricing became a legal-risk category before it became a revenue lever.** New York's Algorithmic Pricing Disclosure Act (effective 10 Nov 2025) requires the literal on-screen text *"THIS PRICE WAS SET BY AN ALGORITHM USING YOUR PERSONAL DATA,"* at $1,000 per violation; California's AB 325 took effect 1 January 2026 ([Skadden, Jan 2026](https://www.skadden.com/insights/publications/2026/01/new-york-algorithmic-pricing-law) — regulator/official). The FTC's 6(b) surveillance-pricing study named airline and hospitality pricing vendor PROS among the intermediaries studied ([FTC, Jan 2025](https://www.ftc.gov/news-events/news/press-releases/2025/01/ftc-surveillance-pricing-study-indicates-wide-range-personal-data-used-set-individualized-consumer)).

**Real-time inventory grounding is harder in travel than in retail.** Prices, availability and fare rules change by the second under fare filings, NDC offers and channel-specific contracts. Sabre describes its MCP Server as *"a secure intelligent translation layer"* for reissues, exchanges and itinerary changes — the hard part is servicing, not shopping ([Sabre Q2 2026 call](https://www.fool.com/earnings/call-transcripts/2026/08/13/sabre-sabr-q2-2026-earnings-call-transcript/)).

**Legacy distribution standards are an unfinished prerequisite.** Agentic booking needs machine-readable, dynamically priced offers and orders. IATA's public NDC fact sheet still contains **no adoption percentage or target**. Travelport's API-driven share of volume moved from 43% (2022) to 63% (2026) — a decade-scale migration ([Travel Distribution News, Jul 2026](https://traveldistributionnews.com/three-gds-three-bets-amadeus-sabre-and-travelport-are-fighting-over-who-owns-the-ai-era-booking/)).

**Guest data is high-sensitivity and increasingly sovereign.** Passport, biometric, dietary and location data are exactly the regulated categories. Saudi Arabia's PDPL has been fully enforceable since 14 September 2024 with **48 SDAIA enforcement decisions by mid-January 2026**, fines up to SAR 5m (doubled for repeat violations) and a **five-day window to respond** to an alleged violation ([Clyde & Co, Mar 2026](https://www.clydeco.com/en/insights/2026/03/enforcement-of-the-saudi-pdp-law) — regulator/official). ⚠ Verify the exact enforcement count against SDAIA before publishing.

**The EU AI Act timetable moved — a planning hazard, not a reprieve.** The Digital Omnibus provisional agreement (6 May 2026) pushed standalone high-risk obligations to 2 December 2027; transparency obligations still land 2 August 2026. Biometric identification at airport e-gates, crew and housekeeping scheduling, and essential-service access sit in or near Annex III. Deferral means budgets slip and readiness decays.

**Franchise and asset-light structures fragment the deployment unit.** Wyndham's AI Concierge is live at ~1,500 of ~8,400 hotels. Every rollout is a franchisee adoption campaign with its own ROI proof burden per owner.

---

## 3. What key players are doing

**Distribution and OTAs**

| Organisation | Deployment | Reported status | Evidence |
|---|---|---|---|
| **Booking Holdings** | Natural-language search globally; Priceline's Penny conversational booking; OpenTable AI concierge; agentic complaint and cancellation flows | CS cost per booking falling double-digit; transformation programme on track for $500–550m savings; **LLM referrals <1% of room nights** | [company-reported](https://www.fool.com/earnings/call-transcripts/2026/04/28/booking-bkng-q1-2026-earnings-transcript/), Apr–Aug 2026 |
| **Expedia Group** | Trip Matching on Instagram; Copilot Actions launch partner; ChatGPT app (Oct 2025) and ads (Feb 2026) | >30% of 250m+ interactions AI-powered; **+60% traveller-intent data** from natural-language tools; answer engines "fastest-growing channel" | [company-reported](https://www.phocuswire.com/news/finance/expedia-group-q1-2026-financial-earnings), 2026 |
| **Sabre** | Agentic APIs and MCP Server | Pilot/production partners **30 → 60 in Q2 2026**; autonomous reissues and exchanges in production with a global loyalty/travel-services company; consumer agentic volumes "small" | [company-reported](https://www.fool.com/earnings/call-transcripts/2026/08/13/sabre-sabr-q2-2026-earnings-call-transcript/), Aug 2026 |
| **Amadeus / Travelport** | Amadeus acquired SkyLink (conversational booking via Slack/Teams); Travelport TripServices on Anthropic's MCP with 400+ European agencies | AI ROI not separately disclosed | [Travel Distribution News](https://traveldistributionnews.com/three-gds-three-bets-amadeus-sabre-and-travelport-are-fighting-over-who-owns-the-ai-era-booking/), Jul 2026 |
| **Google** | Agentic hotel booking in AI Mode (US, 27 Aug 2026) | Ten launch partners; Google Pay; chat context withheld from suppliers | [Skift](https://skift.com/2026/08/27/googles-agentic-hotel-booking-tool-comes-to-ai-mode/), Aug 2026 |

**Airlines**

| Organisation | Deployment | Reported status | Evidence |
|---|---|---|---|
| **American Airlines** | Smart Gating (ML gate assignment) at DFW, CLT, MIA, DCA, ORD | **20% taxi-time reduction at DFW** (~2 min/flight); 17 hours saved daily across hubs; **1.4m gallons of fuel and 13,000+ tonnes CO₂ a year**; >50% fewer gate conflicts at DFW | [company-reported](https://news.aa.com/news/news-details/2023/Straight-to-the-gate-this-holiday-season-OPS-OTH-11/default.aspx), Nov 2023 |
| **Air India** | AI.g generative virtual agent | 40,000 queries/day, **97% resolution**, ~50% of customers choose AI first | [company-reported via Microsoft](https://www.microsoft.com/en/customers/story/26047-air-india-azure-openai-in-foundry-models), Feb 2026 |
| **Delta** | AI-assisted fare setting with Fetcherr | 1% → **3% of domestic network** (Q2 2025), 20% year-end target; coverage in Aug 2026 still cites 3% | [PhocusWire](https://www.phocuswire.com/delta-fetcherr-ai-pricing-deployment), Jul 2025 |
| **Qatar Airways** | Sama AI digital-human crew (Arabic version announced); group-wide "AI Skyways" with Accenture | Programme scope published; contract value and outcomes not disclosed | company-reported, Feb / Aug 2025 |
| **Emirates Group** | ChatGPT Enterprise, AI Centre of Excellence, champion network | Capability-building; **no outcome metrics published** as of Sept 2026 | company-reported, Nov 2025 |
| **Riyadh Air** | "World's first AI-native airline" with IBM watsonx Orchestrate — 59 workstreams, 60+ partners | Three-year programme; commercial service from early 2026; **no results yet** | company-reported, Dec 2025 |
| **Lufthansa / Fraport; Korean Air** | "Seer" turnaround computer vision at FRA; ChromeOS plus gen-AI agent support | Delay reduction claimed, unquantified; Korean Air 5–7 minutes saved per agent at boot-up | [OAG](https://www.oag.com/blog/three-smart-ways-airlines-are-using-ai-to-improve-operations-in-august-2025), Aug 2025 — vendor-claimed |

**Hotels**

| Organisation | Deployment | Reported status | Evidence |
|---|---|---|---|
| **Wyndham** | Wyndham Connect (5,000+ hotels, ~260,000 daily guest interactions); AI Concierge (~1,500 properties) with Canary | Direct voice conversion **+~200bps**; guest satisfaction **+400bps**; AI Concierge reservations **15% higher ADR** than phone; ChatGPT referrals convert 20% higher ⚠ most favourable numbers in the hotel set, no independent verification | [company-reported](https://hoteltechnologynews.com/2026/07/wyndham-scales-ai-guest-engagement-across-more-than-5000-hotel-properties/), Jul 2026 |
| **Hilton** | Hilton AI Planner (Anthropic-powered), beta 10 Mar → full availability 17 Mar 2026 across 9,400+ properties; multi-LLM (Google, OpenAI, Anthropic) | CEO Chris Nassetta: *"AI allows us to be more efficient and more effective. That is code for continuing to build more direct lines to our customers"* | [Hilton](https://stories.hilton.com/releases/hilton-introduces-the-hilton-ai-planner); [PhocusWire](https://www.phocuswire.com/news/distribution/hilton-ai-developments-q1-2026-earnings), Mar–Apr 2026 |
| **Marriott** | Natural-language search phased from Q2 2026; "protocol- and model-agnostic AI chassis"; Google AI Mode partnership; new PMS and reservation systems | 2025 pilot year → 2026 scale; Bonvoy 271m members | [PhocusWire](https://www.phocuswire.com/marriott-q4-full-year-earnings-2025), Feb 2026 |
| **Hyatt** | AI tools for group sales | Group sales teams **~20% more productive** | [J.P. Morgan via Skift](https://skift.com/2026/03/05/hotel-ai-investments-set-to-deliver-earnings-payoff-this-year-j-p-morgan-says/), Mar 2026 — analyst-estimate |
| **Accor** | AI to optimise staffing and shift employees into guest-facing roles | Stated at Skift Global Forum East, Abu Dhabi; no programme detail | company statement, Oct 2025 |

### The reversals worth knowing

**OpenAI walked back in-ChatGPT travel checkout (March 2026).** OpenAI scrapped plans to complete bookings inside ChatGPT, moving Instant Checkout to third-party apps and *"prioritizing making ChatGPT search and product discovery great"* ([Skift, Mar 2026](https://skift.com/2026/03/05/openai-chatgpt-checkout-walkback/)). Technical, behavioural and regulatory barriers stopped conversational AI from handling complex travel transactions.

**Expedia retired Romie**, its flagship 2024 assistant. The published post-mortem is unusually candid: responses were disconnected from live inventory, rates and reservations, and customers abandoned chats over inaccuracy. The repair took roughly a year and involved *"almost no work on the model itself"* — it was evaluation frameworks and data grounding. Ranganathan: AI is *"an organizational problem before a technological one."*

**Delta's AI pricing rollout stalled under political pressure.** After disclosing 3% of the domestic network on Fetcherr pricing with a 20% year-end target, Delta received a letter from Senators Gallego, Blumenthal and Warner and issued a formal statement: *"There is no fare product Delta has ever used, is testing or plans to use that targets customers with individualized prices based on personal data"* ([Skift, Aug 2025](https://skift.com/2025/08/01/delta-says-it-will-not-use-ai-to-target-customers/)). No public confirmation that the 20% target was reached.

---

## 4. Myths versus reality

| The claim | What the evidence shows | Verdict |
|---|---|---|
| "LLM trip planners will replace OTAs." | LLM referrals <1% of Booking room nights, unchanged for quarters; 8% comfortable letting AI book; 54% distrust AI recommendations; OpenAI abandoned in-chat checkout. Against: usage up 124%; Google shipped agentic booking with ten partners; Wyndham sees 20% better conversion from ChatGPT referrals. | **Contradicted as stated; proven in pockets** as a top-of-funnel shift. The real threat today is to search economics and intent data, not booking share. |
| "Personalised pricing is AI's big win in travel." | Delta at 3% drew a Senate inquiry and a formal denial; New York mandates on-screen disclosure; the FTC studied the practice. Verified gains are in *aggregate* demand forecasting and offer optimisation. | **Unproven as an individualised play, and now hazardous; proven in pockets** as aggregate dynamic pricing. |
| "AI concierges replace the front desk." | Wyndham's AI Concierge lifts ADR and satisfaction — augmentation of booking and messaging, not desk replacement. Shortages are in housekeeping and front desk, i.e. physical presence. Rotana's UAE deployment removes paperwork so staff can *"welcome them and issue room key cards without requiring passport presentation."* | **Contradicted as replacement; proven in pockets** as pre-arrival and administrative removal. |
| "Chatbots handle most guest and traveller queries." | Air India 97% of 40,000 daily queries; Airbnb ~45% of issues; Expedia >30% of interactions. True in airline and OTA post-booking service where intents are narrow; untrue in independent hotel operations. Air India's 97% is resolution of queries the AI *received*, not of all contact. | **Proven at scale in airline/OTA post-booking service; unproven in hotel operations.** |
| "AI disruption management saves airlines millions." | The best-documented case is not generative: American's Smart Gating (fuel, taxi time, gate conflicts). Vendor claims of "up to 30% disruption-cost reduction" could not be corroborated against any airline disclosure. | **Proven at scale in operational optimisation; unproven as a headline IROPS claim.** |
| "AI pays for itself in hotel revenue management." | IDeaS and Duetto are widely deployed — IDeaS won Red Sea Global Hospitality portfolio-wide (Oct 2025) — but releases state capabilities, not outcomes. The circulated "19% RevPAR" figure appears only on vendor and affiliate sites. | **Proven in pockets;** public ROI evidence is much weaker than adoption. |
| "Agentic AI is already scaled in travel." | Phocuswright 6% scaling; Skift 2% scaled; Sabre calls consumer volumes "small" and has pushed the timeline to medium-to-long term. | **Contradicted.** |
| "Better models are the bottleneck." | Expedia's year of remediation with "almost no work on the model itself"; Phocuswright Europe case studies name data dependency, API bottlenecks and trust as the barriers. | **Contradicted** — the bottleneck is grounding, evaluation and integration. |
| "Loyalty data gives incumbents an unassailable AI moat." | Airbnb's 200m verified identities and 500m reviews; Marriott 271m Bonvoy members; Hilton 260m Honors. But Google's booking design withholds intent signals from those same partners. Fogel: *"there is no such thing as a moat."* | **Unproven** — first-party data is necessary and is being offset by loss of intent data at the new front door. |

---

## 5. The Cognirise point of view

**In travel, the AI that has paid is operational and grounded; the AI that is being marketed is conversational and ungrounded. The winners will own the servicing layer, be legible to the agents that own discovery, and keep the intent data that Google is trying to take.**

Every documented financial return on this page comes from one of two places: taking cost out of service (Airbnb −16% per booking, Booking's double-digit decline, Air India's 97%) or taking waste out of operations (American's 1.4m gallons of fuel a year). Not one comes from an AI trip planner. Meanwhile the most-publicised deployments — Romie, in-ChatGPT checkout, individualised pricing — were reversed or stalled. The lesson is not that generative AI does not belong in travel. It is that in a 2%-margin industry, the order of operations is everything.

Five convictions follow.

**Grounding is the product.** Expedia spent a year fixing its assistant and touched the model almost not at all. A travel agent that cannot read live inventory, the actual fare rules, the real reservation and the current disruption is a liability, not a feature. We build the retrieval, evaluation and reconciliation layer over PMS, CRS, PNR and loyalty systems first — "the foundation, not the tower" — and the conversational layer last.

**Own the servicing, not just the shopping.** Booking share has barely moved; the servicing volume has. Sabre's agentic APIs are being used for reissues, exchanges and itinerary changes because that is where the complexity, the cost and the customer's loyalty actually sit. An airline or hotel group that lets an agent authenticate, read the live case and *execute* — rebook, refund, re-accommodate — under human oversight captures cost that is real now and defends a relationship that Google's front door cannot reach.

**Be legible to the agents, and negotiate for the intent data.** Six per cent of hotels appear in AI-generated results. Being present in Google AI Mode, the ChatGPT app and the emerging MCP ecosystem is table stakes for 2026–27. But the strategic negotiation is about what comes back. Suppliers that accept the transaction while ceding the chat context are trading their future first-party data for today's booking. Build the direct-channel conversational experience — Hilton's AI Planner, Wyndham's Connect — so that the richest intent signal stays in the brand's own systems.

**Treat pricing AI as a disclosure problem before it is a revenue problem.** The aggregate, demand-based revenue management the industry has run for decades is defensible and effective. Individualised willingness-to-pay pricing on personal data drew a Senate letter, a New York disclosure law and an FTC study before it produced a disclosed dollar of revenue. In the Gulf, where guest data is passport-linked and PDPL enforcement gives five days to respond, the line must be drawn in the architecture, not in the press statement.

**In the GCC, the strongest AI results are at the border, and the biggest bets are greenfield.** Dubai's biometric corridor clears passengers in 6–14 seconds; Abu Dhabi's Smart Travel cut service time from 25 to 7 seconds — because a national identity database is directly accessible to the airport operator, a capability EU operators legally cannot copy. Riyadh Air is attempting an AI-native airline with no legacy PMS or CRS to ground against. Red Sea Global has committed SAR 1.2bn with stc to destination-scale digital infrastructure including digital twins. The regional opportunity is to connect these — sovereign identity, greenfield operations, in-country data — into journeys that no legacy carrier or global OTA can offer, and to do it on WhatsApp, which is the channel the region actually uses (as Rotana's 15-hotel pre-arrival deployment correctly assumes).

### How this maps to Cognirise's service lines

| Service line | In travel & hospitality this means |
|---|---|
| **Agentic Enterprise Transformation** | Post-booking servicing — changes, refunds, disruption re-accommodation, guest requests — redesigned as agent-executed, human-supervised workflows with cost per contact and resolution rate as the measured outcomes. |
| **Data & AI Foundations** | The grounding layer: a governed, evaluated retrieval and reconciliation fabric across PMS, CRS, PNR, RMS and loyalty, plus the guest-data residency and consent model that PDPL and the EU AI Act require. |
| **Engineering with AI** | NDC / Offers-and-Orders readiness and MCP-style agentic API surfaces, built with AI-assisted engineering so the decade-scale distribution migration compresses to quarters. |
| **Sovereign Agentic AI** | Identity-linked journeys for airports, tourism authorities and destination developers — biometric flow, Arabic-first tour guidance, in-country hosting — in the pattern of DXB, Zayed International and Saudi Tourism Authority's Sara. |
| **AI-Native Platforms** | A direct-channel conversational planner and guest-messaging platform on WhatsApp, app and web that keeps the intent data in the brand's hands and reports what it resolves. |

Our operating principle — *value first, foundations behind value, transformation on proof* — has a travel-specific corollary: **fund the AI with the operational savings first, and let the front door earn its budget.**

---

## 6. High-impact use cases and what the evidence says about returns

| # | Use case | Type | Who has done it | Documented outcome | What to expect and measure | Prerequisites |
|---|---|---|---|---|---|---|
| 1 | **ML gate assignment and taxi optimisation** | Analytical | American Airlines (DFW, CLT, MIA, DCA, ORD) | **20% taxi-time cut at DFW; 17 hrs/day across hubs; 1.4m gal fuel + 13,000 t CO₂/yr; >50% fewer gate conflicts** [company-reported, Nov 2023] | Taxi minutes per flight; fuel burn; gate conflicts. The most precisely quantified airline AI result in the public record — and pre-generative. | Real-time ops feed; gate topology; ground-crew integration |
| 2 | **Gen-AI post-booking service (airline)** | Generative | Air India AI.g | **40,000 queries/day; 97% resolved without escalation; 13m+ conversations** [company-reported via vendor, Feb 2026] | Resolution rate *and* share of total contact volume; escalation quality | Grounded PNR and policy retrieval; multilingual; escalation design |
| 3 | **AI support agent (marketplace)** | Agentic | Airbnb | **Support cost per booking −16% YoY; ~45% of issues resolved without a human** [company-reported, Aug 2026] | Cost per booking; resolution without human; CSAT on AI-handled cases | Identity, reviews and host-messaging corpus; ticket taxonomy |
| 4 | **Contact-centre cost per transaction (OTA)** | Generative + agentic | Booking Holdings / Agoda | **Double-digit decline in CS cost per booking; absolute CS cost down in FY2025 despite +12% bookings** [company-reported] | Cost per booking; agentic completion rate for cancellations and complaints. ~2 years to this result. | Agentic flows; partner policy data |
| 5 | **Natural-language search and smart filters** | Generative | Booking.com; Hilton AI Planner; Marriott; IHG; Wyndham | Expedia **+60% traveller-intent data**; Wyndham AI Concierge bookings **+15% ADR** vs phone [company-reported] | Conversion; intent-data capture; cancellation rate. Hilton beta→GA in 7 days; Marriott 12+ months pilot→scale. | Structured property and amenity content; live rates; evaluation harness |
| 6 | **Answer-engine and agentic distribution presence** | Agentic | Expedia; Wyndham; Google AI Mode launch partners | Wyndham ChatGPT referrals **convert 20% higher** [company-reported]; Booking LLM referrals **<1%** of room nights | Referral share and conversion by AI channel; intent data received vs withheld | MCP/agentic API surface; AI-legible content; payment rails |
| 7 | **Agentic servicing over GDS (reissues, exchanges)** | Agentic | Sabre MCP Server | Partners **30 → 60 in one quarter**; in production with a global loyalty/travel-services company; consumer volumes "small" [company-reported, Aug 2026] | Servicing transactions completed autonomously; agent error rate | NDC / Offers-and-Orders readiness; agent identity and auth |
| 8 | **Biometric and AI border and airport flow** | Analytical | Dubai "red carpet" corridor (DXB); Zayed International with ICP and Etihad; Changi | DXB **6–14 seconds per traveller, up to 10 simultaneously** [regulator/official]; AUH **25s → 7s** [company-reported]; Changi 10s | Seconds per traveller; queue length; no-registration coverage | National identity database access; EU Annex III caution outside GCC |
| 9 | **AI-assisted fare and offer pricing (aggregate)** | Analytical | Delta with Fetcherr; Virgin Atlantic, Royal Air Maroc, Viva Aerobus | 3% of Delta's domestic network; CEO claim that AI could lift profitability up to 50% is **projected, not documented** | Revenue per ASK from aggregated demand models; **disclosure compliance** as a gating metric | Aggregated demand data; no personal-data targeting; NY/CA disclosure |
| 10 | **Pre-arrival digital check-in with identity verification** | Agentic | Rotana with H2O Hospitality (15 Abu Dhabi hotels, 4,240 rooms) | Passport and facial image via WhatsApp 1–2 days pre-arrival; paperwork and queueing removed; **no metric published** [vendor-claimed, Aug 2026] | Check-in minutes; front-desk hours redeployed; registration compliance | Immigration registration compliance; WhatsApp channel; PDPL basis |
| 11 | **Turnaround and ground-ops computer vision** | Analytical | Lufthansa and Fraport "Seer" at FRA | Real-time bottleneck detection across baggage, catering and refuelling; delay reduction **claimed, unquantified** [vendor-claimed, Aug 2025] | Turnaround minutes; on-time departure | Apron camera estate; works-council and privacy clearance |
| 12 | **Hotel revenue management (RMS)** | Analytical | IDeaS at Red Sea Global Hospitality (Shebara, Desert Rock, Turtle Bay) | Capabilities stated; **no outcome metric published** [vendor-claimed, Oct 2025] | RevPAR and GOPPAR against a controlled baseline — insist on it | Clean rate and inventory history |
| 13 | **AI-assisted group sales (hotels)** | Generative | Hyatt | **~20% more productive** group sales teams [analyst-estimate, J.P. Morgan, Mar 2026] | RFP turnaround; win rate | CRM hygiene; RFP corpus |
| 14 | **Fuel optimisation at fleet scale** | Analytical | Industry-wide via SITA | 2.9m flights processed in 2025; **127,732 tonnes of fuel saved** [vendor-claimed] | Fuel per block hour | Flight-data and flight-plan integration |

**A note on returns.** Rows 1–5 and 8 have company- or regulator-reported outcome numbers. Rows 6–7 are early and directionally positive. Rows 9–14 are projected, analyst-estimated or vendor-claimed and should be presented as such. In a 2%-margin industry, that ordering is the business case.

---

## 7. Case studies

*Structure to follow the shared case-study template (see `case-study-template.md`). Cognirise case studies for this industry to be added.*

---

## 8. Voices

> "Airlines are bearing the brunt of the fuel price shock… Net profit per passenger is expected to fall to $4.50, half of what it was last year." — **Willie Walsh**, Director General, IATA, June 2026

> "That hasn't moved so much recently, so no material change over the last few months or quarters." — **Ewout Steenbergen**, CFO, Booking Holdings, on LLM referrals below 1% of room nights, August 2026

> "You can't put a tower on a foundation of sand." — **Shilpa Ranganathan**, Chief Product Officer, Expedia Group, on why its AI assistant failed, 2026

> "AI allows us to be more efficient and more effective. That is code for continuing to build more direct lines to our customers." — **Chris Nassetta**, CEO, Hilton, April 2026

> "There is no fare product Delta has ever used, is testing or plans to use that targets customers with individualized prices based on personal data." — **Delta Air Lines**, responding to Senate scrutiny, August 2025

> "What our data is telling us is that travelers probably won't enjoy that [AI booking] experience." — **Clayton Nelson**, VP of AI Alliances, Expedia Group, April 2026

> "Agentic AI is no longer just a future opportunity. It is transforming how travel is bought and serviced." — **Kurt Ekert**, CEO, Sabre, August 2026 — on the same call where management called consumer agentic volumes "small"

---

## GCC snapshot (for a sidebar or regional tab)

- **The economics inverted in 2026.** IATA moved the Middle East from a forecast $6.8bn profit at 9.3% (Dec 2025) to a projected **$4.3bn loss at −6.1%** (Jun 2026).
- **Borders are the region's strongest documented AI result.** DXB's passport-free corridor: **6–14 seconds**, up to 10 travellers at once, being extended to arrivals and departures (GDRFA, Sep 2025). Zayed International's Smart Travel with ICP and Etihad: **25s → 7s**, no prior registration. These work because the operator has direct access to the national identity database.
- **Airlines:** Emirates Group + OpenAI enterprise deployment and AI Centre of Excellence (Nov 2025); Qatar Airways' Arabic-speaking Sama and "AI Skyways" with Accenture (Aug 2025); Riyadh Air + IBM "AI-native airline" (Dec 2025) — all programmes, no published outcomes yet.
- **Destinations:** Saudi Tourism Authority's **Sara** AI tour guide (LEAP, Feb 2025); **Red Sea Global's SAR 1.2bn** stc investment in AI services, digital twins and in-country data centres (Sep 2025) plus IDeaS RMS portfolio-wide (Oct 2025); Visit Qatar / MCIT "SMEs Go Digital" AI workshops for hotels — state-led diffusion to the long tail.
- **Hotels:** Rotana + H2O Hospitality identity-verified WhatsApp pre-arrival check-in across 15 Abu Dhabi properties, 4,240 rooms (Aug 2026).
- **Regulation:** KSA PDPL fully enforceable since Sep 2024 under SDAIA — which is also the national AI authority; UAE PDPL alongside GDRFA/ICP authority for biometrics; sovereign hosting becoming a procurement default.
- **Language:** Qatar Airways' Arabic Sama and STA's multilingual Sara are the named examples. Gulf-dialect guest messaging and Arabic review corpora for RMS and reputation AI remain under-served.

---

## Sources

Primary sources used on this page (full 60-item index in `research/travel-hospitality-dossier.md`):

- IATA, 9 Dec 2025 — https://www.iata.org/en/pressroom/2025-releases/2025-12-09-01/ ; IATA, 7 Jun 2026 — https://www.iata.org/en/pressroom/2026-releases/06-07-middle-east-disruptions-high-fuel-prices-halve-airline-industry-profitability/
- Phocuswright, Feb 2026 — https://www.phocuswright.com/Travel-Research/Research-Updates/2026/61-of-travel-business-surveyed-experimenting-with-or-scaling-agentic-ai ; Skift State of Travel 2026 via Open Jaw, 13 Aug 2026 — https://openjaw.com/newsroom/retail/2026/08/13/2026-state-of-travel-lack-of-ai-adoption-becoming-revenue-risk/ ; Phocuswright Europe case studies, PhocusWire 2026 — https://www.phocuswire.com/news/technology/phocuswright-europe-2026-ai-travel-case-studies
- Booking Holdings: PhocusWire Q2 2026, 4 Aug 2026 — https://www.phocuswire.com/news/finance/booking-holdings-q2-2026-earnings ; Skift, 4 Aug 2026 — https://skift.com/2026/08/04/booking-holdings-saw-pressure-from-googles-ai-overviews/ ; Q1 2026 transcript — https://www.fool.com/earnings/call-transcripts/2026/04/28/booking-bkng-q1-2026-earnings-transcript/ ; FY2025, PhocusWire 18 Feb 2026 — https://www.phocuswire.com/booking-holdings-q4-full-year-2025-earnings
- Expedia: PhocusWire Q1 2026 — https://www.phocuswire.com/news/finance/expedia-group-q1-2026-financial-earnings ; Romie post-mortem, Hospitality.today — https://www.hospitality.today/article/expedia-learned-where-ai-breaks-it-wasnt-the-model ; 8% survey, Skift 14 Apr 2026 — https://skift.com/2026/04/14/expedia-ai-survey-travel-discovery-booking-8-percent/
- Airbnb: TechCrunch, 13 Feb 2026 — https://techcrunch.com/2026/02/13/airbnb-says-a-third-of-its-customer-support-is-now-handled-by-ai-in-the-u-s-and-canada/ ; Skift, 18 Aug 2026 — https://skift.com/2026/08/18/travel-has-started-weighing-ais-worth/
- Sabre Q2 2026 transcript, 13 Aug 2026 — https://www.fool.com/earnings/call-transcripts/2026/08/13/sabre-sabr-q2-2026-earnings-call-transcript/ ; GDS AI positioning, Travel Distribution News, 17 Jul 2026 — https://traveldistributionnews.com/three-gds-three-bets-amadeus-sabre-and-travelport-are-fighting-over-who-owns-the-ai-era-booking/
- Google AI Mode booking, Skift, 27 Aug 2026 — https://skift.com/2026/08/27/googles-agentic-hotel-booking-tool-comes-to-ai-mode/ ; OpenAI checkout walkback, Skift, 5 Mar 2026 — https://skift.com/2026/03/05/openai-chatgpt-checkout-walkback/
- American Airlines Smart Gating, 22 Nov 2023 — https://news.aa.com/news/news-details/2023/Straight-to-the-gate-this-holiday-season-OPS-OTH-11/default.aspx ; OAG operations round-up, Aug 2025 — https://www.oag.com/blog/three-smart-ways-airlines-are-using-ai-to-improve-operations-in-august-2025
- Air India / Microsoft, 11 Feb 2026 — https://www.microsoft.com/en/customers/story/26047-air-india-azure-openai-in-foundry-models
- Delta: PhocusWire, 14 Jul 2025 — https://www.phocuswire.com/delta-fetcherr-ai-pricing-deployment ; Skift, 1 Aug 2025 — https://skift.com/2025/08/01/delta-says-it-will-not-use-ai-to-target-customers/ ; Yahoo Finance, 24 Aug 2026 — https://finance.yahoo.com/technology/ai/articles/delta-ceo-ed-bastian-says-160000381.html
- Pricing regulation: FTC, 17 Jan 2025 — https://www.ftc.gov/news-events/news/press-releases/2025/01/ftc-surveillance-pricing-study-indicates-wide-range-personal-data-used-set-individualized-consumer ; Skadden on New York law, Jan 2026 — https://www.skadden.com/insights/publications/2026/01/new-york-algorithmic-pricing-law
- Hotels: Wyndham, Hotel Technology News, 29 Jul 2026 — https://hoteltechnologynews.com/2026/07/wyndham-scales-ai-guest-engagement-across-more-than-5000-hotel-properties/ ; Hilton, 10 Mar 2026 — https://stories.hilton.com/releases/hilton-introduces-the-hilton-ai-planner ; PhocusWire on Hilton, 29 Apr 2026 — https://www.phocuswire.com/news/distribution/hilton-ai-developments-q1-2026-earnings ; Marriott, PhocusWire Feb 2026 — https://www.phocuswire.com/marriott-q4-full-year-earnings-2025 ; Hotel Dive on Marriott CIO — https://www.hoteldive.com/news/marriott-cio-talks-enterprisewide-ai-deployment-strategy/820467/ ; J.P. Morgan via Skift, 5 Mar 2026 — https://skift.com/2026/03/05/hotel-ai-investments-set-to-deliver-earnings-payoff-this-year-j-p-morgan-says/ ; Hotel Dive Q2 2026 trends — https://www.hoteldive.com/news/top-hotel-industry-trends-q2-2026/828121/
- Trust: Skift/Wunderkind, 23 Jul 2026 — https://skift.com/2026/07/23/travel-ai-trust-report/
- Workforce: AHLA/Hireology survey, 2025 — https://www.ahla.com/news/65-surveyed-hotels-report-staffing-shortages
- Regulation: KSA PDPL enforcement, Clyde & Co, Mar 2026 — https://www.clydeco.com/en/insights/2026/03/enforcement-of-the-saudi-pdp-law ; EU AI Act omnibus, Gibson Dunn, 2026 — https://www.gibsondunn.com/eu-ai-act-omnibus-agreement-postponed-high-risk-deadlines-and-other-key-changes/ ; IATA NDC fact sheet, Jun 2026 — https://www.iata.org/en/iata-repository/pressroom/fact-sheets/fact-sheet-ndc/
- GCC: DXB smart corridor, Gulf News, 2 Sep 2025 — https://gulfnews.com/business/aviation/dubai-expands-ai-powered-red-carpet-smart-corridor-at-dxb-terminal-3-1.500254531 ; Abu Dhabi Smart Travel, Gulf News, 21 Jul 2024 — https://gulfnews.com/uae/transport/abu-dhabi-airport-icp-launch-worlds-first-of-its-kind-biometric-smart-travel-1.103566116 ; Changi / SITA, Computer Weekly, 7 Jul 2026 — https://www.computerweekly.com/news/366645398/Singapore-Changi-Airports-10-second-border-points-aviations-AI-future ; Emirates Group / OpenAI, 21 Nov 2025 — https://www.emirates.com/media-centre/emirates-group-collaborates-with-openai-to-accelerate-ai-adoption-and-innovation/ ; Qatar Airways Sama, Feb 2025 — https://www.qatarairways.com/press-releases/en-WW/247237-a-first-in-aviation-qatar-airways-reinvents-travel-bookings-with-sama-at-web-summit-qatar-2025/ ; Qatar Airways / Accenture, Consultancy-me, 20 Aug 2025 — https://www.consultancy-me.com/news/11341/qatar-airways-flies-in-accenture-to-lead-group-wide-ai-transformation ; Riyadh Air / IBM, 8 Dec 2025 — https://newsroom.ibm.com/2025-12-08-riyadh-air-and-ibm-partner-to-launch-worlds-first-ai-native-airline ; Saudi Tourism Authority Sara, SPA, 12 Feb 2025 — https://www.spa.gov.sa/en/N2260133 ; Red Sea Global / stc, 29 Sep 2025 — https://redseaglobal.com/en/media-center/news/red-sea-global-secures-sar-1-2-billion-investment-from-stc-group-to-accelerate-digital-transformation-across-its-destinations/ ; IDeaS / Red Sea Global Hospitality, 16 Oct 2025 — https://ideas.com/news/ideas-and-red-sea-global-hospitality-establish-portfolio-wide-technology-agreement/ ; Rotana / H2O, Hotel Management Network, 20 Aug 2026 — https://www.hotelmanagement-network.com/news/h2o-check-in-rotana-hotels/ ; Accor, Skift, 30 Oct 2025 — https://skift.com/2025/10/30/accor-deputy-ceo-eyes-middle-east-ai-and-live-events-for-hotel-growth/ ; MCIT Qatar / Visit Qatar — https://www.mcit.gov.qa/en/news/mcit-and-visit-qatar-host-awareness-workshop-on-digital-transformation-and-ai-for-hotels-under-the-smes-go-digital-program/
