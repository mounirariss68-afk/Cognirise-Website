# Case Study Template

Use one file per case study: `case-studies/<industry>/<client-or-anonymised>-<short-slug>.md`. Every case study on the site should follow the same skeleton so readers can compare across industries, and so the sourcing standard of the industry pages carries through: **no number without a basis, no outcome without a baseline, no claim the client would not sign.**

The template is deliberately short at the top (what a buyer scans) and rigorous at the bottom (what a sceptic checks).

---

## Front matter

```yaml
title:            # ≤ 60 characters, outcome-led. e.g. "Refund cycle from four days to eight minutes"
industry:         # Financial Services | Telecoms | Travel & Hospitality | Energy & Resources | Manufacturing
client:           # Named, or "A GCC retail bank" if anonymised. State which.
geography:        # e.g. UAE; KSA; Multi-market GCC
service_lines:    # One or more of: Agentic Enterprise Transformation | Data & AI Foundations | Engineering with AI | Sovereign Agentic AI | AI-Native Platforms
ai_type:          # Analytical | Generative | Agentic | Physical — pick all that apply
engagement_window:  # e.g. Feb–Jul 2026
status:           # Pilot | In production | Scaled | Retired (be honest — a retired case study with a lesson is more credible than a glossy one)
evidence_level:   # Client-verified | Cognirise-measured | Client-estimated  (see "Evidence standard" below)
publishable:      # Yes | Anonymised only | Internal only
```

---

## 1. The headline (≤ 40 words)

One sentence a CEO would repeat. Outcome first, mechanism second. Example pattern: *"[Client] cut [metric] from [baseline] to [result] in [time] by [what was built], with [governance/human role]."*

## 2. The situation (100–150 words)

What was true before. Industry context in one sentence (link to the industry page). The specific operational pain — named process, named team, named volume. The constraint that made it hard (regulation, data, language, sovereignty, safety, labour). Why now.

## 3. What we did (150–250 words)

Written as a sequence, not a feature list. Use the Cognirise blueprint phases where they apply:

- **Innovate (1 day)** — the challenge chosen and why.
- **Demonstrate (48 hours)** — what the prototype showed, on whose real material.
- **Activate (2–4 weeks, MVP)** — what went live, to whom, under what guardrails.
- **Generate (4–12 weeks)** — how it scaled and what was operationalised.

Name the architecture at the level a CIO needs: models used (and where they ran — in-country, on-premise, cloud), what the agents were allowed to do and what remained human, what the system was grounded in, how it was evaluated. Name the client's people who led it. Name partners (e.g. Lupitor for Arabic-dialect voice) where relevant and agreed.

## 4. The results (table, mandatory)

| Metric | Baseline | Result | Period measured | How measured | Verified by |
|---|---|---|---|---|---|
| e.g. Refund cycle time | 4 days | 8 minutes | 3 months post-launch | System timestamps, 100% of cases | Client finance team |
| e.g. Containment rate | n/a (new channel) | 41% | 12 weeks | Platform analytics; human QA sample n=500 | Cognirise, reviewed by client |
| e.g. Employee weekly active use | 0 | 63% | Month 3 | Platform analytics | Client IT |

Rules:
- Every row needs a baseline. If there is no baseline, say "no baseline — new capability" and do not express the result as a percentage change.
- "How measured" must name the instrument. Self-reported survey results are allowed but must be labelled as such (the industry pages show why: perceived and measured productivity can point in opposite directions).
- "Verified by" must name a role. If only Cognirise measured it, say so.
- Financial results (cost saved, revenue added) require the client's sign-off on the figure and the attribution method. If the client will not sign the number, publish the operational metric and omit the currency figure.

## 5. What made it work (3–5 bullets)

The transferable lessons — not "great teamwork." Examples of the right register: *"The regulator's model-inventory requirement became the deployment checklist."* *"We set the false-positive budget before the first camera went up."* *"Arabic and English were built as equals from day one, which is why the disclosure passed compliance review first time."*

## 6. What we would do differently (1–3 bullets, mandatory)

Every honest engagement has these. Their presence is what makes the rest credible.

## 7. Where it goes next (≤ 80 words)

The next horizon for this client, in the client's words where possible.

## 8. Voices (optional, 1–2 quotes)

Client quote with name, title, date. Do not paraphrase a quote into existence.

## 9. Evidence standard (internal — collapse or omit on the public page)

- **Client-verified**: results table reviewed and approved in writing by a named client stakeholder.
- **Cognirise-measured**: instrumented by Cognirise on the client's systems; client informed but not formally approving.
- **Client-estimated**: figure supplied by the client without Cognirise instrumentation. Publish with "client-reported" label.

Link to the internal evidence pack (measurement scripts, dashboards, sign-off email).

---

## Cross-references

- Link the case study from the relevant industry page under **7. Case studies**, and from the relevant row(s) of that page's use-case table.
- Tag with the myths it speaks to (e.g. "Chatbots handle most queries — proven in pockets") so the site can show *our* evidence next to the *industry* evidence.
