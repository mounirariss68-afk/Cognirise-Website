# Telecoms

> **Editor's notes (remove before publishing).** Evidence labels as on every page: **[company-reported]**, **[vendor-claimed]**, **[analyst-estimate]**, **[regulator/official]**, **[independent study]**, **[press-reported]**. The single most useful contrast on this page is NVIDIA's vendor survey (90% of operators say AI raises revenue and cuts cost) against McKinsey's independently-run survey the same month (12% report sizable impact). Keep both. Items flagged ⚠ are the weakest figures. Three things we searched for and could not find from any primary source: an operator publishing a churn-rate reduction attributed to AI; any margin figure on telco GPU-as-a-service; and a GCC operator publishing measured Arabic-dialect voice-AI outcomes. The page says so.

**Working page title:** Telecoms — AI in an industry that has to fund it from cost, not growth.

**Meta description (≤160 chars):** AI in telecoms: where the documented returns are (care and compute, not radio), what autonomous networks really mean, and why GCC operators are different.

---

## 1. The state of the industry, from an AI perspective

Telecoms is the one major sector where growth is arithmetically unavailable. GSMA's *Mobile Economy 2026* puts operator revenue at **$1.19 trillion in 2025, rising to $1.36 trillion by 2030 — about 2.7% a year** — against **$1.2 trillion of capex** committed over the same period ([GSMA via Mobile World Live, Mar 2026](https://www.mobileworldlive.com/gsma/mobile-sector-gdp-contribution-tipped-to-top-11t) — industry body). Dell'Oro expects worldwide telecom capex to *decline* in 2026 ([Dell'Oro](https://www.delloro.com/news/worldwide-telecom-capex-to-decline-in-2026/) — analyst-estimate). Unlike a bank or a pharmaceutical company, an operator cannot fund AI out of revenue growth. Every telecom AI business case is an opex-substitution case, a capex-deferral case, or a bet on an entirely new business line — and it competes for budget against radio and fibre.

### Scaling is common. Impact is rare.

McKinsey surveyed **49 operators across six regions** in December 2025. **57%** are scaling AI across multiple domains and 16% call it the "new normal" — but only **12% report having captured "sizable impact."** The share describing AI as a "blockbuster technology" *fell* from 61% to 51% year on year. Average AI allocation is about 9% of IT spend ([McKinsey, Feb 2026](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/telcos-ai-inflection-point-what-leaders-do-to-capture-value) — analyst-estimate).

Set that against NVIDIA's fourth annual operator survey, published the same week: **90% of operators say AI is increasing revenue and reducing cost**, 89% plan to raise AI spend in 2026 ([NVIDIA, Feb 2026](https://blogs.nvidia.com/blog/ai-in-telco-survey-2026) — vendor-claimed survey). The gap between 90% and 12% is the most instructive number in this industry. STL Partners' read of MWC 2026: *"there was less hype on the show floor than in previous years … discussions on AI were rooted in real, tangible deployments of AI agents and lucid dialogue on their current limitations"* ([STL Partners, Mar 2026](https://stlpartners.com/research/mwc-2026-ai-realism/)).

### Autonomy has a formal ladder — and the honest rung is low

Telecoms is the only sector with a certified autonomy scale. TM Forum's March 2026 study of 125 respondents across 80 companies finds **21% operating at Level 3 or above**, up from 19% a year earlier; Accenture data in the same coverage puts **79% at Level 0/1**, with only 22% expecting Level 4 by 2030 ([Fierce Network, Mar 2026](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum) — industry body / analyst). Every Level 4 claim is domain-bounded: China Mobile in network operations centres, Rakuten in RAN energy management. No operator is Level 4 end to end.

### Where AI revenue is actually appearing in results

SK Telecom's AI Data Centre business grew **92.5% year on year to KRW 136.2bn in Q2 2026** — "the fastest-growing segment" — inside group revenue that grew 0.5% ([SK Telecom, Aug 2026](https://news.sktelecom.com/en/3218) — company-reported). Note the proportion: about 3% of group revenue. TELUS reports **22% growth in AI-enabling revenue** and a sovereign AI factory "sold out of compute capacity within months"; Indosat Ooredoo Hutchison's AI Neocloud generated **$16m in Q1 2026 against $28m for all of 2025**, with blended ARPU up 15% attributed to AI personalisation ([TM Forum Inform, 2026](https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth) — company-reported). Not one of these operators discloses a margin on AI compute.

### Internal adoption is measurable

Deutsche Telekom reports **53% of employees regularly using AI at work** (Nov 2025), up nine points in six months ([DT Annual Report 2025](https://report.telekom.com/annual-report-2025/management-report/group-strategy/data-ai.html)). AT&T went from **8 billion to 27 billion tokens a day** within months, with Ask AT&T used by 100,000+ employees and **up to 90% cost reduction** from routing to small language models ([VentureBeat, Feb 2026](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut) — company-reported). Orange's Live Intelligence reached **90,000 employees with 15,000 daily actives** ([Orange Business](https://www.orange-business.com/en/about-us/customer-stories/live-intelligence-orange-has-helped-90000-employees-use-generative-ai)).

### The regulator has entered the frame

Ofcom's Call for Input on AI's impact on UK broadband and mobile customers closed on 10 March 2026, with findings due in the second half of 2026 — covering customer-service handling and vulnerable-consumer protections ([ISPreview, Jan 2026](https://www.ispreview.co.uk/index.php/2026/01/ofcom-examines-impact-of-ai-on-the-experience-of-uk-telecoms-customers.html) — regulator/official). GSMA Intelligence's own MWC 2026 observation: operators are **underinvesting in AI core-network applications despite proven ROI** while AI-RAN captures disproportionate attention ([RCR Wireless, Mar 2026](https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2)).

---

## 2. The challenges of the AI era — specific to telecoms

**AI must be funded from a shrinking cost base.** With revenue growth near inflation and capex falling, use cases whose payback exceeds roughly two years struggle for funding — which is precisely the profile of network-AI platform work. The hurdle is set by ROIC-versus-WACC pressure, not by enthusiasm.

**The RAN is the biggest cost pool and the hardest place to put AI economically.** Samsung's Alok Shah, December 2025: *"The wholesale shift to GPU compute at the cell site has shown challenges in both capex and opex,"* with only *"a subset of locations where the math works in the coming years"* ([Fierce Network, Dec 2025](https://www.fierce-network.com/wireless/ai-ran-2026-what-lies-ahead)). Ericsson is selling AI-in-RAN as a software subscription explicitly *without* GPUs — a vendor voting with its roadmap against GPU-at-the-cell-site economics ([Mobile Europe, Jun 2026](https://www.mobileeurope.co.uk/ericssons-monetisation-plan-for-ai-in-ran-without-gpus/)).

**Operators are structurally disadvantaged as AI compute providers.** Hyperscalers reach **60–70% GPU utilisation** through global load balancing; regional telco clusters reach **30–50%** — "a utilization trap." Latency-optimised inference costs roughly 50× batch inference, capping the edge-inference market. And *"telcos are not software companies"* ([RCR Wireless analyst assessment, Oct 2025](https://www.rcrwireless.com/20251030/analyst-angle/telecom-gpu-as-a-service)). Deutsche Telekom's flagship Industrial AI Cloud was, by its own launch statement, running at *"over one-third capacity"* ([DT, Feb 2026](https://www.telekom.com/en/media/media-information/archive/germany-s-first-ai-factory-for-industry-1101670)).

**Customer-service AI is a regulatory and reputational risk, not just a cost lever.** Which?'s March 2026 submission to Ofcom flags chatbots struggling with accurate information, reduced human service for vulnerable customers, fairness issues from personalised pricing, and "agentic misalignment" ([Which?, Mar 2026](https://www.which.co.uk/policy-and-insight/article/the-impact-of-ai-adoption-for-telecoms-customers-which-response-aWKz12b5Mk9s)). Telcos are among the most-complained-about industries in most markets; care-AI errors show up in regulator league tables within a quarter.

**Network data is operationally rich and legally constrained.** Telecom metadata — location, call records, traffic signals — sits under confidentiality-of-communications law on top of general data protection. Telefónica had to build Kernel on a "Privacy-by-Design" architecture before generative AI could touch customer data at all ([Telefónica, Feb 2024](https://www.telefonica.com/en/communication-room/press-room/telefonica-partners-with-microsoft-to-incorporate-generative-ai-into-kernel/)). This is why "monetise network data with AI" has under-delivered.

**Autonomy is domain-fragmented.** TM Forum positions most operators between Levels 2 and 3, with some "advancing rapidly toward Level 4 *in specific domains*." Rakuten Mobile's Chief Data & AI Officer Sachin Verma: *"The technology is growing at a pace, but the diffusion of technology in an enterprise is pretty low"* ([RCR Wireless, Jul 2026](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile)). Orange's Steve Jarrett: *"We're at the crawling stage of managing these systems at massive scale. It is another multiyear transformation"* ([TM Forum Inform, Jan 2026](https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai)).

**Sovereignty fragments the AI estate.** DT's Industrial AI Cloud, e&/Core42, stc/HUMAIN and Ooredoo's Qatar cloud all exist because workloads cannot leave the jurisdiction. A multinational group runs several parallel AI stacks — a recurring cost absent from single-market ROI models.

---

## 3. What key players are doing

| Operator | Deployment | Scale / outcome | Evidence |
|---|---|---|---|
| **AT&T** | Ask AT&T, Ask AT&T Workflows (agent builder), Ask Data on a relational knowledge graph; small-language-model routing | 100,000+ employees, >50% daily use; 8bn → 27bn tokens/day; **up to 90% AI cost reduction**; data products in 20 minutes vs 6 weeks | [company-reported](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut), Feb 2026 |
| **Verizon** | Google Gemini agent-assist (Personal Research Assistant, Problem Solver) | **28,000 care reps and retail staff**; "95% comprehensive answerability" | [company/vendor-reported](https://www.googlecloudpresscorner.com/2025-04-09-Google-Cloud-and-Verizon-Drive-Customer-Experience-Improvements-for-Verizon-Customers-with-Gemini-Integration), Apr 2025 |
| **Vodafone** | SuperTOBi on Azure OpenAI, replacing keyword TOBi | Portugal: first-time resolution **15% → 60%**; NPS **+14 to 64**; €140m FY2024 CX investment; 10-year Microsoft partnership | [company-reported](https://www.vodafone.com/news/newsroom/technology/meet-super-tobi-vodafone-s-new-generative-ai-virtual-assistant-now-serving-customers-in-multiple-countries), Jul 2024 |
| **Virgin Media O2** | NLU call routing plus cross-skilling of 5,000 agents | **1.3m call transfers avoided** in 2025; 400,000+ customer hours saved; complaints **down 50%** per Ofcom stats | [company-reported](https://news.virginmediao2.co.uk/ai-helps-virgin-media-o2-avoid-over-one-million-call-transfers-as-it-saves-customers-more-than-400000-hours-of-time-on-the-phone/), Jan 2026 |
| **Deutsche Telekom** | Industrial AI Cloud (Munich, ~10,000 Blackwell GPUs); Frag Magenta; AskT | Live Feb 2026 at "over one-third capacity"; 53% of employees use AI regularly | [company-reported](https://www.telekom.com/en/media/media-information/archive/germany-s-first-ai-factory-for-industry-1101670), Feb 2026 |
| **China Mobile** | Level 4 autonomy in network operations centres | **>30% reduction in backend O&M manpower**; **30% lower MTTR** | [company-reported via TM Forum](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum), Mar 2026 |
| **Rakuten Mobile** | Nationwide RIC with rApps; closed-loop RAN energy management (TM Forum Level 4 validated) | **20% RAN energy conservation**; 17–20% power-bill reduction ≈ ¥1bn/year | [company-reported](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile), Jul 2026 |
| **SoftBank** | AITRAS AI-RAN with NVIDIA | ~30% 5G speed improvement; ~3× spectral efficiency in 16-layer MU-MIMO trials; commercial from FY2026; **no cost or revenue figures** | [company-reported](https://www.softbank.jp/en/corp/technology/research/topics/224/), 2025 |
| **SK Telecom** | AI Data Centre business; SK Hyper (5 GW target from 2029) | AIDC revenue **KRW 136.2bn, +92.5% YoY** (Q2 2026) | [company-reported](https://news.sktelecom.com/en/3218), Aug 2026 |
| **Bharti Airtel** | Network-side spam and scam detection | **8bn spam calls and 0.8bn spam SMS blocked** (no false-positive rate disclosed) | [company-reported via press](https://www.business-standard.com/companies/news/ai-powered-solution-helped-block-8-bn-spam-calls-0-8-bn-smses-airtel-124120900456_1.html), Dec 2024 |
| **Telstra** | One Sentence Summary; Ask Telstra (Azure OpenAI) | 90% of agents reported time savings; **20% less follow-up contact** (100-agent trial) | [vendor-claimed with company metrics](https://www.microsoft.com/en/customers/story/1740058425924206437-telstra-telecommunications-azure-openai-service), Feb 2024 |
| **Telkomsel** | Predictive network operations | **12.6% reduction in wireless traffic loss** (east Indonesia trials) | [company-reported via TM Forum](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum), Mar 2026 |
| **Orange** | Live Intelligence internal gen-AI, later sold to B2B | 90,000 employees; €300m value *target* for 2025 (attainment not confirmed) | [company-reported](https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai), Jan 2026 |

### The reversals and overstated claims

**BT's "55,000 AI job cuts" do not survive the numbers.** BT's plan to shrink to 75,000–90,000 staff by 2030 was reported worldwide as AI-driven. Light Reading's May 2026 analysis of BT's own reporting: *"Despite the incessant messaging about AI, very little of this was caused by the newfangled technology."* The 22,000+ reductions since 2025 are attributed to network modernisation, legacy retirement and falling sales ([Light Reading, May 2026](https://www.lightreading.com/fttx/bt-plans-mass-layoffs-after-cutting-8-500-jobs-in-last-year)). The sector's most-cited AI labour story is mostly not an AI story.

**Verizon's consumer bot produced a public backlash.** The same Gemini programme that gave 28,000 reps a well-received assist tool was extended to the consumer-facing Verizon Assistant; by September 2025 users reported being told in SOS mode to "use Wifi and not use the cellular network," refusals to discuss competitor offers, and accounts flagged for fraud after repeatedly asking for a human ([Yahoo Tech, Sep 2025](https://tech.yahoo.com/ai/articles/verizons-google-powered-chatbot-frustrates-201903926.html) — press-reported). Agent-assist and self-service are different products with different risk profiles.

**T-Mobile IntentCX: announced with unusual specificity, never substantiated.** Announced with OpenAI in September 2024 for a 2025 launch. As of September 2026 we found no launch announcement, deployment scale or outcome metric from either company ([original announcement](https://www.businesswire.com/news/home/20240917013945/en/T-Mobile-and-OpenAI-Join-Forces-to-Revolutionize-the-Customer-Experience-with-First-Ever-Intent-Driven-AI-Decisioning-Platform)). Treat as announced-but-unverified.

---

## 4. Myths versus reality

| The claim | What the evidence shows | Verdict |
|---|---|---|
| "AI will make networks self-driving." | China Mobile at L4 in NOCs; Rakuten L4-validated in RAN energy; TDC NET/Ericsson industry-first L4 certification (Jun 2025). But 21% of operators at L3+, 79% at L0/1, every L4 claim domain-bounded. | **Proven in pockets** (single domains); **unproven end to end.** |
| "Telcos will become AI companies and sell compute profitably." | SKT AIDC +92.5%; TELUS +22%; IOH $16m in a quarter. Against: 30–50% vs 60–70% utilisation; DT's factory at one-third capacity; AIDC ~3% of SKT revenue; **no operator has published a margin.** | **Proven in pockets on revenue; unproven on profitability.** |
| "Gen-AI care bots massively reduce cost-to-serve." | Vodafone FTR 15% → 60%; VMO2 1.3m transfers avoided; Telstra 20% less follow-up. Almost none are *cost* figures — the sector reports experience metrics, not unit economics. Ofcom is investigating; Verizon's bot backfired. | **Proven in pockets on service quality; largely unproven on cost-to-serve.** |
| "AI churn models move the needle on churn." | We searched for a named operator publishing a churn-rate reduction attributable to AI in 2024–26 and **could not find one.** What exists: Entel Connect +40% inbound sales in 10 weeks (a sales metric); IOH +15% ARPU; academic accuracy papers with no P&L outcome. | **Unproven** at the level of reported churn rates. |
| "AI-RAN pays for itself." | SoftBank ~30% speed and ~3× spectral efficiency in trials; Fujitsu uplink gains. Against: Samsung's "challenges in both capex and opex"; Ericsson's GPU-free product bet; **no payback figure published by anyone.** | **Technically proven in trials; economically unproven.** |
| "Telcos will monetise network data with AI." | 45% of operators call AI-enabled revenue a priority (GSMA). But disclosed AI revenue lines are compute and services, not data; Kernel needed a privacy re-architecture first. | **Unproven.** |
| "AI is driving telecom job cuts." | The flagship case (BT) is contradicted by analysis of BT's own reporting. | **Contradicted** in the most-cited case. |
| "AI cuts RAN energy consumption significantly." | Rakuten: 20% RAN energy saving nationwide, ~¥1bn/year; Vodafone UK/Ericsson trial up to 33% daily radio-unit power reduction ([Ericsson, Mar 2025](https://www.ericsson.com/en/press-releases/3/2025/vodafone-uk-and-ericsson-trial-ai-solutions-for-improved-5g-energy-efficiency) — vendor trial, "up to"). | **Proven at scale in one national network; proven in pockets elsewhere.** |
| "Big models are the right architecture for telco workloads." | AT&T routes to small language models at up to 90% lower cost; CDO Andy Markus: *"the future of agentic AI is many, many, many small language models."* | **Contradicted** by the largest deployer. |
| "Network AI is where the money is." | GSMA Intelligence: proven-ROI core-network applications are *underinvested* while AI-RAN absorbs attention; reported revenue is in data centres and care. | **Contradicted** for 2024–26. The money to date is in compute and care, not radio. |

---

## 5. The Cognirise point of view

**In telecoms, AI wins where it converts opex into cash within a budget cycle — and the two places that has demonstrably happened are the contact centre and the network operations centre. Everything else is a capacity bet.**

The industry's own numbers set the terms. Revenue grows at 2.7%; capex is falling; 12% of operators report sizable impact. In that environment, the AI programmes that survive are the ones that show up in the cost line inside the year they are funded. Virgin Media O2's 1.3m avoided transfers, China Mobile's 30% O&M manpower reduction and Rakuten's ¥1bn power-bill saving all share that property. AI-RAN, GPU-as-a-service and network-data monetisation do not — yet.

Five convictions follow.

**Small models, big workflows.** The most instructive architecture in the sector belongs to its biggest deployer: AT&T's 27 billion tokens a day run mostly through small, domain-tuned models at up to 90% lower cost, orchestrated across workflows rather than poured into one giant assistant. For an operator, that is not a technical preference; it is what makes the unit economics of AI compatible with a flat top line. We design telco agents around routing, retrieval and orchestration first, and model size last.

**Agent-assist before self-service, and measure cost — not just NPS.** Verizon's two outcomes from one programme are the lesson: 28,000 reps with a research assistant worked; a consumer bot without escalation design went wrong in public. The sector reports first-time resolution and NPS but almost never cost-to-serve. We instrument cost per contact, transfers avoided and complaint rates from day one, because Ofcom will be reading the same numbers.

**Closed-loop autonomy is a domain decision, not a company slogan.** TM Forum's ladder is the right way to talk to a board: pick the domain — RAN energy, NOC fault handling, capex reprioritisation — where the telemetry is clean and the blast radius is bounded, take it to Level 3–4 with certification-grade evidence, and let the next domain earn its turn. NTT DOCOMO's finding that 10–30% of planned capex interventions were reprioritisable is the highest-leverage, least-discussed use case in the sector — because capex is the sector's defining problem.

**In the GCC, the operator is national AI infrastructure — so monetise the platform with services, not GPUs.** e&/Core42, du/Microsoft, stc/center3/HUMAIN and Ooredoo/NVIDIA are sovereign-compute plays with a government mandate behind them. The evidence from SKT, TELUS and DT is that compute revenue is real and compute margin is undisclosed; the utilisation trap is structural. The durable regional advantage is what runs *on* the sovereign platform: Arabic-dialect care, government and enterprise agentic services, and in-country data products. Operators that treat the data centre as the end state will find hyperscalers better at it; operators that treat it as the foundation for a services business have something no hyperscaler can replicate in-jurisdiction.

**Gulf-dialect voice AI is an unmet, measurable opportunity.** We searched for any GCC operator publishing containment, handling-time or CSAT results for an Arabic-dialect voice agent and found only vendor marketing. The functional requirement — Khaliji Arabic with English code-switching, running in-country — is well understood; the published evidence is absent. The first operator to deploy and *measure* it sets the regional reference point.

### How this maps to Cognirise's service lines

| Service line | In telecoms this means |
|---|---|
| **Agentic Enterprise Transformation** | Contact-centre and NOC workflows redesigned as governed human-plus-agent operations, with cost-to-serve and MTTR as the measured outcomes — the VMO2 and China Mobile patterns. |
| **Data & AI Foundations** | The alarm, telemetry and customer-knowledge foundations that make routing, agent-assist and closed-loop automation possible — and the privacy-by-design layer (Kernel-style) that makes them lawful. |
| **Engineering with AI** | Model routing, small-language-model fleets and FinOps for inference — the AT&T pattern — so the cost curve bends before the token volume does. |
| **Sovereign Agentic AI** | Government and regulated-enterprise agentic services delivered on the operator's sovereign platform: in-country, Arabic-first, with the operator as trusted national provider. |
| **AI-Native Platforms** | One conversational front door for consumer and B2B care with measured containment, explained escalations and Arabic–English parity across voice, chat and WhatsApp. |

Our operating principle — *value first, foundations behind value, transformation on proof* — has a telecom-specific corollary: **if it does not show in the cost line this budget cycle, it is a strategy bet, and should be labelled as one.**

---

## 6. High-impact use cases and what the evidence says about returns

| # | Use case | Type | Who has done it | Documented outcome | What to expect and measure | Prerequisites |
|---|---|---|---|---|---|---|
| 1 | **Autonomous network operations centre (L4 in-domain)** | Agentic, closed-loop | China Mobile | **>30% backend O&M manpower reduction; 30% lower MTTR** [company-reported via TM Forum, Mar 2026] | O&M FTE per network element; MTTR; ticket auto-resolution. The strongest hard-cost evidence in the sector. | Normalised alarm and telemetry; closed-loop execution rights; autonomy governance |
| 2 | **AI-driven RAN energy optimisation** | Analytical + closed-loop | Rakuten Mobile; Vodafone UK/Ericsson (trial) | Rakuten **20% RAN energy saving, 17–20% power bill, ~¥1bn/yr** nationwide [company-reported, Jul 2026]; Vodafone trial up to 33% daily radio-unit power [vendor-claimed] | kWh per site and per GB; QoE guardrails; wake-latency incidents | RIC/rApp or vendor energy suite; traffic prediction; tolerance for sleep modes |
| 3 | **Intelligent call routing and transfer avoidance** | Analytical / NLU | Virgin Media O2 | **1.3m transfers avoided; 400,000+ customer hours saved; complaints −50%** in 2025 [company-reported, Jan 2026] | Transfer rate; complaints per 100k; AHT. Note the human change (5,000 agents cross-skilled) was co-equal with the AI. | Intent NLU; skills taxonomy; agent cross-skilling |
| 4 | **Agent-assist in customer care** | Generative + retrieval | Verizon (28,000 reps); Telstra; VMO2 (Lumi) | Verizon 95% answerability [company/vendor]; Telstra 90% of agents report time saved, **20% less follow-up contact** [vendor-claimed trial] | Repeat-contact rate; AHT; QA scores. Telstra took ~18 months from trial to scale. | Unified knowledge corpus; transcription; CRM integration |
| 5 | **Customer-facing gen-AI assistant** | Generative | Vodafone SuperTOBi | Portugal FTR **15% → 60%; NPS +14** [company-reported, Jul 2024] ⚠ single market, no methodology | Containment *and* cost per contact *and* vulnerable-customer outcomes — all three | Escalation-to-human design; multilingual coverage; Ofcom-grade fairness controls |
| 6 | **Predictive fault and traffic-loss prevention** | Analytical → agentic | Telkomsel; T-Mobile (30,000 antenna adjustments during Winter Storm Fern) | **12.6% reduction in wireless traffic loss** [company-reported via TM Forum] | Traffic loss; truck rolls; outage minutes | Labelled fault history; topology model; dispatch integration |
| 7 | **Network spam, scam and fraud detection** | Analytical, real-time | Bharti Airtel; Rakuten Card | 8bn spam calls blocked [company-reported, no FP rate]; Rakuten **33% fewer risky transactions in two weeks** [company-reported] | Blocked volume *with* false-positive rate — blocking legitimate traffic is a regulatory event. SIM-box "recovered revenue" figures are vendor-only; treat as unverified. | Real-time signalling pipeline; lawful basis; low FP tolerance |
| 8 | **Enterprise-wide employee AI assistant** | Generative → agentic | AT&T; Orange; Deutsche Telekom | AT&T 100,000+ users, data products 20 min vs 6 weeks, **up to 90% inference cost cut** via SLM routing [company-reported]; Orange €300m *target* | Weekly active use; cost per task; workflow-builder adoption | Access controls; model routing and FinOps; adoption programme |
| 9 | **Capex reprioritisation with AI** | Analytical / decision support | NTT DOCOMO | **10–30% of planned capex interventions found reprioritisable** [analyst-reported via McKinsey, Feb 2026] | Capex deferred or redirected per planning cycle | Unified performance, demand and financial data; a planning process willing to be overruled |
| 10 | **AI-assisted sales in inbound care** | Generative + recommendation | Entel Connect | **+40% inbound sales within 10 weeks** [analyst-reported via McKinsey] — the fastest documented time-to-value on this page | Conversion per inbound contact; ARPU uplift | Offer catalogue; next-best-action model |
| 11 | **AI-RAN / signal-processing acceleration** | Inference in the datapath | SoftBank AITRAS; Ericsson (GPU-free) | SoftBank ~30% speed, ~3× spectral efficiency (trials); Ericsson claims up to 20% downlink throughput on existing hardware [vendor-claimed] | **Performance proven; ROI projected only.** Fund as R&D with a site-level payback test. | Virtualised/open RAN; spectrum-constrained sites |
| 12 | **Sovereign AI factory / GPU-as-a-service** | Infrastructure | SKT; TELUS; IOH; DT; KDDI | Revenue documented (SKT KRW 136.2bn/qtr; IOH $16m/qtr); **profitability undocumented anywhere** | Utilisation rate against the 60–70% hyperscaler benchmark; anchor-tenant coverage; services attach rate | Power and land; sovereignty demand; an orchestration layer telcos do not natively have |

**A note on returns.** Rows 1–3 carry outcome numbers at national or network scale. Rows 4–8 are strong on experience metrics and weak on unit cost. Rows 11–12 are strategy bets with revenue but no disclosed margin. A telecom AI roadmap should fund them in that order.

---

## 7. Case studies

*Structure to follow the shared case-study template (see `case-study-template.md`). Cognirise case studies for this industry to be added.*

---

## 8. Voices

> "I believe the future of agentic AI is many, many, many small language models." — **Andy Markus**, Chief Data Officer, AT&T, February 2026

> "The technology is growing at a pace, but the diffusion of technology in an enterprise is pretty low." — **Sachin Verma**, Chief Data and AI Officer, Rakuten Mobile, July 2026

> "We're at the crawling stage of managing these systems at massive scale. It is another multiyear transformation." — **Steve Jarrett**, Chief AI Officer, Orange, January 2026

> "The wholesale shift to GPU compute at the cell site has shown challenges in both capex and opex." — **Alok Shah**, VP Strategy and Marketing, Samsung Electronics America, December 2025

> "The AI Center of Excellence gives us a robust structure to move from experimentation to disciplined execution." — **Maha AlQernas**, EVP of IT and Head of the AI Center of Excellence, Zain KSA, June 2026

> "By combining HUMAIN's AI leadership with center3's world-class data-centre expertise, we are creating the right foundation to strengthen the region's capacity to host next-generation AI workloads." — **Olayan Alwetaid**, Group CEO, stc, December 2025

---

## GCC snapshot (for a sidebar or regional tab)

- **e& (UAE):** H1 2025 net profit Dh8.8bn (+60.7%); AI governance framework with IBM; Sovereign Cloud Launchpad with AWS; **divested 40% of Khazna Data Centers for Dh8bn** — monetising the asset rather than holding it ([Gulf News, Jul 2025](https://gulfnews.com/business/markets/e-profits-soar-60-in-h1-with-ai-cloud-expansion-plans-to-fuel-growth-1.500218049)). July 2026: **Sovereign AI Compute platform with Core42**, zero egress fees, in-country residency ([e&, Jul 2026](https://www.eand.com/en/news/20-07-26-eand-uae-core42-sovereign-ai-infrastructure.html)).
- **du (UAE):** **AED 2bn AI data centre with Microsoft**, sovereign cloud, under Dubai's Universal Blueprint for AI ([RCR Wireless, Apr 2025](https://www.rcrwireless.com/20250428/ai-ml/du-ai-data-microsoft)); Microsoft's wider $15.2bn UAE commitment to 2029.
- **stc group (KSA):** center3 and HUMAIN **50/50 JV for up to 1 GW of AI data centres**, initial 250 MW phase ([Data Centre Magazine, Dec 2025](https://datacentremagazine.com/news/how-will-center3-and-humain-build-1gw-of-ai-data-centres)).
- **Ooredoo (Qatar):** NVIDIA Hopper deployment for the country's first operator sovereign AI cloud, aligned to Digital Agenda 2030 ([Ooredoo, Jul 2025](https://www.ooredoo.com/en/media/news_view/ooredoo-deploys-nvidia-accelerated-computing-in-qatar-ushers-in-the-countrys-next-wave-of-innovation/)); Aug 2026 multi-billion 1 GW platform targeting Southeast Asia with NVIDIA and Nokia.
- **Zain KSA:** AI Center of Excellence launched 3 June 2026, aligned to Saudi's "Year of AI"; no outcome metrics yet ([Zain KSA](https://sa.zain.com/en/all-news/zain-ksa-launches-ai-center-excellence-line-%E2%80%98year-ai%E2%80%99)).
- **Mobily (KSA):** MoU with Ericsson at LEAP 2026 on AI-powered RAN and autonomous networks, building on Hajj 2025 explainable-AI and uplink-interference trials ([Zawya, Sep 2026](https://www.zawya.com/en/press-release/companies-news/ericsson-and-mobily-sign-mou-at-leap-2026-to-advance-ai-powered-ran-and-autonomous-networks-in-saudi-arabia-474008)). Hajj is a uniquely regional testbed: predictable, extreme, time-bounded load.
- **Regulators:** Saudi CST's Global AI Hub Law consultation (Apr–May 2025) proposing Private, Extended and Virtual data-centre sovereignty models ([CST](https://www.cst.gov.sa/en/media-center/news/N2025041401)); CST AI Adoption Guide, Aug 2026 — generic, with no telecom-specific obligations yet. UAE: National AI Strategy 2031, Dubai AI Seal (e& holds "S Class"), data residency as the binding constraint.
- **The pattern:** in the GCC, AI shows up first on the balance sheet as sovereign compute and only second in the network or the contact centre.

---

## Sources

Primary sources used on this page (full 56-item index in `research/telecoms-dossier.md`):

- GSMA Intelligence, *The Mobile Economy 2026* — https://www.gsmaintelligence.com/research/the-mobile-economy-2026 ; Mobile World Live coverage, 2 Mar 2026 — https://www.mobileworldlive.com/gsma/mobile-sector-gdp-contribution-tipped-to-top-11t
- McKinsey, *Telcos' AI inflection point*, 26 Feb 2026 — https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/telcos-ai-inflection-point-what-leaders-do-to-capture-value
- NVIDIA, *State of AI in Telecommunications 2026*, 19 Feb 2026 — https://blogs.nvidia.com/blog/ai-in-telco-survey-2026
- TM Forum autonomy study via Fierce Network, Mar 2026 — https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum ; TDC NET/Ericsson L4 certification, Jun 2025 — https://www.ericsson.com/en/news/2025/6/tdc-net-and-ericsson-achieves-industry-first-certification-from-tm-forum-of-level-4-autonomy
- TM Forum Inform, *Telco results show signs of AI service growth*, 2026 — https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth ; Steve Jarrett interview, 22 Jan 2026 — https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai
- SK Telecom Q2 2026 results, 5 Aug 2026 — https://news.sktelecom.com/en/3218
- AT&T via VentureBeat, 26 Feb 2026 — https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut
- Verizon/Google Cloud, 9 Apr 2025 — https://www.googlecloudpresscorner.com/2025-04-09-Google-Cloud-and-Verizon-Drive-Customer-Experience-Improvements-for-Verizon-Customers-with-Gemini-Integration ; backlash, Yahoo Tech, Sep 2025 — https://tech.yahoo.com/ai/articles/verizons-google-powered-chatbot-frustrates-201903926.html
- Vodafone SuperTOBi, 4 Jul 2024 — https://www.vodafone.com/news/newsroom/technology/meet-super-tobi-vodafone-s-new-generative-ai-virtual-assistant-now-serving-customers-in-multiple-countries ; Vodafone UK/Ericsson energy trial, 11 Mar 2025 — https://www.ericsson.com/en/press-releases/3/2025/vodafone-uk-and-ericsson-trial-ai-solutions-for-improved-5g-energy-efficiency
- Virgin Media O2, 15 Jan 2026 — https://news.virginmediao2.co.uk/ai-helps-virgin-media-o2-avoid-over-one-million-call-transfers-as-it-saves-customers-more-than-400000-hours-of-time-on-the-phone/
- Deutsche Telekom Industrial AI Cloud, 4 Feb 2026 — https://www.telekom.com/en/media/media-information/archive/germany-s-first-ai-factory-for-industry-1101670 ; Annual Report 2025 — https://report.telekom.com/annual-report-2025/management-report/group-strategy/data-ai.html
- Rakuten Mobile via RCR Wireless, 23 Jul 2026 — https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile
- SoftBank AITRAS — https://www.softbank.jp/en/corp/technology/research/topics/224/ ; Samsung/AI-RAN outlook, Fierce Network, 22 Dec 2025 — https://www.fierce-network.com/wireless/ai-ran-2026-what-lies-ahead ; Ericsson GPU-free AI-RAN, Mobile Europe, 11 Jun 2026 — https://www.mobileeurope.co.uk/ericssons-monetisation-plan-for-ai-in-ran-without-gpus/ ; Light Reading on AI-RAN economics, 28 Feb 2024 — https://www.lightreading.com/ai-machine-learning/the-questionable-economics-of-ai-in-the-ran
- GPU-as-a-service economics, RCR Wireless, 30 Oct 2025 — https://www.rcrwireless.com/20251030/analyst-angle/telecom-gpu-as-a-service ; Dell'Oro capex outlook — https://www.delloro.com/news/worldwide-telecom-capex-to-decline-in-2026/
- BT analysis, Light Reading, 21 May 2026 — https://www.lightreading.com/fttx/bt-plans-mass-layoffs-after-cutting-8-500-jobs-in-last-year
- T-Mobile/OpenAI IntentCX announcement, 17 Sep 2024 — https://www.businesswire.com/news/home/20240917013945/en/T-Mobile-and-OpenAI-Join-Forces-to-Revolutionize-the-Customer-Experience-with-First-Ever-Intent-Driven-AI-Decisioning-Platform
- Telstra/Microsoft, 23 Feb 2024 — https://www.microsoft.com/en/customers/story/1740058425924206437-telstra-telecommunications-azure-openai-service ; Orange Live Intelligence — https://www.orange-business.com/en/about-us/customer-stories/live-intelligence-orange-has-helped-90000-employees-use-generative-ai
- Bharti Airtel, Business Standard, 9 Dec 2024 — https://www.business-standard.com/companies/news/ai-powered-solution-helped-block-8-bn-spam-calls-0-8-bn-smses-airtel-124120900456_1.html
- Telefónica Kernel, 26 Feb 2024 — https://www.telefonica.com/en/communication-room/press-room/telefonica-partners-with-microsoft-to-incorporate-generative-ai-into-kernel/
- Ofcom Call for Input, ISPreview, Jan 2026 — https://www.ispreview.co.uk/index.php/2026/01/ofcom-examines-impact-of-ai-on-the-experience-of-uk-telecoms-customers.html ; Which? response, Mar 2026 — https://www.which.co.uk/policy-and-insight/article/the-impact-of-ai-adoption-for-telecoms-customers-which-response-aWKz12b5Mk9s
- GSMA at MWC 2026, RCR Wireless, 25 Mar 2026 — https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2 ; STL Partners, Mar 2026 — https://stlpartners.com/research/mwc-2026-ai-realism/
- GCC: e& H1 2025, Gulf News — https://gulfnews.com/business/markets/e-profits-soar-60-in-h1-with-ai-cloud-expansion-plans-to-fuel-growth-1.500218049 ; e&/Core42, 20 Jul 2026 — https://www.eand.com/en/news/20-07-26-eand-uae-core42-sovereign-ai-infrastructure.html ; du/Microsoft, RCR Wireless, 28 Apr 2025 — https://www.rcrwireless.com/20250428/ai-ml/du-ai-data-microsoft ; stc/HUMAIN, Data Centre Magazine, 20 Dec 2025 — https://datacentremagazine.com/news/how-will-center3-and-humain-build-1gw-of-ai-data-centres ; Ooredoo, 1 Jul 2025 — https://www.ooredoo.com/en/media/news_view/ooredoo-deploys-nvidia-accelerated-computing-in-qatar-ushers-in-the-countrys-next-wave-of-innovation/ ; Zain KSA, 3 Jun 2026 — https://sa.zain.com/en/all-news/zain-ksa-launches-ai-center-excellence-line-%E2%80%98year-ai%E2%80%99 ; Mobily/Ericsson, Zawya, 1 Sep 2026 — https://www.zawya.com/en/press-release/companies-news/ericsson-and-mobily-sign-mou-at-leap-2026-to-advance-ai-powered-ran-and-autonomous-networks-in-saudi-arabia-474008 ; CST Global AI Hub Law, 14 Apr 2025 — https://www.cst.gov.sa/en/media-center/news/N2025041401
