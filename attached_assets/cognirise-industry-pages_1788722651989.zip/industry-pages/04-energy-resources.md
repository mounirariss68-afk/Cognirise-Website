# Energy & Resources

> **Editor's notes (remove before publishing).** Evidence labels as on every page: **[company-reported]**, **[vendor-claimed]**, **[analyst-estimate]**, **[regulator/official]**, **[independent study]**. Two hard corrections built into this page: the ubiquitous "Shell cut downtime 20% with C3 AI" has **no primary source** (the 2022 Shell/C3 release contains no ROI figure at all) and is not used; and no credible public source links AI to a hydrocarbon recovery-factor uplift, so the page claims cycle time, not barrels. Items flagged ⚠ are the weakest figures. The evidence base is strong on IEA, ADNOC, Aramco, mining majors and US wildfire utilities, and thin on European utilities and GCC entities other than ADNOC, Aramco and DEWA — a second research pass should target TAQA, EWEC, ACWA Power, Ma'aden, Kahramaa and Saudi Water Authority.

**Working page title:** Energy & Resources — The only industry where AI is both the tool and the customer.

**Meta description (≤160 chars):** AI in oil & gas, power, renewables and mining: what the IEA's numbers mean, where autonomy is real, what sovereignty requires, and the use cases with proof.

---

## 1. The state of the industry, from an AI perspective

Every other sector asks what AI can do for it. Energy and resources must also answer whether it can physically deliver the electrons AI needs. That two-way relationship — *AI for energy* and *energy for AI* — is the organising fact of the sector's AI story, and it is now tracked formally by the sector's own reference institution, the IEA.

### The demand side: AI is reshaping the load

Data centres consumed **485 TWh in 2025, up 17%** against 3% growth in global electricity demand; AI-focused facilities grew 50% and are projected to **triple** their power use by 2030 ([IEA, *Key Questions on Energy and AI*, Apr 2026](https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary) and its [accompanying news release](https://www.iea.org/news/data-centre-electricity-use-surged-in-2025-even-with-tightening-bottlenecks-driving-a-scramble-for-solutions), which carries the 3% comparator — regulator/official). The IEA's base case has total data-centre demand reaching **~945 TWh by 2030** ([IEA, *Energy and AI*, Apr 2025](https://www.iea.org/reports/energy-and-ai/executive-summary)).

The most consequential number: hyperscaler capex exceeded **$400bn in 2025** and is set to rise a further 75% in 2026 — five technology companies now **out-invest global oil and gas production** ([IEA, Apr 2026](https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary)). The buyers of energy out-invest its producers.

The physical shock is density and connection. AI server power density rose **11-fold between 2020 and 2025**; by 2027 a single rack could draw the equivalent of 65 households. In the United States, **~2,060 GW** of generation and storage sat in interconnection queues at end-2025 (1,312 GW generation plus ~749 GW storage), with a **median wait of over five years** from request to commercial operation for projects built in 2025 ([Lawrence Berkeley National Laboratory, *Queued Up 2026*, Jun 2026](https://emp.lbl.gov/queues) — independent study). NERC raised its ten-year summer peak-demand forecast by **224 GW — 69% higher than the prior year's assessment** — attributing most of the increase to AI data centres ([NERC 2025 LTRA, Jan 2026](https://www.nerc.com/pa/RAPA/ra/Reliability%20Assessments%20DL/NERC_LTRA_2025.pdf) — regulator/official). The IEA estimates grid constraints could delay **around 20% of data-centre capacity planned for 2030**, and that **15–27 GW of onsite gas** may power data centres by then.

### The supply side: where AI has shown up in company numbers

- **ADNOC** reported **$500m (AED 1.84bn) of value from AI in 2023** across seven named systems, plus up to 1 Mt of CO₂ abated over 2022–23 ([ADNOC, Mar 2024](https://www.adnoc.ae/en/news-and-media/press-releases/2023/$500-million-in-value-generated-by-adnoc-through-deployment-of-ai-solutions-in-2023) — company-reported).
- **Aramco** reports **$1.8bn of AI-driven "Technology Realized Value" in 2024** from 442 identified use cases, 200+ deployed ([Aramco, *Building the AI future*](https://www.aramco.com/en/what-we-do/energy-innovation/digitalization/building-the-ai-future) — company-reported). CEO Amin Nasser separately said total technology realisation doubled from $2bn to $4bn; the $1.8bn is the AI-attributed subset.
- **Rio Tinto's AutoHaul** autonomous heavy-haul rail moved **326.2 million tonnes** of Pilbara iron ore in 2025, with mainline stopping incidents down two-thirds over five years and system resets cut from 4 hours to 8 minutes ([International Railway Journal, Mar 2026](https://www.railjournal.com/in_depth/autohaul-drives-efficiencies-at-rio-tinto/) — company-reported via trade press).
- The IEA's upside estimates for *AI for energy* are large and forward-looking: up to **$110bn a year by 2035** from power-plant O&M optimisation, up to **175 GW of transmission capacity** unlockable in existing lines, and **30–50% shorter outages** from AI fault detection ([IEA, Apr 2025](https://www.iea.org/reports/energy-and-ai/ai-for-energy-optimisation-and-innovation) — projections, not results).

### Compute intensity here is old, not new

Oil and gas companies operating Top-500 supercomputers rose from 11 in 2000 to **24 in 2024**, with capacity growing almost 70% a year ([IEA, Apr 2025](https://www.iea.org/reports/energy-and-ai/ai-for-energy-optimisation-and-innovation)). This sector was running HPC-scale numerical modelling decades before AI adoption became a board topic. Aramco trained Metabrain on **7 trillion data points spanning 90+ years**; ADNOC's ENERGYai is trained on **80 years** of proprietary data.

### The structural forces that make this sector different

**Asset-heavy, long-cycle capex.** Investment decisions are 20–40-year commitments made against policy and price assumptions that change every 18 months. AI competes against physical capital with hurdle rates, not against SaaS budgets.

**Safety-critical OT.** Models sit beside safety-instrumented systems and HAZOP-governed processes. An action-taking agent on a compressor is a functional-safety change, not a software release.

**Old, non-stationary data.** Assets are modified, sensors re-tagged, failure modes rare. Shell's predictive-maintenance programme ran **~11,000 ML models against 10,000 assets** ([C3.ai/Shell, Mar 2022](https://ir.c3.ai/news-releases/news-release-details/shell-achieves-major-milestone-scales-artificial-intelligence) — vendor-claimed) — roughly one model per asset, which shows how little generalises across heterogeneous equipment.

**The "great crew change."** The cohort that carries undocumented plant knowledge is retiring. Knowledge-retrieval agents have unusually clear returns here because the alternative is losing the knowledge outright.

**The barriers are named by the regulator.** The IEA lists *"unfavourable regulation, lack of access to data, inaccessibility, interoperability concerns, critical gaps in skills, the paucity of digital infrastructure"*; it calls lack of digital skills *"the single largest barrier"*, and notes only **10% of global electricity consumption is covered by open electricity data policies** ([IEA, Apr 2026](https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary)).

---

## 2. The challenges of the AI era — specific to energy & resources

**AI's own demand is destabilising load forecasts and capital plans.** A 69% jump in a ten-year peak forecast in a single assessment cycle forces multi-billion transmission and generation commitments against hyperscaler load requests that are non-binding, duplicated across territories and withdrawable. No other industry measures its forecasting error in gigawatts of stranded or missing steel.

**The interconnection queue is the real bottleneck, and AI cannot shorten it.** Median interconnection-to-operation above five years; 2,060 GW queued; transformer and turbine backlogs. AI improves siting, study automation and dynamic line rating; the constraint is regulatory process and physical equipment.

**Safety-critical OT means "agentic" cannot mean "autonomous" without a functional-safety case.** The EU AI Act classifies as high-risk *"AI systems intended to be used as safety components in the management and operation of critical digital infrastructure, road traffic, or in the supply of water, gas, heating or electricity"* ([Annex III, point 2](https://artificialintelligenceact.eu/annex/3/) — regulator/official). NERC CIP governs the OT perimeter in North America. In practice this pushes deployment toward advisory and copilot patterns, with closed-loop control confined to ring-fenced, low-consequence loops.

**Data is old, proprietary and not stationary.** Seismic reprocessing works because the physics is stable. Equipment-failure prediction is harder, and every new asset class is close to a new project.

**The vendor layer is financially unstable, which transfers risk to operators.** C3.ai — the most-cited enterprise-AI vendor in oil and gas — reported **Q1 FY2026 revenue down 19%** and withdrew full-year guidance; founder Tom Siebel called the quarter *"completely unacceptable"* ([C3.ai, Sep 2025](https://ir.c3.ai/news-releases/news-release-details/c3-ai-announces-fiscal-first-quarter-2026-financial-results) — company-reported). Its Baker Hughes alliance was at one point **45% of revenue** and its customer-count methodology has been publicly contested ([CNBC, Jun 2023](https://www.cnbc.com/2023/06/02/billionaire-tom-siebel-faces-controversy-at-ai-software-vendor-c3ai-.html)). Operators who built critical maintenance workflows on one platform carry continuity risk.

**Emissions accounting cuts both ways.** Energy companies are asked to fund AI that raises their own Scope 2 while claiming AI-enabled abatement. The IEA's own caution: AI-enabled reductions *"could cancel out any extra data-centre emissions"*, but *"there is currently no existing momentum of AI adoption that would unlock these emissions reductions"*; fossil fuels still supply **nearly 60%** of data-centre power ([IEA via Carbon Brief](https://www.carbonbrief.org/ai-five-charts-that-put-data-centre-energy-use-and-emissions-into-context)).

**Sovereignty is contractual, not aspirational, in the GCC.** National oil companies treat subsurface and production data as state assets, which forces in-country training and inference. That is why ADNOC's programme is delivered through a domestically-owned JV rather than a foreign SaaS contract.

**Measurement infrastructure for environmental claims is fragile.** MethaneSAT — the flagship AI-assisted methane-quantification mission — **lost contact on 20 June 2025** after about a year in orbit; the anomaly investigation could not identify the specific cause ([MethaneSAT, Nov 2025](https://www.methanesat.org/project-updates/results-anomaly-investigation-loss-communication-methanesat) — official). Operators who built reporting narratives on one sensing platform lost their independent verification layer overnight.

---

## 3. What key players are doing

| Organisation | Deployment | Scale / outcome | Evidence |
|---|---|---|---|
| **ADNOC (UAE)** | ENERGYai — agentic system built by AIQ with G42, Microsoft and OpenAI models on 80 years of proprietary data; **$340m AIQ contract** (Mar 2025) for five subsurface agents scaling across 28+ fields over three years | Claims of geological modelling **up to 75% faster** and development planning compressed from 1–2 years to weeks; **$500m of AI value in 2023** | [company-reported](https://www.adnoc.ae/en/news-and-media/press-releases/2024/adnoc-and-aiq-developing-first-of-a-kind-agentic-ai-solution-for-global-energy-transformation), Nov 2024; [G42/AIQ](https://www.g42.ai/resources/news/aiq-announces-340-million-contract-large-scale-deployment-agentic-ai-across-adnoc-operations), Mar 2025 |
| **AIQ + SLB** | ENERGYai integrated with SLB's Lumi platform | On 15% of ADNOC's data across two fields: **10× faster seismic interpretation, +70% precision** — pilot-scale | [vendor/company-claimed](https://www.slb.com/news-and-insights/newsroom/press-release/2025/aiq-slb-energyai-pr), Aug 2025 |
| **Saudi Aramco** | Metabrain (250bn parameters, 7tn data points, 90+ years); 1,500 PB storage; ~10bn data points processed daily | **$1.8bn AI-attributed value in 2024**; 442 use cases, 200+ deployed; legacy seismic reprocessing "months → hours"; drone inspection cutting pipeline inspection time **90%** at Uthmaniyah; 6,000 AI developers to be trained | [company-reported](https://www.aramco.com/en/what-we-do/energy-innovation/digitalization/building-the-ai-future); [Aramco Europe](https://europe.aramco.com/en/news-media/news/2025/aramco-deploys-ai), Mar 2025 |
| **Shell** | AI predictive maintenance at scale (with C3.ai) | **10,000+ assets, ~11,000 models, 3m+ sensors, 15m predictions/day**; **no savings or ROI figure disclosed** | [vendor-claimed](https://ir.c3.ai/news-releases/news-release-details/shell-achieves-major-milestone-scales-artificial-intelligence), Mar 2022 |
| **Rio Tinto** | AutoHaul autonomous rail (fully deployed 2018–19); 130+ autonomous trucks | **7m+ autonomous km; 326.2 Mt hauled in 2025; stopping incidents −2/3; resets 4h → 8min**; trucks ~700 extra operating hours/yr at 15% lower cost | [company-reported via trade press](https://www.railjournal.com/in_depth/autohaul-drives-efficiencies-at-rio-tinto/), Mar 2026; [E&MJ](https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/) ⚠ |
| **Fortescue** | The Hive control centre | **4bn tonnes of iron ore moved autonomously in 2024**; 200+ trucks, 4,000 ore cars, six plants | [company-reported via E&MJ](https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/) ⚠ |
| **BHP** | Ship-loader automation; Escondida process AI; BMA autonomous haulage | Port Hedland **+1 Mt/y**; Escondida granulometry losses **−70%** monthly average; **3 GL water and 118 GWh saved since 2022** | [company-reported via E&MJ](https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/) ⚠ |
| **Freeport-McMoRan** | AI optimisation across copper concentrators | **+10% production at Bagdad**; enterprise target +200m lb Cu/yr, **$350–500m EBITDA**; $1.5–2bn *avoided* capex (a counterfactual) | [company-reported via E&MJ](https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/) ⚠ |
| **PG&E (US utility)** | Continuous Monitoring Center on ~5.5m smart meters; Overstory vegetation analytics | 2025: **17 wildfires intercepted, $6m saved, 1,000+ outages prevented, 12m customer-minutes avoided**; **~50% fewer vegetation-triggered ignitions** 2025 vs 2024 | [company-reported via local press](https://www.actionnewsnow.com/pg-e-monitoring-center-prevented-17-fires-saved-6m/article_3c54792d-78dc-4f55-9bf5-7cf1d2601138.html); [Scientific American](https://www.scientificamerican.com/article/how-new-ai-technology-is-helping-detect-and-prevent-wildfires/) |
| **Portland General Electric; Arizona Public Service** | AI wildfire cameras and sensors | PGE 100% camera coverage of high-risk fire zones, ignition location to ±30 ft; APS detections **10–25 minutes faster than 911** | [company-reported](https://www.renewableenergyworld.com/power-grid/outage-management/ai-cameras-satellites-and-grid-sensors-inside-a-utilitys-wildfire-playbook/), Aug 2024 |
| **DEWA (UAE)** | Rammas virtual employee (Arabic and English, seven channels, GPT-4o); agentic AI across web, app and internal platforms | **1.6m inquiries in 2025, 12.7m since 2017**; security-deposit refunds **4 days → 8 minutes** | [company-reported](https://www.tradingview.com/news/reuters.com,2026-01-26:newsml_Zaw6BwQqb:0-dewa-s-virtual-employee-rammas-handled-over-1-6mln-inquiries-in-2025/), Jan 2026; [Zawya](https://www.zawya.com/en/projects/technology-telecom/dubais-dewa-says-ai-cuts-customer-refund-time-from-four-days-to-eight-minutes-417963), Aug 2026 |
| **Google DeepMind** | ML forecasting on 700 MW of wind | *"roughly 20 percent"* increase in the value of wind vs a no-commitment baseline — **Feb 2019, never publicly updated or replicated** | [company-reported](https://deepmind.google/blog/machine-learning-can-boost-the-value-of-wind-energy/), Feb 2019 |
| **Baker Hughes + C3 AI** | Joint venture renewed through June 2028; customers include Shell, Eni, QatarEnergy LNG, ExxonMobil | "More than half a billion dollars" of cumulative O&G and chemicals revenue — vendor-side figure; customer outcomes not disclosed | [vendor-claimed](https://ir.c3.ai/news-releases/news-release-details/c3-ai-and-baker-hughes-renew-and-expand-joint-venture-agreement), May 2025 |

### The reversals worth knowing

**MethaneSAT.** Launched March 2024, lost power 20 June 2025, declared "likely not recoverable" 1 July 2025 ([EDF](https://www.edf.org/media/methanesat-loses-contact-satellite)). Basin-level independent methane quantification regressed within 15 months of launch.

**C3.ai.** Revenue down 19% year on year, guidance withdrawn, a CEO transition and a sales reorganisation in September 2025 — after a decade as the sector's reference enterprise-AI platform. Any operator citing "C3 AI proves the ROI" should know the vendor's own reporting metrics have been contested.

**The Shell "20% downtime" figure.** It circulates widely. It does not appear in the primary Shell/C3 release, which contains no ROI figure at all. Do not use it.

---

## 4. Myths versus reality

| The claim | What the evidence shows | Verdict |
|---|---|---|
| "Predictive maintenance is solved and delivers 20–30% downtime reduction." | Shell monitors 10,000+ assets with ~11,000 models — deployment at scale is proven. But the primary release has **no savings figure**; the model-per-asset ratio shows no generalisation; Teck's disclosed figure is **~$1m/yr at one site** ([E&MJ](https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/)). | **Proven in pockets.** Demand a named asset class and a baseline before accepting any percentage. |
| "AI will decarbonise energy operations." | ADNOC reports up to 1 Mt CO₂ abated over 2022–23. IEA: potential is large, but *"no existing momentum of AI adoption that would unlock these emissions reductions"*; data centres are one of the few sectors where emissions are set to grow. | **Unproven at sector level; proven in narrow instances.** |
| "AI data centres will be powered by renewables." | Fossil fuels supply ~60% of data-centre power today; IEA projects ~60% clean only by 2035; 15–27 GW of onsite gas by 2030; US queue shows gas +86% while solar, wind and storage fell. | **Contradicted** for this decade. Clean-power procurement is real; hourly physical matching for AI load is not. |
| "AI increases oil recovery by X%." | We searched for a peer-reviewed or audited figure linking AI to incremental recovery or reserves and found none. Documented: seismic interpretation 10× faster on a two-field test; legacy seismic reprocessing months → hours; geological modelling up to 75% faster. Mining, by contrast, does claim throughput: Freeport +10% at Bagdad, BHP +1 Mt/y. | **Unproven in oil & gas (recovery); proven in pockets in mining (throughput).** Cycle time, not barrels, is the defensible claim. |
| "Autonomous operations are here." | Mining is the exception: AutoHaul fully autonomous since 2018–19; Fortescue 4bn t moved autonomously in 2024. In oil & gas and utilities, AI safety components in energy supply are high-risk under the EU AI Act; ADNOC's flagship agentic programme targets engineer productivity, not closed-loop field control. | **Proven at scale in mining haulage only.** The dividing line is a fenced pit or private rail corridor versus a safety-instrumented plant or public grid. |
| "Digital twins deliver measured ROI." | Freeport's programme carries a $350–500m EBITDA claim; its largest number ($1.5–2bn) is avoided capex, a counterfactual. Very few twins publish an audited before/after. | **Proven in pockets, weakly evidenced.** Insist on the counterfactual definition. |
| "Machine learning increases the value of wind by 20%." | Real and precisely worded — *"roughly 20 percent, compared to the baseline scenario of no time-based commitments to the grid"* — but 2019, 700 MW, and a baseline of no forecasting desk at all. No update or replication found in 2024–26. | **Proven once, in one configuration, seven years ago.** Not a current benchmark. |
| "AI can relieve the grid bottleneck." | IEA's 175 GW unlockable on existing lines and 30–50% shorter outages are real levers. The binding constraints are five-year interconnection timelines and equipment backlogs. | **Proven in pockets** (dynamic line rating, fault location, restoration); does not address the dominant bottleneck. |
| "Satellite AI has made methane independently verifiable." | MethaneSAT's loss removed the highest-resolution independent layer for diffuse basin-level emissions. Commercial point-source detection persists. | **Contradicted for basin totals; proven in pockets for large point sources.** |
| "Enterprise AI platforms for energy are a mature, low-risk buy." | C3.ai's 19% revenue decline, withdrawn guidance, contested customer counts and historic 45% single-customer concentration. | **Contradicted.** Architect for portability of models and features away from any single platform. |

---

## 5. The Cognirise point of view

**In energy and resources, the AI that has proven itself works alongside the engineer, inside the physics, and in a fenced environment. The AI that has not is anything asking a safety-instrumented plant or a public grid to run itself. Design for the first, and let the second earn its way in one bounded loop at a time.**

The sector's own disclosures make the case. ADNOC's $500m and Aramco's $1.8bn come from subsurface, planning, inspection and diagnostics — engineers doing months of work in hours. Rio Tinto's and Fortescue's autonomy works because a pit and a private rail corridor are controllable spaces. PG&E's wildfire results come from sensing and anticipation, with humans dispatching. The counter-examples — a vendor platform that lost a fifth of its revenue, a satellite that went dark, a wind-forecasting result never replicated — are what happens when the narrative gets ahead of the physics.

Five convictions follow.

**Build agents for the engineer's loop, not the control loop.** The five ENERGYai agents in ADNOC's subsurface workflow, Aramco's seismic reprocessing, GE-style inspection copilots — these are where agentic AI is delivering measured cycle-time compression today, because the human remains the actor and the AI is the analyst. Under the EU AI Act, NERC CIP and IEC 61511, that is also the only pattern a safety case will currently support at scale. Closed-loop control belongs in ring-fenced, low-consequence loops with a functional-safety case attached — RAN-style energy optimisation, not compressor trips.

**Capture the crew-change knowledge before it retires.** The single highest-certainty return in this sector is the institutional memory of a cohort that is leaving: P&IDs annotated in someone's head, shutdown sequences that live in a notebook, the reason a valve is bypassed. A grounded, cited knowledge agent over decades of maintenance records, procedures and incident reports — Arabic and English, mixed-script — has a return that does not depend on any model getting better. It only depends on starting before the knowledge is gone.

**Claim cycle time, not barrels.** No credible public source links AI to a recovery-factor uplift. What is documented, repeatedly, is time: months to hours on seismic; years to weeks on development planning; four days to eight minutes on a DEWA refund. Operators who frame their AI programme around cycle time build credibility with boards, regulators and investors; operators who promise barrels are one audit away from a problem. In mining, where throughput claims *are* documented, insist on the counterfactual definition every time.

**Own the models and the data through sovereign structures; rent the frontier.** The regional template that has actually worked is ADNOC → AIQ (Presight 51%, ADNOC 49%, valued above $1.4bn) → frontier capability from Microsoft, OpenAI and SLB. Aramco → HUMAIN is the Saudi analogue. Subsurface and production data are state assets; training and inference stay in-country; outcomes are announced as national achievements. Architect for portability from day one — the C3.ai episode is the case for it — so the operator's models, features and knowledge survive any single vendor.

**Treat "energy for AI" as strategy, not a side-effect.** The GCC is simultaneously the most aggressive AI-adopting energy region and the fastest-growing supplier of energy to AI: Stargate UAE's 1 GW cluster, HUMAIN's compute-as-a-service, Aramco citing the IEA's data-centre demand forecasts as strategic justification. For a Gulf utility or producer, the load forecast, the interconnection strategy and the AI programme are one conversation. AI can unlock 175 GW on existing lines; it cannot shorten a transformer backlog. Planning around that asymmetry is the job.

### How this maps to Cognirise's service lines

| Service line | In energy & resources this means |
|---|---|
| **Agentic Enterprise Transformation** | Subsurface, development planning, integrity and inspection, and permitting workflows redesigned around engineer-plus-agent operation, with cycle time and engineer capacity as the measured outcomes. |
| **Data & AI Foundations** | Historian, SCADA, seismic and maintenance-record foundations contextualised for AI — with the OT segmentation, model portability and open-data posture the IEA says the sector lacks. |
| **Engineering with AI** | Modernising decades-old engineering and planning software estates with AI-assisted engineering, on-premise where residency requires it. |
| **Sovereign Agentic AI** | The ADNOC/AIQ pattern: a domestically controlled model-and-data layer, frontier capability under residency controls, Arabic–English parity, and a functional-safety case for every loop that closes. |
| **AI-Native Platforms** | A knowledge and operations front door for the workforce — grounded in the operator's own procedures and records, cited, audit-logged — that becomes the institutional memory the crew change would otherwise take with it. |

Our operating principle — *value first, foundations behind value, transformation on proof* — has an energy-specific corollary: **prove it in advisory mode with a measured baseline, then close the loop where the safety case allows — never the other way round.**

---

## 6. High-impact use cases and what the evidence says about returns

| # | Use case | Type | Who has done it | Documented outcome | What to expect and measure | Prerequisites |
|---|---|---|---|---|---|---|
| 1 | **Seismic interpretation and subsurface agents** | Agentic + generative | AIQ + SLB for ADNOC | **10× speed, +70% precision** on 15% of data across two fields [vendor/company-claimed, Aug 2025] — pilot-grade | Interpretation cycle time; interpreter capacity; precision against human benchmark on a held-out field | Interpreted seismic corpus; GPU cluster; in-country residency |
| 2 | **Legacy seismic reprocessing** | Analytical | Aramco | Processing **"months → hours"**; ~10bn data points/day [company-reported, Mar 2025] | New prospects from archived data; reprocessing throughput | Archived raw field data; HPC |
| 3 | **Predictive maintenance on rotating equipment** | Analytical | Shell / C3; Teck / AspenTech | Shell **10,000 assets, 11,000 models, 15m predictions/day**; Teck **~$1m/yr at one site**; **no published % downtime reduction** | Avoided unplanned downtime per asset class against a baseline; false-alert rate; model maintenance cost | Sensor coverage; historian; failure-labelled history; CMMS integration |
| 4 | **Wildfire ignition prevention and grid fault anticipation** | Analytical | PG&E; PGE; APS | PG&E 2025: **17 fires intercepted, $6m saved, 1,000+ outages prevented**; ~50% fewer vegetation ignitions; APS detection 10–25 min faster than 911 [company-reported] | Ignitions per high-risk day; detection lead time; customer-minutes avoided | Smart-meter/AMI data; sensors; camera and satellite feeds; dispatch integration |
| 5 | **Autonomous haulage (truck and rail)** | Agentic (physical) | Rio Tinto; Fortescue; BHP | **7m+ autonomous km; 326.2 Mt in 2025; incidents −2/3; resets 4h → 8min**; trucks +700 hrs/yr at −15% cost; **4bn t autonomously in 2024** [company-reported] | Tonnes per truck-hour; safety incidents; availability. Rio Tinto took 12 years from partnership to full deployment. | Private controlled corridor; comms coverage; remote ops centre; regulator sign-off |
| 6 | **Process and throughput optimisation in minerals processing** | Analytical | Freeport Bagdad; BHP Escondida | **+10% production** (Bagdad); Escondida granulometry losses **−70%**; enterprise target **$350–500m EBITDA** [company-reported ⚠] | Recovery and throughput against a controlled baseline; energy per tonne | Plant historian; assay data; control-system write-back |
| 7 | **Emissions monitoring and methane detection** | Analytical | ADNOC Emission X; MethaneSAT (lost) | ADNOC up to **1 Mt CO₂ abated 2022–23** across the AI portfolio [company-reported]; satellite basin-level capability demonstrated then lost | Detected vs inventoried emissions; time to repair | Continuous monitoring hardware; multi-source tasking; reconciliation to inventory |
| 8 | **Customer-service and back-office agents at utilities** | Generative + agentic | DEWA | **1.6m inquiries in 2025; refunds 4 days → 8 minutes** [company-reported, 2026] | Resolution rate; process cycle time; Arabic and English parity | Bilingual NLU; billing and CRM integration; channel coverage incl. WhatsApp |
| 9 | **Drone and computer-vision asset inspection** | Analytical | Aramco Uthmaniyah Gas Plant | **Pipeline inspection time −90%** [company-reported] | Inspection hours; defects found per km; inspector exposure hours | Flight permissions; defect-labelled imagery; inspection-record integration |
| 10 | **Institutional knowledge capture (crew change)** | Generative, grounded | Pattern implied by ADNOC (80 yrs of data) and Aramco (90+ yrs); no operator has published a stand-alone outcome metric | **No public figure** — but the return is loss-avoidance and is measurable | Time-to-answer for procedural queries; onboarding time for new engineers; incidents traced to lost knowledge | Digitised procedures, records and incident reports; citation and access control |
| 11 | **Renewables output forecasting and market commitment** | Analytical | Google DeepMind | *"roughly 20 percent"* on 700 MW vs no-commitment baseline [2019, unreplicated] | Forecast error; imbalance cost; captured price vs baseline | Turbine SCADA; weather feeds; market access |
| 12 | **Dynamic line rating / capacity on existing lines** | Analytical | IEA modelling | Up to **175 GW** unlockable [regulator/official — **projected**] | MW released per line; regulatory approval time | Line sensors; weather modelling; TSO/ISO rule change |
| 13 | **Power-plant O&M optimisation** | Analytical | IEA modelling | Up to **$110bn/yr by 2035** [regulator/official — **projected**] | Heat rate; forced-outage rate | Plant data access; open data policy |

**A note on returns.** Rows 2, 4, 5, 8 and 9 are documented, sustained operator results. Rows 1, 3, 6 and 7 are documented but pilot-grade, single-site, or lacking a published percentage. Rows 11–13 are stale or projected and must never be presented as achieved. Row 10 has no published figure and is nonetheless one of the highest-certainty returns in the sector.

---

## 7. Case studies

*Structure to follow the shared case-study template (see `case-study-template.md`). Cognirise case studies for this industry to be added — including the Masdar point of view where appropriate.*

---

## 8. Voices

> "While AI is still an energy taker, it is also becoming an energy maker." — **Fatih Birol**, Executive Director, IEA, April 2026

> "ENERGYai marks a major milestone in ADNOC's journey to be the world's most AI-enabled energy company." — **Dr Sultan Ahmed Al Jaber**, Managing Director and Group CEO, ADNOC, November 2024

> "We are using old seismic data, which we utilized in the past and reprocess[ing] it with AI and we are now able to generate new results from old data, which creates great savings." — **Ahmad O. Al-Khowaiter**, EVP Technology & Innovation, Aramco, March 2025

> "Artificial intelligence is no longer an optional technology that organisations add to their operations, but has become a fundamental pillar of smart and sustainable cities." — **Saeed Mohammed Al Tayer**, MD & CEO, DEWA, August 2026

> "Monitoring 10,000 pieces of critical equipment with AI-enabled predictive maintenance is an important milestone for Shell — an ambitious target we had set for 2021 and successfully achieved." — **Dan Jeavons**, VP Computational Science and Digital Innovation, Shell, March 2022

> "The bad news is that financial performance in Q1 was completely unacceptable." — **Thomas M. Siebel**, Founder, C3 AI, September 2025

---

## GCC snapshot (for a sidebar or regional tab)

- **The regional thesis is unusual:** the GCC is at once the most aggressive AI-adopting energy region and the fastest-growing supplier of energy to AI.
- **ADNOC:** explicit goal to be "the world's most AI-enabled energy company"; $500m of AI value in 2023; ENERGYai (Nov 2024); **$340m AIQ contract** (Mar 2025); SLB/Lumi integration (Aug 2025). **AIQ** — Presight 51% / ADNOC 49%, valued above $1.4bn — is the sovereign delivery vehicle and the regional template ([Presight, May 2024](https://www.presight.ai/news/adnoc-g42-and-presight-partner-to-accelerate-ai-solutions-for-the-energy-sector)).
- **Stargate UAE:** 1 GW Abu Dhabi cluster within a 5 GW UAE–US campus; 200 MW live in 2026; first phase targeted Q3 2026 ([OpenAI, May 2025](https://openai.com/index/introducing-stargate-uae/); [The National, Dec 2025](https://www.thenationalnews.com/business/2025/12/05/stargate-uaes-first-phase-to-be-completed-in-third-quarter-of-2026/)).
- **DEWA:** the region's most-documented utility AI programme — Rammas, Watson Advisor, Wisdom, consumption analytics across ~480,000 residential customers; refunds 4 days → 8 minutes.
- **Aramco:** Metabrain; $1.8bn AI-attributed value in 2024; 442 use cases; 1,500 PB; 6,000 AI developers to be trained with Imperial, Caltech and KAUST; investing in **HUMAIN**, PIF's national AI infrastructure vehicle — cheap domestic energy converted into exportable compute.
- **Qatar:** QatarEnergy LNG is a named Baker Hughes/C3 AI customer; deployment scale and outcomes not verifiable from a primary Qatari source.
- **The delivery pattern that has worked:** sovereign JV holds data and models → global vendor supplies frontier capability → outcomes announced as national achievements.
- **Water** is inseparable from power in the Gulf (co-generation). Desalination optimisation and leak detection are the natural adjacencies; no quantified Saudi Water Authority or Kahramaa AI outcome was verifiable from a primary source.
- **Language:** Arabic-language capability is a hard requirement for customer- and workforce-facing systems — Rammas runs in Arabic and English across seven channels; workforce assistants must handle Arabic alongside English technical vocabulary and mixed-script maintenance records.

---

## Sources

Primary sources used on this page (full 41-item index in `research/energy-resources-dossier.md`):

- IEA, *Energy and AI*, 10 Apr 2025 — executive summary https://www.iea.org/reports/energy-and-ai/executive-summary ; AI for energy optimisation https://www.iea.org/reports/energy-and-ai/ai-for-energy-optimisation-and-innovation ; AI and energy security https://www.iea.org/reports/energy-and-ai/ai-and-energy-security
- IEA, *Key Questions on Energy and AI*, 16 Apr 2026 — https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary ; news release — https://www.iea.org/news/data-centre-electricity-use-surged-in-2025-even-with-tightening-bottlenecks-driving-a-scramble-for-solutions
- Carbon Brief, data-centre energy and emissions in context — https://www.carbonbrief.org/ai-five-charts-that-put-data-centre-energy-use-and-emissions-into-context
- Lawrence Berkeley National Laboratory, *Queued Up 2026*, Jun 2026 — https://emp.lbl.gov/queues
- NERC, *2025 Long-Term Reliability Assessment*, Jan 2026 — https://www.nerc.com/pa/RAPA/ra/Reliability%20Assessments%20DL/NERC_LTRA_2025.pdf
- EU AI Act, Annex III — https://artificialintelligenceact.eu/annex/3/
- ADNOC, $500m AI value, 5 Mar 2024 — https://www.adnoc.ae/en/news-and-media/press-releases/2023/$500-million-in-value-generated-by-adnoc-through-deployment-of-ai-solutions-in-2023 ; ENERGYai, 4 Nov 2024 — https://www.adnoc.ae/en/news-and-media/press-releases/2024/adnoc-and-aiq-developing-first-of-a-kind-agentic-ai-solution-for-global-energy-transformation ; AIQ $340m contract, G42, 10 Mar 2025 — https://www.g42.ai/resources/news/aiq-announces-340-million-contract-large-scale-deployment-agentic-ai-across-adnoc-operations ; SLB/AIQ, 7 Aug 2025 — https://www.slb.com/news-and-insights/newsroom/press-release/2025/aiq-slb-energyai-pr ; Presight/AIQ ownership, 1 May 2024 — https://www.presight.ai/news/adnoc-g42-and-presight-partner-to-accelerate-ai-solutions-for-the-energy-sector
- Aramco, *Building the AI future* — https://www.aramco.com/en/what-we-do/energy-innovation/digitalization/building-the-ai-future ; Aramco Europe, 12 Mar 2025 — https://europe.aramco.com/en/news-media/news/2025/aramco-deploys-ai ; Offshore Technology on Metabrain, 4 Mar 2024 — https://www.offshore-technology.com/news/saudi-aramco-unveils-industry-first-generative-ai-model/
- Shell/C3.ai, 8 Mar 2022 — https://ir.c3.ai/news-releases/news-release-details/shell-achieves-major-milestone-scales-artificial-intelligence ; C3.ai/Baker Hughes renewal, 28 May 2025 — https://ir.c3.ai/news-releases/news-release-details/c3-ai-and-baker-hughes-renew-and-expand-joint-venture-agreement ; C3.ai Q1 FY2026, 3 Sep 2025 — https://ir.c3.ai/news-releases/news-release-details/c3-ai-announces-fiscal-first-quarter-2026-financial-results ; CNBC, 2 Jun 2023 — https://www.cnbc.com/2023/06/02/billionaire-tom-siebel-faces-controversy-at-ai-software-vendor-c3ai-.html
- Rio Tinto AutoHaul, International Railway Journal, 9 Mar 2026 — https://www.railjournal.com/in_depth/autohaul-drives-efficiencies-at-rio-tinto/ ; Hitachi — https://www.hitachi.com/en-au/insights/articles/rio-tinto-fully-autonomous-train-technology/ ; mining round-up, E&MJ — https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/ (⚠ publication date not established; verify against annual reports)
- PG&E, Action News Now, 2025 — https://www.actionnewsnow.com/pg-e-monitoring-center-prevented-17-fires-saved-6m/article_3c54792d-78dc-4f55-9bf5-7cf1d2601138.html ; Scientific American — https://www.scientificamerican.com/article/how-new-ai-technology-is-helping-detect-and-prevent-wildfires/ ; Renewable Energy World, 14 Aug 2024 — https://www.renewableenergyworld.com/power-grid/outage-management/ai-cameras-satellites-and-grid-sensors-inside-a-utilitys-wildfire-playbook/
- DEWA: Reuters/Zawya, 26 Jan 2026 — https://www.tradingview.com/news/reuters.com,2026-01-26:newsml_Zaw6BwQqb:0-dewa-s-virtual-employee-rammas-handled-over-1-6mln-inquiries-in-2025/ ; Zawya, 3 Aug 2026 — https://www.zawya.com/en/projects/technology-telecom/dubais-dewa-says-ai-cuts-customer-refund-time-from-four-days-to-eight-minutes-417963 ; DEWA Data Science and AI — https://www.dewa.gov.ae/en/about-us/strategy-excellence/data-science-and-ai
- Google DeepMind, 26 Feb 2019 — https://deepmind.google/blog/machine-learning-can-boost-the-value-of-wind-energy/
- MethaneSAT anomaly report, 6 Nov 2025 — https://www.methanesat.org/project-updates/results-anomaly-investigation-loss-communication-methanesat ; EDF, 1 Jul 2025 — https://www.edf.org/media/methanesat-loses-contact-satellite
- Stargate UAE: OpenAI, 22 May 2025 — https://openai.com/index/introducing-stargate-uae/ ; G42 construction update, 16 Oct 2025 — https://www.prnewswire.com/news-releases/g42-provides-update-on-construction-of-stargate-uae-ai-infrastructure-cluster-302586430.html ; The National, 5 Dec 2025 — https://www.thenationalnews.com/business/2025/12/05/stargate-uaes-first-phase-to-be-completed-in-third-quarter-of-2026/
