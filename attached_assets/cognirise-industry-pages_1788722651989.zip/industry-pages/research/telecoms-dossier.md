# Telecoms & AI — Evidence Dossier
**Scope:** mobile and fixed operators, towercos, telco B2B/techco units, network vendors where they shape operator economics.
**Compiled:** 6 September 2026. Emphasis on evidence published 2024 – September 2026.
**Labelling convention used throughout:** [company-reported] · [vendor-claimed] · [analyst-estimate] · [regulator/official] · [independent study] · [press-reported]

---

## 1. State of the industry from an AI perspective

**1.1 The structural backdrop: growth is ~inflation, capex is not.**
GSMA's *Mobile Economy 2026* (published at MWC Barcelona, 2 March 2026) puts global operator revenue at **$1.19 trillion in 2025 rising to $1.36 trillion by 2030 — roughly 2.7% a year** — against **$1.2 trillion of capex committed over 2025–2030**. Mobile's contribution to global GDP is put at **$7.6tn (6.4%) in 2025 rising to $11.3tn (8.4%) by 2030**, and **57% of connections are forecast to be 5G by 2030**. [regulator/industry-body] ([Mobile World Live, 2 Mar 2026](https://www.mobileworldlive.com/gsma/mobile-sector-gdp-contribution-tipped-to-top-11t)) This is the single most important framing fact for telecom AI: unlike banking or pharma, the industry cannot fund AI out of revenue growth. AI has to be funded out of cost or out of a genuinely new business line.

**1.2 Connectivity scale.** GSMA Intelligence reports **8.8 billion wireless connections and 5.8 billion unique subscribers (~70% of the global population) as of March 2026**. [industry-body] ([GSMA Intelligence, Mar 2026](https://www.gsmaintelligence.com/research/the-mobile-economy-2026))

**1.3 AI is now a stated strategic priority for slightly under half the industry.** GSMA reports **45% of operators named AI-enabled revenue streams a strategic priority** in the Mobile Economy 2026 research. [industry-body] ([Mobile World Live, 2 Mar 2026](https://www.mobileworldlive.com/gsma/mobile-sector-gdp-contribution-tipped-to-top-11t))

**1.4 Scaling is common; *impact* is rare.** McKinsey surveyed **49 telecom operators across six regions in December 2025** (published 26 Feb 2026): **57% are scaling AI use cases across multiple domains, 16% describe AI as the "new normal" across the organisation — but only 12% report having captured "sizable impact."** Notably, the share calling AI a "blockbuster technology" **fell from 61% to 51% year on year**. Average AI allocation is **~9% of IT spend**; just over half have **≥50 FTEs** dedicated to AI. [analyst-estimate] ([McKinsey, 26 Feb 2026](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/telcos-ai-inflection-point-what-leaders-do-to-capture-value))

**1.5 The upside case, clearly labelled as projection.** The same McKinsey work projects **ROIC and EBITDA margins could rise by up to 10 percentage points within five years**, **EBITDA improvement of 20–30%**, **$16bn of new economic value for the US telecom sector by 2030**, **~30% of telecom workforce hours realistically automatable by 2030** and **91% of sector jobs requiring fundamental redesign by 2030**. [analyst-estimate, projected — not documented] ([McKinsey, 26 Feb 2026](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/telcos-ai-inflection-point-what-leaders-do-to-capture-value))

**1.6 BCG's parallel projection.** BCG (25 Feb 2026) models a **"15 percentage-point uplift in EBITDA," "10 percentage-point uplift in EBIT," a "five-year internal rate of return of 20% to 35%,"** with **"productivity gain of 45% to 60%"** in customer care and **"40% to 50%"** in network operations, plus a **"2% to 3% revenue increase."** BCG explicitly notes the organisation "will retain at least 70% of the net benefit and perhaps as much as 90%." All forward-looking. [analyst-estimate, projected] ([BCG, 25 Feb 2026](https://www.bcg.com/publications/2026/the-ai-first-telecommunications-strategy))

**1.7 Vendor-side survey shows near-universal claimed benefit — treat with care.** NVIDIA's fourth annual *State of AI in Telecommunications* (19 Feb 2026; ~1,000 responses, ~250 from operators) reports **90% of operators say AI is increasing annual revenue and reducing costs**, **60% using or assessing generative AI (up from 49% in 2024)**, **89% planning to increase AI spend in 2026 (up from 65% in 2025)**, **77% expect AI-native networks before 6G**, and **88% self-assess at TM Forum autonomy levels 1–3**. Top ROI use cases: autonomous networks (50%), customer service (41%), internal process optimisation (33%). [vendor-claimed survey] ([NVIDIA, 19 Feb 2026](https://blogs.nvidia.com/blog/ai-in-telco-survey-2026))

**1.8 Autonomous network maturity — the honest number.** TM Forum's March 2026 study (125 respondents across 80 companies) finds **21% operating at Level 3 or above, up from 19% the previous year**. TM Forum issued **37 Level-4-progress certifications in November 2025**. A contrasting Accenture data point in the same coverage: **only 22% of telcos expect to reach Level 4 by 2030, with 79% currently at Level 0/1 maturity**. [industry-body / analyst-estimate] ([Fierce Network, Mar 2026](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum))

**1.9 Where AI revenue is actually showing up in reported results.** TM Forum Inform's review of Q1 2026 earnings found: **TELUS 22% revenue growth from AI-enabling capabilities, targeting growth from $800m (2025) to ~$2bn (2028), with its Sovereign AI Factory "sold out of compute capacity within months"**; **Indosat Ooredoo Hutchison (IOH) AI Neocloud generating $16m in Q1 2026 alone versus $28m for all of 2025, targeting $60m for 2026 and $170m contracted over three years**, with **blended ARPU up 15% attributed to an "AI hyperpersonalization strategy"**. [company-reported, via industry-body] ([TM Forum Inform, 2026](https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth))

**1.10 The clearest AI revenue line in the sector is Korean.** SK Telecom reported **AI Data Centre (AIDC) revenue of KRW 136.2bn in Q2 2026, up 92.5% YoY — "the fastest-growing segment among SKT's business areas"** — within consolidated revenue of KRW 4.3591tn (up only 0.5% YoY) and operating income up 67.3%. SKT established **SK Hyper in July 2026** to accelerate AIDC, targeting an initial **5 GW** with phased launches from 2029. [company-reported] ([SK Telecom, 5 Aug 2026](https://news.sktelecom.com/en/3218)) Note the proportion: AIDC is ~3% of group revenue.

**1.11 Capex direction is down, not up.** Dell'Oro Group projects **worldwide telecom capex to decline in 2026**. [analyst-estimate] ([Dell'Oro Group](https://www.delloro.com/news/worldwide-telecom-capex-to-decline-in-2026/)) AI-in-the-network therefore competes against, rather than adds to, existing radio and fibre budgets.

**1.12 Internal AI adoption is measurable and real.** Deutsche Telekom's Annual Report 2025 states **53% of employees regularly use AI at work (November 2025 survey), up 9 percentage points from May 2025**. [company-reported] ([Deutsche Telekom Annual Report 2025](https://report.telekom.com/annual-report-2025/management-report/group-strategy/data-ai.html)) Orange's Live Intelligence platform reached **90,000 employees with 15,000 daily active users** from a 2023 launch. [company-reported] ([Orange Business](https://www.orange-business.com/en/about-us/customer-stories/live-intelligence-orange-has-helped-90000-employees-use-generative-ai))

**1.13 AT&T's inference volume is a useful proxy for scale.** AT&T went from **8 billion tokens a day to 27 billion tokens a day within months**, deployed Ask AT&T to **100,000+ employees with over 50% reporting daily usage**, and reports **up to 90% cost reduction** via model routing to small language models. Chief Data Officer Andy Markus: *"I believe the future of agentic AI is many, many, many small language models."* [company-reported, via press] ([VentureBeat, 26 Feb 2026](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut))

**1.14 Analyst read on MWC 2026: hype has receded.** STL Partners: *"there was less hype on the show floor than in previous years. There was little talk of 6G and the discussions on AI were rooted in real, tangible deployments of AI agents and lucid dialogue on their current limitations."* [analyst-estimate] ([STL Partners, Mar 2026](https://stlpartners.com/research/mwc-2026-ai-realism/))

**1.15 GSMA Intelligence notes a misallocation.** At MWC 2026, GSMA observed **underinvestment in AI core-network applications despite their proven ROI, while AI-RAN captured disproportionate attention**. Peter Jarich (Head of GSMA Intelligence): *"We've had a year of learnings and so over the last year people kind of figured how to use it."* [industry-body] ([RCR Wireless, 25 Mar 2026](https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2))

**1.16 The regulator has now formally entered the frame.** Ofcom launched a Call for Input on AI's impact on UK broadband and mobile customers, **closing 10 March 2026, with findings expected in H2 2026** — covering customer service handling, vulnerable-consumer protections, and whether existing rules suffice. [regulator/official] ([ISPreview, Jan 2026](https://www.ispreview.co.uk/index.php/2026/01/ofcom-examines-impact-of-ai-on-the-experience-of-uk-telecoms-customers.html))

---

## 2. Challenges in the AI era specific to telecoms

**2.1 AI must be funded from a shrinking cost base, not from growth.**
With revenue CAGR at ~2.7% to 2030 and capex declining, telecom AI business cases are almost entirely opex-substitution or capex-deferral cases. This is materially different from sectors where AI can be pitched against revenue expansion. GSMA/Dell'Oro sources above. The consequence: AI projects in telcos are judged against a hurdle set by ROIC-versus-WACC pressure, so **any use case whose payback is >24 months struggles for funding**, which is precisely the profile of network-AI platform work.

**2.2 The RAN is the biggest cost pool and the hardest place to put AI economically.**
Light Reading's analysis of AI-in-RAN economics quotes Fujitsu that matching GPU AI performance with standard CPUs "would require 10 times or more CPUs to equal one GPU," while Dean Bubley (Disruptive Wireless) says: *"I can buy the notion that secondary network apps could live there... But I'm unconvinced by the mass market cloud/edge pitch."* Milind Kulkarni (InterDigital) argues high-performance LLMs are unnecessary for RAN operations. ([Light Reading, 28 Feb 2024](https://www.lightreading.com/ai-machine-learning/the-questionable-economics-of-ai-in-the-ran)) Two years later the caution persists: Alok Shah, VP Strategy & Marketing, Samsung Electronics America: *"The wholesale shift to GPU compute at the cell site has shown challenges in both capex and opex,"* with only *"a subset of locations where the math works in the coming years."* [vendor-stated] ([Fierce Network, 22 Dec 2025](https://www.fierce-network.com/wireless/ai-ran-2026-what-lies-ahead))

**2.3 Telcos are structurally disadvantaged as AI compute providers.**
An RCR Wireless analyst assessment (30 Oct 2025) sets out the arithmetic: global hyperscalers achieve **60–70% GPU utilisation through worldwide load-balancing, while regional telco clusters reach only 30–50%** because of geographic constraints — *"a utilization trap."* Latency-optimised inference costs roughly **50x** batch inference (*"$0.10 per million tokens on optimized hardware... $5.00 or more per million tokens"* latency-optimised), which caps the addressable market for edge inference. And *"telcos are not software companies"* — building hyperscaler-grade orchestration/MLOps would require billions. [analyst-estimate] ([RCR Wireless, 30 Oct 2025](https://www.rcrwireless.com/20251030/analyst-angle/telecom-gpu-as-a-service))

**2.4 Customer-service AI is now a visible regulatory and reputational risk, not just a cost lever.**
Which?'s March 2026 submission to Ofcom flags **AI chatbots struggling with "accurate and relevant information," reduced human service affecting vulnerable consumers, "fairness issues" from personalised pricing targeting vulnerable groups, and "agentic misalignment"** where AI actions diverge from customer preferences. ([Which?, Mar 2026](https://www.which.co.uk/policy-and-insight/article/the-impact-of-ai-adoption-for-telecoms-customers-which-response-aWKz12b5Mk9s)) Telcos are among the most-complained-about industries in most markets, so care AI errors surface in published regulator league tables within a quarter.

**2.5 The network data that telcos hold is operationally rich but legally constrained.**
Telefónica built Kernel explicitly on a **"Privacy-by-Design" architecture** so that generative AI could touch customer data at all; CDO Chema Alonso: *"The field of generative AI has experienced significant growth, but privacy issues have also arisen."* [company-reported] ([Telefónica, 26 Feb 2024](https://www.telefonica.com/en/communication-room/press-room/telefonica-partners-with-microsoft-to-incorporate-generative-ai-into-kernel/)) Telecom metadata (location, CDRs, DPI-derived signals) sits under sector-specific confidentiality-of-communications law in the EU (ePrivacy) on top of GDPR and now the EU AI Act — a stricter regime than generic customer data in retail or banking. This is the core reason "monetise network data with AI" has under-delivered (see §4).

**2.6 Autonomy is domain-fragmented, so "Level 4" is not a company-level claim.**
TM Forum's own framing is that operators are "most... positioned between Levels 2 and 3" with some "advancing rapidly toward Level 4 *in specific domains*." China Mobile's Level 4 is in **network operations centres**; Rakuten's Level-4 validation is in **RAN energy conservation**. There is no operator at Level 4 end-to-end. ([Fierce Network, Mar 2026](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum); [RCR Wireless, 23 Jul 2026](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile))

**2.7 Organisational diffusion, not model capability, is the binding constraint.**
Sachin Verma, Chief Data and AI Officer, Rakuten Mobile: *"The technology is growing at a pace, but the diffusion of technology in an enterprise is pretty low."* [company-reported] ([RCR Wireless, 23 Jul 2026](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile)) Orange's Steve Jarrett: *"We're at the crawling stage of managing these systems at massive scale. It is another multiyear transformation."* ([TM Forum Inform, 22 Jan 2026](https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai))

**2.8 Sovereignty requirements fragment the AI estate.**
Deutsche Telekom's Industrial AI Cloud, e&/Core42's UAE platform, stc/HUMAIN in Saudi and Ooredoo in Qatar all exist because workloads cannot leave the jurisdiction. GSMA noted France's **2027 mandate for domestically-developed communications solutions** as a driver. ([RCR Wireless, 25 Mar 2026](https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2)) For a multinational group this means running several parallel AI stacks — a real, recurring cost that does not appear in single-market ROI models.

---

## 3. What key players are doing

| # | Organisation | What was deployed | Scale / outcome | Label | Source & date |
|---|---|---|---|---|---|
| 1 | **AT&T** | Ask AT&T, Ask AT&T Workflows (drag-and-drop agent builder), Ask Data with Relational Knowledge Graph; model routing to SLMs | 100,000+ employees, >50% daily use; 8bn → 27bn tokens/day; **up to 90% AI cost reduction**; internal data products built in 20 minutes vs 6 weeks | [company-reported] | [VentureBeat, 26 Feb 2026](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut) |
| 2 | **Verizon** | Google Cloud Gemini: Personal Research Assistant, Problem Solver, Conversational Agents on Vertex AI | **28,000 customer care reps and retail stores**; **95% comprehensive answerability** claimed. Sampath Sowmyanarayan (CEO, Verizon Consumer) called it "a significant advance" | [company/vendor-reported] | [Google Cloud, 9 Apr 2025](https://www.googlecloudpresscorner.com/2025-04-09-Google-Cloud-and-Verizon-Drive-Customer-Experience-Improvements-for-Verizon-Customers-with-Gemini-Integration) |
| 3 | **Vodafone** | SuperTOBi (Azure OpenAI) replacing keyword TOBi; SuperAgent, SuperSearch | Portugal: **first-time resolution 15% → 60%; NPS +14 points to 64**. Launched Italy/Portugal, then Germany/Turkey; TOBi in 13 countries, 11 languages. **€140m FY2024** CX investment; 10-year Microsoft partnership announced Jan 2024 | [company-reported] | [Vodafone, 4 Jul 2024](https://www.vodafone.com/news/newsroom/technology/meet-super-tobi-vodafone-s-new-generative-ai-virtual-assistant-now-serving-customers-in-multiple-countries); [Vodafone/Microsoft](https://www.vodafone.com/news/corporate-and-financial/vodafone-microsoft-sign-10-year-strategic-partnership-generative-ai-digital-services-cloud) |
| 4 | **Deutsche Telekom** | Industrial AI Cloud (Munich, with NVIDIA); Frag Magenta (gen-AI customer assistant); AskT internal chatbot; T Phone 3 / T Tablet 2 with Perplexity | AI factory live **4 Feb 2026**, **~10,000 NVIDIA Blackwell GPUs, up to 0.5 ExaFLOPS**, partners SAP/Siemens/Polarise, first customers Agile Robots and PhysicsX, **operating at just over one-third capacity**. **53% of employees regularly use AI (Nov 2025)**. Frag Magenta named "best digital assistant 2025" (Chip test) | [company-reported] | [Deutsche Telekom, 4 Feb 2026](https://www.telekom.com/en/media/media-information/archive/germany-s-first-ai-factory-for-industry-1101670); [DT Annual Report 2025](https://report.telekom.com/annual-report-2025/management-report/group-strategy/data-ai.html) |
| 5 | **SoftBank (Japan)** | AITRAS AI-RAN with NVIDIA | **~30% improvement in 5G speeds** via Transformer-based signal processing (Aug 2025, 3GPP-compliant, real-time); **~3x spectral efficiency and throughput** from 16-layer MU-MIMO outdoors (Oct 2025); one AITRAS server ran **20 cells (100MHz 4T4R)** plus video to 100 devices, LLM robots and autonomous driving. Commercial deployment targeted **FY2026 onward**. No revenue or cost figures disclosed | [company-reported] | [SoftBank](https://www.softbank.jp/en/corp/technology/research/topics/224/) |
| 6 | **SK Telecom** | AI Data Centre business; A.X K2 model (29 Jul 2026); SK Hyper (Jul 2026) | **AIDC revenue KRW 136.2bn in Q2 2026, +92.5% YoY**; group revenue +0.5%, operating income +67.3%. Initial **5 GW** target, phased from 2029 | [company-reported] | [SK Telecom, 5 Aug 2026](https://news.sktelecom.com/en/3218) |
| 7 | **Rakuten Mobile** | Nationwide RAN Intelligent Controller with rApps; closed-loop autonomous RAN energy management (TM Forum Level 4 validated); AI fraud detection on Rakuten Card | **20% RAN energy conservation**; **17–20% power bill reduction across Japan ≈ ¥1bn/year**; fraud pilot cut **risky transactions 33% within two weeks** | [company-reported] | [RCR Wireless, 23 Jul 2026](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile) |
| 8 | **Virgin Media O2 (UK)** | Natural Language Understanding call routing plus cross-skilling of 5,000 agents | **1.3 million call transfers avoided in 2025**; **400,000+ customer hours saved (1.45bn seconds)**; **complaints down 50% over 12 months** per Ofcom stats. Alan Stott, Director of Customer Contact quoted | [company-reported] | [Virgin Media O2, 15 Jan 2026](https://news.virginmediao2.co.uk/ai-helps-virgin-media-o2-avoid-over-one-million-call-transfers-as-it-saves-customers-more-than-400000-hours-of-time-on-the-phone/) |
| 9 | **Telstra (Australia)** | Ask Telstra; One Sentence Summary (Azure OpenAI) | One Sentence Summary: **90% of agents reported time savings**; calls required **20% less follow-up contact** (100-agent 2023 trial). Ask Telstra: **84% of ~200 trial agents** said positive impact on interactions. Rohit Lakhotia, GM Customer and Channel AI, quoted | [vendor-claimed (Microsoft customer story), company-sourced metrics] | [Microsoft, 23 Feb 2024](https://www.microsoft.com/en/customers/story/1740058425924206437-telstra-telecommunications-azure-openai-service) |
| 10 | **Orange** | Live Intelligence internal gen-AI platform, later productised for B2B; Ivory Coast contact-centre chatbot; data mesh | **90,000 employees, 15,000 daily actives**; ~1,500 use cases identified early; **€300m value generation targeted for 2025** across four domains; per-user monthly CO₂ tracking | [company-reported] | [TM Forum Inform, 22 Jan 2026](https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai); [Orange Business](https://www.orange-business.com/en/about-us/customer-stories/live-intelligence-orange-has-helped-90000-employees-use-generative-ai) |
| 11 | **China Mobile** | Level 4 autonomy in network operations centres | **>30% reduction in backend O&M manpower**; **30% reduction in MTTR** | [company-reported via TM Forum] | [Fierce Network, Mar 2026](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum) |
| 12 | **Bharti Airtel (India)** | Network-side AI spam/scam detection across voice and SMS | **8 billion spam calls and 0.8 billion spam SMS blocked** (reported Dec 2024); state-level figures include **51 million spam calls detected in Rajasthan** and **157 million in 18 days** nationally | [company-reported via press] | [Business Standard, 9 Dec 2024](https://www.business-standard.com/companies/news/ai-powered-solution-helped-block-8-bn-spam-calls-0-8-bn-smses-airtel-124120900456_1.html); [Airtel, Apr 2025](https://www.airtel.in/press-release/04-2025/airtel-announces-new-features-in-its-continued-fight-against-spam) |
| 13 | **Telkomsel (Indonesia)** | AI-driven predictive network operations, east Indonesia trials | **12.6% reduction in wireless traffic loss** | [company-reported via TM Forum] | [Fierce Network, Mar 2026](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum) |
| 14 | **TELUS (Canada)** | Sovereign AI Factory (NVIDIA Cloud Partner) + AI-enabling services | **22% revenue growth from AI-enabling capabilities in Q1 2026**; AI revenue target **$800m (2025) → ~$2bn (2028)**; sovereign AI factory **"sold out of compute capacity within months"** | [company-reported] | [TM Forum Inform, 2026](https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth) |
| 15 | **Indosat Ooredoo Hutchison** | AI Neocloud; "AI hyperpersonalization" in commercial ops | Q1 2026 revenue **IDR 15.2tn (US$867m), +12% YoY, highest ever**; **blended ARPU +15%** attributed to AI personalisation; **Neocloud $16m in Q1 2026 vs $28m for all 2025**; targets $60m (2026), $170m contracted over 3 years | [company-reported] | [TM Forum Inform, 2026](https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth) |
| 16 | **KDDI (Japan)** | Osaka Sakai Data Center with HPE; NVIDIA GB200 NVL72; GPU cloud service | Operational **22 January 2026**; ~57,000 m² floor space; 100% renewable energy; GPU cloud in **trial from 22 Jan 2026, general applications from 1 Apr 2026**; named customer Takeda Pharmaceutical from April 2026 | [company-reported] | [KDDI, Jan 2026](https://newsroom.kddi.com/english/news/detail/kddi_nr-916_4323.html) |

### Documented reversals, scale-backs and overstated claims

**A. BT: the "AI will cut 55,000 jobs" story does not survive the numbers.**
BT's headline plan to reduce to 75,000–90,000 staff by 2030 was widely reported as AI-driven, and CEO Allison Kirkby hinted in June 2025 that AI could take cuts further. But Light Reading's May 2026 analysis of BT's own reporting is blunt: **"Despite the incessant messaging about AI, very little of this was caused by the newfangled technology."** BT was at **77,152 direct employees in March 2026** (~130,000 including contractors), having cut 8,500 in the year and **over 22,000 since 2025**; the reductions are attributed to network modernisation, legacy technology retirement and declining sales. Savings target was **raised from £3bn by 2029 to £3.7bn by 2030**, with CFO Simon Lowth citing **"cumulative gross cost savings of £6.7 billion over the decade to FY30"** driven partly by reduced operational complexity. [press-reported analysis of company data] ([Light Reading, 21 May 2026](https://www.lightreading.com/fttx/bt-plans-mass-layoffs-after-cutting-8-500-jobs-in-last-year); [The Register, 16 Jun 2025](https://www.theregister.com/2025/06/16/bt_chief_says_ai_could_cut_more_staff/))
**Reading:** the largest publicly attributed "AI job cut" in European telecoms is mostly not an AI job cut.

**B. Verizon: the same Gemini deployment that produced a positive press release produced a documented consumer backlash.**
Verizon integrated Gemini into its consumer Verizon Assistant chatbot (announced June 2025). By **15 September 2025**, complaints were widespread across Reddit, Bluesky and X: users in SOS mode advised to "use Wifi and not use the cellular network"; customers mentioning competitor offers told *"Sorry. I am unable to help you with that"*; at least one account flagged for possible fraud after repeated requests for a live agent. Context: Verizon had **lost 289,000 subscribers in Q1 2025**. [press-reported] ([Yahoo Tech, Sep 2025](https://tech.yahoo.com/ai/articles/verizons-google-powered-chatbot-frustrates-201903926.html))
**Reading:** agent-assist (28,000 reps, 95% answerability) and customer-facing self-service are different products with different risk profiles. The first is well-evidenced; the second went wrong in public.

**C. T-Mobile IntentCX: announced with unusual specificity, never substantiated.**
T-Mobile and OpenAI announced IntentCX in **September 2024** as a *"first-ever intent-driven AI-decisioning platform,"* with launch planned for 2025. As of September 2026 I could find **no company-reported launch announcement, deployment scale, or outcome metrics** for IntentCX from T-Mobile or OpenAI. Searches for status updates returned only the original announcement and unrelated T-Mobile layoff coverage. Treat the platform as announced-but-unverified. [announced; not verified] ([T-Mobile/Businesswire, 17 Sep 2024](https://www.businesswire.com/news/home/20240917013945/en/T-Mobile-and-OpenAI-Join-Forces-to-Revolutionize-the-Customer-Experience-with-First-Ever-Intent-Driven-AI-Decisioning-Platform))

**D. Deutsche Telekom's Industrial AI Cloud is running at ~one-third capacity.**
DT's own launch communication (4 Feb 2026) states the facility is **"operating at over one-third capacity with existing customers"** — with two named customers (Agile Robots, PhysicsX). That is a candid disclosure and a useful reality check on "sold-out sovereign AI factory" narratives. [company-reported] ([Deutsche Telekom, 4 Feb 2026](https://www.telekom.com/en/media/media-information/archive/germany-s-first-ai-factory-for-industry-1101670))

---

## 4. Proven vs. not proven — myths tested

**Myth 1: "AI will make networks self-driving."**
*Evidence for:* China Mobile at Level 4 in NOCs (>30% backend O&M manpower cut, 30% MTTR cut); Rakuten Level-4-validated RAN energy autonomy; TDC NET and Ericsson achieved an industry-first TM Forum Level 4 autonomy certification (June 2025); TM Forum issued 37 L4-progress certifications in Nov 2025.
*Evidence against:* only **21% of operators are at Level 3 or above** overall (TM Forum, Mar 2026), most sit between L2 and L3; Accenture data cited alongside indicates **79% at Level 0/1 and only 22% expecting L4 by 2030**. Every L4 claim is domain-bounded.
**Verdict: Proven in pockets (single domains), Unproven end-to-end.** ([TM Forum via Fierce, Mar 2026](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum); [Ericsson, Jun 2025](https://www.ericsson.com/en/news/2025/6/tdc-net-and-ericsson-achieves-industry-first-certification-from-tm-forum-of-level-4-autonomy))

**Myth 2: "Telcos will become AI companies and sell AI compute profitably."**
*Evidence for:* SK Telecom AIDC revenue +92.5% YoY to KRW 136.2bn (Q2 2026); TELUS +22% AI-enabling revenue growth with a sovereign AI factory sold out of capacity; IOH Neocloud $16m in one quarter against $28m for the prior full year.
*Evidence against:* the structural argument — telco GPU clusters run **30–50% utilisation vs hyperscalers' 60–70%**; latency-optimised inference costs ~50x batch; *"telcos are not software companies"* (RCR analyst, Oct 2025). DT's own AI factory at **just over one-third capacity** four months from launch. SKT's AIDC is ~3% of group revenue. **No operator has published a margin figure for AI compute.**
**Verdict: Proven in pockets on revenue; Unproven on profitability.** ([RCR Wireless, 30 Oct 2025](https://www.rcrwireless.com/20251030/analyst-angle/telecom-gpu-as-a-service); [SK Telecom, 5 Aug 2026](https://news.sktelecom.com/en/3218); [TM Forum Inform, 2026](https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth))

**Myth 3: "Gen-AI care bots massively reduce cost-to-serve."**
*Evidence for:* Vodafone Portugal first-time resolution **15% → 60%** and NPS **+14 to 64**; VMO2 **1.3m transfers avoided, 400,000 customer hours saved in 2025, complaints down 50%**; Telstra **20% less follow-up contact**; Verizon **28,000 reps** with **95% answerability**.
*Evidence against:* almost none of these are *cost* figures. Vodafone reports resolution and NPS, not cost-to-serve. VMO2 reports customer hours saved, not operator opex saved. Telstra reports follow-up reduction from a 100-agent trial. Ofcom is now formally investigating whether AI is helping or harming customers (input closed 10 Mar 2026, findings H2 2026), and Which? has raised accuracy and vulnerable-consumer concerns. Verizon's consumer bot generated a documented backlash.
**Verdict: Proven in pockets on service quality; largely Unproven on cost-to-serve** — the sector reports experience metrics, not unit economics.

**Myth 4: "AI churn models move the needle on churn."**
I searched specifically for a named operator publishing a churn-rate reduction attributable to an AI churn model, 2024–2026. **I could not find one.** What exists is: McKinsey citing Entel Connect with a **40% increase in inbound sales within 10 weeks** (a sales, not churn, metric); IOH's **15% blended ARPU rise** attributed to "AI hyperpersonalization"; and a large body of academic and vendor material on churn-model *accuracy* (e.g. SHAP-based ensembles) with no operator P&L outcome. Verizon's chatbot period coincided with **289,000 subscriber losses in Q1 2025**.
**Verdict: Unproven at the level of reported churn rates.** ([McKinsey, 26 Feb 2026](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/telcos-ai-inflection-point-what-leaders-do-to-capture-value); [Frontiers in AI, 2026](https://www.frontiersin.org/journals/artificial-intelligence/articles/10.3389/frai.2026.1748799/full))

**Myth 5: "AI-RAN pays for itself."**
*Evidence for:* SoftBank's ~30% 5G speed improvement and ~3x spectral efficiency/throughput on 16-layer MU-MIMO; Fujitsu's uplink demonstration (252 → 366 Mbit/s).
*Evidence against:* Samsung's Alok Shah — *"The wholesale shift to GPU compute at the cell site has shown challenges in both capex and opex"*, with only *"a subset of locations where the math works."* Ericsson has built a competing commercial position explicitly **without GPUs**, selling AI-in-RAN as a software subscription claiming **up to 20% higher downlink throughput and 10% better spectral efficiency** on existing hardware — a vendor voting with its product roadmap against GPU-at-the-cell-site economics. Dean Bubley remains *"unconvinced by the mass market cloud/edge pitch."* SoftBank has published no cost, revenue or payback figure.
**Verdict: Technically proven in trials; economically Unproven.** ([Fierce Network, 22 Dec 2025](https://www.fierce-network.com/wireless/ai-ran-2026-what-lies-ahead); [Mobile Europe, 11 Jun 2026](https://www.mobileeurope.co.uk/ericssons-monetisation-plan-for-ai-in-ran-without-gpus/); [Light Reading, 28 Feb 2024](https://www.lightreading.com/ai-machine-learning/the-questionable-economics-of-ai-in-the-ran))

**Myth 6: "Telcos will monetise network data with AI."**
*Evidence for:* GSMA reports 45% of operators name AI-enabled revenue streams a strategic priority; network API/CAMARA activity continues.
*Evidence against:* GSMA Intelligence's own MWC 2026 observation is that operators are **underinvesting in AI core-network applications despite proven ROI** while chasing AI-RAN attention. Telefónica needed a full Privacy-by-Design re-architecture of Kernel before generative AI could touch customer data at all. I found **no operator disclosing a material revenue line from AI-driven network-data products** in 2024–2026 results; the disclosed AI revenue lines (SKT, TELUS, IOH) are **compute and services**, not data.
**Verdict: Unproven.** ([RCR Wireless, 25 Mar 2026](https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2); [Telefónica, 26 Feb 2024](https://www.telefonica.com/en/communication-room/press-room/telefonica-partners-with-microsoft-to-incorporate-generative-ai-into-kernel/))

**Myth 7: "AI is driving telecom job cuts."**
*Contradicted in the flagship case.* BT — the sector's most-cited AI-job-cuts story — reduced to 77,152 employees by March 2026, but Light Reading's analysis of the drivers concludes *"very little of this was caused by the newfangled technology,"* attributing cuts to network modernisation, legacy retirement and falling sales.
**Verdict: Contradicted (in the most-cited case).** ([Light Reading, 21 May 2026](https://www.lightreading.com/fttx/bt-plans-mass-layoffs-after-cutting-8-500-jobs-in-last-year))

**Myth 8: "AI cuts RAN energy consumption significantly."**
*Evidence for:* Vodafone UK/Ericsson trial — **up to 33% daily power reduction for 5G radio units**, and **up to 70% energy savings during low-traffic periods** via 5G Deep Sleep, across select London sites (Mar 2025), claimed *"without impacting user experience."* Rakuten Mobile reports **20% RAN energy conservation** and a **17–20% power bill reduction across Japan (~¥1bn/year)** at national scale.
*Caveats:* the Vodafone figure is a **trial** at unspecified site count with no independent verification and no published traffic-impact data. Rakuten's is nationwide and operator-reported.
**Verdict: Proven at scale in at least one national network (Rakuten); Proven in pockets elsewhere.** ([Ericsson, 11 Mar 2025](https://www.ericsson.com/en/press-releases/3/2025/vodafone-uk-and-ericsson-trial-ai-solutions-for-improved-5g-energy-efficiency); [RCR Wireless, 23 Jul 2026](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile))

**Myth 9: "Big-model gen-AI is the right architecture for telco workloads."**
*Contradicted by the largest deployer.* AT&T routes to small language models and reports **up to 90% cost reduction**, with CDO Andy Markus stating SLMs are *"just about as accurate"* as large models in specific domains. InterDigital's Milind Kulkarni makes the same argument for RAN. **Verdict: Contradicted.** ([VentureBeat, 26 Feb 2026](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut))

**Myth 10: "Network AI is where the money is."**
GSMA Intelligence's MWC 2026 read is the opposite: the **proven-ROI core-network AI applications are underinvested** while AI-RAN absorbs attention. The reported revenue lines are AI data centres and B2B services. **Verdict: Contradicted for 2024–26; the money to date is in compute and care, not radio.**

---

## 5. High-impact use cases with ROI evidence

**1. Agent-assist in customer care (generative + retrieval).**
*Who:* Verizon (Personal Research Assistant, Problem Solver — 28,000 reps, 95% answerability, Apr 2025) [company/vendor-reported]; Telstra (One Sentence Summary — 90% of agents reported time savings, 20% less follow-up contact; Ask Telstra — 84% positive impact, Feb 2024) [vendor-claimed with company metrics]; Virgin Media O2 Lumi AI real-time agent assistance [company-reported].
*Prerequisites:* unified customer/knowledge corpus, call transcription, CRM integration, agent workflow redesign.
*Time-to-value:* Telstra trialled with 100–200 agents in 2023 and reached full deployment early 2025 — roughly 18 months trial-to-scale.
*Classification:* generative/retrieval, human-in-the-loop. **ROI documented on handling metrics; not on opex.**

**2. Customer-facing gen-AI virtual assistant.**
*Who:* Vodafone SuperTOBi — Portugal first-time resolution **15% → 60%**, NPS **+14 to 64**, €140m FY2024 investment, 13 countries / 11 languages base [company-reported, Jul 2024].
*Counter-evidence:* Verizon Assistant backlash, Sept 2025 [press-reported].
*Prerequisites:* escalation-to-human design, multilingual coverage, vulnerable-customer handling (now a live Ofcom concern).
*Classification:* generative. **ROI documented on resolution/NPS; contested on customer experience; not documented on cost.**

**3. Intelligent call routing / transfer avoidance.**
*Who:* Virgin Media O2 — **1.3m transfers avoided, 400,000+ customer hours saved in 2025, complaints down 50%**, combined with cross-skilling 5,000 agents [company-reported, Jan 2026].
*Prerequisites:* NLU on inbound intent, skills taxonomy, and — critically — the agent cross-skilling that makes routing decisions actionable.
*Classification:* analytical/NLU. **ROI documented; note the human-side change was co-equal with the AI.**

**4. Autonomous network operations centre (Level 4 in-domain).**
*Who:* China Mobile — **>30% reduction in backend O&M manpower, 30% MTTR reduction** [company-reported via TM Forum, Mar 2026].
*Prerequisites:* normalised alarm/telemetry, closed-loop execution rights, TM Forum-style autonomy governance.
*Classification:* agentic (closed-loop). **ROI documented — the strongest hard-cost evidence in the dossier.**

**5. AI-driven RAN energy optimisation.**
*Who:* Rakuten Mobile — **20% RAN energy conservation, 17–20% power bill reduction nationwide, ~¥1bn/year**, TM Forum Level 4 validated [company-reported, Jul 2026]; Vodafone UK/Ericsson — **up to 33% daily 5G radio-unit power reduction; up to 70% during low-traffic periods** [vendor-claimed trial, Mar 2025].
*Prerequisites:* RIC/rApp platform or vendor energy-management suite, traffic-prediction models, tolerance for sleep-mode wake latency.
*Classification:* analytical + closed-loop agentic. **ROI documented at national scale in one case.**

**6. Predictive fault detection / traffic-loss prevention.**
*Who:* Telkomsel — **12.6% reduction in wireless traffic loss** in east Indonesia AI predictive-operations trials [company-reported via TM Forum, Mar 2026]; T-Mobile deployed **30,000 antenna adjustments during Winter Storm Fern** to maintain connectivity [company-reported via TM Forum].
*Prerequisites:* historical fault/telemetry labels, topology model, field-dispatch integration.
*Classification:* analytical → agentic.

**7. Network spam, scam and fraud detection.**
*Who:* Bharti Airtel — **8bn spam calls and 0.8bn spam SMS blocked** [company-reported, Dec 2024]; **51 million spam calls detected in Rajasthan**, **157 million in 18 days** nationally [press-reported]; Rakuten Card fraud pilot — **33% reduction in risky transactions in two weeks** [company-reported, Jul 2026].
*Prerequisites:* real-time signalling/CDR pipeline, lawful basis for content-adjacent inspection, low false-positive tolerance (blocking legitimate traffic is a regulatory event).
*Classification:* analytical, real-time.
*Note:* SIM-box and Wangiri detection is a mature ML domain, but I could not find an operator publishing a **recovered-revenue** figure for AI-based SIM-box detection in 2024–26; available material is vendor (Subex, Neural Technologies, Synaptique) or academic (Ethio-Telecom deep-learning case study). Treat quantified SIM-box ROI as unverified.

**8. Enterprise-wide employee AI assistant.**
*Who:* AT&T Ask AT&T — **100,000+ employees, >50% daily use**, internal data products in **20 minutes vs 6 weeks**, **up to 90% cost reduction** from SLM routing [company-reported, Feb 2026]; Orange Live Intelligence — **90,000 employees, 15,000 DAU**, **€300m value target for 2025**, later sold as a B2B product [company-reported, Jan 2026]; Deutsche Telekom AskT and **53% regular employee AI use** [company-reported].
*Prerequisites:* internal knowledge access controls, model routing/FinOps, adoption programme.
*Time-to-value:* Orange "brought Live Intelligence to life in just a few months" from a 2023 start.
*Classification:* generative, with agentic workflow builders emerging (Ask AT&T Workflows).
*Caveat:* Orange's €300m is a **target**, not a reported outcome.

**9. AI-RAN / signal processing acceleration.**
*Who:* SoftBank AITRAS — **~30% 5G speed improvement**, **~3x spectral efficiency and throughput** at 16 layers, **20 cells on one server** [company-reported, 2025]; Ericsson's GPU-free alternative claims **up to 20% higher downlink throughput, 10% better spectral efficiency, 90–95% accurate coverage prediction, 5x more precise positioning** [vendor-claimed, Jun 2026].
*Prerequisites:* virtualised/open RAN, GPU or accelerator estate, spectrum where capacity is genuinely the constraint.
*Classification:* analytical/inference in the datapath. **Performance proven; ROI projected only.**

**10. Sovereign AI factory / GPU-as-a-service.**
*Who:* SK Telecom **AIDC KRW 136.2bn, +92.5% YoY** [company-reported, Aug 2026]; TELUS **+22% AI-enabling revenue, $800m → ~$2bn by 2028, capacity sold out** [company-reported]; IOH Neocloud **$16m in Q1 2026, $60m 2026 target, $170m contracted over 3 years** [company-reported]; Deutsche Telekom Industrial AI Cloud **~10,000 Blackwell GPUs, 0.5 ExaFLOPS, one-third utilised** [company-reported, Feb 2026]; KDDI Osaka Sakai live 22 Jan 2026 [company-reported].
*Prerequisites:* power and land, sovereignty demand, an anchor tenant, and a software/orchestration layer telcos do not natively have.
*Classification:* infrastructure, not AI per se. **Revenue documented; profitability undocumented.**

**11. Capex reprioritisation using AI.**
*Who:* NTT DOCOMO — **10–30% of planned capex interventions found reprioritisable** [analyst-reported via McKinsey, Feb 2026]. Given capex intensity is the industry's defining problem, this is arguably the highest-leverage use case in the list, and the least discussed.
*Prerequisites:* unified network performance + demand + financial data; a planning process willing to be overruled.
*Classification:* analytical/decision support.

**12. AI-assisted sales in inbound care.**
*Who:* Entel Connect — **40% increase in inbound sales within 10 weeks** [analyst-reported via McKinsey, Feb 2026]; Verizon reports customer-service-led AI sales improvement [company-reported].
*Time-to-value:* 10 weeks, the fastest documented in this dossier.
*Classification:* generative + recommendation.

---

## 6. GCC / MENA specifics

### 6.1 The regional pattern: telcos as national AI infrastructure
Unlike Europe or North America, GCC operators are majority state-linked and are being used as the delivery vehicle for national AI strategies. The result is that **AI shows up first on the balance sheet as data centres and sovereign compute, and only second in the network or the contact centre.**

**e& (UAE).** H1 2025: **net profit Dh8.8bn (+60.7%), revenue Dh34.9bn (+23.3%), EBITDA Dh15.4bn (44.1% margin), 198 million subscribers globally (15.5m in UAE)**. AI/cloud moves in the period: **UAE Sovereign Cloud Launchpad with AWS and the UAE Cyber Security Council**; edge-AI and 5G partnership with Qualcomm; **AI governance framework deployed with IBM**; **284 UAE nationals trained through AI programmes since 2021**; **'S Class' rating under the Dubai AI Seal** for responsible AI. Materially, e& **divested 40% of Khazna Data Centers for Dh8bn** — i.e. monetised the data-centre asset rather than holding it. CEO Hatem Dowidar: *"We preserved momentum across verticals and executed key strategic moves like the divestments of Khazna and Airalo."* [company-reported] ([Gulf News, 31 Jul 2025](https://gulfnews.com/business/markets/e-profits-soar-60-in-h1-with-ai-cloud-expansion-plans-to-fuel-growth-1.500218049))
In **July 2026**, e& UAE and **Core42** launched a **Sovereign AI Compute platform** — heterogeneous accelerators on demand, **no capex, zero egress fees**, plus a "GPU Connect" service bundling GPU capacity with e& connectivity, with *"full compliance with sovereignty requirements through in-country data residency."* Esam Mahmoud (SVP SMB Sales & Marketing, e& UAE) and Jaafar Al Hashmi (VP Government Relations & Market Development, Core42) quoted. [company-reported] ([e&, 20 Jul 2026](https://www.eand.com/en/news/20-07-26-eand-uae-core42-sovereign-ai-infrastructure.html))

**du (UAE).** **AED 2 billion (~$544.5m)** AI-focused data centre with **Microsoft**, offering **sovereign cloud solutions** for the UAE and regional markets, built in phases; du already operates five UAE data centres. Announced under Dubai's **Universal Blueprint for Artificial Intelligence (2024)**. Crown Prince Sheikh Hamdan: *"This initiative represents a significant investment in digital infrastructure, strengthening Dubai's position at the forefront of innovation."* CEO Fahad Al Hassawi: *"a transformative step in our mission to reshape the UAE's digital landscape."* [company-reported] ([RCR Wireless, 28 Apr 2025](https://www.rcrwireless.com/20250428/ai-ml/du-ai-data-microsoft))
Wider context: **Microsoft announced $15.2bn of UAE investment (to 2029)**. [company-reported] ([Microsoft, 3 Nov 2025](https://blogs.microsoft.com/on-the-issues/2025/11/03/microsofts-15-2-billion-usd-investment-in-the-uae/))

**stc group (Saudi Arabia).** Subsidiary **center3** and **HUMAIN** announced a **50/50 joint venture to develop data centres supporting up to 1 GW of AI workloads in Saudi Arabia, with an initial 250 MW phase** (Dec 2025). Olayan Alwetaid, stc group CEO: *"By combining HUMAIN's AI leadership with center3's world-class data-centre expertise, we are creating the right foundation to strengthen the region's capacity to host next-generation AI workloads."* Tareq Amin, HUMAIN CEO: *"AI at scale requires purpose-built compute, efficiency and resilience."* Fahad AlHajeri, center3 CEO, on delivering *"the density, resilience and availability required for next-generation AI computing."* Investment not disclosed. [company-reported] ([Data Centre Magazine, 20 Dec 2025](https://datacentremagazine.com/news/how-will-center3-and-humain-build-1gw-of-ai-data-centres))

**Ooredoo (Qatar, and regionally).** Deployed **NVIDIA Hopper GPUs** in its Qatar data centres to launch the country's first operator sovereign AI cloud, operated by Syntys, targeting energy, finance, logistics, healthcare and smart cities, supporting **Qatar's Digital Agenda 2030 and National AI Strategy**. Sheikh Ali Bin Jabor Al-Thani, CEO Ooredoo Qatar: *"We are proud to bring this world-class AI infrastructure to Qatar, equipping our customers with the tools they need to turn ambition into real-world solutions."* GPU count, capacity and investment **not disclosed**. [company-reported] ([Ooredoo, 1 Jul 2025](https://www.ooredoo.com/en/media/news_view/ooredoo-deploys-nvidia-accelerated-computing-in-qatar-ushers-in-the-countrys-next-wave-of-innovation/)) In **August 2026**, Ooredoo with NVIDIA and Nokia announced a multi-billion-dollar **1 GW AI compute platform targeting Indonesia/Southeast Asia** [press-reported] ([Fortune, 6 Aug 2026](https://fortune.com/2026/08/06/qatar-ooredoo-nvidia-nokia-unveil-multi-billion-dollar-ai-compute-platformand-southeast-asia-is-their-target/)). Ooredoo Kuwait separately launched a sovereign AI data centre with NVIDIA.

**Zain (Kuwait / KSA).** **Zain KSA launched an AI Center of Excellence on 3 June 2026**, aligned to Saudi's designation of 2026 as the "Year of AI" and to Zain Group's *"4WARD – Progress with Purpose"* AI strategy. Three roles: embedding AI in operations (customer care, commercial, network ops); selling AI to enterprises and government; orchestrating partnerships. Eng. Saad bin Abdulrahman AlSadhan, CEO: *"Innovation is fundamental to how we operate and how we create and deliver value."* Maha AlQernas, EVP IT and head of the AI CoE: *"The AI Center of Excellence gives us a robust structure to move from experimentation to disciplined execution."* No outcome metrics published yet. [company-reported] ([Zain KSA, 3 Jun 2026](https://sa.zain.com/en/all-news/zain-ksa-launches-ai-center-excellence-line-%E2%80%98year-ai%E2%80%99)) Zain Group also ran an operator workshop, *"AI in Action: Smarter Network Operations."* ([Zain Group](https://zain.com/en/press-release/ai-workshop))

**Mobily (Saudi Arabia).** Signed an **MoU with Ericsson at LEAP 2026 (announced 1 Sep 2026)** to advance AI-powered RAN and autonomous networks — rApps on the Ericsson Intelligent Automation Platform across RAN Compute, radio systems and Active Antenna Systems, combining distributed (edge) and centralised AI. Builds on prior work during **Hajj 2025**, including Explainable AI deployment and trials of an **AI-powered 5G Uplink Interference Optimizer**. [company-reported] ([Zawya, 1 Sep 2026](https://www.zawya.com/en/press-release/companies-news/ericsson-and-mobily-sign-mou-at-leap-2026-to-advance-ai-powered-ran-and-autonomous-networks-in-saudi-arabia-474008)) The Hajj use case is genuinely region-specific: a predictable, extreme, time-bounded capacity event that is an unusually good testbed for AI-driven RAN optimisation.

**Omantel (Oman).** Launched an **AI Centre of Excellence and AI Startups Program on 18 May 2026**, spanning telecom, financial services, energy, healthcare and government, with startups Decoil, Remedy, ORKI, DeepAstra and Wiya accelerated through Omantel Innovation Labs, aligned to **Oman Vision 2040**. CEO Aladdin Baitfadhil: *"Through the AI Centre of Excellence and the AI Startups Program, we are building an integrated innovation ecosystem."* [company-reported] ([TechAfrica News, 18 May 2026](https://techafricanews.com/2026/05/18/omantel-unveils-ai-centre-and-startup-program-to-drive-omans-digital-transformation/)) Omantel is separately running a BSS/OSS transformation with Cerillion on an "AI-ready architecture."

**stc Bahrain / Batelco (Bahrain).** stc Bahrain unveiled a "fully integrated GenNext contact centre." [press-reported] ([Trade Arabia](https://tradearabia.com/News/467588/stc-Bahrain-unveils-first-fully-integrated-GenNext-contact-centre/IT)) I could not find published outcome metrics for Batelco AI deployments in the window.

### 6.2 Regulators and national strategies

**Saudi Arabia — CST.** The **Communications, Space and Technology Commission** ran a public consultation on a **Global AI Hub Law (14 April – 14 May 2025)** proposing three data-infrastructure models: a **Private Center** (hosting international data/services inside KSA), an **Extended Center** (for major AI/cloud companies hosting global customers) and a **Virtual Center** (tiered sovereignty-based hosting) — explicitly enabling *"sovereign data centers that ensure service continuity and data sovereignty beyond borders."* [regulator/official] ([CST, 14 Apr 2025](https://www.cst.gov.sa/en/media-center/news/N2025041401))
CST published an **AI Adoption Guide for technology companies on 3 August 2026**, built on five readiness dimensions — context, data, infrastructure, skills, organisational culture — and two implementation pillars (internal operations, and customer-facing solutions including AI agents). The Saudi Council of Ministers designated **2026 the "Year of AI."** [regulator/official] ([TechAfrica News, 3 Aug 2026](https://techafricanews.com/2026/08/03/saudi-arabias-cst-releases-ai-adoption-guide-for-technology-companies/)) Note: the guide is generic to technology companies and contains **no telecom-specific obligations** — a gap operators should not assume will persist.
National AI governance sits with **SDAIA** under the **National Strategy for Data and AI**, which Zain KSA explicitly cites as a compliance reference.

**UAE — TDRA and the AI authority layer.** The UAE's approach is strategy-and-sandbox rather than a single binding AI act: the **National Strategy for Artificial Intelligence 2031**, Dubai's **Universal Blueprint for Artificial Intelligence (2024)** (the stated frame for du's Microsoft data centre), and the **Dubai AI Seal** certification scheme under which e& holds an **'S Class'** rating. Data-residency expectations for regulated and government workloads are the binding constraint in practice — which is exactly the constraint the e&/Core42 and du/Microsoft sovereign platforms are built to satisfy. [regulator/official and company-reported, per sources above]

**Qatar — Digital Agenda 2030 and the National AI Strategy** are the stated frames for Ooredoo's sovereign AI cloud. [company-reported] ([Ooredoo, 1 Jul 2025](https://www.ooredoo.com/en/media/news_view/ooredoo-deploys-nvidia-accelerated-computing-in-qatar-ushers-in-the-countrys-next-wave-of-innovation/))

**ITU.** The ITU-T standardisation sector maintains AI standards work and an **AI Standards Exchange Database**; AI for Good has launched a **Telco Troubleshooting Agentic Challenge**, i.e. a standards-body-hosted benchmark specifically for agentic network troubleshooting. ([ITU AI for Good](https://aiforgood.itu.int/event/telco-troubleshooting-agentic-challenge-global-launch/))

**EU AI Act relevance for telcos.** Operators are affected in three distinct capacities: (a) as **deployers** of AI in customer service and pricing — where personalisation risks touch prohibited/high-risk boundaries and Which? has already flagged *"fairness issues from personalised pricing targeting vulnerable groups"*; (b) as **providers** when they resell AI services to enterprises (e.g. Orange's Live Intelligence-as-a-product, T-Systems' AI Foundation Services); (c) as **operators of critical infrastructure** where network-autonomy systems intersect with resilience obligations. Layered on top: ePrivacy confidentiality-of-communications rules that make telecom metadata a stricter category than ordinary customer data. See the AI Act high-level summary ([artificialintelligenceact.eu](https://artificialintelligenceact.eu/high-level-summary/)). *Caveat: I did not find an authoritative regulator publication specifically mapping AI Act obligations onto telecom operators — this mapping is inference from the Act's structure plus the Which?/Ofcom evidence, not a sourced regulatory determination.*

### 6.3 Arabic-language constraints
The functional requirement across GCC care operations is **Gulf-dialect (Khaliji) spoken Arabic plus code-switching with English**, not Modern Standard Arabic — which is what most commercial ASR/TTS is tuned for. Deployments that matter are therefore dialect-and-residency constrained simultaneously: the model must run in-country *and* handle dialect. **I searched specifically for a GCC operator publishing measured outcomes (containment, AHT, CSAT) for an Arabic-dialect voice agent in 2024–2026 and could not find one from a primary source.** The available material is vendor marketing (Wittify, Mando, Munsit, Caller Digital) and does not meet this dossier's sourcing bar. This is a genuine, currently unmet evidence gap — and a defensible commercial opening.

---

## 7. Notable voices

> **"I believe the future of agentic AI is many, many, many small language models."**
> — **Andy Markus**, Chief Data Officer, AT&T. [VentureBeat, 26 February 2026](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut)

> **"The technology is growing at a pace, but the diffusion of technology in an enterprise is pretty low."**
> — **Sachin Verma**, Chief Data and AI Officer, Rakuten Mobile. [RCR Wireless, 23 July 2026](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile)

> **"We're at the crawling stage of managing these systems at massive scale. It is another multiyear transformation."**
> — **Steve Jarrett**, Chief AI Officer, Orange. [TM Forum Inform, 22 January 2026](https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai)

> **"The wholesale shift to GPU compute at the cell site has shown challenges in both capex and opex."**
> — **Alok Shah**, VP Strategy and Marketing, Samsung Electronics America. [Fierce Network, 22 December 2025](https://www.fierce-network.com/wireless/ai-ran-2026-what-lies-ahead)

> **"The AI Center of Excellence gives us a robust structure to move from experimentation to disciplined execution."**
> — **Maha AlQernas**, EVP of IT and Head of the AI Center of Excellence, Zain KSA. [Zain KSA, 3 June 2026](https://sa.zain.com/en/all-news/zain-ksa-launches-ai-center-excellence-line-%E2%80%98year-ai%E2%80%99)

> **"By combining HUMAIN's AI leadership with center3's world-class data-centre expertise, we are creating the right foundation to strengthen the region's capacity to host next-generation AI workloads."**
> — **Olayan Alwetaid**, Group CEO, stc. [Data Centre Magazine, 20 December 2025](https://datacentremagazine.com/news/how-will-center3-and-humain-build-1gw-of-ai-data-centres)

> **"The field of generative AI has experienced significant growth, but privacy issues have also arisen. Telefónica's Privacy-by-Design approach... ensures our customers' privacy."**
> — **Chema Alonso**, Chief Digital Officer, Telefónica. [Telefónica, 26 February 2024](https://www.telefonica.com/en/communication-room/press-room/telefonica-partners-with-microsoft-to-incorporate-generative-ai-into-kernel/)

> **"This was all very much the art of the practical, not the art of the possible."**
> — reported characterisation of the MWC 2026 agentic AI summit, GSMA coverage. [RCR Wireless, 25 March 2026](https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2)

---

## 8. Source index

1. [The Mobile Economy 2026 — GSMA Intelligence](https://www.gsmaintelligence.com/research/the-mobile-economy-2026), March 2026 — 8.8bn connections, 5.8bn subscribers.
2. [Mobile sector GDP contribution tipped to top $11T — Mobile World Live](https://www.mobileworldlive.com/gsma/mobile-sector-gdp-contribution-tipped-to-top-11t), 2 Mar 2026 — revenue $1.19tn→$1.36tn, $1.2tn capex, GDP contribution, 45% AI revenue priority.
3. [Telcos' AI inflection point — McKinsey](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/telcos-ai-inflection-point-what-leaders-do-to-capture-value), 26 Feb 2026 — 49-operator survey; 57%/16%/12%; 9% IT spend; EBITDA/ROIC projections; KPN, Entel Connect, NTT DOCOMO.
4. [The AI-First Telecommunications Strategy — BCG](https://www.bcg.com/publications/2026/the-ai-first-telecommunications-strategy), 25 Feb 2026 — productivity 45–60% care / 40–50% network; 15pp EBITDA; 20–35% IRR.
5. [State of AI in Telecommunications survey — NVIDIA](https://blogs.nvidia.com/blog/ai-in-telco-survey-2026), 19 Feb 2026 — 90% revenue/cost benefit; 60% gen-AI; 89% spend increase; 88% at autonomy L1–3.
6. [Telcos hit Level 4 autonomous network milestone — Fierce Network](https://www.fierce-network.com/cloud/telcos-hit-level-4-autonomous-network-milestone-says-tm-forum), Mar 2026 — 21% at L3+; China Mobile, Telkomsel, T-Mobile; Accenture 22%/79%.
7. [TDC NET and Ericsson TM Forum L4 certification — Ericsson](https://www.ericsson.com/en/news/2025/6/tdc-net-and-ericsson-achieves-industry-first-certification-from-tm-forum-of-level-4-autonomy), June 2025 — industry-first L4 certification.
8. [Telco results show signs of AI service growth — TM Forum Inform](https://inform.tmforum.org/features-and-opinion/telco-results-show-signs-of-ai-service-growth), 2026 — TELUS, IOH, SoftBank, DT Q1 2026 AI revenue.
9. [SK Telecom Q2 2026 results — SKT Newsroom](https://news.sktelecom.com/en/3218), 5 Aug 2026 — AIDC KRW 136.2bn +92.5%; SK Hyper; A.X K2.
10. [8 billion tokens a day forced AT&T to rethink AI orchestration — VentureBeat](https://venturebeat.com/orchestration/8-billion-tokens-a-day-forced-at-and-t-to-rethink-ai-orchestration-and-cut), 26 Feb 2026 — Ask AT&T scale, 90% cost cut, Markus quote.
11. [Google Cloud and Verizon Gemini integration — Google Cloud press](https://www.googlecloudpresscorner.com/2025-04-09-Google-Cloud-and-Verizon-Drive-Customer-Experience-Improvements-for-Verizon-Customers-with-Gemini-Integration), 9 Apr 2025 — 28,000 reps, 95% answerability.
12. [Verizon's Google-powered chatbot frustrates customers — Yahoo Tech](https://tech.yahoo.com/ai/articles/verizons-google-powered-chatbot-frustrates-201903926.html), Sep 2025 — documented consumer backlash.
13. [Meet SuperTOBi — Vodafone](https://www.vodafone.com/news/newsroom/technology/meet-super-tobi-vodafone-s-new-generative-ai-virtual-assistant-now-serving-customers-in-multiple-countries), 4 Jul 2024 — 15%→60% FTR, NPS +14, €140m.
14. [Vodafone and Microsoft 10-year partnership — Vodafone](https://www.vodafone.com/news/corporate-and-financial/vodafone-microsoft-sign-10-year-strategic-partnership-generative-ai-digital-services-cloud), Jan 2024 — $1.5bn Vodafone commitment to Microsoft cloud/AI over 10 years.
15. [Germany's first AI factory for industry — Deutsche Telekom](https://www.telekom.com/en/media/media-information/archive/germany-s-first-ai-factory-for-industry-1101670), 4 Feb 2026 — 10,000 Blackwell GPUs, 0.5 ExaFLOPS, one-third capacity, Höttges quote.
16. [Data & AI — Deutsche Telekom Annual Report 2025](https://report.telekom.com/annual-report-2025/management-report/group-strategy/data-ai.html), 2026 — 53% employee AI use; Frag Magenta; AskT; T Phone 3.
17. [From PoC to commercial deployment of AI-RAN — SoftBank](https://www.softbank.jp/en/corp/technology/research/topics/224/), 2025/26 — 30% speed gain, 3x MU-MIMO, 20 cells/server, FY2026 target.
18. [The questionable economics of AI in the RAN — Light Reading](https://www.lightreading.com/ai-machine-learning/the-questionable-economics-of-ai-in-the-ran), 28 Feb 2024 — Fujitsu 10x CPU figure; Bubley and Kulkarni scepticism.
19. [AI RAN in 2026: What lies ahead? — Fierce Network](https://www.fierce-network.com/wireless/ai-ran-2026-what-lies-ahead), 22 Dec 2025 — Samsung's Alok Shah on capex/opex.
20. [Ericsson's monetisation plan for AI in RAN without GPUs — Mobile Europe](https://www.mobileeurope.co.uk/ericssons-monetisation-plan-for-ai-in-ran-without-gpus/), 11 Jun 2026 — 20% downlink, 10% spectral efficiency, software subscription.
21. [Telecom GPU-as-a-Service: Beyond the hype — RCR Wireless](https://www.rcrwireless.com/20251030/analyst-angle/telecom-gpu-as-a-service), 30 Oct 2025 — 30–50% vs 60–70% utilisation; 50x latency token cost; named operator platforms.
22. [Vodafone UK and Ericsson trial AI for 5G energy efficiency — Ericsson](https://www.ericsson.com/en/press-releases/3/2025/vodafone-uk-and-ericsson-trial-ai-solutions-for-improved-5g-energy-efficiency), 11 Mar 2025 — up to 33% daily, up to 70% low-traffic.
23. [The Agentic Network — Rakuten Mobile — RCR Wireless](https://www.rcrwireless.com/20260723/carriers/agentic-network-rakuten-mobile), 23 Jul 2026 — 20% RAN energy, 17–20% power bill, ¥1bn/yr, 33% fraud reduction, Verma quote.
24. [AI helps Virgin Media O2 avoid over one million call transfers — Virgin Media O2](https://news.virginmediao2.co.uk/ai-helps-virgin-media-o2-avoid-over-one-million-call-transfers-as-it-saves-customers-more-than-400000-hours-of-time-on-the-phone/), 15 Jan 2026 — 1.3m transfers, 400,000 hours, complaints -50%.
25. [Telstra dials in elevated customer service with Azure OpenAI — Microsoft](https://www.microsoft.com/en/customers/story/1740058425924206437-telstra-telecommunications-azure-openai-service), 23 Feb 2024 — 90% time savings, 20% less follow-up, 84% positive.
26. [Steve Jarrett on how Orange is realizing value from AI — TM Forum Inform](https://inform.tmforum.org/features-and-opinion/steve-jarrett-on-how-orange-is-realizing-value-from-ai), 22 Jan 2026 — €300m target, Jarrett quotes.
27. [Live Intelligence: 90,000 employees using gen AI — Orange Business](https://www.orange-business.com/en/about-us/customer-stories/live-intelligence-orange-has-helped-90000-employees-use-generative-ai), 2025/26 — 90,000 users, 15,000 DAU, CO₂ tracking.
28. [BT plans mass layoffs after cutting 8,500 jobs in last year — Light Reading](https://www.lightreading.com/fttx/bt-plans-mass-layoffs-after-cutting-8-500-jobs-in-last-year), 21 May 2026 — 77,152 employees; "very little of this was caused by" AI; £6.7bn savings.
29. [BT chief says AI could deliver more job cuts — The Register](https://www.theregister.com/2025/06/16/bt_chief_says_ai_could_cut_more_staff/), 16 Jun 2025 — Kirkby on AI-driven cuts beyond 55,000.
30. [T-Mobile and OpenAI launch IntentCX — Businesswire](https://www.businesswire.com/news/home/20240917013945/en/T-Mobile-and-OpenAI-Join-Forces-to-Revolutionize-the-Customer-Experience-with-First-Ever-Intent-Driven-AI-Decisioning-Platform), 17 Sep 2024 — original announcement; no verified launch since.
31. [AI-powered solution helped block 8bn spam calls — Business Standard](https://www.business-standard.com/companies/news/ai-powered-solution-helped-block-8-bn-spam-calls-0-8-bn-smses-airtel-124120900456_1.html), 9 Dec 2024 — Airtel volumes.
32. [Airtel announces new features in fight against spam — Airtel](https://www.airtel.in/press-release/04-2025/airtel-announces-new-features-in-its-continued-fight-against-spam), Apr 2025.
33. [Telefónica partners with Microsoft on gen AI in Kernel — Telefónica](https://www.telefonica.com/en/communication-room/press-room/telefonica-partners-with-microsoft-to-incorporate-generative-ai-into-kernel/), 26 Feb 2024 — Kernel 2.0, Privacy-by-Design, Alonso quote.
34. [Osaka Sakai Data Center commences operations — KDDI](https://newsroom.kddi.com/english/news/detail/kddi_nr-916_4323.html), Jan 2026 — GB200 NVL72, 57,000 m², GPU cloud timeline, Takeda.
35. [e& profits soar 60% in H1 with AI, cloud expansion — Gulf News](https://gulfnews.com/business/markets/e-profits-soar-60-in-h1-with-ai-cloud-expansion-plans-to-fuel-growth-1.500218049), 31 Jul 2025 — e& financials, AWS/Qualcomm/IBM, Khazna divestment, Dowidar quote.
36. [e& UAE and Core42 partner on sovereign AI infrastructure — e&](https://www.eand.com/en/news/20-07-26-eand-uae-core42-sovereign-ai-infrastructure.html), 20 Jul 2026 — sovereign AI compute, GPU Connect, residency.
37. [du plans AI-driven data center with Microsoft — RCR Wireless](https://www.rcrwireless.com/20250428/ai-ml/du-ai-data-microsoft), 28 Apr 2025 — AED 2bn, sovereign cloud, Sheikh Hamdan and Al Hassawi quotes.
38. [Microsoft's $15.2bn investment in the UAE — Microsoft On the Issues](https://blogs.microsoft.com/on-the-issues/2025/11/03/microsofts-15-2-billion-usd-investment-in-the-uae/), 3 Nov 2025.
39. [How will center3 and HUMAIN build 1GW of AI data centres? — Data Centre Magazine](https://datacentremagazine.com/news/how-will-center3-and-humain-build-1gw-of-ai-data-centres), 20 Dec 2025 — 50/50 JV, 1GW, 250MW phase 1, three CEO quotes.
40. [Ooredoo deploys NVIDIA accelerated computing in Qatar — Ooredoo](https://www.ooredoo.com/en/media/news_view/ooredoo-deploys-nvidia-accelerated-computing-in-qatar-ushers-in-the-countrys-next-wave-of-innovation/), 1 Jul 2025 — Hopper GPUs, Syntys, Digital Agenda 2030, Al-Thani quote.
41. [Ooredoo, NVIDIA, Nokia unveil 1GW AI compute platform — Fortune](https://fortune.com/2026/08/06/qatar-ooredoo-nvidia-nokia-unveil-multi-billion-dollar-ai-compute-platformand-southeast-asia-is-their-target/), 6 Aug 2026.
42. [Zain KSA launches AI Center of Excellence — Zain KSA](https://sa.zain.com/en/all-news/zain-ksa-launches-ai-center-excellence-line-%E2%80%98year-ai%E2%80%99), 3 Jun 2026 — CoE scope, AlSadhan and AlQernas quotes, "Year of AI."
43. [Ericsson and Mobily sign MoU at LEAP 2026 — Zawya](https://www.zawya.com/en/press-release/companies-news/ericsson-and-mobily-sign-mou-at-leap-2026-to-advance-ai-powered-ran-and-autonomous-networks-in-saudi-arabia-474008), 1 Sep 2026 — rApps, EIAP, Hajj 2025 XAI and uplink optimiser.
44. [Omantel unveils AI Centre and startup program — TechAfrica News](https://techafricanews.com/2026/05/18/omantel-unveils-ai-centre-and-startup-program-to-drive-omans-digital-transformation/), 18 May 2026 — CoE, five startups, Baitfadhil quote.
45. [CST publishes public consultation for the Global AI Hub Law — CST](https://www.cst.gov.sa/en/media-center/news/N2025041401), 14 Apr 2025 — Private/Extended/Virtual Center models, data sovereignty.
46. [Saudi Arabia's CST releases AI adoption guide — TechAfrica News](https://techafricanews.com/2026/08/03/saudi-arabias-cst-releases-ai-adoption-guide-for-technology-companies/), 3 Aug 2026 — five readiness dimensions, Year of AI.
47. [Ofcom examines impact of AI on UK telecoms customers — ISPreview](https://www.ispreview.co.uk/index.php/2026/01/ofcom-examines-impact-of-ai-on-the-experience-of-uk-telecoms-customers.html), Jan 2026 — Call for Input, 10 Mar 2026 deadline, H2 2026 findings.
48. [The impact of AI adoption for telecoms customers — Which? response](https://www.which.co.uk/policy-and-insight/article/the-impact-of-ai-adoption-for-telecoms-customers-which-response-aWKz12b5Mk9s), Mar 2026 — accuracy, vulnerable consumers, personalised pricing, agentic misalignment.
49. [Ofcom reveals UK telecom complaints figures as VMO2 credits AI — Telecoms.com](https://www.telecoms.com/regulation/ofcom-reveals-uk-telecom-complaints-figures-as-vmo2-hails-ai-for-improvements), Aug 2025 — complaint league tables, VMO2 Lumi AI, 42% complaint reduction.
50. [MWC 2026: AI but with more realism than hype — STL Partners](https://stlpartners.com/research/mwc-2026-ai-realism/), Mar 2026 — "less hype on the show floor."
51. [Telecom moves from AI hype to deployment — RCR Wireless / GSMA](https://rcrwireless.com/20260325/ai/telecom-ai-mwc-2026-gsma-2), 25 Mar 2026 — three AI lanes, Jarich quotes, core-network underinvestment, France 2027 mandate.
52. [Worldwide telecom capex to decline in 2026 — Dell'Oro Group](https://www.delloro.com/news/worldwide-telecom-capex-to-decline-in-2026/), 2026.
53. [High-level summary of the AI Act — artificialintelligenceact.eu](https://artificialintelligenceact.eu/high-level-summary/) — risk tiers, provider/deployer obligations.
54. [Telco Troubleshooting Agentic Challenge — ITU AI for Good](https://aiforgood.itu.int/event/telco-troubleshooting-agentic-challenge-global-launch/) — agentic network troubleshooting benchmark.
55. [Explainable AI-driven customer churn prediction — Frontiers in AI](https://www.frontiersin.org/journals/artificial-intelligence/articles/10.3389/frai.2026.1748799/full), 2026 — academic churn modelling; accuracy but no operator P&L outcome.
56. [stc Bahrain unveils GenNext contact centre — Trade Arabia](https://tradearabia.com/News/467588/stc-Bahrain-unveils-first-fully-integrated-GenNext-contact-centre/IT).

---

## 9. Gaps and caveats

**What I looked for and could not verify:**

1. **A GCC operator publishing measured Arabic-dialect voice-AI outcomes.** Searched repeatedly. Only vendor marketing sites (Wittify, Mando, Munsit, Caller Digital, Thamra) surfaced, none meeting the sourcing bar. If a real GCC deployment with containment/AHT/CSAT numbers exists, it is not publicly disclosed.
2. **Any operator publishing a churn-rate reduction attributable to AI.** Not found for 2024–2026. This is a striking absence given how universally the use case is marketed.
3. **Recovered-revenue figures from AI SIM-box or Wangiri detection.** Only vendor (Subex, Neural Technologies, Synaptique) and academic (Ethio-Telecom deep learning) material. No operator disclosure.
4. **T-Mobile IntentCX post-announcement status.** No launch, scale or outcome disclosure found from T-Mobile or OpenAI as of Sept 2026.
5. **Margin or profitability on any telco AI compute business.** SKT, TELUS, IOH and DT disclose revenue or capacity; none discloses gross margin on GPU services. The GPUaaS profitability question remains open on the public record.
6. **Frag Magenta quantified resolution/volume metrics.** Deutsche Telekom's Annual Report 2025 describes the product and a Chip award but publishes **no resolution rate or volume figures**. An older Rasa case study cites a 40% chat solution rate but predates the generative rebuild and I did not use it.
7. **A regulator publication mapping EU AI Act obligations specifically onto telecom operators.** Not found; §6.2's mapping is reasoned inference and is labelled as such.
8. **GSMA Mobile Economy 2026 primary PDF.** Gated. Figures in §1.1 come from Mobile World Live's report of the launch, which is GSMA's own publication, plus the ungated GSMA Intelligence landing page for §1.2.

**Weakest figures in this dossier, ranked:**
- **BCG's 15pp EBITDA uplift and 20–35% IRR** — pure modelling, no deployed base behind it.
- **McKinsey's "up to 10 percentage points of ROIC/EBITDA in five years"** — same caveat; useful as ambition framing only.
- **NVIDIA's "90% of operators say AI is increasing revenue and reducing costs"** — vendor survey with obvious incentive alignment and self-reported, unaudited responses. Contrast with McKinsey's independently-collected **12% reporting sizable impact**; the gap between those two numbers is the most instructive single comparison in this dossier.
- **Vodafone's Portugal 15%→60% FTR** — company-reported, single market, no methodology published, and now two years old.
- **Ericsson/Vodafone 33% and 70% energy figures** — trial-scale, unspecified site count, vendor-issued, "up to" phrasing preserved deliberately.
- **Orange's €300m** — a target for 2025, not a reported 2025 outcome. I found no follow-up disclosure confirming attainment.
- **Airtel's 8bn spam calls blocked** — company-reported volume with no false-positive rate disclosed; volume blocked is not the same as accuracy.
