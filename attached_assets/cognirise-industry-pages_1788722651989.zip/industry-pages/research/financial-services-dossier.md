# Financial Services & AI — Evidence Dossier
**Scope:** banking, payments, insurance, asset & wealth management, capital markets
**Compiled:** 6 September 2026 · Emphasis on evidence dated 2024 – Sept 2026
**Labels used:** [company-reported] · [vendor-claimed] · [analyst-estimate] · [regulator/official] · [independent study]

---

## 1. State of the industry from an AI perspective

Financial services is the only industry where the AI question is simultaneously a **P&L question, a model-risk-regulation question, and a financial-stability question**. Three things make it structurally distinct: (a) banks have been running regulated statistical models under formal validation regimes since 2011, long before "AI governance" existed; (b) the industry's largest cost lines — compliance, fraud, servicing, technology — are exactly where generative AI lands; and (c) supervisors treat AI concentration as a systemic risk, not just a procurement risk.

**Adoption is near-universal but shallow in autonomy.**

1. 75% of UK financial services firms already use AI, with a further 10% planning to within three years — up from 58% in 2022. Median use cases per firm are expected to roughly double from 9 to 21 over three years. [regulator/official] — Bank of England / FCA third AI survey, 21 Nov 2024.
2. Only **2% of AI use cases operate fully autonomously**; 24% are semi-autonomous with human oversight, and 55% involve some automated decision-making. 62% of use cases were rated low materiality, 16% high. [regulator/official] — BoE/FCA, Nov 2024. This is the single most important counterweight to "agentic banking" narratives.
3. Firms' own understanding of their AI is incomplete: 46% report only "partial understanding" of the AI technologies they use, versus 34% claiming complete understanding. [regulator/official] — BoE/FCA, Nov 2024.
4. Third-party dependency is now a third of all AI use cases (17% in 2022). The top three providers hold **73% of cloud, 44% of model and 33% of data services** used by surveyed firms. [regulator/official] — BoE/FCA, Nov 2024.
5. In the DIFC, AI adoption among authorised firms rose from 33% (2024) to **52% (2025)**, with a **166% year-on-year increase in generative AI usage**; 661 authorised firms responded (88% participation). [regulator/official] — DFSA AI survey, reported June 2025.

**Value has begun to appear in reported financials — but from a narrow set of firms.**

6. JPMorganChase: "We have shown that for $2 billion of expense, we have about $2 billion of benefit." — Jamie Dimon, Oct 2025. [company-reported]
7. Evident's 2025 Index found **8 of 50 banks now disclose group-level AI ROI estimates**, and 32 of 50 disclose at least one use case with an associated impact (up from 12 the prior year). JPMorgan revised its stated AI benefit from ~$1bn to ~$2bn. [independent study] — Evident AI Index, 9 Oct 2025.
8. DBS reported **~SGD 1 billion of economic value from AI/ML in FY2025**, from 2,000+ models across 430+ use cases (SGD 750m in 2024). [company-reported] — DBS, FY2025 results / SFF 2025.
9. Ping An: AI service representatives handled **~1.702 billion service interactions, 80% of total customer service volume**, in 2025; AI-driven smart fraud detection saved **RMB 10.51bn in claims**; 94% of life policies underwritten within seconds. [company-reported] — Ping An 2025 annual results, 26 Mar 2026.
10. Bank of America: clients interacted digitally ~30 billion times in 2025 (+14% YoY); Erica alone was used ~700 million times by 20.6m users in 2025, cumulative 3.2bn interactions since 2018. [company-reported] — BofA newsroom, Mar 2026.

**Spend is escalating and is now an explicit competitive-strategy line item.**

11. JPMorgan guided to **$19.8bn technology spend for 2026**, ~$2bn above the prior year, explicitly framed against fintech competition. [company-reported] — JPMorgan Investor Day, 24 Feb 2026.
12. HSBC's CEO Georges Elhedery named generative AI the bank's **single largest new technology investment area** on the Q4 2025 earnings call; HSBC has tied AI to a group RoTE commitment of ≥17% through 2028. [company-reported] — reported 25 Feb 2026 / 17 Jun 2026.
13. IMF projection cited by the FSB: AI spending in financial services could reach **$400bn by 2027, from $166bn in 2023**. [analyst-estimate via regulator] — FSB, 14 Nov 2024.
14. McKinsey's widely-cited estimate: banking could capture **$200bn–$340bn annually** from generative AI, equivalent to **9–15% of operating profits**. [analyst-estimate] — McKinsey, 23 Jan 2024. Note this is a potential, not realised, figure — and after 2½ years, the largest single *disclosed* realisation is JPMorgan's ~$2bn.

**Structural forces unique to this industry.**

15. **Financial crime compliance is a fixed cost that AI is being pointed at directly.** EMEA financial institutions spend **$85bn a year** on financial crime compliance; costs rose for 98% of institutions in 2023, and 72% saw labour costs rise. [independent study] — LexisNexis Risk Solutions / Forrester, 6 Mar 2024.
16. **The crime side is scaling faster than the control side.** Estimated global illicit funds reached **$4.4 trillion in 2025**, a $1.3tn increase since 2023; fraud and bank fraud schemes totalled **$579.4bn**; **90% of financial crime professionals reported an increase in AI-driven attacks** at their institution over the past two years. [independent study] — Nasdaq Verafin Global Financial Crime Report, 11 Mar 2026.
17. **Model risk regulation predates AI by 15 years.** The Fed/OCC's SR 11-7 (4 Apr 2011) defines a model broadly — "a quantitative method, system, or approach that applies statistical, economic, financial, or mathematical theories, techniques, and assumptions to process input data into quantitative estimates" — and mandates independent validation, documented inventories, and "effective challenge." Any LLM producing a quantitative estimate that feeds a credit, capital, valuation or compliance decision falls inside this perimeter. [regulator/official]
18. **AI talent is concentrating.** The ten banks with the largest AI workforces account for roughly half of all AI professionals across Evident's 50-bank index — about **90,000 people**; the AI talent pool grew 25% YoY, nearly five times the rate of overall headcount growth. [independent study] — Evident, 9 Oct 2025.
19. **Supervisors have moved from observation to instrumentation.** The FSB's Oct 2025 monitoring report tells authorities to close data gaps and build indicators for AI adoption and related vulnerabilities — an admission that regulators still cannot see AI exposure across the system. [regulator/official] — FSB, 10 Oct 2025.
20. **Insurance is on the same curve but a year behind banking.** Allianz topped Evident's first insurance index (30 insurers) with **900+ registered AI use cases** and an AI talent pool 28% larger than the next insurer; AI specialists are now roughly 1 in 50 roles across the insurance industry. [independent study] — Evident AI Index for Insurance, 16 Jun 2026.

---

## 2. Challenges specific to financial services in the AI era

**1. Generative AI collides with a pre-existing model-risk regime that assumes deterministic, explainable models.**
SR 11-7 requires conceptual soundness assessment, outcomes analysis / back-testing, and independent validation at least annually. LLMs are non-deterministic, versioned by a third party, and often lack reproducible training data — none of which maps cleanly onto "effective challenge." The BoE/FCA finding that 46% of firms have only partial understanding of their own AI is the practical symptom. [regulator/official — Fed SR 11-7, 2011; BoE/FCA, Nov 2024]

**2. Credit and life/health insurance pricing become legally "high-risk" AI in the EU on 2 August 2026.**
Under Annex III of the EU AI Act, systems evaluating creditworthiness or credit scoring for natural persons, and risk assessment/pricing for life and health insurance, are high-risk — bringing data governance, technical documentation, transparency, logging and human-oversight obligations. The Article 6(3) "low-risk" carve-out is unavailable once profiling of individuals occurs, which is standard in both contexts. The proposed Digital Omnibus would push Annex III obligations to 2 December 2027 but was not adopted as of mid-2026, so firms have had to plan for the August 2026 date. [regulator/official; delay status secondary — horizon-scanner analysis, Jun 2026]

**3. Third-party and model concentration is now framed as a financial-stability vulnerability, not a vendor issue.**
The FSB names four AI vulnerabilities: third-party dependencies and service-provider concentration; market correlations (common models and data producing correlated trading/lending and amplifying liquidity stress); cyber; and model risk / data governance. With three cloud providers behind 73% of surveyed firms' cloud AI use, a single provider incident is a sector event. [regulator/official — FSB, 14 Nov 2024; BoE/FCA, Nov 2024]

**4. The fraud attack surface is being upgraded by the same technology as the defence.**
The Arup case — HK$200m (~US$25m) transferred after a finance employee in Hong Kong joined a video call populated entirely by deepfaked colleagues including the CFO, disclosed February–May 2024 — reset payment-authorisation controls across corporate banking. Combined with Nasdaq Verafin's finding that 90% of financial crime professionals report rising AI-driven attacks (Mar 2026), the net position is an arms race, not a solved problem. [independent study / press]

**5. AI-driven cost-out collides with service obligations and industrial relations — publicly.**
Commonwealth Bank of Australia cut 45 customer-service roles in July 2025 citing an AI voice bot, then reversed the decision in August 2025 after call volumes *rose*, conceding it "did not adequately consider all relevant business considerations" and that it "should have been more thorough in our assessment of the roles required." [company-reported via ABC News, 21 Aug 2025]

**6. Explainability and consumer redress are now hard regulatory requirements in the Gulf, in two languages.**
The CBUAE's AI guidance (11 Feb 2026) requires licensed financial institutions to provide "clear and understandable disclosures … in both Arabic and English, with adequate customer support," maintain AI model inventories, periodically stress-test AI systems for bias, and retain accountability for outsourced AI outcomes. [regulator/official]

**7. Data sovereignty is being operationalised in infrastructure, not just contracts.**
The CBUAE, with Core42, launched a sovereign financial cloud under its Financial Infrastructure Transformation programme, embedding data residency and direct supervisory access into shared infrastructure rather than relying on contractual assurance. This materially constrains which frontier models a GCC bank can use, and where. [regulator/official, reported 22 Apr 2026]

**8. Fair-lending exposure survives even when the model is cleared.**
NYDFS analysed ~400,000 New York Apple Card applicant records and found **no fair lending violation** — yet still concluded that "credit scoring in its current form and anti-discrimination laws governing lending require strengthening and modernization," and criticised transparency and customer service failures that eroded confidence. The lesson for AI underwriting: a clean statistical result does not neutralise reputational and explanatory risk. [regulator/official — NYDFS, 23 Mar 2021]

---

## 3. What key players are doing

| # | Organisation | What was deployed | Scale | Reported outcome | Source & date |
|---|---|---|---|---|---|
| 1 | **JPMorganChase** | LLM Suite (internal GenAI on OpenAI + Anthropic base models); large legacy ML estate | 0 → 200,000 onboarded users in eight months from summer 2024; ~150,000 of ~250,000 employees using daily by Oct 2025 | "$2 billion of expense … about $2 billion of benefit" (Dimon); employees self-report ~4 extra productive hours/week (Heitsenrether); traditional ML deployments growing 30–40%/yr and still the main value source | [company-reported] JPMC blog 3 Jun 2025; Evident AI Symposium 23 Oct 2025; Dimon Oct 2025 |
| 2 | **Morgan Stanley** | AI @ Morgan Stanley Assistant and Debrief (GPT-4 + Whisper), built with OpenAI | >98% of adviser teams using the Assistant | Adviser document access rose from 20% to 80% of the knowledge base; Debrief compresses post-meeting note/follow-up work from days to hours | [vendor-claimed, OpenAI case study, with company quotes] |
| 3 | **Goldman Sachs** | GS AI Assistant firmwide; Devin (Cognition) autonomous coder pilot; "OneGS 3.0" AI-led efficiency programme | 10,000+ employees tested Assistant for a year before firmwide rollout (24 Jun 2025); Devin pilot announced Jul 2025 | No published productivity metric. OneGS 3.0 (14 Oct 2025) moved annual 3–5% performance reductions earlier and constrained hiring, while still expecting net headcount growth (~48,300 staff at 30 Sep 2025) | [company-reported via Fortune 24 Jun 2025; Banking Dive/Reuters 14 Oct 2025] |
| 4 | **Citi** | Citi Assist, Citi Stylus, Stylus Workspaces, Citi Squad; agentic tools | 175,000+ colleagues across 80 countries/jurisdictions (Sep 2025) | Account/document review time cut from ~1 hour to ~15 minutes in US services; first 50 processes targeted include client onboarding, employee onboarding and parts of KYC; tech staff ~50,000 with contractor share moving from ~50% toward 20% | [company-reported] Citi 4 Sep 2025; Reuters/Yahoo 8 Apr 2026 |
| 5 | **HSBC** | Dynamic Risk Assessment AML (Google Cloud); firmwide GenAI; expanded Google Cloud/Gemini partnership | AML DRA in production since 2023–24; 31,000 engineers given a GenAI coding assistant; ~85% of employees have access to GenAI productivity tools (Feb 2026) | AML: "two to four times more financial crime than we did previously," 60% fewer false positive cases, screening time cut from weeks to days. New Google partnership prioritises only use cases worth **>$100m** in revenue or efficiency, targeting 200+ use cases in two years; first Chief AI Officer (David Rice) from 1 Apr 2026 | [company-reported] HSBC 10 Jun 2024; WatersTechnology 25 Feb 2026; Asian Banker 17 Jun 2026 |
| 6 | **BNY** | Eliza enterprise AI platform; "digital employees" with identities and access controls | 99% of workforce trained with Eliza access; 20,000 employees actively building agents; 125+ live AI tools | Legal contract review cut ~75% (4 hours → 1 hour) across 3,000+ annual vendor agreements; 46% increase in agent-building after an internal training month | [vendor-claimed, OpenAI case study with BNY quotes] 12 Dec 2025 |
| 7 | **DBS** | Enterprise AI/ML industrialisation: DBS-GPT, DBS Joy (corporate GenAI assistant), 2,000+ models | 430+ use cases; DBS Joy 20,000+ users | ~SGD 1bn economic value FY2025 (SGD 750m 2024); Joy associated with a 23% increase in satisfaction score; test-case generation and documentation reduced from months to weeks | [company-reported] DBS FY2025 / SFF Nov 2025 |
| 8 | **Commonwealth Bank of Australia** | Enterprise AI: NameCheck, fraud alerting, scam-engagement bots, Compass AI, AI-assisted lending | 20m+ payments screened daily; 40,355 proactive fraud alerts/day; 27,600 employees completed AI learning series by end-2025 | 76% reduction in customer scam losses vs 2022 peak; $880m of mistaken/scam payments prevented via NameCheck across 110m uses; >20% reduction in customer fraud losses H1 FY26 vs H1 FY25; Compass AI answered 500,000+ staff questions since Jul 2024 | [company-reported] CBA AGM 15 Oct 2025; CBA AI report Feb 2026 |
| 9 | **BBVA** | ChatGPT Enterprise at scale + internal GPT store | 3,000 → 11,000 licences; 20,000+ custom GPTs created (~4,000 used frequently); 250 senior leaders trained including CEO and chairman | ~3 hours saved per employee per week; 83% weekly active usage; a Peru internal assistant cut query handling from ~7.5 min to ~1 min (~80%) for 3,000+ employees | [vendor-claimed, OpenAI case study with BBVA quotes] 2025 |
| 10 | **Mastercard** | Decision Intelligence Pro — generative-AI transaction risk scoring | Scores ~143bn transactions annually; decisions <50ms | Average **+20% fraud detection**, "up to 300%" in some instances; **>85% reduction in false positives** | [company-reported/vendor-claimed] Mastercard newsroom, Feb 2024 |
| 11 | **Visa** | Visa Intelligent Commerce / Trusted Agent Protocol — agentic payments rails | 100+ partners globally, 30+ building in the sandbox, 20+ agents integrating; "hundreds" of agent-initiated transactions in production pilots | Full platform launch expected early 2026; APAC and Europe pilots from early 2026. Note: **hundreds** of transactions, not millions — this is pre-scale | [company-reported] Visa investor release, 18 Dec 2025 |
| 12 | **Stripe** | Payments foundation model trained on tens of billions of transactions | Applied across the Stripe network | Card-testing detection rate for large business accounts improved **+64% "practically overnight"**, on top of an 80% reduction in card-testing attacks achieved by prior models over two years | [company-reported] Stripe Sessions, 7 May 2025 |
| 13 | **Ping An** | "AI in ALL": AI service reps, 70,000+ internal AI agent applications, smart underwriting, smart claims, diagnostic AI | 230,000+ employees on the internal AI platform; 3.65bn model calls in 2025 | 1.702bn AI service interactions (80% of total service volume); RMB 133.18bn of sales attributed to AI-assisted channels; RMB 10.51bn claims savings from smart fraud detection; 94% of life policies underwritten in seconds; 59% of life claims via quick-claim | [company-reported] Ping An 2025 annual results, 26 Mar 2026 |
| 14 | **Allianz / Allianz Partners** | Enterprise AI across underwriting, claims, fraud, service; agentic AI growing share of new deployments | 900+ registered AI use cases group-wide; #1 of 30 insurers in Evident's insurance index | Allianz Partners travel claims: average claim lifecycle **19 days → 4 days**; 71% of claims processed in ≤12 hours; 65% of claims eligible for automation | [independent study] Evident, 16 Jun 2026; [company-reported via Travel Weekly] 24 Sep 2025 |
| 15 | **Bank of America** | Erica (consumer virtual assistant, launched 2018) plus internal Erica-for-employees and CashPro AI | 20.6m Erica users; ~700m interactions in 2025; 3.2bn cumulative | 30bn total client digital interactions in 2025 (+14%); 86% of clients rate the digital experience ≥9/10 | [company-reported] BofA newsroom, Mar 2026 |

### Documented failures, reversals and scale-backs

- **Klarna (reversal).** In Feb 2024 Klarna said its OpenAI-powered assistant handled **2.3m chats in its first month, the work of 700 full-time agents**, cut resolution time from 11 minutes to under 2, reduced repeat inquiries 25%, and would drive a **~$40m profit improvement in 2024** [vendor-claimed, OpenAI case study]. By **May 2025** Klarna was recruiting human agents again. CEO Sebastian Siemiatkowski: *"As cost unfortunately seems to have been a too predominant evaluation factor when organizing this, what you end up having is lower quality"*, and *"I just think it's so critical that you are clear to your customer that there will be always a human if you want."* AI still handles roughly two-thirds of inquiries; the model is now hybrid. [press — CX Dive, May 2025]
- **Commonwealth Bank of Australia (reversal).** 45 customer-service roles cut in July 2025 on the basis of an AI voice bot; reversed in August 2025 after call volumes rose and management resorted to overtime and pulling team leaders onto phones. CBA called the decision an "error." The Finance Sector Union's Julia Angrisano: *"CBA has been caught out trying to dress up job cuts as innovation."* [press — ABC News, 21 Aug 2025]
- **Mashreq (cost, not benefit, showing up first).** Q1 2026 operating expenses rose 15% year-on-year "due to targeted investment in generative AI initiatives, digital onboarding infrastructure and the continued build-out of the international network" — with no disclosed AI-specific benefit offsetting it. [company-reported via AGBI, 1 May 2026]
- **The sector-wide caveat.** MIT's NANDA "GenAI Divide" research (Jul 2025) concluded that "95% of organizations are getting zero return" on $30–40bn of GenAI investment, based on 52 structured interviews, 300+ publicly disclosed initiatives and 153 surveyed leaders — while explicitly noting figures "reflect self-reported outcomes." Its financial-services finding was *not* mass disruption: "backend automation; customer relationships stable," scoring 0.5 on its disruption index. [independent study, with methodological caveats]

---

## 4. Proven vs. not proven

**1. Claim: "AI will cut bank headcount by X%."**
*Evidence for:* Dimon, Oct 2025: "There'll be fewer jobs in certain functions." Goldman's OneGS 3.0 (Oct 2025) accelerated performance-based reductions and constrained hiring explicitly on AI grounds. Citi is shifting tech contractors from ~50% of the tech workforce toward 20%.
*Evidence against:* Goldman still expected **net headcount growth** for full-year 2025 (~1,800 added Jan–Sep 2025), and Citi's technology headcount **rose** to ~50,000. Evident's MEA analysis found that mature AI-adopting banks **expand** headcount rather than reduce it. CBA reversed its only publicly AI-attributed job cut.
**Verdict: Unproven as an aggregate claim; proven in pockets (specific contractor pools, specific service functions).** No large bank has published an audited AI-attributed headcount reduction.

**2. Claim: "Gen AI chatbots resolve most banking/financial queries."**
*Evidence:* Klarna's first-month numbers were real, but the company walked the model back within 15 months on quality grounds; AI now handles ~two-thirds of inquiries with humans on complex cases. CBA's AI voice bot *increased* call volumes. BofA's Erica is enormous in interaction count (3.2bn) but BofA does not publish a containment or resolution rate.
**Verdict: Contradicted as stated ("most queries resolved end-to-end"); Proven in pockets for simple, high-volume, low-consequence intents.** The publicly available evidence base for containment rates in regulated banking is thin — a notable disclosure gap.

**3. Claim: "AI credit models are fairer."**
*Evidence for:* Upstart's testing submitted to the CFPB showed its model approved **27% more applicants** at **16% lower APRs** than the traditional benchmark, with "similar results across all tested race, ethnicity, and sex segments" (approval increases 23–29%, APR decreases 15–17%).
*Evidence against:* The independent monitor (Relman Colfax, 14 Apr 2021) recorded that the CFPB "did not separately replicate these analyses," that the testing predated Upstart's own removal of SAT/ACT-derived school groupings, and that the initial report was descriptive rather than a fair-lending conclusion. NYDFS separately concluded that credit scoring itself "require[s] strengthening and modernization."
**Verdict: Proven in pockets, with weak independent verification.** The strongest fairness result in the sector rests on lender-submitted analysis that the regulator did not replicate.

**4. Claim: "Banks get 20–30% developer productivity from coding assistants."**
*Evidence for:* Deployment scale is real — HSBC has given 31,000 engineers a GenAI coding assistant; Goldman piloted Devin; Citi uses AI for legacy migration, code generation and testing.
*Evidence against:* **No large bank has published a measured productivity figure.** The best independent randomised evidence points the other way: METR (10 Jul 2025) found experienced open-source developers were **19% slower** with early-2025 AI tools while *believing* they were 20% faster. METR's Feb 2026 update on late-2025 tools estimated **−18% (CI −38% to +9%)** for original participants and **−4% (CI −15% to +9%)** for new ones — but abandoned the design after finding severe selection bias (30–50% of developers admitted avoiding tasks they thought AI would do quickly), noting their estimate is "likely a lower bound."
**Verdict: Unproven in banking specifically.** The 20–30% number circulates from vendor and consulting material, not from any bank's disclosed measurement.

**5. Claim: "AI dramatically cuts AML false positives."**
*Evidence for:* HSBC's Dynamic Risk Assessment is the strongest public datapoint: "two to four times more financial crime than we did previously, with much greater accuracy," **60% fewer false positive cases**, and screening of billions of transactions across millions of accounts cut from weeks to days [company-reported, 10 Jun 2024]. Mastercard reports **>85% false-positive reduction** on transaction fraud with Decision Intelligence Pro [company-reported, Feb 2024].
*Evidence against:* EMEA compliance costs still rose for 98% of institutions and labour costs for 72% (LexisNexis, Mar 2024), and estimated illicit flows grew from $3.1tn (2023) to $4.4tn (2025) (Nasdaq Verafin). Aggregate compliance cost is not falling.
**Verdict: Proven in pockets at the detection-engine level; Unproven at the cost-of-compliance level.** The alert-triage win is real and repeatable; it has not yet shown up as sector-level cost reduction.

**6. Claim: "MIT found 95% of AI pilots fail — so enterprise AI doesn't work."**
*What the study actually says:* 95% of organisations are getting **zero return** on GenAI spend, while 5% "are extracting millions in value"; based on 52 interviews, 300+ disclosed initiatives and 153 surveyed leaders, Jan–Jun 2025, with self-reported outcomes. Its financial-services read was "backend automation; customer relationships stable" — low disruption, not failure. Its one financial-services ROI example was modest: "$1M saved annually on outsourced risk management."
**Verdict: Widely over-extended.** The finding is about *integration and learning*, not model capability, and the same window contains JPMorgan's ~$2bn and DBS's ~SGD 1bn disclosures. Use it as evidence that value concentrates in firms with data and workflow foundations — not as evidence that AI doesn't pay in banking.

**7. Claim: "Agentic AI is transforming payments now."**
*Evidence:* Visa's Dec 2025 disclosure — the most concrete public number in agentic commerce — is **"hundreds" of agent-initiated transactions** in production pilots, 100+ partners, full launch "early 2026." Mastercard Agent Pay and Visa Trusted Agent Protocol are standards-building exercises. Meanwhile only 2% of AI use cases in UK financial services run fully autonomously.
**Verdict: Unproven at scale; the rails are being laid.** Treat 2026 agentic commerce claims as infrastructure announcements, not volume.

**8. Claim: "Gen AI is where the value is in banking."**
*Evidence against:* JPMorgan's own Chief Data & Analytics Officer attributed the bank's $2bn AI return "primarily from traditional machine learning rather than generative AI," with classical ML deployments growing "on average, 30% or 40% a year" (Evident AI Symposium, 23 Oct 2025). DBS's SGD 1bn spans 2,000+ models across 430+ use cases — an ML estate, not a chatbot.
**Verdict: Contradicted.** The documented value in banking today is disproportionately classical ML (fraud, credit, pricing, collections, marketing), with GenAI contributing productivity rather than P&L.

**9. Claim: "AI defeats fraud."**
*Evidence:* CBA's 76% reduction in customer scam losses since 2022 and >20% H1 FY26 reduction are among the strongest documented outcomes anywhere in the industry [company-reported]. Against that: $4.4tn estimated illicit flows in 2025, 90% of professionals reporting more AI-driven attacks, and a single deepfake video call extracting **HK$200m (~US$25m)** from Arup in Feb 2024.
**Verdict: Proven at scale defensively for individual institutions; contradicted as a sector-level claim.**

**10. Claim: "Cost-income ratios are falling because of AI."**
*Searched and could not verify.* No bank in this evidence base has published a cost-income ratio movement attributed to AI. The opposite is more commonly disclosed: Mashreq's Q1 2026 opex rose 15% partly on GenAI investment; JPMorgan's tech spend rose ~$2bn for 2026; HSBC set a **$100m per-use-case value threshold** precisely because AI spend needs rationing. **Verdict: Unproven.**

---

## 5. High-impact use cases with ROI evidence

**1. AML transaction monitoring / dynamic risk assessment — analytical (ML).**
*Who:* HSBC with Google Cloud. *Outcome:* 2–4× more financial crime detected; 60% fewer false positive cases; screening cycle weeks → days [company-reported, 10 Jun 2024]. *Prerequisites:* consolidated transaction and counterparty data across entities; model risk validation sign-off; regulator engagement on threshold changes. *Time-to-value:* not disclosed; DRA moved from build to production over multiple years. **Documented.**

**2. Real-time card fraud scoring — analytical + generative hybrid.**
*Who:* Mastercard (Decision Intelligence Pro), Stripe (payments foundation model). *Outcome:* +20% average fraud detection, up to 300% in some cases, >85% false-positive reduction across ~143bn transactions/yr [company-reported, Feb 2024]; Stripe +64% card-testing detection for large accounts [company-reported, May 2025]. *Prerequisites:* network-scale transaction history; sub-50ms inference; issuer integration. **Documented.**

**3. Scam prevention and payee verification — analytical + agentic.**
*Who:* CBA (NameCheck, 40,355 daily proactive alerts, scam-engagement bots). *Outcome:* 76% reduction in customer scam losses since the 2022 peak; $880m of mistaken/scam payments prevented over 110m NameCheck uses; >20% fraud-loss reduction H1 FY26 vs H1 FY25 [company-reported, Oct 2025 / Feb 2026]. *Prerequisites:* payment-rail-level integration and, in CBA's case, AU$900m/yr of combined fraud, scam and cyber investment. **Documented.**

**4. Employee knowledge assistant / enterprise copilot — generative.**
*Who:* JPMorgan (LLM Suite), BBVA (ChatGPT Enterprise), BNY (Eliza), Goldman (GS AI Assistant), Citi (Assist/Stylus), HSBC (~85% of employees with access). *Outcome:* JPMorgan ~4 self-reported extra productive hours/week [company-reported, Oct 2025]; BBVA ~3 hours/week saved, 83% weekly active use [vendor-claimed, 2025]. *Prerequisites:* enterprise identity and permissioning, policy corpus (DBS gave staff role-based access to 4 million policy documents), legal/compliance in from day one. *Time-to-value:* JPMorgan reached 200,000 onboarded users in eight months. **Documented for adoption; self-reported for productivity.**

**5. Adviser meeting capture and follow-up — generative.**
*Who:* Morgan Stanley (Debrief), on Whisper + GPT-4. *Outcome:* >98% of adviser teams using the Assistant; document access lifted from 20% to 80%; post-meeting note and follow-up work reduced from days to hours [vendor-claimed with company quotes]. *Prerequisites:* supervised-communications and recordkeeping compliance (SEC/FINRA books-and-records), client consent. **Documented in adoption terms; time saving not independently quantified.**

**6. Contract and vendor-agreement review — generative.**
*Who:* BNY (Contract Review Assistant). *Outcome:* legal review 4 hours → 1 hour (~75%) across 3,000+ annual vendor agreements [vendor-claimed with BNY quotes, Dec 2025]. *Prerequisites:* clause library, retrieval over an authoritative contract repository, privileged-material handling. **Documented (vendor-labelled).**

**7. Client and account onboarding / KYC refresh — analytical + agentic.**
*Who:* Citi. *Outcome:* document review time ~1 hour → ~15 minutes in US services; client onboarding, employee onboarding and parts of KYC are among the first 50 processes targeted [company-reported via Reuters, 8 Apr 2026]. *Prerequisites:* document ingestion at scale, golden-source customer data, audit trail for every automated determination. **Documented.**

**8. Credit underwriting with alternative data — analytical.**
*Who:* Upstart (bank partners). *Outcome:* +27% approvals at −16% APR vs the traditional benchmark, consistent across tested demographic segments [company-reported to CFPB, monitored by Relman Colfax, Apr 2021]. *Prerequisites:* fair-lending testing and less-discriminatory-alternative search; adverse action reason codes; from Aug 2026 in the EU, full Annex III high-risk conformity. *Caveat:* regulator did not replicate the analysis. **Documented but not independently replicated.**

**9. Insurance claims straight-through processing — analytical + generative.**
*Who:* Allianz Partners (travel); Ping An (life). *Outcome:* Allianz Partners average claim lifecycle 19 days → 4 days, 71% of claims in ≤12 hours, 65% automation-eligible [company-reported, Sep 2025]; Ping An 59% of life claims via quick-claim service, 94% of life policies underwritten within seconds [company-reported, Mar 2026]. *Prerequisites:* structured policy data, document AI, fraud model in-line, regulatory sign-off on automated declines. **Documented.**

**10. Insurance fraud detection — analytical.**
*Who:* Ping An. *Outcome:* RMB 10.51bn of claims savings from smart fraud detection in 2025, exceeding RMB 10bn for a third consecutive year [company-reported, Mar 2026]. *Prerequisites:* cross-line claims history, network/graph features. **Documented and repeated across years — one of the few multi-year-verified AI value disclosures in the industry.**

**11. Legacy modernisation and code migration — generative.**
*Who:* Citi (data migration off legacy systems, code generation, test acceleration); HSBC (31,000 engineers with coding assistants); DBS (test-case generation and documentation reduced from months to weeks). *Outcome:* qualitative or process-level only; **no bank has published a measured engineering productivity percentage.** [company-reported, 2026]. *Prerequisites:* code repository hygiene, test coverage, change-management controls. **Projected, not documented.**

**12. Agentic commerce and agent-initiated payments — agentic.**
*Who:* Visa (Intelligent Commerce, Trusted Agent Protocol), Mastercard (Agent Pay). *Outcome:* hundreds of production agent-initiated transactions; 100+ partners; launch expected early 2026 [company-reported, 18 Dec 2025]. *Prerequisites:* agent identity and credential standards, dispute/chargeback liability allocation, merchant acceptance. **Projected.**

**13. Sales and service assistants at consumer scale — generative + analytical.**
*Who:* Bank of America (Erica), Ping An (AI service reps), DBS (Joy). *Outcome:* Erica 700m interactions in 2025 across 20.6m users [company-reported, Mar 2026]; Ping An 1.702bn AI service interactions = 80% of service volume, with RMB 133.18bn of sales attributed to AI-assisted channels [company-reported, Mar 2026]; DBS Joy 20,000+ corporate users, +23% satisfaction score [company-reported, 2026]. **Documented at scale outside the US/EU; US disclosures are interaction counts, not resolution or cost metrics.**

---

## 6. GCC / MENA specifics

**The regional benchmark now exists.** Evident published its **first AI Index for Banks – Middle East & Africa on 2 June 2026**, covering 25 banks on the same four pillars used globally (Talent 45%, Innovation, Leadership, Transparency). **Emirates NBD ranked #1**, with First Abu Dhabi Bank and Mashreq also in the top ranks and Al Rajhi Bank in the top ten. Evident's finding that mature AI-adopting banks *expand* headcount is directly relevant to Gulf boards weighing AI against Emiratisation and Saudisation commitments. Evident CEO Alexandra Mousavizadeh: *"The GCC is entering a narrow and highly competitive window where early movers can establish clear advantages before AI capabilities become more broadly distributed."* Evident's VP of Intelligence Colin Gilbert framed the regional condition precisely: institutions are scaling AI "in environments characterised by fragmented regulation, uneven data quality, rapid digitalisation and heightened sensitivity around fairness, explainability and cyber risk." GCC countries had collectively committed over **$30bn to AI projects by early 2025** [reported figure, Khaleej Times, 2 Jun 2026].

**Regulators moved from principles to instrumentation in 2025–26.**

- **CBUAE AI guidance (11 Feb 2026)** for licensed financial institutions: documented AI frameworks proportionate to size and complexity; defined roles for risk, compliance, internal audit and IT; periodic **stress testing of AI systems for bias**; AI model inventories; accountability retained even when AI is outsourced; three recognised oversight models (human-in-the-loop, human-on-the-loop, human-out-of-the-loop, the last only for low-risk processes); and **disclosures in both Arabic and English** with adequate customer support and redress. Non-binding guidance, but it sets supervisory expectations inside existing consumer-protection and risk frameworks. [regulator/official]
- **CBUAE sovereign financial cloud with Core42**, under the Financial Infrastructure Transformation (FIT) programme, reported April 2026: data residency, resilience and **direct supervisory access are being built into shared infrastructure** rather than left to contract. This is the sharpest sovereignty constraint on model choice anywhere in the dossier — it determines which models a UAE bank can run and where inference happens. [regulator/official]
- **DFSA (DIFC)**: AI adoption among authorised firms went 33% → 52% in a year with a **166% jump in generative AI use**; 661 firms surveyed (88% participation). Use is deliberately internal-first — process automation and compliance analytics rather than customer-facing tools. Justin Baldacchino, MD of Supervision: *"The DIFC's financial services ecosystem is embracing AI at pace"* but *"innovation must be matched with integrity."* The DFSA also convened its first Cyber and AI Risk Regulatory College in May 2025 with 70 officials from 18 authorities, publishing findings on 30 June 2025 — Baldacchino: *"Digital risks are no longer peripheral – they are fast becoming systemic."* [regulator/official]
- **Saudi Arabia**: the Financial Sector Development Programme under Vision 2030 is the policy container for AI-adjacent financial innovation (open banking licensing began under SAMA, with an expanded licensing framework for open banking providers introduced in March 2026), but **SAMA has not published a dedicated AI rulebook equivalent to the CBUAE guidance** as of Sept 2026 — a genuine gap, and one worth flagging to Saudi clients as near-term regulatory risk.

**Named regional deployments and their evidential quality.**

- **Emirates NBD** — #1 in the MEA index; highest AI talent volume among Middle Eastern banks, particularly in software implementation and product management; 97% of financial transactions conducted outside branches; strongest reported outcomes in HR optimisation. Group CEO Shayne Nelson: *"Our approach is to embed AI deep within our culture, ensuring our technology directly empowers our workforce and simplifies the banking experience."* [company/independent, 2 Jun 2026] — note: **no published AI value figure**, unlike JPMorgan or DBS.
- **First Abu Dhabi Bank** — ranked 3rd overall in the MEA index, with the strongest regional emphasis on *scaling* AI and top marks on transparency and leadership. [independent study, 2 Jun 2026]
- **Mashreq** — top-10 MEA; Q1 2026 opex +15% YoY driven partly by generative AI investment; profit +7%, with no AI-attributed benefit isolated. Chairman Abdul Aziz Al Ghurair framed the quarter against "heightened geopolitical tension in the region." [company-reported via AGBI, 1 May 2026] This is the region's clearest example of AI cost landing before AI benefit.
- **ADCB** — 1.9 million registered mobile/internet banking customers (93% of the base), 1.5m+ migrated to a new AI-powered app, with "hundreds of millions of dollars" planned over 2–3 years on digital capability. Notably, the same reporting covers a week-long ADCB app outage resolved 6 July 2026 and a region-wide UAE IT services breakdown on 2 March 2026 — resilience, not model quality, is the binding constraint on regional AI ambition. IDC's Inci Kaya: *"Banks are accountable not just for their own systems, but also for vendors they rely on."* [press — The National, 25 Aug 2026]
- **Al Rajhi Bank** — top-10 MEA in the Evident index; the largest Islamic bank globally, making it the most consequential test case for Shariah-compliant AI product governance. [independent study, 2 Jun 2026]

**Language and sovereignty constraints are real technical constraints, not talking points.**
The CBUAE requires customer-facing AI disclosures in **Arabic and English**. That makes Arabic model quality a compliance input. **Falcon-Arabic** (TII, Abu Dhabi, released 21 May 2025) is a 7B-parameter model with 32k context covering Modern Standard Arabic and Gulf/MENA dialects, which TII reports outperforms all existing Arabic LLMs in its size range and some models up to 4× larger on Arabic MMLU, MadinahQA and AraTrust (average 62.57 on OALL v2). For a Gulf bank, the practical stack question is whether an Arabic-capable sovereign-hosted model is good enough for regulated disclosure and complaint handling, or whether a frontier model must be used under residency constraints — which the CBUAE/Core42 sovereign financial cloud is designed to make possible.

**What this means commercially in the GCC.** The region has: (i) high digital penetration (ENBD 97% of transactions outside branches; ADCB 93% digitally registered), (ii) a newly explicit regulatory expectation of model inventories, bias stress-testing and bilingual explainability, (iii) sovereign infrastructure that constrains model choice, and (iv) **almost no published quantified AI value from regional banks** — in sharp contrast to JPMorgan, DBS and Ping An. The gap between announced ambition and disclosed outcome is wider here than in any other region in this dossier, which is both the risk and the opportunity.

---

## 7. Notable voices

> "We have shown that for $2 billion of expense, we have about $2 billion of benefit."
> — **Jamie Dimon**, Chairman & CEO, JPMorganChase, October 2025

> "There'll be fewer jobs in certain functions."
> — **Jamie Dimon**, JPMorganChase, October 2025

> "We're finding two to four times more financial crime than we did previously, with much greater accuracy."
> — **Jennifer Calvery**, Group Head of Financial Crime, HSBC, 10 June 2024

> "As cost unfortunately seems to have been a too predominant evaluation factor when organizing this, what you end up having is lower quality."
> — **Sebastian Siemiatkowski**, CEO, Klarna, on reversing its AI-only customer service model, May 2025

> "While we are still in the early innings in terms of assessing where AI solutions can best be deployed, it's become increasingly clear that our operational efficiency goals need to reflect the gains that will come from these transformational technologies."
> — **David Solomon, John Waldron and Denis Coleman**, Goldman Sachs "OneGS 3.0" staff memo, 14 October 2025

> "Digital risks are no longer peripheral – they are fast becoming systemic."
> — **Justin Baldacchino**, Managing Director of Supervision, DFSA, 30 June 2025

> "The GCC is entering a narrow and highly competitive window where early movers can establish clear advantages before AI capabilities become more broadly distributed."
> — **Alexandra Mousavizadeh**, CEO, Evident, 2 June 2026

> "Responsible AI is growing in importance across banking in MEA because many institutions are attempting to scale AI deployment in environments characterised by fragmented regulation, uneven data quality, rapid digitalisation and heightened sensitivity around fairness, explainability and cyber risk."
> — **Colin Gilbert**, VP Intelligence, Evident, 2 June 2026

> "The lack of comprehensive data on AI adoption by financial services firms complicates an in-depth assessment of use cases."
> — **Financial Stability Board**, *The Financial Stability Implications of Artificial Intelligence*, 14 November 2024

---

## 8. Source index

1. Evident AI Index — Banking Rankings 2025 — Evident Insights — 8 Oct 2025 — https://evidentinsights.com/ai-index/ — top-10 bank AI maturity ranking, methodology weightings.
2. "JPMorganChase tops AI Index as banks boost investment returns" — IT Brief — 9 Oct 2025 — https://itbrief.news/story/jpmorganchase-tops-ai-index-as-banks-boost-investment-returns — 8 banks disclosing ROI, 32/50 disclosing impact, ~90,000 AI staff, 25% talent growth, Mousavizadeh quote.
3. "Evident: J.P. Morgan retains top spot… HSBC surges" — Finadium — 17 Oct 2024 — https://finadium.com/evident-j-p-morgan-retains-top-spot-for-ai-maturity-but-hsbc-surges/ — 2024 edition: 50 banks, 300+ new use cases in public view.
4. "JPMorganChase continues to lead the world's top banks in AI maturity" — JPMorganChase — 13 Oct 2025 — https://www.jpmorganchase.com/about/technology/blog/jpmc-evident-25 — Waldron "AI-connected enterprise" framing.
5. "LLM Suite named 2025 'Innovation of the Year'" — JPMorganChase — 3 Jun 2025 — https://www.jpmorganchase.com/about/technology/blog/llmsuite-ab-award — 0→200,000 onboarded users in eight months.
6. "JPMorgan's LLM Suite yields 4 hours of productivity per employee each week" — FinAI News — reporting Evident AI Symposium, 23 Oct 2025 — https://finainews.com/banking/jpmorgans-ai-driven-llm-suite-yields-4-hours-of-productivity-per-employee-each-week/ — Heitsenrether quote; ~150,000 of 250,000 daily users; $2bn FY2024 return "primarily from traditional machine learning"; ML growing 30–40%/yr.
7. "Jamie Dimon Declares JPMorgan Chase's $2B AI Investment 'Paid For Itself'" — Yahoo Finance/Benzinga — 27 Oct 2025 — https://finance.yahoo.com/news/jamie-dimon-declares-jpmorgan-chases-173130430.html — the $2bn-in/$2bn-out and "fewer jobs" quotes.
8. "Jamie Dimon predicts JPMorgan will be a winner in AI race, boosts 2026 tech spend to nearly $20 billion" — Finviz/Benzinga — 24 Feb 2026 — https://finviz.com/news/319857/jamie-dimon-predicts-jpmorgan-will-be-a-winner-in-ai-race-boosts-2026-tech-spend-to-nearly-20-billion — $19.8bn 2026 tech spend.
9. "Morgan Stanley uses AI evals to shape the future of financial services" — OpenAI — 2025 — https://openai.com/index/morgan-stanley/ — >98% adviser team adoption; 20%→80% document access; McMillan quote.
10. "Goldman Sachs rolls out internal AI assistant" — Fortune — 24 Jun 2025 — https://fortune.com/2025/06/24/goldman-sachs-internal-ai-assistant — firmwide GS AI Assistant; 10,000+ prior testers; Argenti quote.
11. "Goldman Sachs adds AI coder Devin to its headcount" — Quartz — Jul 2025 — https://qz.com/goldman-sachs-ai-coder-devin-cognition — Devin/Cognition pilot.
12. "One Goldman Sachs 3.0" — Banking Dive — 14 Oct 2025 — https://www.bankingdive.com/news/goldman-sachs-limited-cuts-ai-acquisition-industry-ventures-965-million-solomon-q3-earnings/802869/ — OneGS 3.0 memo, headcount ~48,300, net growth, executive quote.
13. "Goldman Sachs eyes job cuts and hiring slowdown amid AI push, memo shows" — Reuters via TradingView — Oct 2025 — https://www.tradingview.com/news/reuters.com,2025:newsml_L3N3VV1FA:0-goldman-sachs-eyes-job-cuts-and-hiring-slowdown-amid-ai-push-memo-shows — 3–5% reductions moved to Q2, hiring slowdown.
14. "Citi AI Enters 80 Markets and Counting" — Citigroup — 4 Sep 2025 — https://www.citigroup.com/global/news/perspectives/2025/citi-ai-enters-80-markets-and-counting — 175,000+ colleagues, Stylus/Assist/Squad, Tim Ryan quote.
15. "Citigroup says AI helps speed account openings and systems upgrades" — Reuters via Yahoo Finance — 8 Apr 2026 — https://finance.yahoo.com/sectors/technology/articles/citigroup-says-ai-helps-speed-161132650.html — 1 hour → 15 minutes; ~50,000 tech staff; contractor mix 50%→20%; first 50 processes.
16. "Harnessing the power of AI to fight financial crime" — Jennifer Calvery, HSBC — 10 Jun 2024 — https://www.hsbc.com/news-and-views/views/hsbc-views/harnessing-the-power-of-ai-to-fight-financial-crime — 2–4× detection, 60% fewer false positives, weeks→days.
17. "HSBC gives 31,000 engineers an AI coding assistant" — WatersTechnology — 25 Feb 2026 — https://www.waterstechnology.com/emerging-technologies/7952964/hsbc-gives-31000-engineers-an-ai-coding-assistant — 31,000 engineers; ~85% of staff with GenAI access; Elhedery on investment priority.
18. "HSBC expands Google Cloud AI partnership with $100 million use case threshold" — The Asian Banker — 17 Jun 2026 — https://www.theasianbanker.com/updates-and-articles/hsbc-expands-google-cloud-ai-partnership-with-100-million-use-case-threshold — $100m threshold, ≥17% RoTE to 2028, 200+ use cases in two years, first Chief AI Officer.
19. "BNY builds 'AI for everyone, everywhere' with OpenAI" — OpenAI — 12 Dec 2025 — https://openai.com/index/bny/ — 99% trained, 20,000 agent builders, 125+ live tools, 75% legal review reduction.
20. "Powering DBS' next phase of growth with AI" — DBS Bank — Singapore FinTech Festival 2025 — https://www.dbs.com/artificial-intelligence-machine-learning/artificial-intelligence/singapore-finTech-festival-2025-powering-dbs-next-phase-of-growth-with-ai.html — SGD 750m (2024), SGD 1bn target (2025), iCoach/DBS-GPT/Joy.
21. "DBS says AI and data analytics initiatives generated about $1 bil" — The Edge Singapore via Yahoo Finance — 2026 — https://sg.finance.yahoo.com/news/dbs-says-ai-data-analytics-170000548.html — FY2025 ~SGD 1bn, 2,000+ models, 430+ use cases, Joy 20,000 users/+23% satisfaction, Tan Su Shan quotes.
22. "2025 Commonwealth Bank AGM: CEO's address" — CBA — 15 Oct 2025 — https://www.commbank.com.au/articles/newsroom/2025/10/agm-ceo-address.html — 76% scam loss reduction, $880m prevented via NameCheck, AU$900m fraud/cyber investment, 10× alerts.
23. "CommBank releases Australian-first report outlining how it is adopting AI" — CBA — Feb 2026 — https://www.commbank.com.au/articles/newsroom/2026/02/cba-approach-to-adopting-ai-report-announcement.html — 40,355 daily alerts, >20% fraud loss reduction H1 FY26, Compass AI 500,000+ questions, 27,600 staff trained, six AI principles.
24. "Commonwealth Bank backtracks on AI job cuts, apologises for 'error' as call volumes rise" — ABC News — 21 Aug 2025 — https://www.abc.net.au/news/2025-08-21/cba-backtracks-on-ai-job-cuts-as-chatbot-lifts-call-volumes/105679492 — 45 roles, reversal, CBA and FSU quotes.
25. "How BBVA is scaling AI from pilot to practice" — OpenAI — 2025 — https://openai.com/index/bbva-2025/ — 3,000→11,000 licences, 20,000+ GPTs, ~3 hrs/week saved, 83% WAU, Peru 7.5→1 minute.
26. "Klarna AI assistant does the work of 700 full-time agents" — OpenAI — Feb 2024 — https://openai.com/index/klarna/ — 2.3m chats, 11→<2 min, 25% fewer repeats, $40m 2024 profit improvement, 23 markets/35+ languages.
27. "Klarna changes its AI tune and again recruits humans for customer service" — CX Dive — May 2025 — https://www.customerexperiencedive.com/news/klarna-reinvests-human-talent-customer-service-AI-chatbot/747586/ — reversal, Siemiatkowski quotes, ~two-thirds still AI-handled.
28. "BofA AI and Digital Innovations Fuel 30 Billion Client Interactions" — Bank of America newsroom — Mar 2026 — https://newsroom.bankofamerica.com/content/newsroom/press-releases/2026/03/bofa-ai-and-digital-innovations-fuel-30-billion-client-interacti.html — Erica 20.6m users / ~700m 2025 interactions / 3.2bn cumulative; 30bn total digital interactions.
29. "Mastercard supercharges consumer protection with gen AI" — Mastercard newsroom — Feb 2024 — https://newsroom.mastercard.com/news/press/2024/february/mastercard-supercharges-consumer-protection-with-gen-ai/ — +20% (up to 300%) detection, >85% false-positive reduction, 143bn transactions, <50ms, Bhalla quote.
30. "Stripe accelerates the utility of AI and stablecoins" — Stripe — 7 May 2025 — https://stripe.com/newsroom/news/sessions-2025 — payments foundation model, tens of billions of transactions, +64% card-testing detection.
31. "Visa and Partners Complete Secure AI Transactions, Setting the Stage for Mainstream Adoption in 2026" — Visa Investor Relations — 18 Dec 2025 — https://investor.visa.com/news/news-details/2025/Visa-and-Partners-Complete-Secure-AI-Transactions-Setting-the-Stage-for-Mainstream-Adoption-in-2026/default.aspx — hundreds of agentic transactions, 100+ partners, Trusted Agent Protocol, Birwadker quote.
32. "Ping An Reports 2025 Performance…" — Ping An Group — 26 Mar 2026 — https://group.pingan.com/media/news/2026/ar-25.html — 1.702bn AI service interactions (80%), 70,000+ agent apps, 3.65bn model calls, RMB 133.18bn AI-assisted sales, RMB 10.51bn fraud savings, 94% instant underwriting.
33. "Allianz ranked #1 in 2026 Evident AI Index for Insurance" — Allianz — 16 Jun 2026 — https://www.allianz.com/en/mediacenter/news/articles/260616-allianz-ranked-first-in-2026-evident-ai-Index-for-insurance.html — 30 insurers, 900+ use cases, 28% larger talent pool, 1-in-50 roles, Karuth-Zelle quote.
34. "AI is revolutionizing Allianz's travel insurance claims process" — Travel Weekly — 24 Sep 2025 — https://www.travelweekly.com/Travel-News/Travel-Agent-Issues/Allianz-Partners-leverages-AI-for-faster-payouts — 19→4 days, 71% within 12 hours, 65% automation-eligible.
35. "Fair Lending Monitorship of Upstart Network's Lending Model — Initial Report" — Relman Colfax PLLC — 14 Apr 2021 — https://www.relmanlaw.com/media/cases/1088_Upstart%20Initial%20Report%20-%20Final.pdf — +27% approvals, −16% APR, segment ranges, CFPB non-replication caveat.
36. "DFS Issues Findings on the Apple Card and Its Underwriter Goldman Sachs Bank" — NYDFS — 23 Mar 2021 — https://www.dfs.ny.gov/reports_and_publications/press_releases/pr202103231 — ~400,000 records, no violation, Lacewell quote on modernising credit scoring.
37. "Artificial intelligence in UK financial services – 2024" — Bank of England / FCA — 21 Nov 2024 — https://www.bankofengland.co.uk/report/2024/artificial-intelligence-in-uk-financial-services-2024 — 75% adoption, 2% fully autonomous, 46% partial understanding, third-party concentration figures.
38. "The Financial Stability Implications of Artificial Intelligence" — Financial Stability Board — 14 Nov 2024 — https://www.fsb.org/uploads/P14112024.pdf — four vulnerabilities, IMF $166bn→$400bn spend projection, 66% open-source foundation models, data-gap quote.
39. "Monitoring Adoption of Artificial Intelligence and Related Vulnerabilities in the Financial Sector" — FSB — 10 Oct 2025 — https://www.fsb.org/2025/10/monitoring-adoption-of-artificial-intelligence-and-related-vulnerabilities-in-the-financial-sector/ — supervisory monitoring gaps, provider concentration.
40. "SR 11-7: Guidance on Model Risk Management" — US Federal Reserve — 4 Apr 2011 — https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm — model definition, validation, effective challenge, inventory.
41. "The EU AI Act timeline for financial services" — Horizon Scanner — Jun 2026 — https://www.horizon-scanner.com/landing/en/blog/eu-ai-act-timeline-financial-services — 2 Aug 2026 Annex III date, credit/insurance high-risk classification, Article 6(3) profiling exclusion, Digital Omnibus not adopted.
42. "Study Reveals Annual Cost of Financial Crime Compliance Totals $85 Billion in EMEA" — LexisNexis Risk Solutions / Forrester — 6 Mar 2024 — https://risk.lexisnexis.com/global/en/about-us/press-room/press-release/20240306-true-cost-of-compliance-emea — $85bn, 98% cost increases, 72% labour cost rises, survey base incl. Saudi Arabia and UAE.
43. "Nasdaq Verafin Report Finds the Financial Crime Epidemic Reaching Alarming New Heights…" — Nasdaq Investor Relations — 11 Mar 2026 — https://ir.nasdaq.com/news-releases/news-release-details/nasdaqr-verafin-report-finds-financial-crime-epidemic-reaching — $4.4tn illicit funds 2025, $579.4bn fraud/bank fraud, 90% reporting more AI-driven attacks.
44. "Incident 634: Deepfake CFO Scam Costs Arup $25 Million" — AI Incident Database — Feb/May 2024 — https://incidentdatabase.ai/cite/634/ — HK$200m (~US$25m), Hong Kong police 4 Feb 2024, Arup confirmation May 2024.
45. "Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity" — METR — 10 Jul 2025 — https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/ — 16 developers, 246 issues, 19% slower vs 20% perceived speedup, caveats.
46. "We are Changing our Developer Productivity Experiment Design" — METR — 24 Feb 2026 — https://metr.org/blog/2026-02-24-uplift-update/ — −18% and −4% point estimates with wide CIs, selection-bias findings, "likely a lower bound."
47. "The GenAI Divide: State of AI in Business 2025" — MIT NANDA (Challapally, Pease, Raskar et al.) — Jul 2025 — https://valtao.com/wp-content/uploads/2025/11/Rapport-MIT.pdf — 95% zero-return claim, 52 interviews / 300+ initiatives / 153 leaders, financial-services disruption score 0.5, self-report caveat.
48. "Banking's gen AI opportunity" — McKinsey — 23 Jan 2024 — https://www.mckinsey.com/featured-insights/week-in-charts/bankings-gen-ai-opportunity — $200–340bn annually, 9–15% of operating profits.
49. "UAE Central Bank publishes responsible AI guidance for financial sector" — Pinsent Masons Out-Law — 11 Feb 2026 — https://www.pinsentmasons.com/out-law/news/uae-central-bank-responsible-ai-guidance-financial-sector — CBUAE guidance scope, bias stress-testing, Arabic/English disclosure, oversight models, 166% GenAI growth context.
50. "Sovereign financial cloud launch prompts UAE firms to rethink cloud and data strategies" — Pinsent Masons Out-Law — 22 Apr 2026 — https://www.pinsentmasons.com/out-law/news/uae-sovereign-financial-cloud-prompts-data-strategy-rethink — CBUAE + Core42, FIT programme, supervisory access, residency.
51. "Emirates NBD and FAB lead responsible AI index as region's banks close gap with global peers" — The National — 2 Jun 2026 — https://www.thenationalnews.com/business/banking/2026/06/02/emirates-nbd-and-fab-lead-responsible-ai-index-as-regions-banks-close-gap-with-global-peers/ — Evident MEA index ranking, methodology, Gilbert quote, headcount-expansion finding.
52. "Emirates NBD, FAB and Mashreq among GCC's most AI-advanced banks" — Khaleej Times — 2 Jun 2026 — https://www.khaleejtimes.com/business/tech/emirates-nbd-fab-and-mashreq-among-gccs-most-ai-advanced-banks — 25 banks, $30bn+ GCC AI investment, Mousavizadeh quote.
53. "Emirates NBD ranked #1 in inaugural Evident AI Index for Banks – MEA" — Zawya press release — 2 Jun 2026 — https://www.zawya.com/en/press-release/companies-news/emirates-nbd-ranked-1-in-inaugural-evident-ai-index-for-banks-middle-east-and-africa-pndptokn — talent volume, 97% of transactions outside branches, Shayne Nelson quote.
54. "AI investments help lift Mashreq's first-quarter profits" — AGBI — 1 May 2026 — https://www.agbi.com/banking-finance/2026/05/ai-investments-help-lift-mashreqs-first-quarter-profits/ — opex +15% on GenAI/digital investment, Al Ghurair quote.
55. "Banks can't afford to fall behind on AI. But can they afford for it to fail?" — The National — 25 Aug 2026 — https://www.thenationalnews.com/business/banking/2026/08/25/banks-cant-afford-to-fall-behind-on-ai-but-can-they-afford-for-it-to-fail/ — ADCB 1.9m digital customers / 1.5m app migration, NBF Dh100m/yr, 2 Mar 2026 UAE IT outage, 6 Jul 2026 ADCB restoration, IDC quote.
56. "New DFSA report explores regulatory insights into cybersecurity, Artificial Intelligence, and quantum risks" — DFSA — 30 Jun 2025 — https://www.dfsa.ae/news/new-dfsa-report-explores-regulatory-insights-cybersecurity-artificial-intelligence-and-quantum-risks — Cyber and AI Risk Regulatory College, 70 officials / 18 authorities, Baldacchino quote.
57. "AI adoption surges across DIFC: DFSA survey reveals 52% of financial firms now using AI" — GCC Business Watch — Jun 2025 — https://gccbusinesswatch.com/news/ai-adoption-surges-across-difc-dfsa-survey-reveals-52-of-financial-firms-now-using-artificial-intelligence/ — 33%→52%, 166% GenAI growth, 661 firms / 88% participation, Baldacchino quote. *(Secondary reporting of the DFSA survey; corroborated on the 166% figure by Pinsent Masons, source 49.)*
58. "Falcon-Arabic: A Breakthrough in Arabic Language Models" — Technology Innovation Institute (TII), Abu Dhabi — 21 May 2025 — https://falcon-lm.github.io/blog/falcon-arabic/ — 7B parameters, 32k context, MSA + Gulf/MENA dialects, OALL v2 average 62.57.
59. "SAMA introduces Licensing Framework for open banking providers" — Clyde & Co — Mar 2026 — https://www.clydeco.com/en/insights/2026/03/sama-new-licensing-framework-for-open-banking — Saudi open banking licensing expansion (context for FSDP).
60. "Financial Sector Development Program" — Saudi Vision 2030 — https://www.vision2030.gov.sa/en/explore/programs/financial-sector-development-program — programme mandate (see caveats: no AI-specific targets retrievable).

---

## 9. Gaps & caveats

**Things I searched for and could not verify:**

- **A cost-income ratio movement attributed to AI at any major bank.** Nothing in the public record. The only disclosed directional evidence runs the other way (Mashreq opex +15%; JPMorgan tech spend +$2bn for 2026; HSBC imposing a $100m per-use-case value hurdle). Any claim that AI is compressing bank cost-income ratios today should be treated as unsupported.
- **A measured developer-productivity percentage from a bank.** HSBC (31,000 engineers), Citi and Goldman all describe deployment; none publishes a measured uplift. The only rigorous RCT evidence (METR) is negative-to-neutral and its authors have since withdrawn the design over selection bias. The commonly quoted "20–30% developer productivity" figure for banks is, on this evidence base, **unsourced**.
- **Containment/resolution rates for bank chatbots.** BofA publishes interaction counts, not resolution rates. Klarna's numbers are the only detailed public ones and they were subsequently walked back. This is a systematic disclosure gap across the industry.
- **A dedicated SAMA AI rulebook for Saudi financial institutions.** I could not find one as of Sept 2026, in contrast to the CBUAE's February 2026 guidance and the DFSA's supervisory work. If a client asserts one exists, verify directly with SAMA before relying on it.
- **Quantified AI value disclosures from GCC banks.** Emirates NBD, FAB, Mashreq, Al Rajhi and ADCB all have public AI positioning; none publishes a JPMorgan- or DBS-style value figure. Regional ROI claims in this dossier are therefore ranking-based (Evident) or activity-based, not financial.
- **Jamie Dimon's April 2026 shareholder letter text.** Widely reported (CNBC, Forbes, Quartz, 6 Apr 2026) but the primary text and the CNBC coverage were not retrievable through this session's fetch (403). No figures from that letter are used here.
- **Lemonade, Zest AI, Ant Group and stc pay specifics.** Not verified to primary sources within this session's search budget; deliberately excluded rather than cited loosely.

**Weakest figures in this dossier, in order:**

1. **McKinsey's $200–340bn** — a 2024 potential estimate, not a realisation; it has been recycled for 2½ years without an updated realisation figure. Use only as an addressable-value framing, never as evidence of achieved value.
2. **Self-reported time savings** (JPMorgan ~4 hrs/week; BBVA ~3 hrs/week). Both are employee self-reports collected by the deploying organisation, and the METR work shows self-reported AI speedup can invert the measured result. Label these as perceived, not measured.
3. **Vendor case studies** (OpenAI on Morgan Stanley, BBVA, BNY, Klarna). Internally consistent and quoting named executives, but the metrics are selected by the vendor and the deploying firm. The Klarna case is the cautionary example: the same source page still carries the 700-agent claim that the CEO later qualified.
4. **Mastercard's "up to 300%"** detection improvement — an outlier band within an average of +20%; the average is the citable number.
5. **The Evident MEA index (Jun 2026)** — first edition, 25 banks, and heavily talent-weighted (45%), which favours banks that hire and publish job adverts over banks that outsource. It measures maturity signals, not outcomes.
6. **The "$30bn+ GCC AI investment"** figure — reported by Khaleej Times without an identified primary source; treat as indicative only.
7. **MIT NANDA's 95%** — self-reported outcomes, 153 surveyed leaders, no published sampling frame. Directionally useful, statistically weak, and routinely misquoted as "95% of AI projects fail."
