# Manufacturing & Industrials — AI Evidence Dossier
**Scope:** discrete & process manufacturing (automotive, aerospace, electronics/semiconductors, chemicals & petrochemicals, metals, FMCG/pharma production, industrial equipment)
**Compiled:** 6 September 2026 · Evidence window emphasised: Jan 2024 – Sept 2026
**Label key:** [company-reported] · [vendor-claimed] · [analyst-estimate] · [regulator/official] · [independent study]

---

## 1. State of the industry from an AI perspective

Manufacturing is the industry where AI has the longest history of *physical* proof (statistical process control, machine vision, robotics) and the shortest history of *enterprise* proof. The 2024–2026 evidence shows a widening gap between a small élite of sites that have industrialised AI and a long tail — the majority — that has barely started.

**1.1 Adoption is far shallower than the discourse implies.** Only **29% of manufacturers reported using AI or machine learning at facility or network level**, and just **24% had deployed generative AI**, per Deloitte's 2025 Smart Manufacturing and Operations Survey, as reported 26 May 2026. The same piece cites Intrinsic CTO Brian Gerkey's estimate that **"80% of U.S. manufacturing facilities have zero automation."** [independent study / executive estimate] — https://www.manufacturingdive.com/news/most-us-manufacturers-still-not-automating-ai-robotics/819725/ (26 May 2026)

**1.2 Vendor-side surveys are more bullish but still show a one-third ceiling.** Rockwell Automation's 11th annual *State of Smart Manufacturing* report (1,560 respondents, 17 countries, fielded with Sapio Research) found **90% of manufacturers say digital transformation is essential**, **59% actively deploy smart manufacturing in daily operations**, only **18% remain in pilot phase**, but **only ~34% of operations currently incorporate AI**, expected to exceed 50% by 2030. It also found **43% of collected data is being used effectively** and **46% suffered at least one cybersecurity incident in the prior year**. [vendor-claimed survey] — https://www.prnewswire.com/news-releases/90-of-manufacturers-say-digital-transformation-is-now-essential-according-to-new-global-study-302775186.html (2026)

**1.3 Industrials specifically struggle to escape pilots.** McKinsey's 2025 State of AI work, as reported for industrial audiences, found **two-thirds of organisations remain in experimentation or pilot phases**, **only ~one-third have scaled AI enterprise-wide**, and **only 39% report any effect on earnings — mostly under 5% of EBIT**. [analyst-estimate] — https://www.bicmagazine.com/departments/maintenance-reliability/industrial-companies-struggle-to-scale-ai/ (2025)

**1.4 The lighthouse cohort is where value is documented — and it is small.** The WEF/McKinsey Global Lighthouse Network reached **201 sites in September 2025** and **238 sites across 35+ countries and 30+ industries by June 2026**. Against a global base of hundreds of thousands of factories, that is a rounding error — which is precisely the representativeness critique (see §4.1). [regulator/official — WEF] — https://www.weforum.org/press/2025/09/global-lighthouse-network-2025-world-economic-forum-recognizes-12-new-sites-driving-holistic-transformation-in-manufacturing/ (16 Sept 2025); https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/ (22 June 2026)

**1.5 Lighthouse KPI improvements (Sept 2025 cohort, cohort averages):** **+40% labour productivity, −48% lead time, −41% product defects, −28% energy consumption, −44% cycle time**, with **up to 50% of top use cases AI-enabled**. [regulator/official — WEF] — same URL as 1.4 (16 Sept 2025)

**1.6 The January 2025 cohort was even stronger — and clarifies which AI matters.** 17 new sites (network then 189): **+53% labour productivity, −26% conversion costs, −50% new-product-introduction time, −30–50% Scope 1&2 emissions, −30% material waste, −25% energy and water**. Critically: **77% of top-five use cases were enabled by analytical AI and only 9% by generative AI**. [regulator/official — WEF] — https://www.weforum.org/press/2025/01/global-lighthouse-network-2025-world-economic-forum-recognizes-companies-transforming-manufacturing-through-innovation/ (14 Jan 2025)

**1.7 Robots keep arriving, but density is wildly uneven.** IFR *World Robotics 2025*: **542,000 industrial robots installed in 2024** (4th consecutive year above 500,000), operational stock **~4.66 million**; Asia 74% of installations, China alone **295,000 units (54% of global)**, US 34,200, Germany 26,982. Forecast ~575,000 in 2025 and >700,000 by 2028. [independent study — IFR] — https://ifr.org/ifr-press-releases/news/global-robot-demand-in-factories-doubles-over-10-years

**1.8 Robot density (per 10,000 manufacturing employees, 2024):** global average **132**; Korea **1,220**, Singapore **818**, Germany **449**, Japan **446**, US **307**. Western Europe 267 (+3% y/y), North America 204 (+4%), Asia 131 (+11%). [independent study — IFR, published 8 Apr 2026] — https://ifr.org/ifr-press-releases/news/robot-density-surges-in-europe-asia-and-americas

**1.9 The workforce constraint is structural, not cyclical.** Deloitte / The Manufacturing Institute: US manufacturing needs **3.8 million new employees 2024–2033**; **1.9 million roles could go unfilled** if the skills gap is not closed; **65% of manufacturers name talent attraction/retention as their primary business challenge**. [independent study] — https://themanufacturinginstitute.org/manufacturers-need-as-many-as-3-8-million-new-employees-by-2033/ (April 2024)

**1.10 Budgets are being committed but the sector is contracting.** Deloitte's 2026 Manufacturing Industry Outlook: **80% of executives plan to invest ≥20% of improvement budgets in smart manufacturing** (2025 survey, 600 executives); **physical-AI adoption expected to rise from 9% today to 22% within two years** (Manufacturing Leadership Council, early 2025); **78% of manufacturers cite trade uncertainty as top concern** (NAM Q3 2025); expected input-cost increases **5.4%**; **ISM PMI stayed below 50 throughout 2025**. [analyst-estimate + industry-association survey] — https://www.deloitte.com/us/en/insights/industry/manufacturing-industrial-products/manufacturing-industry-outlook.html

**1.11 The "reshoring boom" that was supposed to fund automation has not shown up in the data.** IoT Analytics: US manufacturing construction spending **peaked at $239bn in June 2024 and fell 21% through March 2026**; excluding electronics it grew only **5.6% from Feb 2025 to Mar 2026 (~2.3% real)**; **manufacturing employment declined 1% since the April 2025 "Liberation Day" tariffs**. Meanwhile **data-centre construction rose from $9.5bn (Jan 2020) to $47bn (Jan 2026)** and US hyperscaler capex exceeded **$410bn in 2025**. [independent study] — https://iot-analytics.com/us-manufacturing-reshoring-boom-what-the-data-says/ (2026)

**1.12 Cyber risk is now a first-order manufacturing operating risk.** Dragos 2026 OT/ICS Year in Review: ransomware attacks on industrial organisations **up 64% y/y**, **119 groups** targeting industrials (from 80 in 2024), **~3,300 organisations impacted**, **average dwell time in OT 42 days** (5 days for orgs with full OT visibility). **Manufacturing accounted for over two-thirds of all ransomware victims in 2025.** [independent study] — https://www.dragos.com/resources/press-release/dragos-2026-year-in-review-new-ot-threats-ransomware (17 Feb 2026)

**1.13 Historic cost benchmark for OT downtime.** Norsk Hydro's March 2019 LockerGoga attack cost **~$75m in H1 2019 alone** ($34.6–40.4m Q1; $28.8–34.6m Q2), contributing to a **32% earnings decline to $101m in Q2**. Still the cleanest public number for what an OT outage costs a metals producer. [company-reported via press] — https://www.computerweekly.com/news/252467199/Norsk-Hydro-cyber-attack-could-cost-up-to-75m (2019)

**1.14 Vendor capital is flowing hard into industrial AI.** Bosch committed **more than $2.7bn to AI by end-2027**, has filed **1,500+ AI patent applications in five years**, and has trained **65,000+ employees** through its AI Academy with **~5,000 AI specialists**. [company-reported] — https://us.bosch-press.com/pressportal/us/en/press-release-27776.html (25 June 2025)

**1.15 The data characteristic that makes manufacturing different.** Manufacturing's dominant data asset is high-frequency, unlabelled, physically-grounded time-series and image data locked in heterogeneous OT protocols — not text. That is why analytical AI outperforms generative AI 77% to 9% in lighthouse use-case mixes (§1.6), and why the binding constraint is labelling and contextualisation, not model access. Corroborating symptom: Rockwell finds only **43% of collected data is used effectively** (§1.2).

---

## 2. Challenges specific to manufacturing in the AI era

**2.1 Machinery safety law, not AI law, is the binding regulator for AI on the line.**
EU Regulation 2023/1230 (Machinery Regulation) **applies from 20 January 2027** and explicitly extends coverage to "autonomous mobile machinery (robots), internet of things with connected equipment, or artificial intelligence, where specific modules of AI using learning techniques ensure safety functions." High-risk machinery products are subject to **third-party conformity assessment**. [regulator/official — EU-OSHA] — https://osha.europa.eu/en/legislation/directive/regulation-20231230eu-machinery
Practical consequence: an AI model that performs a *safety function* on a machine sold into the EU cannot be silently updated. Continuous learning collides with CE marking. This is a manufacturing-specific problem no bank or telco faces.

**2.2 EU AI Act Annex I stacks on top of that, with a moving deadline.**
AI systems that are safety components of products already covered by EU harmonisation legislation (machinery included) fall under **Annex I high-risk**, historically the less-scrutinised branch of the AI Act, with the Annex I compliance deadline running later than Annex III (**2 August 2028** per current tracking) and further adjusted by the 2026 digital omnibus. [regulator-derived summary] — https://www.regulation-ai.eu/en/annex-i/ ; https://www.globalpolicywatch.com/2026/05/eu-ai-act-update-timeline-relief-targeted-simplification-and-new-prohibitions/ (May 2026)
*Caveat: the omnibus source did not render on fetch (redirect loop); treat the exact revised dates as requiring re-verification against the Official Journal.*

**2.3 The false-positive economics of AI visual inspection.**
Industry reporting on automotive AI vision states that **approximately 77% of AI vision implementations never advance beyond the pilot phase** — while explicitly flagging the figure as "widely cited, rarely examined." The mechanism named is trust collapse: *"Even a small percentage of false positives at production volume is sufficient to erode operator trust, and once that trust is lost, it is extremely difficult to recover."* Unsupervised anomaly detection flags normal variation (lighting, material lots) as defects. [industry press, statistic self-flagged as unverified] — https://www.automotivemanufacturingsolutions.com/smart-factory/ai-vision-finds-its-footing-on-the-factory-floor/2644253
At 1,400 vehicles/day (BMW Regensburg scale) a 1% false-positive rate on a single station is 14 unnecessary interventions per day — enough for operators to disable the alert.

**2.4 Predictive maintenance does not scale linearly — it scales combinatorially.**
McKinsey's canonical PdM analysis: *"Few have been able to deploy PdM at scale across their operations,"* and *"the highest-maturity, asset-wide PdM 4.0 systems are still rare today,"* because a plant-wide system requires model counts *"often exceeding triple digits."* [analyst-estimate] — https://www.mckinsey.com/capabilities/operations/our-insights/prediction-at-scale-how-industry-can-get-more-value-out-of-maintenance (22 July 2021 — older, but still the most precise public statement of the scaling mechanism, and unchallenged by later data)
Each asset class needs its own failure-mode labels; there is no equivalent of a foundation model that transfers across a compressor, a press and a furnace.

**2.5 Labour has an explicit veto in unionised manufacturing.**
The Korean Metal Workers' Union (Hyundai Motor branch) publicly blocked humanoid deployment on **22 January 2026**: *"Keep in mind that not a single robot can enter the workplace without labour-management agreement."* The union's arithmetic: at ~KRW 200m (~$145,000) per Atlas unit, one continuously operating robot replaces roughly three workers' labour, paying back in about two years. [press-reported union statement] — https://www.techtimes.com/articles/317005/20260522/hyundai-commits-25000-atlas-robots-own-factories-union-blocks-deployment-without-labor-deal.htm (22 May 2026)
No consumer-internet AI programme carries this constraint.

**2.6 OT cyber exposure converts AI connectivity into balance-sheet risk.**
Connecting lines to cloud AI expands the attack surface at exactly the moment manufacturing became the top ransomware target (§1.12) with **42-day average OT dwell time**. Rockwell's own survey found **46% of manufacturers had a cyber incident in the prior year** (§1.2). ISA/IEC 62443 zone-and-conduit segmentation is the accepted control framework, and it is in direct tension with the flat, high-bandwidth data plumbing that industrial AI wants.

**2.7 Data residency fragments the MES/IIoT cloud stack in the Gulf.**
Saudi PDPL enforcement (SDAIA + NCA) requires companies to **store sensitive and personally identifiable data within Saudi Arabia unless specific exemptions are granted**, under active enforcement as of **August 2025**. [regulator-derived, US ITA] — https://www.trade.gov/market-intelligence/saudi-arabia-ict-cross-border-data-transfer-rules-now-under-enforcement
For manufacturers this bites on operator-identifiable video (safety analytics, SOP-compliance vision), biometric access, and shift/HR data feeding scheduling AI — i.e. exactly the highest-ROI shop-floor computer-vision cases.

**2.8 Latency and cost physics push AI to the edge, against the cloud vendors' grain.**
Emirates Global Aluminium moved image/video analytics off public cloud onto Azure Stack HCI and reported an **86% cost reduction** and **13x faster AI response (from >1 second to sub-second)**, with deployment frequency moving from weeks/months to multiple per day. EGA's stated rationale is sovereignty as much as economics: *"We want AI decisions about our plant to be done with as little outside exposure and with as little reliance on networks and the internet as possible—fully disconnected, if necessary."* [vendor-claimed customer story, EGA-attributed quote] — https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates

---

## 3. What key players are actually doing

**3.1 BMW Group — humanoids, AIQX, virtual factory (Spartanburg, Debrecen, Regensburg).**
Figure 02 completed an **11-month deployment at Plant Spartanburg**, doing sheet-metal insertion for welding in the body shop, contributing to production of **30,000+ BMW X3 vehicles**. Figure's own tally: **90,000+ parts loaded, 1,250+ hours of runtime, 10-hour shifts Mon–Fri**. The pilot ended not in failure but in **fleet-wide decommissioning of Figure 02 on release of Figure 03**, which is now starting at Spartanburg on a *sequencing logistics* use case (picking unsorted components into just-in-sequence trolleys) — a step **down** in dexterity ambition from welding-adjacent work to logistics. [company-reported + vendor-reported] — https://www.press.bmwgroup.com/global/article/detail/T0458778EN/bmw-group-advances-the-use-of-physical-ai-in-production-with-figure-03-project-in-spartanburg?language=en ; https://www.figure.ai/news/production-at-bmw (19 Nov 2025)
Quote: *"Plant Spartanburg is the birthplace of humanoid robotics in BMW Manufacturing's operational day-to-day activities."* — Ulrich Wieland, VP, BMW Manufacturing.
BMW's non-humanoid AI is the more consequential story: **AIQX** (Artificial Intelligence Quality Next) uses cameras, sensors and acoustic microphones along conveyors for automated real-time defect detection, deployed at the new **Debrecen** plant (2,000 staff, ~1,000 robots; iX3 production launched Oct 2025) alongside digital pre-validation of robot placement in the body shop. [company-reported via press] — https://www.rcrwireless.com/20251009/industry-4-0/bmw-ai-car-factory-hungary (9 Oct 2025)
And **GenAI4Q** at Regensburg (~1,400 vehicles/day, X1/X2) generates a *vehicle-specific* inspection catalogue per car, delivered to inspectors via a smartphone app with speech recognition, co-developed with Munich startup Datagon AI. **No performance metrics were published.** [company-reported] — https://www.press.bmwgroup.com/global/article/detail/T0449729EN/artificial-intelligence-as-a-quality-booster?language=en (28 Apr 2025)

**3.2 Siemens — Industrial Copilot and Xcelerator.**
Industrial Copilot for Engineering was integrated by **thyssenkrupp Automation Engineering** into an EV battery quality-inspection machine, with plans to roll out across global machine locations from 2025. It assists engineers writing IEC structured-text control code in TIA Portal and generating WinCC Unified visualisations. **No quantified time savings were published in the release** — the CEO's claim is qualitative: projects delivered *"in a much shorter time."* [company-reported, unquantified] — https://press.siemens.com/global/en/pressrelease/siemens-industrial-copilot-expanded-adopted-thyssenkrupp (12 Nov 2024)
The **Schaeffler** engagement, frequently cited as a proof point, was announced at SPS Nuremberg as a *world-premiere demonstration* with **no deployment scale and no quantified metrics** — only "significantly reduce time, effort, and the probability of errors." [company-reported, unquantified] — https://press.siemens.com/global/en/pressrelease/ai-industry-schaeffler-and-siemens-bring-industrial-copilot-shopfloor
At CES 2026 Siemens announced nine new copilots (Teamcenter, Polarion, Opcenter) and cited a **PepsiCo case: +20% throughput on initial deployment**, plus claims of **up to 90% of potential issues identified before physical modifications** and **10–15% capex reduction through virtual validation**. [vendor-claimed] — https://news.siemens.com/en-us/siemens-unveils-technologies-to-accelerate-the-industrial-ai-revolution-at-ces-2026/ (14 Jan 2026)
Quote: *"Industrial AI is no longer a feature; it's a force that will reshape the next century."* — Roland Busch, President & CEO, Siemens AG (14 Jan 2026).

**3.3 Emirates Global Aluminium (UAE) — the best-documented GCC industrial AI programme.**
McKinsey-supported transformation across **80+ customised use cases** delivering **>$123 million combined impact**, self-funded from inception. Reported operational metrics: **92% reduction in operator reaction time for safety alerts**, **65% improvement in SOP compliance** (video-based SOP monitoring), **50% reduction in inbound logistics delays**, **35x faster data processing**, **80% reduction in storage need**, **30% of procurement time shifted to value-adding work**, 20+ shop-floor mobile apps for 1,500 users, **3,000+ employees upskilled**. [vendor-claimed (consultant case study) with client-attributed figures] — https://www.mckinsey.com/capabilities/tech-and-ai/how-we-help-clients/rewired-in-action/emirates-global-aluminium-leading-the-industry-with-ai-driven-transformation
On the infrastructure side: Azure Stack HCI edge deployment gave **86% lower cost** and **13x faster inference**, three months from concept to first production edge instance, applied to green-anode inspection and smart-crane monitoring analysing **2.9 petabytes of video annually**. [vendor-claimed] — https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates
EGA's Al Taweelah site was named an **End-to-End Value Chain Lighthouse** in Jan 2025 — an aluminium-industry first. [regulator/official — WEF] — https://www.weforum.org/press/2025/01/global-lighthouse-network-2025-world-economic-forum-recognizes-companies-transforming-manufacturing-through-innovation/

**3.4 Unilever — the strongest published multi-site digital-twin ROI set.**
Unilever, with Accenture, is building **more than 40 new digital twins over 18 months** on top of an existing programme. Site-level results: **Raeford, NC (deodorant)** — 95% prediction accuracy on process restrictions, **−20% waste, +10% capacity**; **Poznań, Poland (mayonnaise)** — **up to −20% minor stoppages, ~−30% waste**; **Gandhidham, India (soap)** — **−30% quality defects over four years**; **Cu Chi, Vietnam** — **1–2% savings on premium ingredients**; **Haldia, India** — thermal energy reduction over two years (unquantified). [company-reported] — https://www.unilever.com/news/press-and-media/press-releases/2026/unilever-scales-digital-twins-across-global-manufacturing-network-with-accenture/ (16 June 2026)
Quote: *"Scaling AI across our operations isn't just a technological shift, it's a commitment to superior products and sustainability."* — Adam Raeburn-James, Global VP Digital Business Operations.

**3.5 GE Aerospace — narrow, quantified, in-service AI.**
AI-enabled Blade Inspection Tool for GEnx Stage 1 & 2 HPT blades cuts inspection from **3 hours to 1.5 hours (−50%)** while improving accuracy versus standard borescope inspection; being extended to **CFM LEAP** and **GE9X**. Installed base context: ~44,000 commercial and 26,000 military engines. [company-reported] — https://www.geaerospace.com/news/press-releases/ge-aerospace-expanding-application-ai-blade-inspections-cfm-leap-and-ge9x-engines (23 Oct 2024)
Quote: *"inspection process times cut in half from 3 to 1.5 hours while improving quality"* — Nicole Jenkins, Chief MRO Engineer.

**3.6 TSMC + NVIDIA — AI inside the fab, not just in the chip.**
Deployed: **cuLitho** (computational lithography, **20–50% improvement in cost-effectiveness or cycle time** vs CPU), **cuEST** (**50x faster chemistry simulations on average**), **cuML** for advanced process control (reduced process variation), **H200 GPUs** for fab-operations optimisation, **Metropolis + TAO** for nanometre-scale defect inspection (reducing repeated labelling and retraining), and **Omniverse "FabTwin."** No headline yield number was published. [vendor-claimed, joint release] — https://nvidianews.nvidia.com/news/nvidia-and-tsmc-bring-ai-into-fabs-to-advance-semiconductor-design-and-manufacturing (31 May 2026)
Quote: *"TSMC is bringing NVIDIA AI and accelerated computing into the fab itself."* — Jensen Huang, NVIDIA.

**3.7 Foxconn / Hon Hai — digital twins first, humanoids second.**
Foxconn's Digital Twin (FODT) work with NVIDIA reports **150x faster CFD thermal simulations** using PhysicsNeMo and — per Leo Guo, GM of Fii Robotic Group — **~50% reduction in factory-planning time and time-to-revenue**, with production lines migrated between global sites (Taiwan→Mexico) using standardised USD asset libraries. The Houston AI-server plant is being validated in the twin **before physical construction** — meaning no operational performance data exists yet for the site most often described as a "lights-out AI factory." [vendor-claimed] — https://www.nvidia.com/en-us/case-studies/foxconn-develops-physical-ai-enabled-smart-factories-with-digital-twins/

**3.8 Mercedes-Benz — humanoids as intralogistics, MO360 as the real asset.**
Apptronik **Apollo** robots at the Digital Factory Campus Berlin-Marienfelde handle **transport of components to lines and initial quality checks** — repetitive intralogistics, not assembly. Mercedes made a **low double-digit-million-euro investment** in Apptronik. Production knowledge was transferred to Apollo via **teleoperation and augmented reality**, with the robots collecting data inside the **MO360** production ecosystem. Still an **initial testing phase**. [company-reported] — https://group.mercedes-benz.com/company/production/procuction-network/mbdfc-humanoid-robots.html (announcement 18 Mar 2025)

**3.9 Hyundai / Boston Dynamics — the biggest humanoid commitment, with the biggest caveat.**
Plan: **30,000 humanoid robots per year by 2028**, deployed first at Metaplant America (Savannah, GA) on **parts sequencing** in 2028, expanding to component assembly by 2030; Atlas lifts up to **110 lb**, trainable for most tasks in under a day; partnerships with Google DeepMind and NVIDIA; part of a $26bn US investment plan. [company-reported] — https://www.axios.com/2026/01/05/hyundai-humanoid-robots-boston-dynamics (5 Jan 2026)
Caveat: the Korean Metal Workers' Union has blocked shop-floor entry pending a labour agreement (§2.5).

**3.10 Tesla — the documented gap between claim and delivery (the sector's clearest reversal).**
January 2025: Musk stated Tesla would build **"roughly 10,000 Optimus robots" in 2025** — **target completely missed**. January 2026: Musk **acknowledged that zero Optimus robots were performing "useful work" in Tesla's factories**, despite prior claims. Gen 3 reveal slipped from Q1 2026 to "probably middle of this year"; Optimus manufacturing at Fremont was pushed to **late July/August 2026**, with a second Giga Texas line targeted at **summer 2027**. Musk on predictability: *"It will move as fast as the least lucky, slowest, dumbest part in the entire 10,000. It is impossible to predict these things."* [press-reported company statements] — https://electrek.co/2026/04/22/tesla-optimus-production-fremont-model-sx-line/ (22 Apr 2026)

**3.11 Alat (PIF, Saudi Arabia) — a documented GCC scale-back.**
Alat, launched in 2024 as a **$100bn** advanced-manufacturing/electronics champion, **scrapped its semiconductor manufacturing plans** and redeployed its chip team and resources into **data-centre infrastructure**; CEO Amit Midha was removed and PIF's head of industrials and mining, Muhammad Nasser Aldawood, became acting CEO. Rationale: rather than compete in capital-intensive fabrication, leverage cheap energy and geography for a "faster, more bankable pathway." [press-reported] — https://enterpriseam.com/menaplus/2026/04/10/pif-pivots-alat-from-chip-manufacturing-to-data-center-buildout/ (10 Apr 2026)
This matters as a template: in the Gulf, industrial-AI capital is repeatedly being re-optimised toward compute infrastructure and away from hard manufacturing.

**3.12 Saudi Aramco — the most decorated process-industry AI operator globally.**
**Five Aramco facilities** in the Global Lighthouse Network as of Jan 2025 (North Ghawar Oil Producing Complex joined Uthmaniyah Gas Plant, Khurais Oil Complex, Abqaiq Plants, Yanbu Refinery) — *"the only global energy company to be represented by more than three facilities."* A sixth, **Hawiyah NGL**, was added in the June 2026 cohort in the *Productivity* category. Quantified metrics are not published per site. [company-reported + regulator/official] — https://www.aramco.com/en/news-media/news/2025/fifth-aramco-facility-receives-world-economic-forum-global-lighthouse-network-status (14 Jan 2025); https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/ (22 June 2026)
Quote: *"This recognition demonstrates our dedication to innovation and operational excellence."* — Nasir K. Al-Naimi, Aramco Upstream President.

**3.13 QatarEnergy / Shell — Pearl GTL, Ras Laffan.**
First Qatari facility admitted to the Global Lighthouse Network (Sept 2025), having implemented **over 45 advanced digital solutions** including AI-driven predictive analytics, digital twins and real-time integrity monitoring. Outcomes described as "measurable improvements in reliability, emissions reduction and operational efficiency" — **not quantified publicly**. [company-reported via press] — https://thepeninsulaqatar.com/article/21/09/2025/qatarenergy-and-shells-pearl-gtl-recognised-by-world-economic-forum-as-global-lighthouse-site (21 Sept 2025)
Quote: *"Being named to the Global Lighthouse Network demonstrates how the large-scale adoption of digital technologies can transform operational efficiency, reliability and environmental performance."* — Rob Maxwell, Shell Managing Director for Qatar.

**3.14 EDGE Group (UAE) — defence manufacturing at Industry 4.0 scale.**
Reported at MIITE 2026: **68 Industry 4.0 transformation projects completed across 28 production facilities**, **production capacity doubled across 13 entities**, **5,276 individuals trained in Industry 4.0 programmes** via BRIDGE, **>80% of systems manufactured in the UAE**, AED 596m (**$162.4m**) in-country value in 2025, $7.96bn order intake, $20.4bn backlog. Separately, EDGE launched a **Group AI Accelerator** (19 May 2025) as a centre of excellence spanning engineering/R&D and business transformation. [company-reported] — https://edgegroup.ae/news/edge-charts-defence-manufacturing-progress-make-it-emirates-2026 (May 2026); https://edgegroup.ae/news/edge-launches-group-ai-accelerator-drive-excellence-ai-enhanced-solutions (19 May 2025)
Quote: *"The Group AI Accelerator marks our latest step towards operating with increased speed and efficiency."* — Dr Chaouki Kasmi, President of Technology & Innovation, EDGE Group.

**3.15 Bosch — agentic AI in maintenance and scheduling.**
Multi-agent systems monitor equipment to forecast maintenance need **and schedule the personnel**, reported to reduce unplanned downtime and improve productivity; Bosch planned to release its multi-agent platform externally from autumn 2025, projecting **"several million euros"** in savings from orchestrated deployment. [company-reported] — https://us.bosch-press.com/pressportal/us/en/press-release-27776.html (25 June 2025)
Quote: *"Agentic AI can give a boost to AI similar to the one the smartphone gave the internet."* — Tanja Rueckert, Bosch board member.

---

## 4. Proven vs. not proven

**4.1 "Lighthouse factories prove industrial AI works at scale."**
*Evidence for:* real, audited, peer-reviewed KPI improvements — +40% labour productivity, −48% lead time, −41% defects (Sept 2025 cohort); +53% productivity, −26% conversion cost (Jan 2025 cohort). Selection follows *"rigorous independent peer review by industry and academic experts to ensure fairness and neutrality."*
*Evidence against:* the network is **238 sites** worldwide (June 2026) — self-nominated, consultant-supported, disproportionately large-cap, and disproportionately Chinese (the Sept 2025 cohort of 13 named sites had **7 in China**). It is a *selected* sample by construction: sites that failed are never in the denominator. McKinsey's own framing concedes the contrast — *"many industrial organizations struggle to move beyond pilots."*
**Verdict: Proven in pockets.** The KPI deltas are real for the sites that achieved them; they are not a base rate. Sources: https://www.weforum.org/press/2025/09/... ; https://www.mckinsey.com/capabilities/operations/our-insights/the-continuing-evolution-of-the-global-lighthouse-network (13 July 2026)

**4.2 "Humanoid robots will be on production lines by 2026."**
*Evidence for:* Figure 02 ran 11 months at BMW Spartanburg, 1,250+ hours, 90,000+ parts. Apollo is in initial testing at Mercedes Berlin. Hyundai committed to 30,000 units/year by 2028.
*Evidence against:* the BMW work was **one robot, one station, one shift pattern**, and its successor was reassigned to **logistics sequencing** rather than escalating into assembly. Mercedes' Apollo does transport and initial checks. Hyundai's first deployment is **2028**, on **parts sequencing**, and is **union-blocked**. Tesla shipped **zero** robots doing useful factory work as of Musk's own January 2026 admission after promising 10,000 in 2025.
**Verdict: Contradicted for 2026 line work; Unproven at production economics.** Sources as §3.1, §3.8, §3.9, §3.10.

**4.3 "Generative AI writes PLC code."**
*Evidence for:* Siemens Industrial Copilot demonstrably generates IEC structured text inside TIA Portal and is in production at thyssenkrupp; Siemens' Sara McGhee: *"It's a lot easier to train a model on a text-based language, rather than a graphical one."*
*Evidence against:* the strongest documented value is **explaining legacy code**, not authoring new control logic — AI can *"kick out at least an idea of what is going on in that program"* when the original programmer has left. Experts stress IEC 61131-3 remains essential because of *"inherent safety features baked into traditional scan cycles"* and the avoidance of dynamic memory allocation in real-time systems. Most installed logic is graphical ladder, not text. And neither Siemens release for thyssenkrupp nor for Schaeffler published a single quantified time saving.
**Verdict: Proven in pockets (comprehension, boilerplate, HMI generation); Unproven for authoring safety-relevant control logic.** Sources: https://www.controldesign.com/control/plcs-pacs/article/55311461/... (21 Aug 2025); https://press.siemens.com/global/en/pressrelease/siemens-industrial-copilot-expanded-adopted-thyssenkrupp

**4.4 "AI visual inspection replaces QC inspectors."**
*Evidence for:* BMW AIQX runs camera/sensor/acoustic inspection in-line at Debrecen; GE Aerospace halved blade inspection time with improved accuracy.
*Evidence against:* the binding constraint is false positives at volume, not detection rate; the claim that ~77% of AI vision projects never leave pilot is widely circulated *and explicitly unverified by the publication that cites it*. BMW's own GenAI4Q design keeps a human inspector in the loop and **augments** the checklist rather than removing the check.
**Verdict: Proven in pockets as augmentation; Contradicted as replacement.** Sources: §2.3, §3.1, §3.5.

**4.5 "Predictive maintenance pays for itself everywhere."**
*Evidence for:* Bosch reports reduced unplanned downtime from multi-agent maintenance orchestration; PdM is standard in the lighthouse use-case mix.
*Evidence against:* McKinsey — plant-wide PdM needs model counts *"often exceeding triple digits,"* and *"the highest-maturity, asset-wide PdM 4.0 systems are still rare today."* Payback depends on failure frequency × downtime cost × warning lead time; on low-criticality, cheap-to-replace assets the model costs more than the failures.
**Verdict: Proven in pockets (high-criticality, high-downtime-cost rotating assets); Unproven as a plant-wide programme.** Sources: §2.4, §3.15.

**4.6 "Digital twins equal ROI."**
*Evidence for:* the single best-quantified dataset in this dossier — Unilever's site-by-site twins (−20% waste and +10% capacity at Raeford; −30% waste at Poznań; −30% defects at Gandhidham). Foxconn: ~50% faster factory planning. Siemens/PepsiCo: +20% throughput.
*Evidence against:* every one of these is a **process/production twin tied to a specific control decision**. Geometry-and-visualisation twins (the kind most often sold) have no comparable published ROI. Foxconn's most-publicised twin — Houston — has **no operational data at all** because the plant does not yet exist.
**Verdict: Proven at scale for process twins with closed-loop decisions; Unproven for visualisation twins.** Sources: §3.4, §3.7, §3.2.

**4.7 "Lights-out / dark factories are the destination."**
*Evidence for:* Chinese "dark factory" demonstrations are real for narrow, high-volume, low-variance products.
*Evidence against:* Erik Nieves (CEO, Plus One Robotics), writing March 2026: *"The future will not be a fully lights-out, human-free operation,"* with humans essential for *"variability, fine manipulation and judgement"*; the realistic projection is *"by 2030, there could be at least one fully automated automotive assembly plant"* — singular, *"limited and specialized."* Set against **80% of US plants having zero automation** (§1.1), lights-out is a marketing frame, not a roadmap.
**Verdict: Contradicted as a general destination; Proven in pockets for narrow high-volume lines.** Source: https://www.qualitymag.com/articles/99453-the-dark-factory-myth (6 Mar 2026)

**4.8 "Tariffs and reshoring are driving an automation supercycle."**
*Evidence for:* 227 public industrial companies announced US footprint changes in Q2 2025 alone; >$500bn of semiconductor commitments; 41% of manufacturers plan to prioritise factory-automation investment in the next two years.
*Evidence against:* manufacturing construction spending **fell 21% from its June 2024 peak through March 2026**; ex-electronics growth was **~2.3% real**; manufacturing **employment fell 1%** post-tariffs; ISM PMI stayed below 50 all of 2025. Capital went to **data centres** ($9.5bn→$47bn) and power, not factories.
**Verdict: Contradicted (so far) at aggregate level; Proven in pockets in semiconductors.** Sources: §1.10, §1.11.

**4.9 "Generative AI is the manufacturing AI story."**
*Evidence:* in the Jan 2025 lighthouse cohort, **77% of top-five use cases were analytical AI and 9% generative**. Every quantified ROI in §3 with a hard number — GE (−50% inspection time), Unilever (−30% waste), TSMC (50x simulation), Foxconn (150x CFD) — is analytical, simulation or vision, not LLM.
**Verdict: Contradicted.** GenAI's proven manufacturing role in this evidence base is engineering-copilot and knowledge-retrieval, not operations. Source: §1.6.

**4.10 "Industrial AI programmes are self-funding."**
*Evidence for:* EGA's programme was *"self-funded from inception"* with **>$123m impact from 80+ use cases** and positive three-year ROI.
*Evidence against:* McKinsey's industrials read — only 39% report any EBIT effect, mostly **under 5%**. EGA is a single, exceptionally well-run counterexample, not a base rate.
**Verdict: Proven in pockets.** Sources: §3.3, §1.3.

---

## 5. High-impact use cases with ROI evidence

| # | Use case | Class | Named evidence | Quantified outcome | Prerequisites | Time-to-value |
|---|---|---|---|---|---|---|
| 1 | **Process digital twin for yield/waste** | Analytical + simulation | Unilever (Raeford, Poznań, Gandhidham, Cu Chi) [company-reported], 16 Jun 2026 | −20% waste & +10% capacity; −20% minor stoppages & ~−30% waste; −30% defects over 4 yrs; 1–2% ingredient saving | Historised process tags at second-level granularity, validated first-principles model, closed loop to control | Gandhidham figure accrued over 4 years; 40+ twins planned in 18 months |
| 2 | **AI borescope / part inspection in MRO** | Analytical (vision) | GE Aerospace GEnx BIT [company-reported], 23 Oct 2024 | Inspection 3h → 1.5h (−50%), accuracy improved | Large labelled defect-image corpus per blade stage; regulatory acceptance of AI-assisted inspection | Extended from GEnx to LEAP/GE9X within ~2 yrs |
| 3 | **In-line vision + acoustic quality (AIQX-type)** | Analytical (vision/audio) | BMW Debrecen & Group AIQX [company-reported], 9 Oct 2025 | Real-time defect detection in-line; **no % published** | Camera/sensor/mic infrastructure on conveyors; cloud or edge inference; false-positive governance | Not published |
| 4 | **Edge inference for video/image analytics** | Analytical | EGA Azure Stack HCI [vendor-claimed] | −86% cost vs public cloud; **13x** faster response (>1s → sub-second); 2.9 PB video/yr | On-prem GPU/edge cluster, Kubernetes, OT network segmentation | **3 months** concept → first production edge instance |
| 5 | **Computer-vision SOP compliance & safety alerting** | Analytical (vision) | EGA [vendor-claimed], part of 80+ use cases | **−92%** operator reaction time on safety alerts; **+65%** SOP compliance | Camera coverage of work cells; **personal-data/works-council clearance** (critical in EU & KSA PDPL) | Delivered in "quarterly waves" |
| 6 | **Computational lithography & process simulation** | Analytical + HPC | TSMC with NVIDIA cuLitho/cuEST [vendor-claimed], 31 May 2026 | 20–50% better cost-effectiveness or cycle time; **50x** faster chemistry simulation | GPU cluster, existing physics models, fab data pipeline | Not published |
| 7 | **Factory-planning digital twin (greenfield/line migration)** | Simulation | Foxconn FODT [vendor-claimed]; Siemens virtual validation [vendor-claimed] | ~**−50%** factory-planning time/time-to-revenue; **150x** faster CFD; Siemens claims up to 90% of issues found pre-build and **10–15% capex reduction** | USD/asset libraries, CAD-to-simulation pipeline, equipment vendor models | Pre-construction; ROI is *projected* until plants run |
| 8 | **Engineering copilot for control code & HMI** | Generative | Siemens Industrial Copilot at thyssenkrupp [company-reported], 12 Nov 2024; Schaeffler [company-reported] | **No quantified saving published by either** | TIA Portal/WinCC estate, code repositories, review gate before download to PLC | Rollout "beginning 2025" |
| 9 | **Agentic maintenance + labour scheduling** | Agentic | Bosch multi-agent systems [company-reported], 25 Jun 2025 | Reduced unplanned downtime; **"several million euros"** projected from orchestrated deployment | CMMS/EAM integration, technician skills matrix, asset criticality model | Platform externalised from autumn 2025 |
| 10 | **Throughput optimisation copilot in production ops** | Generative + analytical | PepsiCo via Siemens [vendor-claimed], CES 14 Jan 2026 | **+20% throughput on initial deployment** | MES/Opcenter data model; line-level OEE history | "Initial deployment" — single site |
| 11 | **Gen-AI-generated per-unit inspection plans** | Generative | BMW GenAI4Q, Regensburg with Datagon AI [company-reported], 28 Apr 2025 | **No metrics published**; 1,400 vehicles/day scope | Vehicle-order + production-pattern data; mobile app with speech recognition | Pilot |
| 12 | **Humanoid intralogistics / parts sequencing** | Agentic + physical AI | Figure 03 at BMW Spartanburg; Apollo at Mercedes Berlin; Atlas at Hyundai (2028) | Figure 02 predecessor: 90,000+ parts, 1,250+ hrs, 11 months — **no cost/throughput figure published by BMW or Figure** | Safety case under EU Machinery Regulation; union agreement; wireless charging/fleet ops | Hyundai first deployment **2028** |

**Documented vs projected:** rows 1, 2, 4, 5, 6 (partly) and 10 carry outcome numbers attached to running operations. Rows 7, 9 and 12 are substantially **projected** — factory-planning twins for plants not yet built, agentic savings stated as forecasts, and humanoid economics with no published unit economics anywhere in this evidence base.

---

## 6. GCC / MENA specifics

**6.1 National strategies as the demand signal.**
- **UAE — Operation 300bn / UAE Industry 4.0:** MoIAT (established July 2020) runs the Fourth Industrial Revolution programme aiming to "transform UAE's industrial base into a globally competitive, productive and sustainable sector," with the **Industry 4.0 Index, Champions 4.0 Network, Leadership 4.0 and Talent 4.0** as instruments, plus the **Technology Transformation Program (TTP)**. [regulator/official] — https://moiat.gov.ae/en/programs/uae-industry-4-backup
- Operationally this shows up as small, concrete cohorts: at Make it in the Emirates 2025, MoIAT and Noventiq signed an MoU to digitally upgrade **20 national factories** into model smart facilities, with services valued at **AED 3 million**. [press release] — https://www.zawya.com/en/press-release/companies-news/make-it-in-the-emirates-2025-moiat-and-noventiq-partner-to-digitally-transform-20-uae-factories-with-industry-40-technologies-qxdas8iz (Jan 2025)
- **Saudi Arabia:** industrial ambition is anchored in Vision 2030's NIDLP and the National Industrial Strategy; the practical AI/industrial governance layer is **SDAIA** (data & AI authority) and **NCA** (cybersecurity).

**6.2 Regional lighthouse footprint — genuinely world-class in process industries.**
- **Aramco: five sites in the Global Lighthouse Network by Jan 2025** (Uthmaniyah, Khurais, Abqaiq, Yanbu, North Ghawar) — the only global energy company with more than three — plus **Hawiyah NGL** added June 2026 in the Productivity category.
- **EGA Al Taweelah (UAE): End-to-End Value Chain Lighthouse**, Jan 2025 — a world aluminium-industry first.
- **Qatar Shell / QatarEnergy Pearl GTL, Ras Laffan: Sept 2025**, first Qatari site, 45+ digital solutions.
This makes the Gulf disproportionately represented in *process* lighthouses relative to its share of global manufacturing output — and near-absent in *discrete* manufacturing lighthouses, which is the honest picture of regional capability.

**6.3 Sovereignty and residency are architectural constraints, not compliance paperwork.**
Saudi PDPL enforcement (SDAIA/NCA) requires sensitive and personally identifiable data to be **stored inside the Kingdom absent an exemption**, under active enforcement as of **August 2025**. For manufacturing this specifically constrains: operator-identifiable safety video, SOP-compliance vision, biometric plant access, and shift-level workforce data feeding scheduling AI. https://www.trade.gov/market-intelligence/saudi-arabia-ict-cross-border-data-transfer-rules-now-under-enforcement
EGA's architecture is the regional reference implementation of the answer: analytics moved to on-prem edge, with the explicit intent that AI decisions be made *"with as little outside exposure… fully disconnected, if necessary."* That is a design pattern GCC manufacturers can copy directly — and one that also delivered 86% cost reduction and 13x latency improvement, i.e. sovereignty here was not a tax.

**6.4 Defence and localisation as a distinct GCC driver.**
EDGE Group's numbers (68 Industry 4.0 projects across 28 facilities; capacity doubled at 13 entities; 5,276 people trained; >80% of systems UAE-manufactured; AED 596m in-country value in 2025) show that in the Gulf, **in-country-value mandates**, not labour cost, are the primary automation driver. The economics run the opposite way to Western reshoring: automation is justified by sovereignty and capability localisation, with skills-building (BRIDGE, 57+ programmes) as an explicit deliverable rather than a side-effect.

**6.5 The capital-allocation risk: industrial AI losing to data-centre AI.**
The **Alat pivot** (April 2026) — abandoning semiconductor fabrication within a $100bn advanced-manufacturing mandate to build data centres, with the CEO replaced — is the clearest regional warning. Gulf industrial-AI budgets compete against sovereign-compute buildouts that offer faster, more bankable returns. Any manufacturing AI proposal in the region is implicitly competing with a data-centre business case.

**6.6 Language and workforce specifics.**
The highest-value GCC shop-floor cases in this evidence base — SOP compliance, safety alerting, mobile shop-floor apps (EGA: 20+ apps, 1,500 users; 3,000+ employees upskilled) — sit on a workforce that is heavily multilingual and largely non-Arabic-native expatriate labour in the UAE, while regulatory, HSE and quality documentation is frequently Arabic-first in KSA. Practical implication: SOP/knowledge copilots in the Gulf need **Arabic–English (and often Hindi/Urdu/Tagalog) parity at the instruction layer**, not Arabic as a translation afterthought. *Caveat: I could not locate a published, sourced GCC manufacturing deployment reporting Arabic-language shop-floor copilot performance — see §9.*

---

## 7. Notable voices

1. **Roland Busch, President & CEO, Siemens AG** — *"Industrial AI is no longer a feature; it's a force that will reshape the next century."* CES, 14 Jan 2026. https://news.siemens.com/en-us/siemens-unveils-technologies-to-accelerate-the-industrial-ai-revolution-at-ces-2026/

2. **Erik Nieves, CEO, Plus One Robotics** — *"The future will not be a fully lights-out, human-free operation."* Humans remain essential for *"variability, fine manipulation and judgement."* Quality Magazine, 6 Mar 2026. https://www.qualitymag.com/articles/99453-the-dark-factory-myth

3. **Elon Musk, CEO, Tesla**, on Optimus production predictability — *"It will move as fast as the least lucky, slowest, dumbest part in the entire 10,000. It is impossible to predict these things."* Reported 22 Apr 2026. https://electrek.co/2026/04/22/tesla-optimus-production-fremont-model-sx-line/

4. **Alexander Simon Kraehenbuehl, Emirates Global Aluminium** — *"We want AI decisions about our plant to be done with as little outside exposure and with as little reliance on networks and the internet as possible—fully disconnected, if necessary."* Microsoft customer story. https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates

5. **Cedrik Neike, CEO Digital Industries, Siemens** — *"In the past, we had to speak to machines in their language. With the Siemens Industrial Copilot, we can speak to machines in our language."* https://press.siemens.com/global/en/pressrelease/ai-industry-schaeffler-and-siemens-bring-industrial-copilot-shopfloor

6. **Robert M. Lee, CEO, Dragos** — *"Adversaries are mapping how control systems work, understanding where commands originate, how they propagate, and where physical effects can be induced."* 17 Feb 2026. https://www.dragos.com/resources/press-release/dragos-2026-year-in-review-new-ot-threats-ransomware

7. **Korean Metal Workers' Union, Hyundai Motor branch** — *"Keep in mind that not a single robot can enter the workplace without labour-management agreement."* 22 Jan 2026. https://www.techtimes.com/articles/317005/20260522/hyundai-commits-25000-atlas-robots-own-factories-union-blocks-deployment-without-labor-deal.htm

8. **World Economic Forum, Global Lighthouse Network 2026 cohort** — *"The true winners are not those that pilot the most technologies, but those that successfully scale their highest-value innovations."* 22 June 2026. https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/

9. **Rob Maxwell, Managing Director, Shell Qatar** — *"Being named to the Global Lighthouse Network demonstrates how the large-scale adoption of digital technologies can transform operational efficiency, reliability and environmental performance."* 21 Sept 2025. https://thepeninsulaqatar.com/article/21/09/2025/qatarenergy-and-shells-pearl-gtl-recognised-by-world-economic-forum-as-global-lighthouse-site

---

## 8. Source index

1. WEF — *Global Lighthouse Network 2025: WEF Recognizes 12 New Sites*, press release, 16 Sept 2025. https://www.weforum.org/press/2025/09/global-lighthouse-network-2025-world-economic-forum-recognizes-12-new-sites-driving-holistic-transformation-in-manufacturing/ — network size (201), 12 new sites incl. Qatar Shell GTL, cohort KPIs.
2. WEF — *Global Lighthouse Network 2025* (Jan cohort), 14 Jan 2025. https://www.weforum.org/press/2025/01/global-lighthouse-network-2025-world-economic-forum-recognizes-companies-transforming-manufacturing-through-innovation/ — 189 sites, Aramco North Ghawar & EGA Al Taweelah, 77%/9% analytical vs generative AI split.
3. WEF — *New Global Lighthouse Sites Demonstrate How AI Is Rewiring Manufacturing*, 22 June 2026. https://www.weforum.org/press/2026/06/new-global-lighthouse-sites-demonstrate-how-ai-is-rewiring-manufacturing-and-supply-chains/ — 238 sites, 16 new, Aramco Hawiyah NGL, per-site KPI examples.
4. McKinsey — *The continuing evolution of the Global Lighthouse Network*, 13 July 2026. https://www.mckinsey.com/capabilities/operations/our-insights/the-continuing-evolution-of-the-global-lighthouse-network — selection process, scaling gap, cohort KPIs.
5. Siemens Press — *Siemens Industrial Copilot expanded, adopted by thyssenkrupp*, 12 Nov 2024. https://press.siemens.com/global/en/pressrelease/siemens-industrial-copilot-expanded-adopted-thyssenkrupp — deployment description, absence of quantified savings.
6. Siemens Press — *Schaeffler and Siemens bring Industrial Copilot to shopfloor*. https://press.siemens.com/global/en/pressrelease/ai-industry-schaeffler-and-siemens-bring-industrial-copilot-shopfloor — Neike quote; demo-stage status; no metrics.
7. Siemens Newsroom — *Siemens unveils industrial AI innovations at CES 2026*, 14 Jan 2026. https://news.siemens.com/en-us/siemens-unveils-technologies-to-accelerate-the-industrial-ai-revolution-at-ces-2026/ — nine copilots, PepsiCo +20% throughput, 10–15% capex claim, Busch quote.
8. BMW Group Press — *BMW Group advances the use of Physical AI… Figure 03 in Spartanburg*. https://www.press.bmwgroup.com/global/article/detail/T0458778EN/... — Figure 02 11-month result, Figure 03 logistics use case, AIQX, BMW Virtual Factory.
9. Figure AI — *F.02 contributed to the production of 30,000 cars at BMW*, 19 Nov 2025. https://www.figure.ai/news/production-at-bmw — 90,000+ parts, 1,250+ hours, decommissioning.
10. BMW Group Press — *Artificial intelligence as a quality booster* (GenAI4Q, Regensburg), 28 Apr 2025. https://www.press.bmwgroup.com/global/article/detail/T0449729EN/... — per-vehicle inspection catalogues, Datagon AI, no metrics.
11. RCR Wireless — *BMW opens "most innovative" AI car factory in Hungary*, 9 Oct 2025. https://www.rcrwireless.com/20251009/industry-4-0/bmw-ai-car-factory-hungary — AIQX at Debrecen, plant stats, Zipse/Kemser quotes.
12. Electrek — *Tesla pushes Optimus V3 reveal later this year – again*, 22 Apr 2026. https://electrek.co/2026/04/22/tesla-optimus-production-fremont-model-sx-line/ — missed 10,000-unit target, zero useful work admission, revised timelines, Musk quote.
13. Mercedes-Benz Group — *Digital Factory Campus Berlin: humanoid robots*. https://group.mercedes-benz.com/company/production/procuction-network/mbdfc-humanoid-robots.html — Apollo tasks, investment size, MO360 integration, teleoperation/AR training.
14. Axios — *Hyundai plans 30,000 humanoid robots a year for factories by 2028*, 5 Jan 2026. https://www.axios.com/2026/01/05/hyundai-humanoid-robots-boston-dynamics — volumes, Metaplant, task sequence, payload.
15. TechTimes — *Hyundai commits 25,000 Atlas robots… union blocks deployment*, 22 May 2026. https://www.techtimes.com/articles/317005/20260522/... — KMWU statement of 22 Jan 2026, unit cost, labour arithmetic.
16. IFR — *World Robotics 2025 – Industrial Robots*. https://ifr.org/ifr-press-releases/news/global-robot-demand-in-factories-doubles-over-10-years — 542,000 installations 2024, 4.66m stock, regional split, forecasts.
17. IFR — *Robot Density Surges in Europe, Asia and the Americas*, 8 Apr 2026. https://ifr.org/ifr-press-releases/news/robot-density-surges-in-europe-asia-and-americas — density per 10,000 employees by country and region.
18. Rockwell Automation / PR Newswire — *90% of Manufacturers Say Digital Transformation Is Now Essential* (11th State of Smart Manufacturing), 2026. https://www.prnewswire.com/news-releases/90-of-manufacturers-say-digital-transformation-is-now-essential-according-to-new-global-study-302775186.html — 1,560 respondents/17 countries, 34% AI in operations, 43% data used, 46% cyber incidents.
19. Manufacturing Dive — *Why most US manufacturers still aren't using AI and automation*, 26 May 2026. https://www.manufacturingdive.com/news/most-us-manufacturers-still-not-automating-ai-robotics/819725/ — Deloitte 2025 survey 29%/24%, 80% zero automation, barriers.
20. BIC Magazine — *Industrial companies struggle to scale AI beyond pilot programs, McKinsey survey reveals*, 2025. https://www.bicmagazine.com/departments/maintenance-reliability/industrial-companies-struggle-to-scale-ai/ — two-thirds in pilots, 39% earnings effect, <5% EBIT.
21. Deloitte Insights — *2026 Manufacturing Industry Outlook*. https://www.deloitte.com/us/en/insights/industry/manufacturing-industrial-products/manufacturing-industry-outlook.html — 80% budget commitment, physical AI 9%→22%, NAM trade-uncertainty figures, ISM PMI.
22. The Manufacturing Institute / Deloitte — *Manufacturers Need as Many as 3.8 Million New Employees by 2033*, April 2024. https://themanufacturinginstitute.org/manufacturers-need-as-many-as-3-8-million-new-employees-by-2033/ — 3.8m / 1.9m unfilled / 65% talent challenge.
23. IoT Analytics — *US manufacturing reshoring boom: what the data says one year after "Liberation Day" tariffs*, 2026. https://iot-analytics.com/us-manufacturing-reshoring-boom-what-the-data-says/ — construction spending −21%, employment −1%, data-centre and hyperscaler capex contrast.
24. Dragos — *2026 OT/ICS Cybersecurity Year in Review*, 17 Feb 2026. https://www.dragos.com/resources/press-release/dragos-2026-year-in-review-new-ot-threats-ransomware — +64% ransomware, 119 groups, manufacturing >2/3 of victims, 42-day dwell time, Lee quote.
25. Computer Weekly — *Norsk Hydro cyber attack could cost up to $75m*, 2019. https://www.computerweekly.com/news/252467199/Norsk-Hydro-cyber-attack-could-cost-up-to-75m — cost breakdown and earnings impact.
26. Bosch Media Service — *Bosch Tech Day 2025*, 25 June 2025. https://us.bosch-press.com/pressportal/us/en/press-release-27776.html — $2.7bn AI investment, agentic maintenance, 1,500 patents, 65,000 trained, Rueckert quote.
27. Unilever — *Digital twins scaled across global manufacturing network with Accenture*, 16 June 2026. https://www.unilever.com/news/press-and-media/press-releases/2026/unilever-scales-digital-twins-across-global-manufacturing-network-with-accenture/ — 40+ new twins, five site-level quantified results, Raeburn-James quote.
28. GE Aerospace — *Expanding application of AI for blade inspections to CFM LEAP and GE9X*, 23 Oct 2024. https://www.geaerospace.com/news/press-releases/ge-aerospace-expanding-application-ai-blade-inspections-cfm-leap-and-ge9x-engines — 3h→1.5h, engine installed base, Jenkins quote.
29. NVIDIA Newsroom — *NVIDIA and TSMC bring AI into fabs*, 31 May 2026. https://nvidianews.nvidia.com/news/nvidia-and-tsmc-bring-ai-into-fabs-to-advance-semiconductor-design-and-manufacturing — cuLitho 20–50%, cuEST 50x, Metropolis/TAO defect inspection, FabTwin, Huang quote.
30. NVIDIA — *Foxconn develops physical AI-enabled smart factories with digital twins*. https://www.nvidia.com/en-us/case-studies/foxconn-develops-physical-ai-enabled-smart-factories-with-digital-twins/ — 150x CFD, ~50% planning-time reduction, Houston pre-construction status.
31. McKinsey — *Emirates Global Aluminium: leading the industry with AI-driven transformation*. https://www.mckinsey.com/capabilities/tech-and-ai/how-we-help-clients/rewired-in-action/emirates-global-aluminium-leading-the-industry-with-ai-driven-transformation — >$123m, 80+ use cases, −92% reaction time, +65% SOP compliance, 3,000+ upskilled.
32. Microsoft Customer Stories — *EGA cuts cost of manufacturing AI by 86% with Azure Stack HCI*. https://www.microsoft.com/en/customers/story/1777264680029793974-ega-azure-arc-discrete-manufacturing-en-united-arab-emirates — 86% cost, 13x latency, 2.9 PB video, 3-month time-to-production, Kraehenbuehl quote.
33. Aramco — *Fifth Aramco facility receives WEF Global Lighthouse Network status*, 14 Jan 2025. https://www.aramco.com/en/news-media/news/2025/fifth-aramco-facility-receives-world-economic-forum-global-lighthouse-network-status — five lighthouse sites, Al-Naimi quote.
34. The Peninsula Qatar — *QatarEnergy and Shell's Pearl GTL recognised… as Global Lighthouse Site*, 21 Sept 2025. https://thepeninsulaqatar.com/article/21/09/2025/... — 45+ digital solutions, Maxwell quote, first Qatari site.
35. EDGE Group — *EDGE charts defence manufacturing progress at Make it in the Emirates 2026*, May 2026. https://edgegroup.ae/news/edge-charts-defence-manufacturing-progress-make-it-emirates-2026 — 68 Industry 4.0 projects, 28 facilities, 5,276 trained, AED 596m ICV, Al Marar quote.
36. EDGE Group — *EDGE launches Group AI Accelerator*, 19 May 2025. https://edgegroup.ae/news/edge-launches-group-ai-accelerator-drive-excellence-ai-enhanced-solutions — remit, governance, Kasmi quote.
37. MoIAT — *UAE Industry 4.0*. https://moiat.gov.ae/en/programs/uae-industry-4-backup — programme framing, Index/Champions/Leadership/Talent 4.0, TTP.
38. Zawya — *MoIAT and Noventiq partner to digitally transform 20 UAE factories*, Jan 2025. https://www.zawya.com/en/press-release/companies-news/make-it-in-the-emirates-2025-moiat-and-noventiq-partner-to-digitally-transform-20-uae-factories-with-industry-40-technologies-qxdas8iz — 20 factories, AED 3m in services.
39. Enterprise MENA+ — *PIF pivots Alat from chip manufacturing to data center buildout*, 10 Apr 2026. https://enterpriseam.com/menaplus/2026/04/10/pif-pivots-alat-from-chip-manufacturing-to-data-center-buildout/ — scrapped semiconductor plans, CEO change, $100bn original mandate.
40. US ITA / trade.gov — *Saudi Arabia: ICT cross-border data transfer rules now under enforcement*, Aug 2025. https://www.trade.gov/market-intelligence/saudi-arabia-ict-cross-border-data-transfer-rules-now-under-enforcement — PDPL residency requirement, SDAIA/NCA enforcement.
41. EU-OSHA — *Regulation 2023/1230/EU – machinery*. https://osha.europa.eu/en/legislation/directive/regulation-20231230eu-machinery — 20 Jan 2027 application date, AI safety-function coverage, third-party conformity assessment.
42. Regulation-AI.eu — *Annex I High-risk AI: Safety Components in Regulated Products*. https://www.regulation-ai.eu/en/annex-i/ — Annex I high-risk pathway and 2 Aug 2028 deadline.
43. Covington Global Policy Watch — *EU AI Act Update: Timeline Relief, Targeted Simplification, and New Prohibitions*, May 2026. https://www.globalpolicywatch.com/2026/05/eu-ai-act-update-timeline-relief-targeted-simplification-and-new-prohibitions/ — omnibus timeline changes (**fetch failed: redirect loop — unverified**).
44. Control Design — *Artificial intelligence is coming for PLC programming, but not how you think*, 21 Aug 2025. https://www.controldesign.com/control/plcs-pacs/article/55311461/... — Siemens engineers on structured text vs ladder, code comprehension, IEC 61131-3 safety rationale.
45. Automotive Manufacturing Solutions — *AI vision finds its footing on the factory floor*. https://www.automotivemanufacturingsolutions.com/smart-factory/ai-vision-finds-its-footing-on-the-factory-floor/2644253 — 77% pilot-stall figure (self-flagged as unexamined), false-positive trust mechanism, 36ZERO Vision/phil-vision/aku.automation.
46. Quality Magazine — Erik Nieves, *The 'Dark Factory' Myth*, 6 Mar 2026. https://www.qualitymag.com/articles/99453-the-dark-factory-myth — lights-out critique, 2030 single-plant projection.
47. McKinsey — *Prediction at scale: how industry can get more value out of maintenance*, 22 July 2021. https://www.mckinsey.com/capabilities/operations/our-insights/prediction-at-scale-how-industry-can-get-more-value-out-of-maintenance — PdM scaling constraint, triple-digit model counts.

---

## 9. Gaps & caveats

**Searched for and could not verify:**
- **Quantified Siemens Industrial Copilot savings.** Both the thyssenkrupp and Schaeffler releases are qualitative. The widely repeated "engineering time savings" attributed to Industrial Copilot could not be traced to a Siemens-published percentage in either release. Treat any specific % figure circulating for Schaeffler/thyssenkrupp as unsourced.
- **BMW AIQX quantified outcomes.** AIQX is well documented as deployed (Debrecen, group-wide) but BMW has published **no defect-detection rate, false-positive rate or cost figure**. Same for GenAI4Q.
- **The "77% of AI vision projects never leave pilot" statistic.** The publication that cites it explicitly calls it *"widely cited, rarely examined."* Do not use it as a hard number.
- **A credible, primary criticism paper on Global Lighthouse Network representativeness.** The representativeness critique in §4.1 is constructed from the WEF's own disclosed numbers (238 sites, self-nomination, cohort composition) plus McKinsey's own admission that most industrials cannot scale — not from a published independent audit. I found no peer-reviewed critique.
- **Ma'aden, SABIC, Emirates Steel Arkan, Ducab, Strata and QAFCO AI deployments with quantified outcomes.** SABIC publishes a digital-transformation narrative in its Integrated Annual Reports (https://www.sabic.com/en/reports/integrated-report-2024/value-chain-impact/digital-transformation) but I could not extract audited AI-attributable financial figures within this session's search budget. Treat regional coverage outside Aramco / EGA / EDGE / Pearl GTL as thin.
- **Arabic-language shop-floor AI performance.** No sourced deployment reporting Arabic copilot accuracy or adoption on a GCC production line was found. §6.6 is therefore an inference from workforce composition and regulatory language, flagged as such.
- **Toyota's public position on generative AI vs TPS**, and **ABB/Fanuc/Schneider internal-factory AI results** — not covered; this session's web-search budget was exhausted before these could be researched. Schneider's most-cited AI material is product marketing, not internal deployment evidence (verified: https://rcrwireless.com/20250514/internet-of-things/schneider-ai-factory-edge-infra shows product/copilot launches, not internal plant results).
- **EU AI Act omnibus revised deadlines** — the Covington source failed to fetch (redirect loop). Verify Annex I dates against the Official Journal before publication.

**Weakest figures in this dossier:**
1. The **77% pilot-stall** vision statistic (source self-disclaims it).
2. **EGA's >$123m** — a consultant case study; client-attributed but not independently audited or reconcilable to EGA's published accounts.
3. **Siemens/PepsiCo +20% throughput** — vendor-claimed, single deployment, no baseline disclosed.
4. **Foxconn's ~50% planning-time reduction** and **150x CFD** — vendor case study for a plant not yet operating.
5. **Bosch's "several million euros"** — explicitly a projection, not a realised saving.
6. **McKinsey PdM article (2021)** — the most precise public statement of the PdM scaling problem, but five years old; used for mechanism, not for current rates.

**Strongest figures (safe for public use):** IFR robot installation/density data; WEF lighthouse cohort KPIs and network sizes; Deloitte/Manufacturing Institute workforce numbers; Dragos ransomware statistics; Unilever's site-level twin results; GE Aerospace's 3h→1.5h; IoT Analytics' construction-spend series; Tesla's own missed targets; the EU Machinery Regulation date.
