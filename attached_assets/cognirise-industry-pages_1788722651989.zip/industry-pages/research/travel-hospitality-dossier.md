# Travel & Hospitality — AI Evidence Dossier

**Prepared for Cognirise industry page. Evidence window: 2024 – Sept 2026. Compiled 6 September 2026.**
Every figure below carries a source URL and date in the Source Index (§8). Labels: [company-reported], [vendor-claimed], [analyst-estimate], [regulator/official], [independent study].

---

## 1. State of the industry from an AI perspective

Travel is the first consumer industry where a general-purpose AI interface sits directly between the customer and the supplier — and it is also one of the thinnest-margin industries on earth. That combination is what makes its AI story unlike banking, telco or healthcare: the distribution layer is under existential attack at the same moment the operating margin is too small to absorb a failed transformation.

**The margin backdrop is brutal and got worse in 2026.**

1. IATA's December 2025 outlook forecast 2026 industry net profit of **$41.0bn on a 3.9% net margin**, with **$7.90 net profit per passenger** on $1.053tn of revenue [regulator/official — IATA, 9 Dec 2025]. Willie Walsh's framing is the single most quotable line in the industry: *"Apple will earn more selling an iPhone cover than the $7.90 airlines will make"* per passenger.
2. Six months later IATA **halved** that outlook: **$23.0bn net profit, 2.0% net margin, $4.50 profit per passenger**, on $1.165tn revenue, driven by Middle East conflict and jet fuel averaging ~$152/bbl vs $90 in 2025 [regulator/official — IATA, 7 Jun 2026]. The Middle East region flipped from a forecast $6.8bn profit (9.3% margin, $28.60/passenger — the world's best) to a **projected $4.3bn net loss (-6.1% margin)**.
3. Practical consequence: an AI programme that costs 1% of revenue must return more than half the industry's entire net margin to be worth doing. AI business cases in travel are judged against a 2% margin, not a 20% one. This is the industry's defining AI constraint.

**Adoption is broad but shallow.**

4. Phocuswright (Feb 2026, global survey of senior travel executives): **60%+ of travel businesses are experimenting with or scaling agentic AI**, but only **6% are actively scaling** and 22% "beginning to scale"; **over 50%** are already exploring or implementing MCP and A2A interoperability standards [independent study].
5. Skift *State of Travel 2026* (Aug 2026): **33% of travel companies are experimenting with agentic AI; 2% have scaled it**. Only **6% of hotels appear in AI-generated search results** [independent study].
6. SITA/industry projection cited by Computer Weekly (Jul 2026): **97% of airlines and 82% of airports** expect to invest in AI by end-2026 [vendor-claimed, SITA].

**Where value has actually shown up in reported financials — customer service, not revenue.**

7. **Airbnb**: support cost per booking down **~16% YoY**, with **~45% of customer issues resolved without human intervention** (Q2 2026) [company-reported, via Skift 18 Aug 2026]. In Feb 2026 the company reported **one-third of US/Canada customer support handled by AI**, targeting >30% of global tickets across all languages within a year [company-reported].
8. **Booking Holdings**: customer service **cost per booking declining at a double-digit rate** (Q2 2026 call); Agoda specifically achieved a "double-digit reduction in customer service cost per booking" (Q1 2026) [company-reported]. FY2025 saw an absolute YoY decrease in customer service costs despite 12% gross-bookings growth [company-reported, 18 Feb 2026].
9. **Expedia Group**: **>250 million service interactions annually, more than 30% AI-powered**; AI-enabled tools "driving hundreds of millions of dollars in realized marketing value" (Q1 2026) [company-reported]. Q1 2026 adjusted EBITDA rose **83% YoY to $542m** on 15% revenue growth — the clearest financial inflection in the sector, though management does not attribute it solely to AI.
10. **Air India**: AI.g virtual agent handles **40,000 queries/day**, **97% resolved without human escalation**, **13m+ conversations** since launch, deployed within six months; ~50% of customers now choose the AI as first contact [company-reported via Microsoft customer story, 11 Feb 2026].

**Distribution: the disruption is real but has not yet moved bookings.**

11. **LLM referrals remain under 1% of Booking Holdings' room nights**, paid and unpaid combined, with CFO Ewout Steenbergen stating it "hasn't moved so much recently, so no material change over the last few months or quarters" (4 Aug 2026) [company-reported]. This is the single most important counter-fact to the "LLMs will eat the OTAs" thesis.
12. But the *search* layer is already eroding: CEO Glenn Fogel — *"I do believe that some of the changes that were made in the display at Google definitely put some pressure on SEO"* — while noting direct traffic (mid-60% of B2C mix) "hasn't gone down at all" (Aug 2026) [company-reported].
13. Expedia calls answer engines its **"fastest-growing channel"**, with ChatGPT ads launched Feb 2026 showing encouraging new-user conversion and higher average purchase size [company-reported, Q1 2026].
14. **Wyndham** reports **ChatGPT app referral traffic converts 20% higher** than other website traffic [company-reported, Q2 2026 call, 23 Jul 2026] — a rare positive conversion data point from the agentic channel.

**Consumer trust is the gating factor, not capability.**

15. Expedia's own survey: **only 8% of travellers are comfortable with AI handling bookings** [company-reported, Apr 2026]. Expedia VP of AI alliances Clayton Nelson: *"What our data is telling us is that travelers probably won't enjoy that [AI booking] experience."*
16. Wunderkind "Future of Travel" (23 Jul 2026): **54% of travellers distrust AI-generated travel recommendations**; only **24%** trust them; **50%** are comfortable using AI to *compare* flights/hotels/packages; **40%** are uncomfortable sharing personal data [independent study].
17. Skift *State of Travel 2026*: traveller **familiarity** with AI trip-planning tools at **62%**, usage up **124% YoY**, with business travellers using AI at roughly twice the rate of leisure travellers [independent study]. Discovery has shifted "from search-scroll-compare to ask-shortlist-decide."

**Workforce and data structure.**

18. **65% of surveyed US hotels report staffing shortages** (down from 76% in May 2024); **9% severely understaffed**; most-needed roles are housekeeping (38%) and front desk (26%); 71% have unfilled openings averaging 6–7 per property; hotel employment remains ~10% below pre-pandemic levels [independent study — AHLA/Hireology, n=282, survey Dec 2024–Jan 2025]. The labour gap is in *physical* roles AI cannot fill, not in the desk roles AI is being pointed at.
19. The data estate is genuinely fragmented: PMS, CRS, CRM, GDS, RMS, loyalty and booking engines are separate systems, frequently per-property and franchise-owned. Expedia CPO Shilpa Ranganathan on why its chatbot failed: *"You can't put a tower on a foundation of sand"* — the fix took roughly a year with "almost no work on the model itself," and was almost entirely evaluation frameworks and data grounding [company-reported, 2026].
20. **Marriott** committed **$1.0–1.1bn of 2026 capex with up to 40% earmarked for digital technology transformation**, with CIO Naveen Manga calling 2026 *"a year for scale"* after a 2025 of piloting [company-reported, Feb/Aug 2026].

---

## 2. Challenges in the AI era specific to travel & hospitality

**(a) A 2% net margin cannot fund a speculative AI programme.** With IATA's revised 2026 industry margin at 2.0% and $4.50 profit per passenger (Jun 2026), airline AI investment competes directly with fuel hedging and fleet. This is why airline AI spend clusters in provable-savings domains (gating, turnaround, crew, fuel) rather than experience. Contrast hotels, where brand-level franchisors (Marriott, Hilton, Wyndham) fund technology centrally and recover it via fees — Wyndham has spent **$450m+ on technology since 2018** [company-reported, Jul 2026].

**(b) The customer interface is being disintermediated by parties who own no inventory.** Google launched **in-chat hotel booking inside AI Mode on 27 Aug 2026**, with Booking.com, Choice, Expedia, Hilton, Hotels.com, IHG, Marriott, Priceline, Trip.com and Wyndham as launch partners, paying via Google Pay — and critically, Google **withholds chat context and inspiration signals from partners**, sharing only name, payment, occupancy and property. Suppliers get the transaction and lose the intent data. That data asymmetry, not the commission, is the strategic problem.

**(c) Personalised pricing is now a legal-risk category, not just a revenue lever.** New York's **Algorithmic Pricing Disclosure Act took effect 10 Nov 2025**, requiring the literal on-screen disclosure *"THIS PRICE WAS SET BY AN ALGORITHM USING YOUR PERSONAL DATA,"* with civil penalties of $1,000 per violation [regulator/official]. California's **AB 325 (effective 1 Jan 2026)** restricts "common pricing algorithms" in anticompetitive agreements. The FTC's 6(b) surveillance pricing study (17 Jan 2025) named **PROS** — an airline/hospitality pricing vendor — among the intermediaries studied [regulator/official]. Delta's experience (see §3) shows the reputational cost arrives before the revenue does.

**(d) Real-time inventory grounding is harder in travel than in retail.** Prices, availability and fare rules change by the second and are governed by fare filings, NDC offers and channel-specific contracts. Sabre describes its MCP Server as *"a secure intelligent translation layer"* enabling agents to do ticket reissues, exchanges and itinerary changes — i.e., the hard part is servicing, not shopping [company-reported, Q2 2026]. Phocuswright Europe 2026 case studies identify **API bottlenecks** and **data dependency** as the top two barriers.

**(e) Legacy distribution standards are an unfinished prerequisite.** Agentic booking requires machine-readable, dynamically-priced offers and orders. IATA's public NDC fact sheet (June 2026) still contains **no adoption percentage or target**, stating only that "it remains each airline's responsibility to individually assess the opportunity for NDC adoption and to decide their best timelines" [regulator/official]. Travelport's API-driven share of customer volume moved from **43% (2022) to 63% (2026)** — a decade-scale migration, not a two-year one.

**(f) Guest data is high-sensitivity and increasingly sovereign.** Hotel and airline records contain passport, biometric, health/dietary, and location data — precisely the categories most regulated. Saudi Arabia's PDPL has been fully enforceable since **14 Sept 2024**, with **48 SDAIA enforcement decisions by mid-January 2026**, fines up to **SAR 5m** (doubled for repeat violations), and an extraordinarily tight **5-day window to respond to an alleged violation** [regulator/official, Clyde & Co, Mar 2026]. Any AI system touching guest PII in KSA needs a compliance-response operating model, not just a DPIA.

**(g) The EU AI Act timetable moved, which is a planning hazard, not a reprieve.** The Digital Omnibus provisional agreement of **6 May 2026** pushed standalone Annex III high-risk obligations from 2 Aug 2026 to **2 Dec 2027**, and embedded-product AI to **2 Aug 2028**; transparency obligations still land **2 Aug 2026**, with a four-month watermarking grace period to 2 Dec 2026 [regulator/official]. Travel systems that touch biometric identification (airport e-gates), employment decisions (crew/housekeeping scheduling) or essential-service access sit in or near Annex III. Deferral means budgets slip and readiness decays.

**(h) Franchise and asset-light structures fragment the deployment unit.** Marriott, Hilton, Wyndham and IHG mostly do not own or operate the hotels. Wyndham's AI Concierge is at ~1,500 of ~8,400 hotels; Wyndham Connect at 5,000+. Any AI rollout is a franchisee adoption campaign with its own ROI proof burden per owner — Wyndham's pitch is that engaged franchisees generate **$100,000+ in additional annual revenue** [company-reported/vendor-claimed, Jul 2026].

---

## 3. What key players are doing

**Distribution & OTAs**

1. **Booking Holdings** — Natural language search rolled out globally on Booking.com; smart filters across verticals including cars; Priceline's **Penny** now supports conversational multi-product booking with a "dynamic travel map" and shows "noticeable uplift" in engagement in early testing; OpenTable's AI concierge expanded from Q&A into discovery with voice-enabled reservations. Agentic service flows for complaints and cancellations. Group transformation programme on track for **$500–550m in-year savings**. LLM referrals <1% of room nights. [company-reported, Q1 2026 call 28 Apr 2026; Q2 call 4 Aug 2026]
2. **Expedia Group** — Multi-surface strategy: Trip Matching on Instagram (May 2025), launch partner for Microsoft Copilot Actions (Apr 2025), ChatGPT app (Oct 2025), ChatGPT ads (Feb 2026), Uber partnership. **>30% of 250m+ annual service interactions AI-powered**; **60%+ increase in traveller-intent data** from natural-language search and agent tools; higher conversion at Vrbo and record attach rates attributed to AI capabilities. [company-reported]
3. **Sabre** — First agentic APIs plus MCP Server; **active pilot/production partners doubled from 30 to 60 in Q2 2026**; hundreds of developers in production; 400+ developers at a Silicon Valley hackathon judged by Andrew Ng with American Airlines and PayPal executives; MCP Server deployed with a global enterprise loyalty/travel services company for autonomous reissues, exchanges and itinerary changes. CEO Kurt Ekert: *"Agentic AI is no longer just a future opportunity. It is transforming how travel is bought and serviced."* Management is explicit that **consumer agentic volumes remain "small"** and the timeline has shifted to medium-to-long term. [company-reported, 13 Aug 2026]
4. **Amadeus** — Acquired Y Combinator-backed **SkyLink** (Feb 2026), whose orchestration engine enabled conversational bookings through Slack and Microsoft Teams; publishes standards positioning on MCP/UCP. AI ROI is not disclosed separately and is bundled into R&D. [company-reported / traveldistributionnews, Jul 2026]
5. **Travelport** — TripServices integrated with Travelsoft's Orchestra using Anthropic's Model Context Protocol (1 Jul 2026), reaching **400+ European travel agencies**; API-driven share of customer volume 43% (2022) → **63% (2026)**; shareholders committed **$50m** to accelerate. [company-reported]
6. **Google** — AI Mode agentic hotel booking live in the US from 27 Aug 2026 with ten major supplier/OTA launch partners, transacting via Google Pay with Google as facilitator, not merchant of record.
7. **OpenAI** — ChatGPT apps launched Oct 2025 with **Booking.com and Expedia among the first**. See §4/§3 (11) for the documented reversal.

**Airlines**

8. **Delta Air Lines** — AI-assisted fare setting with **Fetcherr**: 1% of domestic network (Nov 2024) → **3% (Q2 2025)**, with a stated **20% by end-2025** target. President Glen Hauenstein: *"We like what we see. We like it a lot… but we're going to take our time."* CEO Ed Bastian has said AI could improve profitability by as much as 50% (roughly 10% → 15% margins). Delta insists it does not share customer personal information with Fetcherr and uses aggregated data. [company-reported, Jul 2025 – Aug 2026]
9. **American Airlines** — **Smart Gating** (machine learning gate assignment): **20% taxi-time reduction at DFW (~2 minutes per flight, 11+ hours daily)**, ~1 minute per flight at CLT, **17 hours saved daily across hubs**, **1.4m gallons of jet fuel and 13,000+ tonnes of CO₂ saved annually**, **>50% reduction in gate conflicts at DFW**, 70% fewer ramp-blocking incidents at DCA, 11% of on-the-ground gate changes eliminated at CLT. Deployed at DFW, CLT, MIA, DCA, ORD. [company-reported, Nov 2023 — the most precisely quantified airline AI result in the public record]
10. **Air India** — **AI.g**, the first airline generative-AI virtual agent deployed at scale: 40,000 queries/day, **97% resolution rate**, 13m+ conversations, built on Azure OpenAI, live within six months; "millions" saved (unquantified). [company-reported, Feb 2026]
11. **Qatar Airways** — **Sama**, an AI digital-human cabin crew, extended at Web Summit Qatar (Feb 2025) to conversational itinerary curation across QVerse, app and web; an Arabic-speaking version was announced for Arabian Travel Market. Separately, Qatar Airways engaged **Accenture** (Aug 2025) for a group-wide programme, **"AI Skyways"**, covering schedule optimisation, predictive maintenance, personalisation and real-time decision support, with a responsible-AI framework and a value realisation office. Contract value undisclosed. CEO Badr Mohammed Al-Meer: *"a significant milestone in our journey to become leaders in AI-driven aviation."*
12. **Emirates Group** — Enterprise-wide **ChatGPT Enterprise** deployment with OpenAI (21 Nov 2025), plus AI literacy programmes, an internal AI champion network, an **AI Centre of Excellence**, sandboxes and early research access. EVP IT Ali Serdar Yakut: *"We see enormous potential for AI technology to support our business requirements."* Scope is capability-building; no outcome metrics published as of Sept 2026.
13. **Riyadh Air** — Launched with **IBM** as the *"world's first AI-native airline"* (8 Dec 2025): IBM watsonx Orchestrate agentic platform, AI-enabled voice bots and agent assist, an agentic concierge for crew enablement, contextually-aware next-best-action agents, an AI-powered digital workplace — **59 workstreams, 60+ partners including Adobe, Apple, FLYR and Microsoft, over a three-year collaboration**, targeting 100+ destinations by 2030. No performance outcomes published yet. [company-reported]
14. **Alaska Airlines** — Natural-language destination discovery built on Azure OpenAI/Microsoft Foundry, plus **Odysee**, an AI schedule-optimisation startup launched with UP.Labs. [company-reported/vendor-claimed]
15. **Lufthansa & Fraport** — **"Seer"**, an AI camera system at Frankfurt monitoring baggage handling, catering and refuelling to detect turnaround bottlenecks in real time (Aug 2025). **Korean Air** — ChromeOS migration plus generative AI agent support saving agents **5–7 minutes at boot-up alone** (Jul 2025). [vendor-claimed/company-reported via OAG]

**Hotels**

16. **Hilton** — **Hilton AI Planner**, an Anthropic-powered conversational planner, beta 10 Mar 2026, full hilton.com availability 17 Mar 2026, spanning 28 brands / 9,400+ properties / 1.4m rooms / 144 countries / 260m Honors members. Explicitly **multi-LLM**: Google, OpenAI and Anthropic integrations. CEO Chris Nassetta: *"AI allows us to be more efficient and more effective. That is code for continuing to build more direct lines to our customers"* — with 80%+ of business already direct. [company-reported, Mar–Apr 2026]
17. **Marriott** — 2025 pilot year, 2026 "year for scale": natural-language search phased from Q2 2026 across Marriott.com and the Bonvoy app; a "horizontal, protocol- and model-agnostic AI chassis"; content optimisation for AI visibility; Google AI Mode partnership from Nov 2025; a ChatGPT ad pilot; new PMS and reservation systems to "a meaningful number of hotels" in 2026. Bonvoy at 271m members (+43m in 2025). CEO Anthony Capuano sees an *"opportunity to potentially redefine the customer acquisition paradigm."* [company-reported]
18. **Wyndham** — The most granular hotel AI numbers published: **Wyndham Connect at 5,000+ hotels** (40m+ guest messages, ~260,000 daily interactions), **AI Concierge at ~1,500 properties**; **direct voice conversion +~200bps**, **guest satisfaction +400bps**, **AI Concierge reservations carry 15% higher ADR than phone bookings**, direct contribution up to **+500bps** at participating properties, and **ChatGPT app referrals converting 20% higher** than other web traffic. Partner: Canary Technologies. [company-reported/vendor-claimed, 23–29 Jul 2026]
19. **Hyatt** — J.P. Morgan (5 Mar 2026) reports Hyatt group sales teams roughly **20% more productive** since AI tool deployment, and Wyndham AI-powered call centres reducing franchisee labour costs; the analysts frame 2026 as an "inflection point" from pilots to earnings impact [analyst-estimate].
20. **IHG / Choice** — IHG launched an AI-powered search tool integrated with ChatGPT in Q2 2026; Choice advanced an enterprise-wide AI deployment with AWS [company-reported, Aug 2026].
21. **Accor** — Deputy CEO Jean-Jacques Morin (Skift Global Forum East, Abu Dhabi, 30 Oct 2025) described investing in AI to **optimise hotel staffing and shift employees into guest-facing roles** — the clearest public statement of AI-for-labour-reallocation in hospitality, though without disclosed programme detail.

**Documented failure / reversal — three, in order of significance**

22. **OpenAI walked back in-ChatGPT travel checkout (Mar 2026).** OpenAI scrapped plans to complete purchases and bookings inside ChatGPT, moving Instant Checkout to third-party apps and stating it is *"prioritizing making ChatGPT search and product discovery great, with the Agentic Commerce Protocol serving as infrastructure."* Skift's framing — "Good News for Expedia and Booking" — captures the market read: technical, behavioural and regulatory barriers stopped conversational AI from handling complex travel transactions [reported 5 Mar 2026, updated 11 May 2026].
23. **Expedia retired Romie**, its flagship 2024 AI assistant. The published post-mortem is unusually candid: responses were ungrounded — disconnected from live inventory, rates and reservations — and customers abandoned chats over inaccuracy, not tone. The repair took roughly a year and involved "almost no work on the model itself," instead rebuilding evaluation frameworks and data grounding. CPO Shilpa Ranganathan: AI is *"an organizational problem before a technological one."*
24. **Delta's AI pricing rollout stalled under political pressure.** After Delta disclosed 3% of the domestic network on Fetcherr-assisted pricing with a 20% year-end target (Jul 2025), Senators Ruben Gallego, Richard Blumenthal and Mark Warner wrote to CEO Ed Bastian demanding detail on data collection and model training. Delta issued a public clarification on **1 Aug 2025**: *"There is no fare product Delta has ever used, is testing or plans to use that targets customers with individualized prices based on personal data,"* attributing the episode to "confusion and misinformation." As of Aug 2026 reporting, the coverage still cites 3% as the disclosed deployment figure — no public confirmation that the 20% target was reached.

---

## 4. Proven vs. not proven — myths and reality

**Myth 1: "LLM trip planners will replace OTAs."**
Evidence against: LLM referrals are **<1% of Booking Holdings' room nights**, unchanged over several quarters (Aug 2026). Only **8%** of travellers are comfortable letting AI book (Expedia, Apr 2026); **54%** distrust AI recommendations (Wunderkind, Jul 2026). OpenAI abandoned in-chat checkout (Mar 2026). Evidence for: Skift finds AI trip-planning tool usage up **124% YoY** with 62% familiarity; Expedia calls answer engines its fastest-growing channel; Google shipped agentic hotel booking with ten major partners (Aug 2026); Wyndham sees ChatGPT referrals convert 20% better. **Verdict: Contradicted as stated; proven in pockets as a top-of-funnel discovery shift.** The threat that is real today is to *paid and organic search economics*, not to booking share.

**Myth 2: "Personalised pricing is AI's big win in travel."**
Delta ran AI-assisted pricing on 3% of its domestic network, drew a Senate inquiry, and issued a formal denial that it prices on personal data (Aug 2025). New York now requires an explicit on-screen algorithmic-pricing disclosure (Nov 2025, $1,000/violation); California AB 325 took effect Jan 2026; the FTC's 6(b) study documented the practice across intermediaries including travel pricing vendor PROS (Jan 2025). The verified gains are in *aggregate* demand forecasting and offer optimisation, not individual willingness-to-pay. **Verdict: Unproven as an individualised play, and now actively hazardous; proven in pockets as aggregate dynamic pricing/RM.**

**Myth 3: "AI concierges replace the front desk."**
Wyndham's AI Concierge sits at ~1,500 of ~8,400 hotels and is credited with **15% higher ADR** on its reservations and a **400bps guest-satisfaction lift** — augmentation of the booking and messaging layer, not desk replacement. Meanwhile 65% of US hotels report staffing shortages concentrated in **housekeeping (38%)** and front desk (26%) — the shortage is physical-presence labour. Rotana's UAE deployment (15 hotels, 4,240 rooms, Aug 2026) uses WhatsApp pre-arrival registration and facial verification so staff can *"welcome them and issue room key cards without requiring passport presentation"* — the human is still there, the paperwork is gone. Accor's stated aim is to "shift employees to more guest-focused roles." **Verdict: Contradicted as replacement; Proven in pockets as pre-arrival/administrative removal.**

**Myth 4: "Chatbots handle most guest and traveller queries."**
Air India: **97% of 40,000 daily queries** resolved by AI [company-reported]. Airbnb: **~45%** resolved without a human, **one-third** of US/Canada support (Feb 2026). Expedia: **>30%** of 250m+ interactions. So it is true in airline post-booking service where intents are narrow and structured, and materially untrue elsewhere. Note also the definitional gap: Air India's 97% is *resolution of queries the AI received*, not 97% of all customer contact. **Verdict: Proven at scale in airline/OTA post-booking service; Unproven in independent hotel operations.**

**Myth 5: "AI disruption management saves airlines millions."**
The best-documented case is not generative at all: American's **Smart Gating** — 20% taxi-time reduction at DFW, 17 hours saved daily across hubs, 1.4m gallons of fuel and 13,000+ tonnes CO₂ annually. American also used generative AI rebooking to help **200,000+ travellers** during East Coast storms (Aug 2025). Lufthansa/Fraport "Seer" and Korean Air's 5–7 minutes/agent are directionally positive but unquantified in currency. Searches for a verified, currency-denominated IROPS ROI figure from a named airline returned only vendor marketing ("up to 30% disruption cost reduction") that could not be corroborated against a company disclosure. **Verdict: Proven at scale in operational optimisation (fuel, taxi, gating); Unproven as a headline "millions saved" IROPS claim in public disclosures.**

**Myth 6: "AI pays for itself in hotel revenue management."**
IDeaS G3 RMS and Duetto are genuinely widely deployed — IDeaS won a portfolio-wide agreement with Red Sea Global Hospitality (Oct 2025) covering Shebara (73 villas), Desert Rock (64 suites/villas) and Turtle Bay. But that press release, like most in the category, states expected capabilities ("precision pricing," "real-time portfolio visibility") and **no outcome metric**. The frequently-circulated "19% RevPAR increase" figures for AI RM appear only on vendor and affiliate sites and could not be verified against an operator disclosure. **Verdict: Proven in pockets; the category's public ROI evidence is materially weaker than its adoption.**

**Myth 7: "Agentic AI is already scaled in travel."**
Phocuswright: 6% actively scaling. Skift: 2% scaled. Sabre's own management says consumer agentic volumes are "small" and has pushed the timeline to medium-to-long term, noting large AI platforms are prioritising enterprise before retail e-commerce, with travel later still. **Verdict: Contradicted.**

**Myth 8: "Better models are the bottleneck."**
Expedia's Romie post-mortem: a year of remediation with "almost no work on the model itself." Phocuswright Europe 2026 case studies name data dependency, API bottlenecks, cost-vs-value and trust as the barriers. TrustYou's working agent required a memory layer over 1.6m properties, 250m reviews and 2bn sentiment datapoints. **Verdict: Contradicted — the bottleneck is grounding, evaluation and integration.**

**Myth 9: "Loyalty data gives incumbents an unassailable AI moat."**
Chesky's claim rests on **200m verified identities, 500m proprietary reviews** and host messaging used by 90% of guests; Marriott has 271m Bonvoy members, Hilton 260m Honors. But Google's AI Mode booking design **deliberately withholds chat context and inspiration signals** from those same partners. Fogel has publicly said *"there is no such thing as a moat."* **Verdict: Unproven — first-party data is necessary but is being offset by loss of intent data at the new front door.**

---

## 5. High-impact use cases with ROI evidence

| # | Use case | Class | Who / evidence | Quantified outcome | Prerequisites | Time-to-value |
|---|---|---|---|---|---|---|
| 1 | **ML gate assignment & taxi optimisation** | Analytical | American Airlines Smart Gating, DFW/CLT/MIA/DCA/ORD | 20% taxi-time cut at DFW (~2 min/flight); 17 hrs/day across hubs; 1.4m gal fuel + 13,000t CO₂/yr; >50% fewer gate conflicts at DFW [company-reported] | Real-time ops feed, gate/stand topology, ground-crew integration | Piloted DFW 2021, hub-wide by 2023 |
| 2 | **Gen-AI customer service deflection (airline)** | Generative | Air India AI.g | 40,000 queries/day; 97% resolved without escalation; 13m+ conversations; ~50% of customers pick AI first [company-reported] | Grounded PNR/policy retrieval, multilingual, escalation design | Deployed within 6 months |
| 3 | **AI support agent (marketplace)** | Agentic | Airbnb, US/Canada then global | Support cost per booking **−16% YoY**; ~45% issues resolved without human; one-third of US/CA support [company-reported] | Identity, reviews, host-messaging corpus; ticket taxonomy | Quiet rollout May 2025 → 1/3 of US/CA by Feb 2026 |
| 4 | **Contact-centre cost per transaction (OTA)** | Generative + agentic | Booking Holdings / Agoda | Double-digit % decline in CS cost per booking; absolute FY2025 CS cost decrease despite +12% gross bookings [company-reported] | Agentic flows for complaints/cancellations; partner policy data | ~2 years (2024→2026) |
| 5 | **Natural-language search & smart filters** | Generative | Booking.com (global), Marriott (H1 2026), Hilton AI Planner (Mar 2026), IHG, Wyndham | Expedia: **+60% traveller-intent data**; Booking: faster search, shorter booking paths, lower cancellation rates, higher CSAT [company-reported]; Wyndham AI Concierge reservations **+15% ADR** vs phone | Structured property/amenity content; live rates; eval harness | Hilton beta→GA in 7 days; Marriott 12+ months pilot→scale |
| 6 | **Answer-engine / agentic distribution channel** | Agentic | Expedia (ChatGPT app + ads), Wyndham, Google AI Mode (10 launch partners) | Wyndham: ChatGPT referrals convert **20% higher**; Expedia: fastest-growing channel, encouraging new-user conversion and higher basket [company-reported]. Counterweight: Booking LLM referrals **<1%** of room nights | MCP/agentic API surface; AI-legible content; payment rails | Live 2025–26; volumes still small |
| 7 | **AI-assisted fare/offer pricing** | Analytical | Delta + Fetcherr; also Virgin Atlantic, Royal Air Maroc, Viva Aerobus | 3% of Delta domestic network (Q2 2025); target 20% by YE2025; Bastian claims AI could lift profitability up to 50% (~10%→15% margin) — **projected, not documented** | Aggregated demand data; disclosure compliance (NY/CA); no personal-data targeting | 18+ months partnership before 3% |
| 8 | **Hotel revenue management (RMS)** | Analytical | IDeaS G3 + Optix at Red Sea Global Hospitality (Shebara, Desert Rock, Turtle Bay) | Capabilities stated; **no outcome metric published** [vendor-claimed] | Clean rate/inventory history; villa-level inventory modelling | Agreement Oct 2025 |
| 9 | **Turnaround & ground-ops computer vision** | Analytical | Lufthansa + Fraport "Seer" at FRA | Real-time bottleneck detection across baggage, catering, refuelling; delay reduction claimed, unquantified [vendor-claimed] | Apron camera estate, privacy/works-council clearance | Announced Aug 2025 |
| 10 | **Biometric / AI border and airport flow** | Analytical | Dubai "red carpet" smart corridor (DXB T3); Abu Dhabi Zayed Smart Travel with ICP + Etihad; Changi | DXB: **6–14 seconds per traveller, up to 10 simultaneously** [regulator/official]; AUH: service time **25s → 7s** [company-reported]; Changi: **10-second** resident clearance; SITA risk platform: 271m travellers/yr, most clearances **<4 seconds** [vendor-claimed] | National identity database access; EU AI Act Annex III caution outside GCC | AUH: phased from Nov 2023 terminal opening |
| 11 | **Fuel optimisation at fleet scale** | Analytical | SITA fuel software across the industry | 2.9m flights processed in 2025; **127,732 tonnes of fuel saved** [vendor-claimed] | Flight data recorder + flight-plan integration | Continuous |
| 12 | **Agentic servicing over GDS (reissues/exchanges)** | Agentic | Sabre MCP Server + agentic APIs | Partners **30 → 60** in one quarter; deployed with a global enterprise loyalty/travel services company; **consumer volumes "small"** [company-reported] | NDC/Offers-and-Orders readiness; agent identity & auth | Pilot-stage as of Aug 2026 |
| 13 | **AI-assisted sales productivity (hotels)** | Generative | Hyatt group sales teams | ~**20% more productive** [analyst-estimate, J.P. Morgan Mar 2026] | CRM hygiene, RFP corpus | Reported within ~1 year of deployment |
| 14 | **Pre-arrival digital check-in with identity verification** | Agentic | Rotana (15 Abu Dhabi hotels, 4,240 rooms) with H2O Hospitality | Passport + facial image submitted via WhatsApp 1–2 days pre-arrival; eliminates paper forms and queueing; **no metric published** [vendor-claimed] | Immigration/registration compliance; WhatsApp channel; PDPL basis | Live Aug 2026 |

**Documented vs projected:** items 1–5 and 10–11 have company- or regulator-reported outcome numbers. Items 7 (Bastian's 50%), 8, 9, 13 and 14 are projected, analyst-estimated or vendor-claimed and should be presented as such.

---

## 6. GCC / MENA specifics

**The regional economics inverted in 2026.** IATA's December 2025 outlook had the Middle East as the world's most profitable region — **$6.8bn net profit, 9.3% net margin, $28.60 profit per passenger**, RPK growth 6.1%. By 7 June 2026 IATA forecast a Middle East **net loss of $4.3bn at a -6.1% margin**, on regional conflict and a ~70% jet-fuel price rise. Any regional AI narrative written before mid-2026 is now describing a different balance sheet. Middle East airport passenger volumes are meanwhile heading toward ~240 million.

**Airlines.**
- **Emirates Group + OpenAI** (21 Nov 2025): enterprise-wide ChatGPT Enterprise, AI Centre of Excellence, internal AI champion network, sandboxes, early research access, and explicit collaboration on "government-led innovation projects." Capability-building, no published outcomes.
- **Qatar Airways**: Sama, the AI digital-human cabin crew, with an **Arabic-speaking version** announced for Arabian Travel Market in Dubai — one of the few named Arabic-first conversational deployments in aviation. Group-wide **"AI Skyways"** with Accenture (Aug 2025) covering schedule optimisation, predictive maintenance, personalisation and a value realisation office; Accenture CEO Julie Sweet signed in Doha.
- **Riyadh Air + IBM** (8 Dec 2025): positioned as the "world's first AI-native airline" — watsonx Orchestrate, agentic crew concierge, AI voice bots, agent assist, 59 workstreams, 60+ partners, three-year programme, commercial service from early 2026. The greenfield advantage is genuine: no legacy PMS/CRS to ground against. Outcomes not yet published — this is the region's highest-visibility unproven bet.

**Airports and borders — the region's strongest documented AI results.**
- **DXB "red carpet" smart corridor**: passport-free AI/biometric immigration in **6–14 seconds**, up to **10 passengers simultaneously**, GDRFA expanding it to both departing and arriving passengers (announced 2 Sept 2025). Dubai Airports reported **9m+ passengers processed** through AI-powered smart gates and biometric systems in H1 2026.
- **Zayed International, Abu Dhabi + ICP + Etihad**: "Smart Travel" biometric authentication drawing on national identity databases with **no prior registration**, cutting per-traveller service time **from 25 seconds to 7**, phased across check-in to boarding, starting with Etihad and expanding to all airlines.
- Comparator: **Changi's 10-second** resident clearance via face and iris.
- Strategic point for GCC operators: these systems work precisely because a **national identity database is directly accessible** to the airport operator. That is a sovereignty-enabled capability that is legally far harder to replicate in the EU, where biometric identification sits in EU AI Act Annex III (obligations now deferred to 2 Dec 2027).

**Destinations and tourism authorities.**
- **Saudi Tourism Authority — "Sara"**, an AI smart tour guide / digital human launched in beta at **LEAP 2025 (12 Feb 2025)** on the "Spirit of Saudi Arabia" platform, offering interactive information and recommendations in several major languages, explicitly framed as combining AI with Saudi cultural authenticity.
- **Red Sea Global**: **SAR 1.2bn investment from stc group** (29 Sept 2025) covering AI-driven services, cloud operations, **digital twins**, advanced analytics, cybersecurity and data centres — the region's largest disclosed destination-scale digital infrastructure commitment. Followed by an **HPE AI-native switching and Wi-Fi** build (Apr 2026) and the **IDeaS** portfolio-wide RMS agreement (Oct 2025) for Shebara, Desert Rock and Turtle Bay. Group CAO Ahmad Ghazi Darwish: *"This SAR 1.2 billion investment enables us to embed world-class digital infrastructure into our destinations."*
- **Visit Qatar / MCIT**: an "SMEs Go Digital" awareness programme running digital-transformation and AI workshops **for hotels**, targeting tourism SMEs — the region's clearest example of state-led AI diffusion to the long tail of hospitality rather than to flag carriers.
- **Accor** (Skift Global Forum East, Abu Dhabi, 30 Oct 2025): Deputy CEO Jean-Jacques Morin — *"The first place in the world where we recovered from Covid was here in the Middle East"* — citing regional "speed and leadership" and a three-minute airport arrival as the benchmark, alongside AI investment to optimise staffing.
- **Rotana + H2O Hospitality** (Aug 2026): AI identity-verified smart check-in across **15 Abu Dhabi properties, 4,240 rooms**, using WhatsApp pre-arrival registration and facial verification — notable because WhatsApp, not an app, is the channel, which is the correct regional assumption.

**Regulation, sovereignty and language.**
- **KSA PDPL** is fully enforceable since 14 Sept 2024, administered by **SDAIA** (which is also the national AI authority — an unusual single-regulator combination). **48 enforcement decisions by mid-Jan 2026**; fines to **SAR 5m**, doubled for repeat violations; **5 days** to respond to an alleged violation, 15 days for committee notification, 60 days to appeal. Practical implication for hotel and airline groups: incident-response and legal-representation plumbing (valid PoA, platform access) must exist *before* an AI system touches guest data.
- **UAE PDPL** governs guest and passenger data alongside sectoral aviation/immigration rules; biometric border systems operate under government authority (GDRFA, ICP) rather than commercial consent frameworks — a materially different design space from EU/US deployments.
- **Arabic language**: Qatar Airways' Arabic Sama and STA's multilingual Sara are the named examples. The broader gap — Gulf-dialect Arabic in guest messaging, and Arabic-language review/sentiment corpora for RMS and reputation AI — is where regional deployments still lean on English-first vendor stacks. This is a genuine, under-served differentiator.
- **Sovereign hosting** is becoming a procurement default: Red Sea Global's stc partnership explicitly includes in-country data centres, and Riyadh Air's stack is being assembled with a named systems integrator rather than assembled from consumer APIs.

---

## 7. Notable voices

> **"Airlines are bearing the brunt of the fuel price shock… Net profit per passenger is expected to fall to $4.50, half of what it was last year."**
> — Willie Walsh, Director General, IATA, 7 June 2026

> **"Apple will earn more selling an iPhone cover than the $7.90 airlines will make."**
> — Willie Walsh, Director General, IATA, 9 December 2025

> **"That hasn't moved so much recently, so no material change over the last few months or quarters."**
> — Ewout Steenbergen, CFO, Booking Holdings, on LLM referrals staying below 1% of room nights, 4 August 2026

> **"I do believe that some of the changes that were made in the display at Google definitely put some pressure on SEO."**
> — Glenn Fogel, CEO, Booking Holdings, 4 August 2026

> **"There is no fare product Delta has ever used, is testing or plans to use that targets customers with individualized prices based on personal data."**
> — Delta Air Lines statement responding to Senate scrutiny of its Fetcherr AI pricing, 1 August 2025

> **"You can't put a tower on a foundation of sand."**
> — Shilpa Ranganathan, Chief Product Officer, Expedia Group, on why its AI assistant failed — AI is *"an organizational problem before a technological one"*, 2026

> **"AI allows us to be more efficient and more effective. That is code for continuing to build more direct lines to our customers."**
> — Chris Nassetta, CEO, Hilton, 29 April 2026

> **"2026 is a year for scale."**
> — Naveen Manga, Global CIO, Marriott International, after a 2025 of piloting, 2026

> **"Agentic AI is no longer just a future opportunity. It is transforming how travel is bought and serviced."**
> — Kurt Ekert, CEO, Sabre, 13 August 2026 — the same call on which management called consumer agentic volumes "small"

> **"What our data is telling us is that travelers probably won't enjoy that [AI booking] experience."**
> — Clayton Nelson, VP of AI alliances, Expedia Group, on the finding that only 8% of travellers are comfortable with AI booking, April 2026

---

## 8. Source index

1. PhocusWire, "Booking Holdings: AI visibility is up, but referrals stay under 1% of room nights," 4 Aug 2026 — https://www.phocuswire.com/news/finance/booking-holdings-q2-2026-earnings — LLM referral share, CS cost per booking, Q2 2026 financials, Fogel/Steenbergen quotes.
2. Skift, "Booking Holdings CEO: AI Overviews Are Squeezing SEO," 4 Aug 2026 — https://skift.com/2026/08/04/booking-holdings-saw-pressure-from-googles-ai-overviews/ — SEO pressure quote, direct-traffic mix.
3. IATA press release, "Middle East Disruptions and High Fuel Prices Halve Airline Industry Profitability," 7 Jun 2026 — https://www.iata.org/en/pressroom/2026-releases/06-07-middle-east-disruptions-high-fuel-prices-halve-airline-industry-profitability/ — revised 2026 net profit, margin, profit/passenger, regional figures.
4. IATA press release, "Airline Profitability Stabilizes with 3.9% Net Margin Expected in 2026," 9 Dec 2025 — https://www.iata.org/en/pressroom/2025-releases/2025-12-09-01/ — 2025 actuals, original 2026 forecast, Middle East region, Walsh quotes.
5. Skift, "Delta Responds to AI-Pricing Backlash," 1 Aug 2025 — https://skift.com/2025/08/01/delta-says-it-will-not-use-ai-to-target-customers/ — Delta statement, senators' letter.
6. PhocusWire, "Delta encouraged by early results of AI pricing with Fetcherr," 14 Jul 2025 — https://www.phocuswire.com/delta-fetcherr-ai-pricing-deployment — 1%→3% deployment, 20% target, Hauenstein quote, other Fetcherr airlines.
7. Yahoo Finance, "Delta CEO Ed Bastian says AI could boost profits by 50%…," 24 Aug 2026 — https://finance.yahoo.com/technology/ai/articles/delta-ceo-ed-bastian-says-160000381.html — 50% profitability claim, 3% of tickets, aggregated-data position.
8. FTC press release, "FTC Surveillance Pricing Study Indicates Wide Range of Personal Data Used to Set Individualized Consumer Prices," 17 Jan 2025 — https://www.ftc.gov/news-events/news/press-releases/2025/01/ftc-surveillance-pricing-study-indicates-wide-range-personal-data-used-set-individualized-consumer — data types, intermediaries incl. PROS.
9. Skadden, "New York Algorithmic Pricing Law Enacted…," Jan 2026 — https://www.skadden.com/insights/publications/2026/01/new-york-algorithmic-pricing-law — NY disclosure wording, effective date, penalties, CA AB 325.
10. TechCrunch, "Airbnb says a third of its customer support is now handled by AI in the U.S. and Canada," 13 Feb 2026 — https://techcrunch.com/2026/02/13/airbnb-says-a-third-of-its-customer-support-is-now-handled-by-ai-in-the-u-s-and-canada/ — AI support share, Chesky quotes, data-moat claims.
11. Skift, "Travel Has Started Weighing AI's Worth," 18 Aug 2026 — https://skift.com/2026/08/18/travel-has-started-weighing-ais-worth/ — Airbnb −16% cost/booking and 45% resolution; Expedia +60% intent data; Sabre 30→60 partners.
12. American Airlines Newsroom, "Straight to the gate this holiday season," 22 Nov 2023 — https://news.aa.com/news/news-details/2023/Straight-to-the-gate-this-holiday-season-OPS-OTH-11/default.aspx — Smart Gating metrics, hubs, quotes.
13. Skift, "ChatGPT Bails on Transactions — Good News for Expedia and Booking," 5 Mar 2026 (upd. 11 May 2026) — https://skift.com/2026/03/05/openai-chatgpt-checkout-walkback/ — OpenAI checkout walkback.
14. PhocusWire, "Marriott shares details of AI projects, partnerships," Feb 2026 — https://www.phocuswire.com/marriott-q4-full-year-earnings-2025 — Marriott capex, Google/OpenAI partnerships, Bonvoy scale, Capuano quote.
15. Hotel Dive, "Marriott CIO talks enterprisewide AI deployment strategy," 2026 — https://www.hoteldive.com/news/marriott-cio-talks-enterprisewide-ai-deployment-strategy/820467/ — Manga quotes, AI chassis, personas.
16. PhocusWire, "Hilton to bring app to more AI platforms," 29 Apr 2026 — https://www.phocuswire.com/news/distribution/hilton-ai-developments-q1-2026-earnings — Nassetta quotes, Anthropic planner, Q1 2026 financials.
17. Hilton Stories, "Hilton Introduces the Hilton AI Planner," 10 Mar 2026 — https://stories.hilton.com/releases/hilton-introduces-the-hilton-ai-planner — scale, beta/GA dates, Leidinger quote.
18. CIO Dive, "Hilton bets big on AI with vendor partnerships, guest planning tool," 29 Apr 2026 — https://www.ciodive.com/news/hilton-bets-ai-with-vendor-partnerships/818875/ — Google/OpenAI/Anthropic multi-LLM approach, Nassetta productivity quotes.
19. Hotel Technology News, "Wyndham Scales AI Guest Engagement Across More Than 5,000 Hotel Properties," 29 Jul 2026 — https://hoteltechnologynews.com/2026/07/wyndham-scales-ai-guest-engagement-across-more-than-5000-hotel-properties/ — Connect/Concierge scale, ADR, conversion, CSAT, $450m tech spend.
20. Hotel Dive, "Top trends from the hotel industry's Q2 2026 earnings," Aug 2026 — https://www.hoteldive.com/news/top-hotel-industry-trends-q2-2026/828121/ — IHG, Wyndham, Choice, Marriott AI statements and dates.
21. Skift, "Hotel AI Investments Set to Deliver Earnings Payoff This Year, J.P. Morgan Says," 5 Mar 2026 — https://skift.com/2026/03/05/hotel-ai-investments-set-to-deliver-earnings-payoff-this-year-j-p-morgan-says/ — Hyatt 20% sales productivity, Wyndham call centres.
22. PhocusWire, "Expedia Group hits record Q1 profitability amid AI overhaul," Apr 2026 — https://www.phocuswire.com/news/finance/expedia-group-q1-2026-financial-earnings — 250m interactions/30% AI, marketing value, answer engines, Gorin quotes.
23. Hospitality.today, "Expedia learned where AI breaks. It wasn't the model," 2026 — https://www.hospitality.today/article/expedia-learned-where-ai-breaks-it-wasnt-the-model — Romie retirement, Ranganathan quote, remediation timeline.
24. CX Dive, "Expedia sees AI as the biggest change in experience since mobile," 2025 — https://www.customerexperiencedive.com/news/expedia-ai-experience-copilot-openai-mobile/747814/ — Romie, Trip Matching (May 2025), Copilot Actions (Apr 2025), Gorin quote.
25. The Motley Fool, "Booking (BKNG) Q1 2026 Earnings Transcript," 28 Apr 2026 — https://www.fool.com/earnings/call-transcripts/2026/04/28/booking-bkng-q1-2026-earnings-transcript/ — Penny, natural-language search, Agoda CS savings, $500–550m programme, Fogel quote.
26. PhocusWire, "Booking Holdings sees 20% rise in travelers booking multiple trip components," 18 Feb 2026 — https://www.phocuswire.com/booking-holdings-q4-full-year-2025-earnings — FY2025 financials, connected trip, CS cost decrease.
27. The Motley Fool, "Sabre (SABR) Q2 2026 Earnings Call Transcript," 13 Aug 2026 — https://www.fool.com/earnings/call-transcripts/2026/08/13/sabre-sabr-q2-2026-earnings-call-transcript/ — agentic APIs, MCP Server, 30→60 partners, hackathon, Ekert quotes, "small" volumes.
28. Travel Distribution News, "Three GDS, Three Bets: Amadeus, Sabre and Travelport…," 17 Jul 2026 — https://traveldistributionnews.com/three-gds-three-bets-amadeus-sabre-and-travelport-are-fighting-over-who-owns-the-ai-era-booking/ — SkyLink acquisition, Travelport/Anthropic MCP, 43%→63% API share, $50m.
29. Skift, "Google's Agentic Hotel Booking Tool Comes to AI Mode," 27 Aug 2026 — https://skift.com/2026/08/27/googles-agentic-hotel-booking-tool-comes-to-ai-mode/ — launch partners, Google Pay, data-withholding design.
30. Phocuswright research update, "61% of travel business surveyed experimenting with or scaling agentic AI," Feb 2026 — https://www.phocuswright.com/Travel-Research/Research-Updates/2026/61-of-travel-business-surveyed-experimenting-with-or-scaling-agentic-ai — 6% scaling, 22% beginning to scale, MCP/A2A.
31. PhocusWire, "Case studies on AI in travel highlight data, trust and bottleneck challenges," 2026 — https://www.phocuswire.com/news/technology/phocuswright-europe-2026-ai-travel-case-studies — TrustYou memory layer, Lighthouse "Ernest", barriers.
32. Open Jaw, "2026 State of Travel: Lack of AI Adoption Becoming Revenue Risk," 13 Aug 2026 — https://openjaw.com/newsroom/retail/2026/08/13/2026-state-of-travel-lack-of-ai-adoption-becoming-revenue-risk/ — Skift State of Travel 2026 figures: 62% familiarity, +124% usage, 33%/2% agentic, 6% of hotels in AI results, market sizes.
33. Skift, "Expedia: Only 8% Trust AI to Book Travel," 14 Apr 2026 — https://skift.com/2026/04/14/expedia-ai-survey-travel-discovery-booking-8-percent/ — 8% figure, Nelson quote.
34. Skift, "54% of Travelers Distrust Your AI Recommendations — Now What?," 23 Jul 2026 — https://skift.com/2026/07/23/travel-ai-trust-report/ — Wunderkind Future of Travel figures.
35. Microsoft Customer Stories, "How Azure AI helped Air India reinvent customer service…," 11 Feb 2026 — https://www.microsoft.com/en/customers/story/26047-air-india-azure-openai-in-foundry-models — 40k/day, 97%, 13m conversations, Ramaswamy quotes.
36. OAG, "Three Smart Ways Airlines Are Using AI to Improve Operations in August 2025," Aug 2025 — https://www.oag.com/blog/three-smart-ways-airlines-are-using-ai-to-improve-operations-in-august-2025 — AA storm rebooking 200,000+, Korean Air 5–7 min, Lufthansa/Fraport "Seer".
37. Computer Weekly, "Singapore Changi Airport's 10-second border points to aviation's AI future," 7 Jul 2026 — https://www.computerweekly.com/news/366645398/Singapore-Changi-Airports-10-second-border-points-aviations-AI-future — 10-second clearance, 97%/82% investment intent, SITA fuel 2.9m flights/127,732t, 271m travellers <4s.
38. Gulf News, "Dubai expands AI-powered 'red carpet' smart corridor at DXB Terminal 3," 2 Sept 2025 — https://gulfnews.com/business/aviation/dubai-expands-ai-powered-red-carpet-smart-corridor-at-dxb-terminal-3-1.500254531 — 6–14 seconds, 10 simultaneous, GDRFA expansion.
39. Nomad Lawyer / Travel And Tour World reporting on Dubai Airports H1 2026 smart-gate volumes, 2026 — https://www.nomadlawyer.org/dubai-airport-smart-travel-ai-gates-immigration-2026 — 9m+ passengers processed H1 2026 [weak source; see §9].
40. Gulf News, "Abu Dhabi airport, ICP launch world's first-of-its-kind biometric 'Smart Travel'," 21 Jul 2024 — https://gulfnews.com/uae/transport/abu-dhabi-airport-icp-launch-worlds-first-of-its-kind-biometric-smart-travel-1.103566116 — 25s→7s, phases, Etihad first, Murphy quote.
41. Emirates Media Centre, "Emirates Group collaborates with OpenAI…," 21 Nov 2025 — https://www.emirates.com/media-centre/emirates-group-collaborates-with-openai-to-accelerate-ai-adoption-and-innovation/ — ChatGPT Enterprise, CoE, quotes.
42. Qatar Airways Newsroom, "A First in Aviation: Qatar Airways Reinvents Travel Bookings with Sama at Web Summit Qatar 2025," Feb 2025 — https://www.qatarairways.com/press-releases/en-WW/247237-a-first-in-aviation-qatar-airways-reinvents-travel-bookings-with-sama-at-web-summit-qatar-2025/ — Sama capabilities, Al-Meer and Antinori quotes.
43. Consultancy-me, "Qatar Airways flies in Accenture to lead group-wide AI transformation," 20 Aug 2025 — https://www.consultancy-me.com/news/11341/qatar-airways-flies-in-accenture-to-lead-group-wide-ai-transformation — AI Skyways scope, Al-Meer and Sweet quotes.
44. Breaking Travel News, "Qatar Airways to Unveil Arabic-Speaking Version of Sama at ATM Dubai" — https://www.breakingtravelnews.com/news/article/qatar-airways-to-unveil-arabic-speaking-version-of-sama-at-atm-dubai/ — Arabic Sama.
45. IBM Newsroom, "Riyadh Air and IBM partner to launch world's first AI-native airline," 8 Dec 2025 — https://newsroom.ibm.com/2025-12-08-riyadh-air-and-ibm-partner-to-launch-worlds-first-ai-native-airline — watsonx Orchestrate, 59 workstreams, 60+ partners, Boukadida quote.
46. Saudi Press Agency, "Saudi Tourism Authority Launches Smart Tour Guide 'Sara'…," 12 Feb 2025 — https://www.spa.gov.sa/en/N2260133 — Sara launch at LEAP 2025, languages, purpose.
47. Red Sea Global, "Red Sea Global secures SAR 1.2 billion investment from stc group," 29 Sept 2025 — https://redseaglobal.com/en/media-center/news/red-sea-global-secures-sar-1-2-billion-investment-from-stc-group-to-accelerate-digital-transformation-across-its-destinations/ — AI, digital twins, data centres, quotes.
48. IDeaS, "IDeaS and Red Sea Global Hospitality Establish Portfolio-Wide Technology Agreement," 16 Oct 2025 — https://ideas.com/news/ideas-and-red-sea-global-hospitality-establish-portfolio-wide-technology-agreement/ — G3 RMS + Optix, three properties, quotes.
49. HPE Newsroom, "HPE accelerates Red Sea Global's vision… with AI-native switching and Wi-Fi," Apr 2026 — https://www.hpe.com/us/en/newsroom/press-release/2026/04/hpe-accelerates-red-sea-globals-vision-to-redefine-luxury-hospitality-in-saudi-arabia-with-ai-native-switching-and-wi-fi.html — network infrastructure.
50. Hotel Management Network, "H2O rolls out smart check-in system at Rotana hotels in Abu Dhabi," 20 Aug 2026 — https://www.hotelmanagement-network.com/news/h2o-check-in-rotana-hotels/ — 15 hotels, 4,240 rooms, WhatsApp + facial verification.
51. Skift, "Accor Deputy CEO Eyes Middle East, AI, and Live Events for Hotel Growth," 30 Oct 2025 — https://skift.com/2025/10/30/accor-deputy-ceo-eyes-middle-east-ai-and-live-events-for-hotel-growth/ — Morin quotes, AI for staffing.
52. MCIT Qatar, "MCIT and Visit Qatar Host Awareness Workshop on Digital Transformation and AI for Hotels under the SMEs Go Digital Program" — https://www.mcit.gov.qa/en/news/mcit-and-visit-qatar-host-awareness-workshop-on-digital-transformation-and-ai-for-hotels-under-the-smes-go-digital-program/ — state-led AI diffusion to tourism SMEs.
53. Clyde & Co, "Enforcement of the Saudi PDP Law is live: Are you ready?," Mar 2026 — https://www.clydeco.com/en/insights/2026/03/enforcement-of-the-saudi-pdp-law — enforcement date, 48 decisions, SAR 5m, 5/15/60-day windows, SDAIA.
54. Gibson Dunn, "EU AI Act Omnibus Agreement — Postponed High-Risk Deadlines and Other Key Changes," 2026 — https://www.gibsondunn.com/eu-ai-act-omnibus-agreement-postponed-high-risk-deadlines-and-other-key-changes/ — 6 May 2026 agreement, Annex III to 2 Dec 2027, Annex I to 2 Aug 2028, transparency 2 Aug 2026.
55. IATA, "Fact Sheet – Distribution with Offers and Orders," Jun 2026 — https://www.iata.org/en/iata-repository/pressroom/fact-sheets/fact-sheet-ndc/ — absence of published adoption targets; ARM index.
56. AHLA, "65% of surveyed hotels report staffing shortages," 2025 — https://www.ahla.com/news/65-surveyed-hotels-report-staffing-shortages — shortage %, role breakdown, n=282, Maietta quote.
57. Economy Middle East, "AI, biometrics drive next phase of Middle East airport expansion as passenger volumes near 240 million," 2026 — https://economymiddleeast.com/news/ai-biometrics-drive-next-phase-of-middle-east-airport-expansion-as-passenger-volumes-near-240-million/ — regional passenger volume context [headline only; page returned 403 on fetch — see §9].
58. Skift, "ChatGPT Travel Apps Are Now a Thing – Starting with Booking.com and Expedia," 6 Oct 2025 — https://skift.com/2025/10/06/expedia-booking-chatgpt-apps-openai/ — first ChatGPT travel apps.
59. Microsoft Customer Stories, "Alaska Airlines inspires destination discovery with Microsoft Foundry" — https://www.microsoft.com/en/customers/story/25850-alaska-airlines-azure-openai — natural-language destination discovery.
60. Alaska Airlines Newsroom, "Alaska Airlines and UP.Labs launch Odysee…" — https://news.alaskaair.com/company/alaska-airlines-up-labs-launch-odysee-ai-enabled-startup-taking-a-new-approach-to-schedule-optimization/ — Odysee schedule optimisation.

---

## 9. Gaps and caveats

**Searched for and could not verify:**
- **A currency-denominated IROPS/disruption-management ROI figure from a named airline.** Vendor material claims "up to 30% reduction in disruption costs," but no airline disclosure corroborates it. The credible, verifiable operational-AI numbers in aviation are American's Smart Gating figures and SITA's fleet fuel savings — both of which predate or sit outside the generative-AI wave.
- **Whether Delta reached its 20%-of-domestic-network AI pricing target.** Coverage as recent as Aug 2026 still cites 3%. Absence of confirmation is not the same as a documented reversal; treat as "stalled/unconfirmed," which is how §3 states it.
- **Any published RevPAR or GOPPAR uplift attributable to AI revenue management from a named operator.** IDeaS' and Duetto's public materials state capabilities, not outcomes. The widely-circulated "19% RevPAR increase" figure appears only on affiliate/vendor sites and was dropped.
- **Cruise-line AI deployments with credible outcome data.** Searches for Royal Caribbean and MSC returned only listicles and consultancy blogs; nothing at primary-source standard. Cruise is deliberately excluded from §3 and §5 rather than padded.
- **Airbnb's promised "AI trip-planning app."** Chesky has described the ambition; no shipped product with metrics was found as of Sept 2026.
- **Emirates', Riyadh Air's and Accor's AI outcome metrics.** All three have well-documented *programmes* and zero published *results*. This is stated plainly rather than inferred.
- **Trip.com TripGenie usage and conversion metrics.** Trip.com discusses AI expansion on earnings calls, but no reliable quantified TripGenie outcome was retrievable at primary-source standard; the company is therefore omitted from §3 rather than described vaguely.
- **Qatar Tourism / Visit Qatar Microsoft partnership specifics.** Only secondary forum coverage surfaced; the MCIT SMEs Go Digital page was fetched but carried no dates or figures.
- **IATA's own quantified NDC / Offers-and-Orders adoption rate.** The public fact sheet contains none, which is itself the finding reported in §2(e).

**Weakest figures in this dossier — use with the labels attached:**
- Wyndham's basis-point improvements and the "$100,000+ additional annual revenue per engaged franchisee" are company-reported on an earnings call and vendor-adjacent (Canary); they are the most favourable numbers in the hotel set and have no independent verification.
- Ed Bastian's "AI could boost profits by 50%" is a CEO projection, not a result.
- The Dubai Airports "9m+ passengers via smart gates in H1 2026" figure (source 39) comes from low-tier aggregator sites; the underlying GDRFA/Dubai Airports primary release was not located. The 6–14 second processing figure (source 38, Gulf News) is solid; the volume figure is not.
- Source 57 (Economy Middle East) returned a 403 on direct fetch; the ~240 million regional passenger figure is taken from the search-result headline only and should be re-verified before publication.
- SITA's fuel and border-clearance figures are vendor-claimed, reported via Computer Weekly rather than independently audited.
- The Wunderkind and Expedia consumer-trust surveys are corporate research; sample sizes and methodology were not disclosed in the accessible coverage.
