# Shared research brief (read fully before starting)

You are producing an evidence dossier for ONE industry page on the website of Cognirise, a UAE-based AI transformation firm (service lines: Agentic Enterprise Transformation; Data & AI Foundations; Engineering with AI; Sovereign Agentic AI; AI-Native Platforms). Other agents cover the other industries — DO NOT write generic cross-industry material ("data silos", "talent shortage", "start with pilots"). Everything must be specific to your industry's economics, regulators, operating model and named players.

## Non-negotiable sourcing rules
- Every number, claim, quote and named deployment MUST carry a URL and a date (month/year). No URL = do not include it.
- Prefer primary sources: company annual reports, earnings-call transcripts, investor days, regulator publications (central banks, BIS, FSB, IEA, GSMA, IATA, WEF, ITU, etc.), peer-reviewed or well-known research (McKinsey, BCG, Bain, Gartner, Forrester, MIT, Stanford HAI, Evident), reputable press (FT, Reuters, Bloomberg, WSJ, The Economist, Skift, Light Reading, etc.).
- Label each figure: [company-reported], [vendor-claimed], [analyst-estimate], [regulator/official], [independent study]. Vendor case studies ARE allowed but must be labelled as vendor-claimed.
- If you can only find a claim on a vendor blog or a low-quality site, either verify it elsewhere or drop it. Say explicitly when you searched and could not verify something notable (this is useful for the myths section).
- Quote precise wording when the number is contested or nuanced. Do not round "up to 30%" into "30%".
- Use WebFetch to open the actual source page for every key figure (at least the 15–20 most important ones) — do not rely on search snippets alone.
- Time window: emphasise 2024–Sept 2026. Note the date of every data point. Today is 6 Sept 2026.

## Geographic lens
Global evidence base, with a dedicated, substantive GCC/MENA section: named regional players (UAE, KSA, Qatar, and others), what they have publicly deployed or announced, regulators and national strategies, data-residency/sovereignty rules relevant to this industry, and Arabic-language specifics where relevant.

## Required dossier structure (write to the file path given, markdown, 4,000–7,000 words, dense with sourced facts)
1. **State of the industry from an AI perspective** — adoption levels, spend, where value has actually shown up in reported financials, structural forces unique to this industry (economics, regulation, data characteristics, workforce). 10–20 sourced data points.
2. **Challenges in the AI era specific to this industry** — 5–8 challenges, each with evidence. Must be industry-specific (e.g., for banks model-risk regulation & explainability; for telcos network data volumes & margin compression). Avoid generic ones.
3. **What key players are doing** — 10–15 named organisations (global + regional), each with: what exactly was deployed, scale, reported outcome (with label), source, date. Include at least one publicly documented failure, reversal, or scale-back.
4. **Proven vs. not proven (myths vs. reality)** — 6–10 items. For each: the common claim, what the evidence actually shows (with sources on both sides where they exist), verdict (Proven at scale / Proven in pockets / Unproven / Contradicted).
5. **High-impact AI use cases with ROI evidence** — 8–12 use cases. For each: description, who has done it (named, sourced), quantified outcome range with labels, prerequisites/data needed, time-to-value indication IF sourced, agentic vs. analytical vs. generative classification. Distinguish between ROI that is documented vs. projected.
6. **GCC/MENA specifics** — players, regulators, national strategies, sovereignty and language constraints, notable local deployments.
7. **Notable voices** — 5–8 short direct quotes from executives/regulators with source and date (usable on a website).
8. **Source index** — numbered list of every URL used, with title, publisher, date, and what it supports.
9. **Gaps & caveats** — what you looked for and could not verify; which figures are weakest.

Write the dossier to the file path given in your task, then reply with a 300-word summary of the most distinctive findings (what makes THIS industry's AI story different from any other industry).
