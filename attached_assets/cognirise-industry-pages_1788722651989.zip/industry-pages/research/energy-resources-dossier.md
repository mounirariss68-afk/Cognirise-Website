# Energy & Resources: AI Evidence Dossier
### Oil & gas · utilities, power & grid · renewables · mining & metals · water
**Prepared for Cognirise industry page · Evidence cut-off 6 September 2026**

---

## 1. State of the industry from an AI perspective

Energy and resources is the only industry where AI is simultaneously a **tool** and a **customer**. Every other sector asks "what can AI do for us?" This one also has to answer "can we physically deliver the electrons AI needs?" That two-way relationship is the organising fact of the sector's AI story, and it is now formally tracked by the sector's own regulator-equivalent, the IEA.

**The demand side ("energy for AI")**

1. Data centres consumed **around 415 TWh in 2024, ~1.5% of world electricity consumption**; the IEA's Base Case has this "more than double to around 945 TWh by 2030" and "around 1 200 TWh by 2035" [regulator/official] (IEA, *Energy and AI*, 10 Apr 2025).
2. Updated one year later: data centre electricity use reached **485 TWh in 2025**, growing **17% in 2025** against global electricity demand growth of 3%; **AI-focused data centres grew 50% in 2025** and are projected to **triple** their power use by 2030 [regulator/official] (IEA, *Key Questions on Energy and AI*, 16 Apr 2026).
3. Hyperscaler capex "surged to more than **$400 billion in 2025** and is set to increase by a further **75% in 2026**" — the IEA notes five major tech companies' capex now **exceeds global oil and natural gas production investment** [regulator/official] (IEA, 16 Apr 2026). This is the single most consequential number in the dossier: the buyers of energy now out-invest the producers of it.
4. Power density is the operational shock: AI server power density rose **11-fold between 2020 and 2025**, with a further ~4-fold increase projected by 2027; by 2027 an individual rack could draw power equivalent to **65 households** [regulator/official] (IEA, 16 Apr 2026).
5. Grid, not chips, is increasingly the binding constraint. The IEA estimates **grid constraints could delay around 20% of global data centre capacity planned for construction by 2030** [regulator/official] (IEA, *Energy and AI*, "AI and energy security", Apr 2025).
6. In the US, **over 2,060 GW** of generation and storage was actively seeking grid connection at end-2025 (~1,312 GW generation, 749 GW storage, ~8,200 projects), and the **median time from interconnection request to commercial operation for projects built in 2025 was over 5 years** [independent study] (Lawrence Berkeley National Laboratory, *Queued Up: 2026 Edition*, Jun 2026). Notably, active queue volume **fell 10% vs 2024**, while **natural gas capacity in the queue rose 86%** and solar, wind and storage fell 19%, 19% and 16% respectively.
7. North American reliability planners have re-based their forecasts around AI: NERC's 2025 Long-Term Reliability Assessment (published Jan 2026) projects a **10-year summer peak demand increase of over 224 GW — 69% higher than the prior year's assessment** — and states that "new data centers for artificial intelligence and the digital economy account for most of the projected increase in North American electricity demand over the next 10 years." **13 of 23 assessment areas** face elevated or high resource-adequacy risk [regulator/official].
8. Roughly **15–27 GW of onsite natural gas** may power data centres by 2030 [regulator/official] (IEA, 16 Apr 2026) — i.e. behind-the-meter generation is becoming a mainstream utility competitor.

**The supply side ("AI for energy")**

9. IEA's headline upside estimates: AI in power plant operations and maintenance could deliver **"up to USD 110 billion annually by 2035 from avoided fuels and lower costs"**, and **"up to 175 GW of additional transmission capacity could be unlocked in existing lines with the use of AI"** [regulator/official] (IEA, Apr 2025). AI-based fault detection is credited with reducing **outage durations by 30–50%** [regulator/official] (IEA executive summary, Apr 2025).
10. Compute intensity inside oil and gas is real and old: companies operating supercomputers in the global Top 500 rose from **11 in 2000 to 24 in 2024**, with **total computing capacity growing at almost 70% annually**, outpacing the broader supercomputing industry [regulator/official] (IEA, Apr 2025). This sector was doing HPC-scale numerical modelling decades before "AI adoption" was a board topic.
11. Where value has shown up in company-reported numbers: **ADNOC reported $500 million (AED 1.84bn) of value generated from AI in 2023** across Panorama, Thamama, CPAD, Emission X, SMARTi, AR360 and RoboWell, plus **up to 1 million tonnes of CO2 abated 2022–2023** [company-reported] (ADNOC, 5 Mar 2024).
12. **Aramco reports $1.8 billion of AI-driven "Technology Realized Value" in 2024**, from **442 identified AI use cases**, **200+ solutions deployed and 100+ in development** [company-reported] (Aramco, "Building the AI future", 2025/26). Separately CEO Amin Nasser said total technology realisation **doubled from $2bn (2023) to $4bn (2024)** [company-reported, Bloomberg TV, Jun 2025] — note the $1.8bn is the AI-attributed subset, not the $4bn.
13. Mining has the deepest at-scale automation record: Rio Tinto's AutoHaul autonomous heavy-haul rail moved **326.2 million tonnes of iron ore in the Pilbara in 2025**, with **mainline stopping incidents down two-thirds over five years** and system resets cut **from 4 hours to 8 minutes** [company-reported via trade press] (*International Railway Journal*, 9 Mar 2026).
14. Barriers are structural, not attitudinal. The IEA names them precisely: **"unfavourable regulation, lack of access to data, inaccessibility, interoperability concerns, critical gaps in skills, the paucity of digital infrastructure and, in some cases, a general resistance to change"** [regulator/official] (IEA, Apr 2025). It adds that **"lack of digital skills is the single largest barrier to greater AI adoption"** and that **"only 10% of global electricity consumption is covered by open electricity data policies"** [regulator/official] (IEA, 16 Apr 2026).
15. Cybersecurity is now an AI-shaped risk. IEA records rising cyberattacks per energy organisation 2020–2024 and warns **"AI-based tools can also be exploited to automate attacks and evade detection"**, with generative AI already documented in reconnaissance, network access and evasion scripting [regulator/official] (IEA, Apr 2025).
16. Materials coupling: **data centre demand for gallium could reach 10% of current global supply by 2030**, with **China controlling 95% of gallium refining** [regulator/official] (IEA, Apr 2025) — the AI build-out is itself a mining and metals demand story.

**Structural forces unique to this sector**

- **Asset-heavy, long-cycle capex.** Investment decisions are 20–40 year commitments in a sector where policy and price assumptions change every 18 months. AI projects compete against physical capital with hurdle rates, not against SaaS budgets.
- **Safety-critical OT.** Models sit next to SIS/ESD systems, HAZOP-governed processes and IEC 61511 safety-integrity levels. An action-taking agent on a compressor is a functional-safety change, not a software release.
- **Decades-old, non-stationary data.** Aramco trained Metabrain on **7 trillion data points spanning 90+ years** of company history [company-reported]; ADNOC's ENERGYai is trained on **80 years** of proprietary data [company-reported]. Historical SCADA and seismic archives are heterogeneous, often analogue-derived, and describe assets that have since been rebuilt.
- **The "great crew change."** The retirement of the cohort that carries undocumented plant knowledge is the reason knowledge-retrieval agents have unusually clear ROI here — the alternative is losing the knowledge outright.
- **Energy-transition capital allocation.** AI budgets are being set inside a live argument about whether to fund hydrocarbons, electrons, or both. BP's 2025 strategy reset is the standing example of that argument resolving against transition capex.

---

## 2. Challenges in the AI era specific to this industry

**2.1 AI's own demand is destabilising your customers' load forecasts — and your capital plan.**
NERC's 10-year peak forecast jumped **69% in a single assessment cycle** (2025 LTRA vs 2024) [regulator/official]. Utilities must now commit multi-billion-dollar transmission and generation capex against load requests from hyperscalers that are non-binding, frequently duplicated across territories, and can be withdrawn. There is no analogue in banking or telecoms: the forecasting error is measured in gigawatts of stranded or missing steel.

**2.2 The interconnection queue is the real deployment bottleneck, and AI cannot shorten it.**
Median interconnection-to-COD exceeded **5 years for 2025 projects**, with **2,060 GW queued** [independent study, LBNL, Jun 2026]. AI improves siting, study automation and dynamic line rating, but the constraint is regulatory process and physical equipment (transformer and turbine backlogs, per IEA Apr 2026), not analytics.

**2.3 Safety-critical OT means "agentic" cannot mean "autonomous" without a functional-safety case.**
The EU AI Act classifies as high-risk: **"AI systems intended to be used as safety components in the management and operation of critical digital infrastructure, road traffic, or in the supply of water, gas, heating or electricity"** (Annex III, point 2). That triggers conformity assessment, risk-management systems, logging and human oversight obligations for exactly the grid-control and process-control agents vendors are selling. In North America, NERC CIP standards govern the OT perimeter and asset inventory that an AI agent would have to sit inside. In practice this pushes deployments toward advisory/copilot patterns and toward closed-loop control only in ring-fenced, low-consequence loops.

**2.4 Data is old, proprietary, and not stationary.**
Seismic reprocessing works precisely because the physics is stable. Equipment failure prediction is harder: assets are modified, sensors are re-tagged, and failure modes are rare. Shell's C3-based programme runs **~11,000 ML models against 3+ million sensors and 20 billion rows a week** to monitor 10,000 assets [vendor-claimed, C3.ai/Shell, 8 Mar 2022] — the model-count-to-asset ratio shows how little generalisation is achievable across heterogeneous rotating equipment. Every new asset class is close to a new project.

**2.5 The vendor layer is financially unstable, which transfers risk to operators.**
C3.ai — the most cited enterprise-AI vendor in oil and gas — reported **Q1 FY2026 revenue of $70.3 million, down 19% year-on-year**, withdrew full-year guidance, and its founder said "the bad news is that financial performance in Q1 was completely unacceptable" [company-reported, 3 Sep 2025]. Its Baker Hughes alliance, which at peak was **45% of revenue** and generated **90%+ of unbilled receivables** [independent/press, CNBC, 2 Jun 2023], was renewed only **through June 2028** [company-reported, 28 May 2025]. Operators building critical maintenance workflows on a single vendor's platform now carry genuine continuity risk.

**2.6 Emissions accounting cuts both ways.**
Energy companies are being asked to fund AI that raises their own Scope 2 while claiming AI-enabled abatement. The IEA's own caution, as reported by Carbon Brief: AI-enabled emissions reductions **"could cancel out any extra data-centre emissions"**, but **"there is currently no existing momentum of AI adoption that would unlock these emissions reductions"** [regulator/official via independent analysis]. Fossil fuels currently supply **nearly 60% of power to data centres** (renewables 27%, nuclear 15%) [regulator/official, IEA via Carbon Brief].

**2.7 Sovereignty and data residency are contractual, not aspirational, in the GCC.**
National oil companies treat subsurface and production data as state assets. That forces in-country model training, in-country inference, and vetted personnel — which is why ADNOC's programme is delivered through a domestically-owned JV (AIQ) rather than a foreign SaaS contract, and why Aramco is investing in HUMAIN rather than renting frontier compute abroad.

**2.8 Measurement infrastructure for the environmental claims is fragile.**
MethaneSAT, the flagship AI-assisted methane-quantification mission, **lost communication on 20 June 2025** after roughly one year in orbit; nearly **400 contact attempts over 21 days** failed, and the anomaly investigation published **6 November 2025** concluded the likely cause was a disruption in the flight avionics unit or electrical power subsystem, with **"the specific reason for the system failure remains unknown"** [regulator-adjacent/NGO official]. Operators who built methane-reporting narratives around a single sensing platform lost their independent verification layer overnight.

---

## 3. What key players are doing

**ADNOC (UAE) — the most complete public agentic-AI programme in the sector.**
ENERGYai, announced **4 November 2024**, is a custom agentic system built by AIQ with G42, Microsoft and OpenAI models, trained on ADNOC's **80 years of proprietary data**; claimed capabilities include **accelerating geological modelling by up to 75%** and compressing development planning **from 1–2 years to weeks** [company-reported]. On **10 March 2025**, AIQ announced a **$340 million contract** from ADNOC for large-scale deployment: first operational version mid-2025 with **five AI agents** in subsurface, scaling across **28+ producing fields** and thousands of wells over three years [company-reported]. Earlier, ADNOC reported **$500m of AI-generated value in 2023** [company-reported, 5 Mar 2024]. Ownership was restructured on **1 May 2024**: Presight took **51% of AIQ**, ADNOC retained 49%, valuing AIQ at **over $1.4 billion** [company-reported].

**AIQ + SLB (global) — the most specific published accuracy claim in subsurface AI.**
Announced **7 August 2025**: integration of ENERGYai with SLB's Lumi platform. Testing on **15% of ADNOC's data across two fields** produced **"a 10x increase in the speed of seismic interpretation, and a 70% increase in precision"** [vendor-claimed / company-reported jointly]. Rollout from Q4 2025. Treat as a pilot-scale result: it is a two-field test, not a fleet-wide outcome.

**Saudi Aramco (KSA) — largest disclosed AI value figure, with careful attribution.**
Metabrain, unveiled at LEAP on **4 March 2024**, launched at **250 billion parameters** trained on **7 trillion data points** over 90+ years, with a stated plan to reach **1 trillion parameters** [company-reported]. Aramco reports **$1.8bn of AI-driven Technology Realized Value in 2024**, **442 identified use cases**, **200+ deployed**, and a commitment to train **6,000 AI developers** with Imperial College, Caltech and KAUST [company-reported]. On legacy data, EVP Ahmad O. Al-Khowaiter: **"We are using old seismic data, which we utilized in the past and reprocess[ing] it with AI and we are now able to generate new results from old data, which creates great savings"** — processing that took months now takes hours [company-reported, 12 Mar 2025]. Storage expanded to **1,500 petabytes**; ~**10 billion data points processed daily**. Aramco also reports drone/wearable inspection cutting **pipeline inspection times by 90%** at the Uthmaniyah Gas Plant [company-reported].

**Shell (global) — the reference at-scale predictive-maintenance deployment, and its limits.**
By **8 March 2022** Shell had scaled AI predictive maintenance to **10,000+ pieces of equipment** across upstream, manufacturing and integrated gas, running **nearly 11,000 ML models**, **3+ million sensors**, **20 billion rows/week** and **15 million predictions/day** [vendor-claimed, C3.ai release; Shell VP Dan Jeavons quoted]. Critically, **no financial savings or ROI figure was disclosed in the announcement** — the widely circulated "20% downtime reduction" attributed to this programme does not appear in the primary release (see §4).

**Baker Hughes + C3 AI (global).** JV originally signed 2019, **renewed and amended four times**, most recently **28 May 2025, extending through June 2028**. C3 AI states the alliance has generated **"more than half a billion dollars in revenue from the O&G and chemical markets"**, with customers including Shell, Eni, QatarEnergy LNG and ExxonMobil [vendor-claimed]. Baker Hughes is also expanding internal deployments (sourcing optimisation, inventory optimisation, sustainability suite) [company-reported].

**QatarEnergy LNG** is named as a C3 AI customer within the Baker Hughes alliance [vendor-claimed, 28 May 2025]. We could not independently verify deployment scale or outcomes.

**Rio Tinto (mining, global).** AutoHaul: fully autonomous heavy-haul rail, **fully deployed since 2018/2019**, ~**2.5 km trains, 3 locomotives, ~240 cars, ~28,000 tonnes per train**, **800 km return routes**; trains have travelled **more than 7 million kilometres since 2019** [company-reported via trade press]. Reported effects: **mainline stopping incidents down two-thirds over five years**; fleet passing without engineer inspection improved **from 40% to 60%**; resets **4 hours → 8 minutes**; **326.2 Mt** hauled in the Pilbara in 2025 [*IRJ*, 9 Mar 2026]. Its autonomous truck fleet (**130+**) is reported to deliver **~700 additional operating hours per truck per year at 15% lower cost**, with its Mine Automation System pulling data from **98% of sites** [company-reported via E&MJ].

**BHP (mining, global).** Reported outcomes include Port Hedland ship-loader automation adding **"more than 1 million mt/y"** of production; Escondida **reducing monthly production losses due to granulometry by an average of 70%**; and **more than 3 gigalitres of water and 118 GWh of energy saved since 2022**; BMA autonomous haulage excellence delivering **~10% p.a. increase in productive movement** [company-reported via E&MJ].

**Fortescue (mining, Australia).** The Hive control centre oversaw the **autonomous movement of over 4 billion tonnes of iron ore** in 2024, managing **200+ haul trucks, 4,000 ore cars and six processing plants** [company-reported via E&MJ].

**Freeport-McMoRan (mining, US).** The most aggressive quantified claim in the sector: AI optimisation delivered a **10% production improvement at Bagdad, Arizona**, an enterprise programme targeting **+200 million pounds of annual copper**, a **$350–500 million EBITDA uplift**, and **$1.5–2 billion avoided** by not building new facilities [company-reported via E&MJ]. Treat the avoided-capex figure as a counterfactual, not a realised cash saving.

**Teck Resources (mining, Canada).** Condition-based maintenance at Trail Operations using AspenTech Mtell; fleet analytics with a stated potential of **$1 million in annual savings at one site** [company-reported via E&MJ] — a useful reality check on the scale of a single well-executed predictive-maintenance use case.

**PG&E (utility, US) — the clearest utility-side operational ROI.**
Its Continuous Monitoring Center in San Ramon applies ML to data from ~**5.5 million smart meters** and tens of thousands of sensors. In **2025** it reported **17 wildfires intercepted**, **$6 million in operational cost savings**, **over 1,000 outages prevented**, **12 million minutes of unplanned customer downtime avoided**, **2,620 hours of emergency response time reduced** and **1,484 preventive interventions** since inception [company-reported via local press]. Separately, PG&E's use of Overstory satellite/computer-vision vegetation analytics is associated with a **~50% reduction in vegetation-triggered ignitions in 2025 vs 2024** [company/vendor-reported via *Scientific American*].

**Portland General Electric & Arizona Public Service (utilities, US).** PGE reached **100% AI-camera coverage of its High Risk Fire Zones**, paired with Pano AI infrared satellite feeds and IND Technology sensors that locate ignition sources to **±30 feet** [company-reported, Aug 2024]. APS reports Pano AI detections beating 911 callers by **"10 to 15 to 25 minutes"** [company/vendor-reported].

**DEWA (utility/water, UAE).** Rammas, its virtual employee, handled **over 1.6 million inquiries in 2025** and **12.7 million cumulatively since 2017** in Arabic and English across seven channels including WhatsApp, Alexa and Google Assistant [company-reported, 26 Jan 2026]. In **August 2026** DEWA reported AI cutting **security-deposit refund time from four days to eight minutes**, with agentic AI deployed across web, app and internal platforms and GPT-4o integrated into Rammas [company-reported]. Other named systems: Watson Advisor (cyber defence centre), Wisdom (executive assistant), and MSLP consumption analytics covering **~480,000 residential customers**.

**Google DeepMind (technology, global).** In **February 2019** DeepMind reported that ML applied to **700 MW of wind capacity in the central US** "boosted the value of our wind energy by roughly 20 percent, compared to the baseline scenario of no time-based commitments to the grid." This is the single most-cited AI-for-renewables statistic in the industry — and it has not been publicly updated or independently replicated in the seven years since (see §4).

**MethaneSAT / EDF (measurement, global) — the documented failure.**
Launched March 2024; **lost power 20 June 2025**; declared **"likely not recoverable"** on **1 July 2025**; anomaly report **6 November 2025** could not identify the specific failure cause [official]. EDF states it will still release additional data scenes and reuse the retrieval technology.

**C3.ai (vendor, global) — the documented reversal/scale-back.**
Revenue fell to **$70.3m in Q1 FY2026, down 19% YoY**, full-year guidance withdrawn amid a CEO transition and sales reorganisation [company-reported, 3 Sep 2025]. Historically: a 2022 investor suit alleging misrepresentation of access to a "12,000-person sales organization" via Baker Hughes; Kerrisdale Capital (Apr 2023) alleging **"aggressive accounting"** and **"accounting red flags abound"** around unbilled receivables; Spruce Point (Feb 2023) questioning customer-counting methodology, which shifted C3's reported customer count from **110 to 218** (Mar 2022) and then to **287** (Apr 2023) under revised definitions [independent/press, CNBC 2 Jun 2023]. Any energy operator citing "C3 AI proves the ROI" should be aware the vendor's own reporting metrics have been contested.

---

## 4. Proven vs. not proven — myths and reality

**Myth 1: "Predictive maintenance is a solved problem and delivers ~20–30% downtime reduction."**
*Evidence for:* Shell genuinely monitors **10,000+ assets with ~11,000 models** [vendor-claimed, Mar 2022]. Teck, BHP and others report real gains.
*Evidence against:* The primary Shell/C3 announcement contains **no savings, downtime or ROI figure at all** — the "20% downtime cut" widely attributed to it circulates on secondary content sites without a primary source. The model-per-asset ratio (~1.1 models per monitored item) shows the approach does not generalise across equipment classes. Teck's disclosed figure is **~$1m/year at one site**.
**Verdict: Proven in pockets.** Scale of deployment is proven; a portable percentage benefit is not. Demand a named asset class and a baseline before accepting any percentage.

**Myth 2: "AI will decarbonise energy operations."**
*Evidence for:* ADNOC reports **up to 1 Mt CO2 abated 2022–2023** alongside its AI programme [company-reported]. IEA models large potential efficiency gains.
*Evidence against:* IEA's own framing, reported by Carbon Brief: AI-enabled reductions **"could cancel out any extra data-centre emissions"**, but **"there is currently no existing momentum of AI adoption that would unlock these emissions reductions."** Data centres are **"one of the few sectors where emissions are set to grow."**
**Verdict: Unproven at sector level; proven in narrow instances.**

**Myth 3: "AI data centres will be powered by renewables."**
*Evidence against:* Fossil fuels supply **nearly 60% of data-centre power today** (renewables 27%, nuclear 15%); IEA projects roughly 60% clean / 40% fossil only by **2035** [regulator/official]. Meanwhile **15–27 GW of onsite natural gas** may power data centres by 2030 [IEA, Apr 2026], and the US interconnection queue shows **gas capacity up 86%** while solar, wind and storage all declined [LBNL, Jun 2026].
**Verdict: Contradicted** for the current decade. Clean-power procurement is real; physical hourly matching for AI load is not.

**Myth 4: "AI increases oil recovery / production by X%."**
We searched for a peer-reviewed or audited figure linking AI to incremental recovery factor or reserves. We did not find one. What is documented is *cycle-time* compression: seismic interpretation **10x faster with 70% higher precision on a two-field test** [AIQ/SLB, Aug 2025]; Aramco reprocessing legacy seismic **"months → hours"** [company-reported]; ADNOC claiming geological modelling **up to 75% faster** and development planning **1–2 years → weeks** [company-reported]. In mining, by contrast, direct production uplift *is* claimed and quantified (Freeport **+10% at Bagdad**; BHP **+1 Mt/y** at Port Hedland).
**Verdict: Unproven in oil & gas (recovery); proven in pockets in mining (throughput).** Cycle time, not barrels, is the defensible oil & gas claim.

**Myth 5: "Autonomous operations are here."**
*Evidence for:* Mining is the exception. AutoHaul has been fully autonomous since 2018/19 across **7 million+ km**; Fortescue's Hive moved **4 billion tonnes autonomously in 2024**.
*Evidence against:* In oil & gas and utilities, the EU AI Act designates AI **"safety components ... in the supply of water, gas, heating or electricity"** as high-risk, and NERC CIP governs the OT perimeter. ADNOC's flagship agentic programme is explicitly framed around **engineer productivity and interpretation speed**, with five agents in a subsurface workflow — not closed-loop field control.
**Verdict: Proven at scale in mining haulage only. Unproven elsewhere.** The distinction that matters: bounded, fenced, geospatially-constrained environments (a pit, a private rail corridor) versus safety-instrumented process plants and public grids.

**Myth 6: "Digital twins deliver measured ROI."**
*Evidence for:* Newmont deployed Metso's Geminex metallurgical digital twin at Lihir (2023); Freeport's programme is twin-adjacent and carries a **$350–500m EBITDA** claim.
*Evidence against:* Very few digital-twin deployments publish an audited before/after. Freeport's largest number (**$1.5–2bn "saved"**) is avoided capital expenditure — a counterfactual, not cash.
**Verdict: Proven in pockets, weakly evidenced.** Insist on the counterfactual definition.

**Myth 7: "Machine learning increases the value of wind by 20%."**
The DeepMind claim is real and precisely worded — **"roughly 20 percent, compared to the baseline scenario of no time-based commitments to the grid"** — but it dates from **26 February 2019**, covers **700 MW**, and the baseline is *no day-ahead commitment at all*, not a competent forecasting desk. We found no updated or independently replicated figure in 2024–2026.
**Verdict: Proven once, in one configuration, seven years ago.** Do not present as a current benchmark.

**Myth 8: "AI can relieve the grid bottleneck."**
*Evidence for:* IEA's **175 GW of transmission capacity unlockable in existing lines** and **30–50% outage-duration reduction** via AI fault detection [regulator/official].
*Evidence against:* The binding constraints in LBNL and IEA data are process and hardware: **5+ year median interconnection timelines**, transformer and gas-turbine backlogs, and planning/regulatory systems "holding up grid connections and other necessary approvals" [IEA, Apr 2026].
**Verdict: Proven in pockets (DLR, fault location, outage restoration); does not address the dominant bottleneck.**

**Myth 9: "Satellite AI has made methane emissions independently verifiable."**
MethaneSAT's loss (20 Jun 2025) removed the highest-resolution independent quantification layer for diffuse basin-level emissions within ~15 months of launch. Commercial point-source detection (e.g. GHGSat-class) persists, but basin-total attribution capability regressed.
**Verdict: Contradicted for basin-level totals; proven in pockets for large point sources.**

**Myth 10: "Enterprise AI platforms for energy are a mature, low-risk buy."**
C3.ai's **19% YoY revenue decline, withdrawn FY26 guidance**, contested customer-count methodology and historic **45% single-customer revenue concentration** show the category's commercial fragility.
**Verdict: Contradicted.** Architect for portability of models and features away from any single platform.

---

## 5. High-impact AI use cases with ROI evidence

| # | Use case | Class | Who / evidence | Quantified outcome | Prerequisites | Time-to-value |
|---|---|---|---|---|---|---|
| 1 | **Seismic interpretation & subsurface agents** | Agentic + generative | AIQ + SLB for ADNOC, 7 Aug 2025 | **10x speed, +70% precision** on 15% of data across two fields [vendor/company-claimed] | Interpreted seismic corpus, GPU cluster, in-country residency | Rollout began Q4 2025, ~9 months from announcement |
| 2 | **Legacy seismic reprocessing** | Analytical | Aramco, 12 Mar 2025 | Processing **"months → hours"**; 1,500 PB storage; ~10bn data points/day [company-reported] | Archived raw field data, HPC | Documented, ongoing |
| 3 | **Predictive maintenance on rotating equipment** | Analytical | Shell/C3, 8 Mar 2022; Teck/AspenTech | **10,000 assets, 11,000 models, 15m predictions/day**; Teck **~$1m/yr at one site** [vendor/company-claimed]. No published % downtime reduction | Sensor coverage, historian, failure-labelled history, CMMS integration | Shell's target was set for 2021 and met — multi-year |
| 4 | **Wildfire ignition prevention & grid fault anticipation** | Analytical | PG&E 2025; PGE & APS 2024–26 | **17 fires intercepted, $6m saved, 1,000+ outages prevented, 12m customer-minutes avoided** (PG&E 2025); **~50% fewer vegetation ignitions 2025 vs 2024** with Overstory; APS detection **10–25 min faster than 911** [company-reported] | Smart-meter/AMI data, EFD sensors, camera network, satellite feed, dispatch integration | PG&E figures are annual, from an operating centre |
| 5 | **Autonomous haulage (truck + rail)** | Agentic (physical) | Rio Tinto AutoHaul; Fortescue Hive; BHP BMA | **7m+ km autonomous rail; 326.2 Mt in 2025; stopping incidents −2/3; resets 4h→8min**; trucks **+700 hrs/yr at −15% cost**; Fortescue **4bn t moved autonomously in 2024**; BHP **+10% productive movement p.a.** [company-reported] | Private controlled corridor, comms coverage, remote ops centre, regulator sign-off | Rio Tinto: 2006 partnership → 2018 full deployment (12 yrs) |
| 6 | **Process/throughput optimisation in minerals processing** | Analytical | Freeport Bagdad; BHP Escondida | **+10% production** (Bagdad); Escondida **granulometry losses −70% monthly average**; enterprise target **+200m lb Cu, $350–500m EBITDA** [company-reported] | Plant historian, assay data, control-system write-back | Freeport's programme scaled over ~2–3 years |
| 7 | **Emissions monitoring & methane detection** | Analytical | ADNOC Emission X; MethaneSAT (failed) | ADNOC: **up to 1 Mt CO2 abated 2022–23** across the AI portfolio [company-reported]. MethaneSAT: capability demonstrated then lost [official] | Continuous monitoring hardware, satellite/aerial tasking, reconciliation to inventory | ADNOC figure is a 2-year cumulative |
| 8 | **Customer-service and back-office agents at utilities** | Generative + agentic | DEWA Rammas | **1.6m inquiries in 2025; 12.7m since 2017**; refunds **4 days → 8 minutes** [company-reported] | Arabic+English NLU, billing/CRM integration, channel coverage | Rammas launched 2017; GPT-4o added by Jan 2025 |
| 9 | **Renewables output forecasting & market commitment** | Analytical | Google DeepMind, 26 Feb 2019 | **"roughly 20 percent"** increase in value of 700 MW wind vs no time-based grid commitments [company-reported, not replicated] | Turbine SCADA, NWP feeds, market access | Not disclosed |
| 10 | **Dynamic line rating / capacity release on existing lines** | Analytical | IEA modelling | **Up to 175 GW** unlockable in existing lines [regulator/official — projected, not realised] | Line sensors, weather modelling, TSO/ISO rule change | Regulatory-gated |
| 11 | **Power plant O&M optimisation** | Analytical | IEA modelling | **Up to $110bn annually by 2035** from avoided fuel and lower costs [regulator/official — projected] | Plant data access, open data policy | Projected to 2035 |
| 12 | **Drone / computer-vision asset inspection** | Analytical | Aramco Uthmaniyah Gas Plant | **Pipeline inspection time −90%** with drones and wearables [company-reported] | Flight permissions, defect-labelled imagery, integration to inspection records | Documented at plant level |
| 13 | **Safety observation & PPE/hazard computer vision** | Analytical | ADNOC SMARTi [company-reported, within $500m 2023 portfolio] | Not separately quantified | CCTV estate, worker-consent framework | Not disclosed |

**Documented vs projected:** items 1–8 and 12 are documented outcomes reported by operators or their vendors; items 10 and 11 are IEA *projections* and should never be presented as achieved. Item 9 is documented but stale and unreplicated.

---

## 6. GCC / MENA specifics

**The regional thesis is unusual: the GCC is simultaneously the most aggressive AI-adopting energy region and the fastest-growing supplier of energy to AI.**

**United Arab Emirates**
- **ADNOC** has made "the world's most AI-enabled energy company" an explicit corporate goal (Dr Sultan Ahmed Al Jaber). Portfolio: Panorama Digital Command Center, Thamama subsurface CoE, CPAD predictive diagnostics, Emission X, SMARTi, AR360, RoboWell — **$500m of value in 2023** and **up to 1 Mt CO2 abated 2022–23** [company-reported, 5 Mar 2024]; ENERGYai (Nov 2024) and the **$340m AIQ contract** (Mar 2025); SLB/Lumi integration (Aug 2025).
- **AIQ** is the sovereign delivery vehicle: **Presight 51% / ADNOC 49%**, valued at **>$1.4bn** in the May 2024 restructuring. This is the regional template — a domestically-controlled JV holding the models and the data, buying frontier capability from Microsoft/OpenAI/SLB rather than outsourcing the workflow.
- **Stargate UAE / G42**: announced **22 May 2025** with OpenAI, Oracle, NVIDIA, Cisco and SoftBank — a **1 GW Abu Dhabi cluster** within a **5 GW UAE–US AI campus**, with **200 MW live in 2026**; construction update **16 Oct 2025** confirmed civil/structural work advanced and long-lead equipment procurement complete; *The National* reported (5 Dec 2025) first phase completing in **Q3 2026** [company-reported]. The UAE is also stated to become "the first country in the world to enable ChatGPT nationwide."
- **DEWA** is the region's most-documented utility AI programme (see §3): Rammas, Watson Advisor, Wisdom, MSLP across ~480,000 residential customers; **refunds 4 days → 8 minutes** (Aug 2026).

**Saudi Arabia**
- **Aramco**: Metabrain (Mar 2024), **$1.8bn AI-driven Technology Realized Value in 2024**, **442 use cases / 200+ deployed**, **6,000 AI developers** to be trained with Imperial College, Caltech and KAUST, world's-first industrial distributed cloud with Microsoft and Armada, **1,500 PB** storage [company-reported]. Aramco cites the IEA finding that AI and data centres will account for **~20% of electricity demand growth in advanced economies** to 2030 as strategic justification for its position.
- **HUMAIN** (PIF-owned) is the national AI infrastructure vehicle Aramco plans to invest in — data centres, cloud, and models offered as compute-as-a-service for the region [company-reported]. The strategic logic is explicit: cheap domestic energy converted into exportable compute.
- **Aramco Digital** and the LEAP conference (Riyadh) are the primary announcement venues; expect Q1 announcements to cluster around LEAP each February/March.

**Qatar**
- **QatarEnergy LNG** is a named customer of the Baker Hughes/C3 AI alliance [vendor-claimed, 28 May 2025]. We could not verify deployment scale, applications or outcomes from a primary Qatari source — a genuine evidence gap.

**Sovereignty, residency and language constraints that shape delivery**
- Subsurface, reservoir and production data are treated as state assets; contracts routinely require **in-country training and inference**, which is precisely why the compute build-out (Stargate UAE, HUMAIN) and the AI programmes are being announced together rather than separately.
- **Arabic-language capability is a hard requirement for customer-facing and workforce-facing systems, not a nice-to-have.** DEWA's Rammas operates in Arabic and English across seven channels; regional workforce assistants must handle Arabic alongside English technical vocabulary and mixed-script maintenance records.
- The delivery pattern that has actually worked regionally is: **sovereign JV holds data and models → global vendor supplies frontier capability → outcomes announced as national achievements.** ADNOC/AIQ/Presight is the archetype; Aramco/HUMAIN is the KSA analogue.
- **Water** is inseparable from power in the Gulf (co-generation). DEWA's AI portfolio spans electricity and water; desalination optimisation and leak detection are the natural adjacencies, though we could not verify a quantified Saudi Water Authority or Kahramaa AI outcome from a primary source in the time available.

---

## 7. Notable voices

> **"AI is one of the biggest stories in the energy world today – but until now, policy makers and markets lacked the tools to fully understand the wide-ranging impacts."**
> — Fatih Birol, Executive Director, International Energy Agency, 10 April 2025

> **"While AI is still an energy taker, it is also becoming an energy maker – driving forward innovative solutions like next-generation nuclear reactors, flexible data centres and long-duration energy storage."**
> — Fatih Birol, IEA, 16 April 2026

> **"ENERGYai marks a major milestone in ADNOC's journey to be the world's most AI-enabled energy company."**
> — Dr Sultan Ahmed Al Jaber, Managing Director and Group CEO, ADNOC, 4 November 2024

> **"ADNOC is on a mission to become the world's most AI-enabled energy company, maximizing AI's potential to drive efficiency and value creation."**
> — Musabbeh Al Kaabi, CEO Upstream, ADNOC, 10 March 2025

> **"We are using old seismic data, which we utilized in the past and reprocess[ing] it with AI and we are now able to generate new results from old data, which creates great savings."**
> — Ahmad O. Al-Khowaiter, EVP Technology & Innovation, Aramco, 12 March 2025

> **"Artificial intelligence is no longer an optional technology that organisations add to their operations, but has become a fundamental pillar of smart and sustainable cities."**
> — Saeed Mohammed Al Tayer, MD & CEO, DEWA, 3 August 2026

> **"Monitoring 10,000 pieces of critical equipment with AI-enabled predictive maintenance is an important milestone for Shell — an ambitious target we had set for 2021 and successfully achieved."**
> — Dan Jeavons, VP Computational Science and Digital Innovation, Shell, 8 March 2022

> **"The bad news is that financial performance in Q1 was completely unacceptable."**
> — Thomas M. Siebel, Founder, C3 AI, 3 September 2025

> **"The threat of wildfire requires more than incremental improvement, it demands a different kind of vigilance."**
> — PG&E, Continuous Monitoring Center, 2025

---

## 8. Source index

1. IEA, *Energy and AI* — Executive summary, 10 Apr 2025. https://www.iea.org/reports/energy-and-ai/executive-summary — 415 TWh 2024, 945 TWh 2030, 1,200 TWh 2035, $0.5tn 2024 data-centre investment, 30–50% outage duration, 175 GW transmission.
2. IEA, *Energy and AI* — Energy demand from AI, Apr 2025. https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai — regional splits (US +240 TWh, China +175 TWh, Europe +45 TWh), accelerated-server growth 30%/yr, scenario range 700–1,700 TWh by 2035.
3. IEA, *Energy and AI* — AI for energy optimisation and innovation, Apr 2025. https://www.iea.org/reports/energy-and-ai/ai-for-energy-optimisation-and-innovation — $110bn/yr by 2035, 175 GW, oil & gas supercomputing 11→24 and ~70% annual capacity growth, adoption barriers wording.
4. IEA, *Energy and AI* — AI and energy security, Apr 2025. https://www.iea.org/reports/energy-and-ai/ai-and-energy-security — cyberattack trend, AI-enabled attack quote, gallium 10%/China 95%, 20% of 2030 data-centre capacity at risk from grid constraints, transformer backlogs.
5. IEA news release, 10 Apr 2025. https://www.iea.org/news/ai-is-set-to-drive-surging-electricity-demand-from-data-centres-while-offering-the-potential-to-transform-how-the-energy-sector-works — Birol quotes, quadrupling of AI-optimised data-centre demand, 20% of advanced-economy demand growth.
6. IEA, *Key Questions on Energy and AI* — Executive summary, 16 Apr 2026. https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary — 485 TWh 2025, 950 TWh 2030, capex >$400bn 2025 and +75% 2026, 11x power density, 65-household racks, 15–27 GW onsite gas, digital-skills barrier, 10% open electricity data.
7. IEA news, 16 Apr 2026. https://www.iea.org/news/data-centre-electricity-use-surged-in-2025-even-with-tightening-bottlenecks-driving-a-scramble-for-solutions — 17% 2025 growth vs 3% global, AI facilities tripling, turbine/transformer/chip supply chains, Birol "energy taker / energy maker".
8. S&P Global Commodity Insights, 10 Apr 2025. https://www.spglobal.com/energy/en/news-research/latest-news/electric-power/041025-global-data-center-power-demand-to-double-by-2030-on-ai-surge-iea — ~100 GW global data-centre capacity, 12% five-year CAGR, 50% of US demand growth.
9. Carbon Brief, "AI: Five charts that put data-centre energy use – and emissions – into context". https://www.carbonbrief.org/ai-five-charts-that-put-data-centre-energy-use-and-emissions-into-context — 0.5% of global CO2 in 2024, 1–1.4% by 2030, 60% fossil / 27% renewables / 15% nuclear, "no existing momentum of AI adoption" quote, EV and A/C comparisons.
10. Lawrence Berkeley National Laboratory, *Queued Up: 2026 Edition*, Jun 2026. https://emp.lbl.gov/queues — 2,060 GW queued end-2025, 5+ year median IR-to-COD, gas +86%, solar/wind/storage −19/−19/−16%.
11. NERC, *2025 Long-Term Reliability Assessment*, Jan 2026. https://www.nerc.com/pa/RAPA/ra/Reliability%20Assessments%20DL/NERC_LTRA_2025.pdf — +224 GW summer peak (69% above prior assessment), ERCOT 23 GW data-centre load by 2030, MISO 18 GW by 2035, 13 of 23 areas at risk.
12. EU AI Act, Annex III. https://artificialintelligenceact.eu/annex/3/ — exact high-risk wording for AI safety components in supply of water, gas, heating or electricity.
13. ADNOC press release, 5 Mar 2024. https://www.adnoc.ae/en/news-and-media/press-releases/2023/$500-million-in-value-generated-by-adnoc-through-deployment-of-ai-solutions-in-2023 — $500m/AED 1.84bn 2023 value, named systems, up to 1 Mt CO2 abated.
14. ADNOC press release, 4 Nov 2024. https://www.adnoc.ae/en/news-and-media/press-releases/2024/adnoc-and-aiq-developing-first-of-a-kind-agentic-ai-solution-for-global-energy-transformation — ENERGYai, 80 years of data, up to 75% faster geological modelling, planning 1–2 years → weeks, Al Jaber quote.
15. G42 / AIQ, 10 Mar 2025. https://www.g42.ai/resources/news/aiq-announces-340-million-contract-large-scale-deployment-agentic-ai-across-adnoc-operations — $340m contract, five agents, 28+ fields, three-year rollout, Al Kaabi and Kenesbai quotes.
16. SLB press release, 7 Aug 2025. https://www.slb.com/news-and-insights/newsroom/press-release/2025/aiq-slb-energyai-pr — 10x seismic interpretation speed, +70% precision, 15% of data across two fields, Q4 2025 rollout.
17. Presight, 1 May 2024. https://www.presight.ai/news/adnoc-g42-and-presight-partner-to-accelerate-ai-solutions-for-the-energy-sector — Presight 51% / ADNOC 49% of AIQ, >$1.4bn valuation.
18. Aramco, "Building the AI future". https://www.aramco.com/en/what-we-do/energy-innovation/digitalization/building-the-ai-future — $1.8bn AI-driven Technology Realized Value 2024, 442 use cases, 200+ deployed, HUMAIN, 6,000 developers.
19. Middle East AI News, Jun 2025. https://www.middleeastainews.com/p/aramco-ai--drives-4-billion-value — Nasser on Bloomberg TV: technology realisation $2bn (2023) → $4bn (2024), Metabrain 1tn parameters, 1,500 PB, caveat that the $4bn is not wholly AI-attributable.
20. Aramco Europe, 12 Mar 2025. https://europe.aramco.com/en/news-media/news/2025/aramco-deploys-ai — legacy seismic reprocessing months → hours, ~10bn data points/day, Al-Khowaiter quote.
21. Offshore Technology, 4 Mar 2024. https://www.offshore-technology.com/news/saudi-aramco-unveils-industry-first-generative-ai-model/ — Metabrain 250bn parameters, 7tn data points, 90+ years, Uthmaniyah inspection time −90%.
22. C3.ai investor relations, 8 Mar 2022. https://ir.c3.ai/news-releases/news-release-details/shell-achieves-major-milestone-scales-artificial-intelligence — Shell 10,000 assets, ~11,000 models, 3m+ sensors, 20bn rows/week, 15m predictions/day, Jeavons quote, no ROI disclosed.
23. C3.ai investor relations, 28 May 2025. https://ir.c3.ai/news-releases/news-release-details/c3-ai-and-baker-hughes-renew-and-expand-joint-venture-agreement — renewal through June 2028, >$0.5bn cumulative O&G/chemicals revenue, named customers incl. QatarEnergy LNG.
24. C3.ai investor relations, 3 Sep 2025. https://ir.c3.ai/news-releases/news-release-details/c3-ai-announces-fiscal-first-quarter-2026-financial-results — $70.3m revenue, −19% YoY, guidance withdrawn, Siebel quote.
25. CNBC, 2 Jun 2023. https://www.cnbc.com/2023/06/02/billionaire-tom-siebel-faces-controversy-at-ai-software-vendor-c3ai-.html — Kerrisdale and Spruce Point allegations, Baker Hughes 45% of revenue and 90%+ of unbilled receivables, customer-count methodology changes.
26. Yahoo Finance, 10 Sep 2024. https://finance.yahoo.com/news/the-real-trouble-for-c3ai-may-still-be-ahead-as-it-eyes-renewal-with-its-biggest-customer-120028583.html — Baker Hughes >⅓ of revenue, expiry timing, analyst price-target cuts.
27. Google DeepMind, 26 Feb 2019. https://deepmind.google/blog/machine-learning-can-boost-the-value-of-wind-energy/ — "roughly 20 percent" on 700 MW, baseline defined as no time-based grid commitments.
28. MethaneSAT, 6 Nov 2025. https://www.methanesat.org/project-updates/results-anomaly-investigation-loss-communication-methanesat — anomaly 20 Jun 2025, ~400 contact attempts over 21 days, avionics/EPS likely cause, cause unknown.
29. Environmental Defense Fund, 1 Jul 2025. https://www.edf.org/media/methanesat-loses-contact-satellite — "likely not recoverable", launched Mar 2024, capability demonstrated.
30. *Engineering & Mining Journal*, "AI: Bringing Mining Companies Closer to Their Data". https://www.e-mj.com/features/ai-bringing-mining-companies-closer-to-their-data/ — BHP, Rio Tinto, Fortescue, Teck, Freeport, Newmont figures.
31. *International Railway Journal*, 9 Mar 2026. https://www.railjournal.com/in_depth/autohaul-drives-efficiencies-at-rio-tinto/ — 326.2 Mt 2025, stopping incidents −⅔, resets 4h→8min, 40%→60% inspection-free, Le Breton quote.
32. Hitachi, "Rio Tinto – Fully Autonomous Train Technology". https://www.hitachi.com/en-au/insights/articles/rio-tinto-fully-autonomous-train-technology/ — 2.5 km trains, 240 cars, 28,000 t, 800 km return, 50+ radio bases, full deployment Jul 2018, 6% speed improvement.
33. Renewable Energy World, 14 Aug 2024. https://www.renewableenergyworld.com/power-grid/outage-management/ai-cameras-satellites-and-grid-sensors-inside-a-utilitys-wildfire-playbook/ — Portland General Electric 100% HRFZ camera coverage, ±30 ft ignition location, 85% of ignitions from vegetation contact.
34. Action News Now, 2025. https://www.actionnewsnow.com/pg-e-monitoring-center-prevented-17-fires-saved-6m/article_3c54792d-78dc-4f55-9bf5-7cf1d2601138.html — PG&E San Ramon centre: 17 fires, $6m, 1,000+ outages, 12m customer-minutes, 5.5m smart meters.
35. *Scientific American*, "How new AI technology is helping detect and prevent wildfires". https://www.scientificamerican.com/article/how-new-ai-technology-is-helping-detect-and-prevent-wildfires/ — Pano AI, ALERTCalifornia 1,200+ cameras, APS 10–25 min faster than 911, Overstory/PG&E ~50% vegetation-ignition reduction 2025 vs 2024, detection caveats.
36. Zawya, 3 Aug 2026. https://www.zawya.com/en/projects/technology-telecom/dubais-dewa-says-ai-cuts-customer-refund-time-from-four-days-to-eight-minutes-417963 — refunds 4 days → 8 min, 13m+ Rammas inquiries since 2017, GPT-4o, Al Tayer quote.
37. Reuters/Zawya via TradingView, 26 Jan 2026. https://www.tradingview.com/news/reuters.com,2026-01-26:newsml_Zaw6BwQqb:0-dewa-s-virtual-employee-rammas-handled-over-1-6mln-inquiries-in-2025/ — 1.6m inquiries in 2025, 12.7m cumulative, channels, Al Tayer quote.
38. DEWA, Data Science and AI. https://www.dewa.gov.ae/en/about-us/strategy-excellence/data-science-and-ai — Rammas, Watson Advisor, Wisdom, DAQRI, HoloLens, MSLP ~480,000 customers.
39. OpenAI, 22 May 2025. https://openai.com/index/introducing-stargate-uae/ — 1 GW Abu Dhabi cluster, 200 MW live 2026, 5 GW campus, partners, OpenAI for Countries, nationwide ChatGPT.
40. G42 / PR Newswire, 16 Oct 2025. https://www.prnewswire.com/news-releases/g42-provides-update-on-construction-of-stargate-uae-ai-infrastructure-cluster-302586430.html — construction status, Khazna, long-lead procurement complete, 2026 delivery.
41. *The National*, 5 Dec 2025. https://www.thenationalnews.com/business/2025/12/05/stargate-uaes-first-phase-to-be-completed-in-third-quarter-of-2026/ — first phase completion Q3 2026.

---

## 9. Gaps and caveats

**What we searched for and could not verify:**
- **A credible, primary-sourced claim that AI increases hydrocarbon recovery factor or reserves by a specific percentage.** Multiple searches returned only cycle-time claims. If a client asks for this number, the honest answer is that it does not exist in the public record.
- **The widely circulated "Shell cut downtime 20% with C3 AI."** The primary C3.ai/Shell release (8 Mar 2022) contains no ROI, savings or downtime figure. Every source we found carrying the 20% figure was a secondary content site without attribution. **Do not use this number.**
- **QatarEnergy AI deployments.** Named as a C3 AI customer via Baker Hughes, but no primary Qatari source with scale or outcomes was reachable.
- **Kahramaa, TAQA, EWEC, ACWA Power, Ma'aden, Emirates Global Aluminium and Saudi Water Authority / SWCC AI outcomes.** Corporate newsroom pages for several of these were not retrievable within this session's fetch constraints. Regional utility and mining AI claims outside DEWA, ADNOC and Aramco should be treated as unverified until a primary source is obtained.
- **National Grid, Enel, Iberdrola, E.ON, Duke, Southern California Edison, Ørsted, Equinor, BP, ExxonMobil, Chevron, TotalEnergies, Petrobras, Woodside, Halliburton, Vale, Anglo American.** Not verified in this pass — the utility evidence base here is US-weighted (PG&E, PGE, APS) and the European utility picture is a genuine hole.
- **GHGSat commercial detection performance figures.** Not verified.
- **A 2026 IEA update to the "AI for energy" savings estimates.** The 2026 *Key Questions* report we reached is demand-side weighted; the $110bn/175 GW figures remain 2025-vintage projections.

**Weakest figures in this dossier (flag if used publicly):**
- **Freeport-McMoRan's $1.5–2bn "saved"** — an avoided-capex counterfactual reported via trade press, not an audited saving.
- **All E&MJ-sourced mining figures** — the article's publication date was not established, and figures are company-reported at one remove. Verify against each company's annual report before publication.
- **ADNOC's $500m** — a company-reported aggregate across seven systems with no published methodology for attributing value to AI versus concurrent operational changes. The same caution applies to Aramco's $1.8bn.
- **AIQ/SLB's 10x / +70%** — a two-field test on 15% of data, jointly announced by the two commercial parties. Pilot-grade evidence.
- **DeepMind's 20%** — 2019, single site, favourable baseline, never replicated.
- **The *Scientific American* wildfire article** — publication date not established from the page retrieved; the 2025-vs-2024 comparison implies 2026 publication.

**Methodological note:** this dossier was compiled under a hard web-search budget that was exhausted mid-research; the later portion relied on direct URL retrieval of sources surfaced earlier. That biases the evidence base toward organisations with strong search presence (IEA, ADNOC, Aramco, C3.ai, PG&E) and against European utilities and smaller GCC entities. A second pass with fresh search capacity should prioritise the named gaps above.
