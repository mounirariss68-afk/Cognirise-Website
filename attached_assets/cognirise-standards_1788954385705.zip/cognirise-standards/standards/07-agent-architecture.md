---
id: agent-architecture
domain: Agent Architecture & Orchestration
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 07. Agent Architecture

> **Purpose.** Prevent over-built, unreliable, or unrecoverable agent systems by fixing the workflow-vs-agent decision, the canonical pattern catalogue, multi-agent topology choice, durable execution, and resilience defaults before a single line of orchestration code is written.
> **Read this when.** Technical spec authoring; any point at which a "should this be an agent" or "should this be multi-agent" question is raised; implementation of any run loop.

## Scope
- In scope: the workflow-vs-agent decision, the seven canonical single-agent patterns, multi-agent orchestration topologies, subagent/context-isolation patterns, durable execution and checkpointing, resilience defaults (retries, timeouts, circuit breakers, budgets), model routing, cost/latency budgeting, and the Replit Autoscale viability boundary.
- Out of scope: tool schema and contract design — see [08 — Tool Contracts](./08-tool-contracts.md); memory tiering and retrieval — see [09 — Memory](./09-memory.md); system prompt structure — see [11 — Prompt & Context Engineering](./11-prompt-context-engineering.md); guardrails/safety layering — see the guardrails standard (GRD); human-in-the-loop UX and escalation triggers — see the HITL standard.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Autonomy level | Simplest solution that meets requirements: single call → workflow → agent, in that order | Agentic loops trade latency and cost for flexibility; unjustified complexity fails demos ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)) |
| Determinism | Determinism is preferred until proven insufficient | Deterministic code is debuggable, cheap, and testable; only prove insufficiency by attempting the fixed pipeline first |
| Orchestration runtime | Vercel AI SDK for tool-calling and streaming; LangGraph JS only when durable multi-step orchestration, checkpointing, or `interrupt()`-based HITL is required | Canonical stack escape hatch, not a free choice — see `_CANON-CONVENTIONS.md` §2 |
| Durable state | Postgres, never in-process memory | No in-memory state survives Autoscale scale-to-zero or a redeploy |
| Step/cost ceilings | Hard-coded numeric caps checked in code, never left to model self-termination | Unbounded loops are a cost and safety failure mode, not just an inefficiency |
| Multi-agent threshold | Single agent with a curated tool set, until instruction complexity or tool overlap forces a split | Splitting prematurely adds coordination overhead without benefit |

## Rules

### Workflow vs. agent decision

**`AGT-001` — Default to the lowest-complexity solution that reliably meets requirements** · `MUST`
Start every new feature as a single LLM call or a fixed-code-path workflow. Escalate to a model-driven agent loop only after proving the fixed pipeline cannot handle the task's variability.
- *Why:* "Finding the simplest solution possible, and only increasing complexity when needed... this might mean not building agentic systems at all" ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:* Implement the feature as a plain async function chain first; introduce a `while` loop calling the LLM until an exit condition only once the chain is demonstrated insufficient in a spec review or a failing eval.
- *Check:* The technical spec includes a written justification (the decision table below, filled in) before any agent loop is approved for implementation.

**`AGT-002` — Use the workflow-vs-agent decision table before writing orchestration code** · `MUST`

| Question | If mostly "yes" → | If mostly "no" → |
|---|---|---|
| Is the task well-defined with a predictable, fixed set of steps? | Workflow | Agent |
| Can you enumerate the subtasks in advance? | Workflow (prompt chaining / routing / parallelization) | Agent (orchestrator-workers) |
| Does predictability matter more than adaptability for this job? | Workflow | Agent |
| Is the number of steps unknowable ahead of time? | — | Agent |
| Do you have both a stopping condition and sufficient trust in the model's judgment for this environment? | — | Agent (else: workflow, or do not build) |
| Would a rules engine become unmaintainably complex (many branching conditions)? | Agent | Workflow |
| Is the input heavy unstructured data that resists deterministic parsing? | Agent | Workflow |

- *Why:* OpenAI frames an agent as a system that "recognizes when a workflow is complete and can proactively correct its actions if needed," reserved for cases the above table routes to "agent" ([OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- *How:* Attach the filled table as an appendix to the technical spec's architecture section.
- *Check:* Reviewer confirms every "agent" row in the table cites a specific reason a workflow was tried or ruled out.

**`AGT-003` — Determinism is preferred until proven insufficient** · `MUST`
Any capability implementable in deterministic code (parsing, routing on an explicit field, pagination, retries, arithmetic) MUST be implemented in deterministic code, not delegated to a model call, regardless of whether an agent loop exists elsewhere in the run.
- *Why:* Deterministic code is unit-testable, has zero inference cost, and cannot hallucinate; reserving model calls for genuinely dynamic decisions is the same discipline recommended for tool granularity (see [08 — Tool Contracts](./08-tool-contracts.md) · TOOL-010).
- *How:* Code review flags any LLM call whose input/output could be produced by a pure function.
- *Check:* Grep the run's LLM call sites; each must have a one-line comment stating what non-deterministic judgment it performs.

### Canonical single-agent workflow patterns

**`AGT-004` — Select one of the seven canonical patterns explicitly; do not invent an eighth** · `MUST`
Every workflow or agent step MUST map to one of: prompt chaining, routing, parallelization, orchestrator-workers, evaluator-optimizer, reflection, ReAct, or plan-and-execute. Record the chosen pattern name in the technical spec next to the component it describes.

| Pattern | Definition | When to use | Failure modes |
|---|---|---|---|
| Prompt chaining | Sequence of LLM calls, each processing the prior output, with optional programmatic gate checks between steps | Task cleanly decomposes into fixed subtasks (outline → validate → write) | Error compounding across steps with no gate; silent drift from the original goal |
| Routing | Classify input, direct to a specialized downstream prompt/tool/model | Distinct input categories are better handled separately, or cheap/expensive model split is desired | Misclassification with no fallback route; router itself becomes a bottleneck if too capable/expensive |
| Parallelization (sectioning/voting) | Independent subtasks run concurrently, aggregated programmatically | Subtasks are independent, or multiple attempts/perspectives increase confidence | Non-independent subtasks producing inconsistent results; aggregation logic silently favoring one voter |
| Orchestrator-workers | Central LLM dynamically breaks down the task and delegates to worker LLM calls, then synthesizes | Subtasks cannot be predicted ahead of time (multi-file edits, open-ended research) | Orchestrator re-planning indefinitely with no step cap; workers lacking enough context to succeed |
| Evaluator-optimizer | One LLM generates, another evaluates/critiques in a loop | Clear evaluation criteria exist and iterative refinement demonstrably helps | Unbounded refinement loop; evaluator and generator sharing blind spots because they are the same model/prompt |
| Reflection | Agent critiques its own prior output before finalizing, without a separate evaluator | Single-pass output has a known, checkable defect class (e.g., syntax, completeness) | Self-critique convergence to false confidence; no independent check on grounding |
| ReAct | Interleaved reasoning and tool-action steps, observation feeds the next reasoning step | Open-ended tasks needing external information gathered incrementally | Tool-call thrashing (calling the same tool repeatedly without new information); reasoning traces leaking into user-facing output |
| Plan-and-execute | Upfront plan generated once, then executed step by step with limited re-planning | Task decomposes reasonably well upfront but benefits from a visible, auditable plan | Plan staleness when execution reveals the plan was wrong and no re-planning trigger exists |

- *Why:* All patterns except reflection/ReAct/plan-and-execute are catalogued directly in [Anthropic's Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents); reflection and ReAct are the standard complementary patterns for self-correction and tool-interleaved reasoning referenced in the same agentic-patterns literature.
- *How:* Name the pattern in code as a comment or module name (`orchestratorWorkersPlan.ts`) matching this table's terminology.
- *Check:* Spec reviewer can point at any orchestration code path and name its pattern from this table without asking the author.

**`AGT-005` — Implement prompt chaining as a persisted, resumable step pipeline** · `MUST`
Persist each chain step's output to Postgres before invoking the next step.
- *Why:* Persisting intermediate outputs makes the chain resumable after a crash or redeploy and gives you a free audit trail.
- *How:*
```typescript
import { generateText } from "ai";
import { anthropic } from "@ai-sdk/anthropic";
import { db } from "@/lib/db";
import { planSteps } from "@/lib/schema";

async function runChainStep(jobId: string, stepIndex: number, prompt: string) {
  const { text, usage } = await generateText({
    model: anthropic("claude-sonnet-4-5"),
    prompt,
  });

  await db.insert(planSteps).values({
    jobId,
    stepIndex,
    output: text,
    status: "done",
    inputTokens: usage.inputTokens,
    outputTokens: usage.outputTokens,
  });

  return text;
}

async function reconcileInvoiceChain(jobId: string, rawInvoice: string) {
  const outline = await runChainStep(jobId, 0, `Extract line items from: ${rawInvoice}`);
  // Programmatic gate check between steps — deterministic, not another LLM call.
  if (!outline.includes("total")) {
    throw new Error("Gate failed: outline missing required 'total' field");
  }
  const validated = await runChainStep(jobId, 1, `Validate these line items against policy: ${outline}`);
  return runChainStep(jobId, 2, `Produce the final reconciliation summary from: ${validated}`);
}
```
- *Check:* Killing the process mid-chain and restarting resumes from the last persisted step, not step zero.

**`AGT-006` — Implement routing as a typed enum classifier, never a free-text branch** · `MUST`
The router's output MUST be a closed enum validated by Zod before any `switch`/`if` branches on it.
- *Why:* Free-text routing decisions are unauditable and prone to drift; enums force the model into a closed decision space (see [08 — Tool Contracts](./08-tool-contracts.md) · TOOL-006 for the general enum-over-freetext rule).
- *How:*
```typescript
import { generateObject } from "ai";
import { anthropic } from "@ai-sdk/anthropic";
import { z } from "zod";

const RouteSchema = z.object({
  route: z.enum(["billing", "technical", "refund", "escalate_human"]),
  confidence: z.number().min(0).max(1),
});

async function routeTicket(ticketText: string) {
  const { object } = await generateObject({
    model: anthropic("claude-haiku-4-5"),
    schema: RouteSchema,
    prompt: `Classify this support ticket: ${ticketText}`,
  });

  switch (object.route) {
    case "billing": return handleBilling(ticketText);
    case "technical": return handleTechnical(ticketText);
    case "refund": return handleRefund(ticketText);
    case "escalate_human": return escalateToHuman(ticketText);
  }
}
```
- *Check:* `RouteSchema` enum values match exhaustively against the `switch` cases; TypeScript's exhaustiveness checking (a `never` default case) fails compilation otherwise.

**`AGT-007` — Aggregate parallelized results in code, not with another LLM call, whenever possible** · `SHOULD`
Prefer deterministic aggregation (majority vote, score threshold, merge) over an LLM synthesis call for parallel sectioning/voting patterns.
- *Why:* Anthropic's parallelization pattern separates concurrent generation from aggregation specifically to avoid compounding non-determinism at the merge step ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:*
```typescript
const results = await Promise.all(
  perspectives.map((p) => generateText({ model: anthropic("claude-sonnet-4-5"), prompt: p }))
);
const votes = results.map((r) => extractVerdict(r.text)); // deterministic parser
const consensus = votes.filter((v) => v === "approve").length > votes.length / 2;
```
- *Check:* No LLM call exists downstream of `Promise.all`/`asyncio.gather` unless the merge genuinely requires semantic synthesis (documented in a code comment).

**`AGT-008` — Cap orchestrator-workers delegation depth and worker count per run** · `MUST`
The orchestrator MUST enforce a maximum number of worker delegations and a maximum plan depth, checked in code.
- *Why:* Orchestrator-workers is "well-suited for complex tasks where you can't predict the subtasks needed" but is precisely the pattern most prone to runaway delegation without an explicit cap ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:* See `AGT-016` for the shared step/budget cap mechanism; apply `MAX_WORKERS_PER_RUN = 8` and `MAX_PLAN_DEPTH = 2` as studio defaults absent a documented client-specific override.
- *Check:* Integration test asserts the orchestrator halts and escalates once `MAX_WORKERS_PER_RUN` is exceeded, rather than continuing silently.

**`AGT-009` — Cap evaluator-optimizer and reflection iteration counts in code** · `MUST`
Never let the model self-report "I am satisfied" as the sole loop-termination condition; pair it with a hard iteration ceiling.
- *Why:* Anthropic's agent definition treats a maximum-iteration stopping condition as a required design element, not an optional safeguard ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:*
```typescript
const MAX_REFINEMENT_ITERATIONS = 3;
let iteration = 0;
let draft = await generateInitialDraft(input);
while (iteration < MAX_REFINEMENT_ITERATIONS) {
  const critique = await evaluate(draft);
  if (critique.passed) break;
  draft = await optimize(draft, critique.feedback);
  iteration++;
}
if (iteration === MAX_REFINEMENT_ITERATIONS) {
  await flagForHumanReview(draft);
}
```
- *Check:* Unit test forces `evaluate` to always fail and asserts the loop terminates at exactly `MAX_REFINEMENT_ITERATIONS` and calls `flagForHumanReview`.

**`AGT-010` — Implement ReAct with an explicit observation-to-reasoning boundary and a tool-repeat guard** · `MUST`
Detect when the agent calls the same tool with materially identical arguments more than twice in a row and force escalation or termination.
- *Why:* Tool-call thrashing is a named ReAct failure mode; loop detection must be systemic, not left to the model noticing it is stuck (mirrors the escalation-trigger philosophy: "the agent does not decide whether it is confused; the system defines when human review is required" — see the HITL standard).
- *How:*
```typescript
function detectRepeatLoop(history: ToolCall[], threshold = 3): boolean {
  const recent = history.slice(-threshold);
  if (recent.length < threshold) return false;
  const signature = (c: ToolCall) => `${c.name}:${JSON.stringify(c.args)}`;
  return recent.every((c) => signature(c) === signature(recent[0]));
}
```
- *Check:* Feed a synthetic history of three identical tool calls into `detectRepeatLoop` and assert it returns `true`.

**`AGT-011` — Persist plan-and-execute plans as a durable, independently-tracked step ledger** · `MUST`
Store the upfront plan as rows in a `plan_steps` table (see `AGT-018` schema), not only inside the conversation transcript.
- *Why:* This ledger doubles as the durable execution record and the user-facing progress source of truth; plan staleness is caught by comparing execution results against the persisted plan, not by re-deriving intent from chat history.
- *How:* See the `plan_steps` DDL in `AGT-018`.
- *Check:* Querying `plan_steps WHERE job_id = ?` reconstructs the full plan and status without reading the message log.

### Multi-agent orchestration

**`AGT-012` — Prefer a single agent with more tools over a multi-agent system until a concrete wall is hit** · `MUST`
Split into multiple agents only when you hit instruction complexity (many conditional branches the prompt cannot express cleanly) or tool-set overload — defined as tool *similarity/overlap*, not raw tool count.
- *Why:* "Splitting only when prompts contain many conditional statements... or tool overload" — noting that "some production systems manage 15+ distinct tools fine; others struggle with fewer than 10 overlapping ones" ([OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- *How:* Before adding a second agent, first try: (1) rewriting the system prompt's conditional logic as a decision table, (2) removing overlapping tools, (3) adding tool descriptions that disambiguate near-duplicate tools (see [08 — Tool Contracts](./08-tool-contracts.md) · TOOL-002). Only split if all three fail.
- *Check:* The spec's "multi-agent justification" section names which of the three mitigations were tried and why each failed.

**`AGT-013` — Choose a named multi-agent topology; do not leave orchestration ad hoc** · `MUST`

| Topology | Definition | Best for | Cap/guard |
|---|---|---|---|
| Sequential | Linear pipeline, agent B always runs after agent A | Clear, ordered dependencies | Max pipeline length; no cycles |
| Concurrent | Independent agents run in parallel, results fan in | Independent-perspective or latency-sensitive fan-out | Aggregation is deterministic code, not another agent |
| Group chat | Roundtable/debate among agents, including maker-checker/reflection loops | Consensus-building, QA review | Cap at ≤3 agents; mandatory iteration cap and fallback behavior |
| Handoff | One-way (optionally round-trip) control transfer between agents | Triage flows where the right specialist only becomes clear at runtime | Cap handoff-chain depth (studio default: 5); log every transfer |
| Magentic | Dynamic, open-ended task-ledger orchestration with no predetermined solution path | Genuinely open-ended problems with no fixed decomposition | Explicitly the slowest to converge and most prone to stalling; require a wall-clock and step budget stricter than any other topology |

- *Why:* This restates, in technology-agnostic form, [Microsoft Azure Architecture Center's AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns), which documents group chat and magentic alongside sequential/concurrent/handoff.
- *How:* Name the chosen topology in the technical spec's architecture diagram; implement handoff as a typed function call that swaps the active system prompt/tool set while carrying forward the session state row.
- *Check:* Reviewer can identify the topology from the Mermaid sequence diagram (see [04 — Journey Design](./04-journey-design.md) if present) without reading the code.

**`AGT-014` — Implement handoff with a hard maximum chain depth and full transfer logging** · `MUST`
```typescript
import { db } from "@/lib/db";
import { sessions, handoffLog } from "@/lib/schema";

const MAX_HANDOFF_DEPTH = 5;

async function transferTo(sessionId: string, targetAgent: string, contextPayload: unknown) {
  const session = await db.query.sessions.findFirst({ where: (s, { eq }) => eq(s.id, sessionId) });
  if (!session) throw new Error("Session not found");
  if (session.handoffCount >= MAX_HANDOFF_DEPTH) {
    await escalateToHuman(sessionId, "Handoff depth exceeded");
    return;
  }
  await db.insert(handoffLog).values({ sessionId, fromAgent: session.currentAgent, toAgent: targetAgent, contextPayload });
  await db.update(sessions)
    .set({ currentAgent: targetAgent, handoffCount: session.handoffCount + 1 })
    .where((s, { eq }) => eq(s.id, sessionId));
}
```
- *Why:* Azure's architecture guidance explicitly warns handoff orchestration risks "infinite handoff loops" and "unpredictable routing paths" ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- *How:* As above; `handoffCount` is a column on `sessions`, incremented atomically with the log insert.
- *Check:* Integration test drives six consecutive handoffs and asserts the sixth is rejected with an escalation, not executed.

**`AGT-015` — Use subagents for context isolation, not for dividing business logic** · `SHOULD`
Spin up a subagent to isolate large exploratory context (research, code search) and return only a distilled 1,000–2,000 token summary to the lead agent, rather than splitting ownership of a business decision across agents.
- *Why:* Anthropic documents this as a token/attention-isolation technique, not a business-logic split, citing measurable improvement over single-agent systems on complex research tasks ([Anthropic, Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).
- *How:* The subagent's system prompt instructs it to return a structured summary object (validated by Zod) capped at a token budget; the subagent's own tool-call transcript is discarded after the summary is extracted, not forwarded to the lead agent.
- *Check:* Inspect the lead agent's context window construction — subagent raw transcripts must not appear in it, only the summary object.

### Durable execution, checkpointing, and resumption

**`AGT-016` — Every agent run MUST persist to a durable `runs`/`steps`/`checkpoints` schema; never rely on in-process memory** · `MUST`
No agent state that must survive a restart, a long pause (awaiting human approval), or a deploy may live only in process memory.
- *Why:* "`MemorySaver`/`InMemorySaver` store checkpoints in RAM… When the process restarts, all checkpoints are lost" — production requires a durable, Postgres-backed store ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)). This is categorically true on Replit Autoscale, which scales to zero between requests.
- *How:* See the DDL in `AGT-018`.
- *Check:* Kill the process mid-run (`kill -9`) and confirm the run resumes from its last checkpoint on the next invocation rather than restarting from scratch or being lost.

**`AGT-017` — Separate thread-scoped run state from cross-thread long-term state** · `MUST`
Runs, steps, and checkpoints (thread-scoped) are distinct tables from long-term memory (cross-thread) — see [09 — Memory](./09-memory.md) · MEM-001 for the long-term side of this boundary; this file owns only the run-scoped side.
- *Why:* LangGraph's persistence model draws exactly this distinction: checkpointers for "conversation continuity, human-in-the-loop workflows, time travel, and fault tolerance" versus stores for "user preferences, facts, and shared knowledge" ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)).
- *How:* `runs`, `plan_steps`, and `checkpoints` tables (below) never join against long-term memory tables except by `user_id`/`tenant_id` foreign key for scoping.
- *Check:* Schema review confirms no column in `checkpoints` duplicates data that belongs in a `09-memory.md`-owned table.

**`AGT-018` — Use this canonical Postgres/Drizzle schema for runs, steps, and checkpoints** · `MUST`
```typescript
// schema/agent-runs.ts
import { pgTable, uuid, text, jsonb, integer, timestamp, index, uniqueIndex } from "drizzle-orm/pg-core";

export const runs = pgTable("runs", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id").notNull(),
  jobType: text("job_type").notNull(),
  status: text("status", { enum: ["not_started", "in_progress", "needs_human", "done", "failed"] })
    .notNull()
    .default("not_started"),
  autonomyMode: text("autonomy_mode", { enum: ["assist", "copilot", "autopilot"] }).notNull(),
  currentAgent: text("current_agent"),
  handoffCount: integer("handoff_count").notNull().default(0),
  stepCount: integer("step_count").notNull().default(0),
  totalInputTokens: integer("total_input_tokens").notNull().default(0),
  totalOutputTokens: integer("total_output_tokens").notNull().default(0),
  totalCostCents: integer("total_cost_cents").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (t) => ({
  tenantIdx: index("runs_tenant_idx").on(t.tenantId),
  statusIdx: index("runs_status_idx").on(t.status),
}));

export const planSteps = pgTable("plan_steps", {
  id: uuid("id").primaryKey().defaultRandom(),
  runId: uuid("run_id").notNull().references(() => runs.id, { onDelete: "cascade" }),
  stepIndex: integer("step_index").notNull(),
  description: text("description").notNull(),
  dependsOn: jsonb("depends_on").$type<string[]>().notNull().default([]),
  status: text("status", { enum: ["pending", "in_progress", "done", "failed", "skipped"] })
    .notNull()
    .default("pending"),
  output: jsonb("output"),
  inputTokens: integer("input_tokens").default(0),
  outputTokens: integer("output_tokens").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  runIdx: index("plan_steps_run_idx").on(t.runId),
  runStepUnique: uniqueIndex("plan_steps_run_step_unique").on(t.runId, t.stepIndex),
}));

export const checkpoints = pgTable("checkpoints", {
  id: uuid("id").primaryKey().defaultRandom(),
  runId: uuid("run_id").notNull().references(() => runs.id, { onDelete: "cascade" }),
  checkpointIndex: integer("checkpoint_index").notNull(),
  state: jsonb("state").notNull(), // full serialized agent state: messages, plan pointer, tool results
  reason: text("reason", { enum: ["step_boundary", "awaiting_approval", "compaction", "manual"] }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  runIdx: index("checkpoints_run_idx").on(t.runId),
  runCheckpointUnique: uniqueIndex("checkpoints_run_checkpoint_unique").on(t.runId, t.checkpointIndex),
}));
```
- *Why:* Mirrors LangGraph's checkpointer contract (thread-scoped state, resumable, prunable) in hand-rolled form for teams not using LangGraph, and matches the `plan_steps` ledger pattern from the source research ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)).
- *How:* Apply via Drizzle migrations; `runs.id` is the durable run identifier passed to every downstream table.
- *Check:* `\d runs`, `\d plan_steps`, `\d checkpoints` in `psql` match this shape; foreign keys enforce cascade delete.

**`AGT-019` — Write a checkpoint at every step boundary and before any pause for human approval** · `MUST`
- *Why:* Azure's guidance: "mandatory gates make the orchestration synchronous at that step, so persist state at these checkpoints to resume operation without a replay of prior agent work" ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- *How:* Wrap each step executor so it writes to `checkpoints` immediately after producing output, before returning control; on an `awaiting_approval` pause, checkpoint reason is `awaiting_approval` and the run's `status` becomes `needs_human`.
- *Check:* Force an approval pause in a test run, kill the process, restart, and confirm the run resumes without re-executing already-completed steps.

**`AGT-020` — Prune checkpoints and completed runs on a retention schedule** · `MUST`
- *Why:* "Checkpoints growing unboundedly… can increase latency and storage costs" ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)).
- *How:* A Replit Scheduled Deployment (cron) runs nightly, deleting `checkpoints` and `runs` older than the documented retention window (default: 90 days for `done`/`failed` runs; regulated clients set their own window per the data governance standard).
- *Check:* Query `SELECT count(*) FROM checkpoints WHERE created_at < now() - interval '90 days'` returns 0 after the scheduled job runs.

**`AGT-021` — Nothing with a side effect executes without a durable record written first** · `MUST NOT`
No tool call classified `write` or `irreversible` (see [08 — Tool Contracts](./08-tool-contracts.md) · TOOL-008) may execute before its corresponding `plan_steps` row and idempotency key are committed to Postgres.
- *Why:* This is the concrete enforcement mechanism behind "the agent does not decide whether it is confused; the system defines when human review is required," extended to: the system, not the model's in-context state, is the source of truth for what has and has not executed.
- *How:* Wrap every write/irreversible tool invocation in a transaction: insert the pending step row, commit, execute the side effect, then update the row to `done`/`failed`. If the process crashes between insert and execute, the resumed run sees a `pending` row and can safely retry using the idempotency key rather than blindly re-calling the tool.
- *Check:* Kill the process between the insert-commit and the tool execution in a test; on restart, confirm the system detects the `pending` row and does not double-execute the side effect.

### Resilience defaults

**`AGT-022` — Apply these named resilience defaults; do not invent per-project numbers without documented reason** · `MUST`

| Parameter | Default | Notes |
|---|---|---|
| Retry max attempts | 3 | Exponential backoff with full jitter, base delay 1.0s, max delay 30–60s |
| Retry-eligible errors | Rate limits, timeouts, connection errors | Never retry on validation/schema errors — those are not transient |
| Timeout: LLM call | 45s | Time-to-first-token timeout for streaming, plus a mid-stream stall check |
| Timeout: tool execution | 15s | Per individual tool invocation |
| Timeout: web search | 10s | Per individual search call |
| Timeout: database query | 5s | Per individual query |
| Timeout: total request | 120s | Backstop covering the full run |
| Circuit breaker failure threshold | 5 | Failures in a rolling window before opening |
| Circuit breaker recovery timeout | 30–60s | Time before allowing a half-open trial |
| Circuit breaker half-open max calls | 3 | Trial calls allowed before fully closing |
| Circuit breaker success threshold | 2 | Consecutive successes to close from half-open |
| Max steps per run | 25 (single agent), 8 workers / depth 2 (orchestrator-workers, `AGT-008`) | Hard cap in code, not model-reported |
| Max tokens per run | Declared per task class in the spec (see `AGT-027`) | Enforced by summing `usage.total_tokens` before every new LLM call |
| Max cost per run | Declared per task class in the spec (see `AGT-027`) | Enforced against `runs.total_cost_cents` before every new LLM call |
| Loop detection | 3 identical consecutive tool calls | See `AGT-010` |

- *Why:* Concrete parameter defaults are drawn directly from [CallSphere, Building Resilient AI Agents](https://callsphere.ai/blog/building-resilient-ai-agents-circuit-breakers-retries-graceful-degradation), which documents that five sequential 99%-reliable tool calls succeed only 95.1% of the time absent these patterns, and that proper retries/circuit breakers/fallbacks restore effective reliability above 99.9%.
- *How:* Implement as small, dependency-free utility modules — a `RetryConfig` class plus a decorator, and a `CircuitBreaker` class with `CLOSED/OPEN/HALF_OPEN` state — no heavyweight resilience framework required.
- *Check:* Load-test with a fault-injecting mock provider that fails 20% of calls; confirm effective run success rate exceeds 99% and no run exceeds the timeout backstop.

**`AGT-023` — Persist circuit-breaker and rate-limit state across Autoscale instances** · `MUST`
In-process breaker state is insufficient on Autoscale, since each new instance starts with no memory of a prior instance's failures.
- *Why:* In-process circuit-breaker and rate-limit counters do not share state across multiple Autoscale instances, a documented gap in Replit's Autoscale model; production resilience patterns require this state to be shared, per [CallSphere, Building Resilient AI Agents](https://callsphere.ai/blog/building-resilient-ai-agents-circuit-breakers-retries-graceful-degradation).
- *How:* Persist failure counters and breaker state (`CLOSED`/`OPEN`/`HALF_OPEN`, opened-at timestamp) in Postgres, read-modify-write per call; accept per-instance approximation only for documented low-traffic apps with explicit sign-off in the spec.
- *Check:* Run two concurrent Autoscale instances against a failing dependency; confirm the circuit opens for both after the shared threshold is crossed, not per-instance.

**`AGT-024` — Build fallback chains for both models and tools** · `SHOULD`
Attempt a primary model/tool, then a documented fallback (cheaper/alternate model; alternate search provider; cached result), failing the operation only when every fallback is exhausted.
- *Why:* Fallback chains are named alongside retries and circuit breakers as core resilience patterns ([CallSphere, Building Resilient AI Agents](https://callsphere.ai/blog/building-resilient-ai-agents-circuit-breakers-retries-graceful-degradation)).
- *How:* Wrap the primary call in a `try`/`catch` that dispatches to the next entry in a `fallbackChain: Array<() => Promise<T>>` and logs which tier ultimately served the request.
- *Check:* Disable the primary provider's API key in a test environment and confirm the run completes via the fallback tier with a logged tier marker.

**`AGT-025` — Define explicit service levels for graceful degradation** · `SHOULD`
Specify full / degraded / minimal / offline behavior per job type so the system serves something rather than failing outright when a dependency is down.
- *Why:* Named as a required resilience pattern alongside retries and circuit breakers in the source research.
- *How:* A `degradation_level` check at run start selects behavior: full agent loop → workflow-only fallback → rule-based canned response → explicit "service unavailable" with retry guidance.
- *Check:* Spec includes a table mapping each degradation level to concrete behavior for the job type in question.

### Model selection and routing

**`AGT-026` — Route by task class using this table; do not use the most expensive model for every call by default** · `MUST`

| Task class | Model tier | Rationale |
|---|---|---|
| Classification / routing / extraction | Cheap, fast (e.g., Claude Haiku tier) | High volume, low ambiguity — cost dominates |
| Formatting / structured-output transforms | Cheap, fast | Deterministic-adjacent; capability is not the bottleneck |
| Standard task execution / tool orchestration | Mid tier (e.g., Claude Sonnet tier) | Balances capability and cost for the bulk of agent work |
| Synthesis / final answer generation in multi-agent systems | Most capable available tier | Orchestrator/synthesis step is the single highest-leverage point for quality |
| High-stakes decisions (financial, regulatory, irreversible) | Most capable available tier, evaluated against a baseline before any downgrade | Errors here have outsized cost; do not optimize cost before establishing an accuracy baseline |

- *Why:* "Route easy/common questions to smaller, cost-efficient models... and hard/unusual questions to more capable models to optimize for best performance" ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)); Azure's multi-agent guidance confirms the same per-agent assignment rule ("agents that perform classification, extraction, or formatting can often use smaller, less expensive models without a reduction in overall quality") ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- *How:* Implement routing as a cheap pre-classification call or a non-LLM heuristic before dispatching to the main model; store the routing decision on the `runs` row for audit.
- *Check:* Query `runs` grouped by task class and model tier; confirm no high-volume classification task class is routed to the most expensive tier without a documented exception.

**`AGT-027` — Declare per-task-class cost and latency budgets in the spec; enforce them in code** · `MUST`
Every technical spec MUST include a budget table (below); the corresponding run loop MUST check consumed tokens/cost/latency against it before every new LLM call and halt-and-escalate on breach.

| Task class | Target p50 latency | Target p95 latency | Max tokens per run | Max cost per run |
|---|---|---|---|---|
| Simple classification/routing | 500ms | 1.5s | 2,000 | $0.01 |
| Standard single-agent task | 5s | 20s | 30,000 | $0.25 |
| Multi-step orchestrator-workers job | 20s | 90s | 150,000 | $2.00 |
| Deep research / open-ended magentic job | 60s | 300s | 500,000 | $8.00 |

Values above are studio defaults; the spec author MUST replace them with client- and job-specific numbers and MUST NOT leave the table unfilled.
- *Why:* AWS's Well-Architected guidance instructs teams to "select cost-optimized models," "engineer prompts for cost," and "optimize vector stores and agent workflows" against declared budgets, not ad hoc monitoring after the fact ([source: standards-areas inventory B5, mirroring AWS Well-Architected Generative AI Lens guidance]).
- *How:* See [11 — Prompt & Context Engineering](./11-prompt-context-engineering.md) for the token-budget accounting table; enforce via the `runs.total_cost_cents`/`totalInputTokens`/`totalOutputTokens` counters checked before each LLM call, per `AGT-022`.
- *Check:* CI includes a load test that asserts p95 latency and total cost for a representative job stay under the declared budget; breach fails the build.

### Not viable on Replit Autoscale

**`AGT-028` — Flag and route around the four documented Autoscale non-viabilities** · `MUST`

| Not viable on Autoscale | Required workaround |
|---|---|
| In-memory checkpointers/state (`MemorySaver`, in-process breaker state, in-process caches) — lost on every scale-to-zero cycle or redeploy | Persist all durable state (checkpoints, approvals, plan steps, memory) in Replit Postgres; use a Reserved VM only where a genuinely single, always-running process is required |
| Hosting your own MCP server for a single in-app tool set | Register tools directly with the model SDK; only add an MCP client (not a server) when consuming third-party MCP servers — see [08 — Tool Contracts](./08-tool-contracts.md) · TOOL-013 |
| Secure sandboxing of untrusted, agent-generated code execution inside the main app process | Delegate code execution to an external sandboxing service reached via HTTP tool call, with its own timeout/circuit breaker, kept outside the main deployment process |
| Shared circuit-breaker/rate-limiter state across multiple Autoscale instances | Persist breaker/rate-limit counters in Postgres (`AGT-023`); accept per-instance approximation only for documented low-traffic apps |

- *Why:* These four gaps are explicitly named in the source research's Replit-Specific Platform Reference and "Not Viable on Replit" summary, each with a stated workaround.
- *How:* Cross-reference [20 — Replit & Deployment](./20-replit-deployment.md) (DEP prefix) for the full deployment-type decision; this rule only fixes the agent-architecture-relevant subset.
- *Check:* Architecture review confirms the spec names, for each of the four gaps that applies to the project, which workaround was chosen — silence is a review failure, not an assumption of "not applicable."

## Reference implementation

Folder layout for a Cognirise agent module:
```
src/
  agents/
    <job-type>/
      plan.ts            # plan-and-execute / orchestrator-workers logic
      router.ts           # routing pattern implementation
      tools/               # tool definitions — see 08-tool-contracts.md
      prompts/             # versioned prompt files — see 11-prompt-context-engineering.md
  lib/
    db/
      schema/
        agent-runs.ts      # runs, plan_steps, checkpoints (AGT-018)
    resilience/
      retry.ts             # RetryConfig + decorator (AGT-022)
      circuit-breaker.ts   # CircuitBreaker class (AGT-022, AGT-023)
      loop-detection.ts    # detectRepeatLoop (AGT-010)
```

State machine (Mermaid) for a single run, matching `runs.status`:
```mermaid
stateDiagram-v2
    [*] --> not_started
    not_started --> in_progress: run started
    in_progress --> needs_human: high-risk step / approval gate
    needs_human --> in_progress: approved, resumed from checkpoint
    needs_human --> failed: SLA expired, no safe default
    in_progress --> done: plan complete
    in_progress --> failed: max steps/cost/loop-detection breach
    done --> [*]
    failed --> [*]
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Building a multi-agent system on day one for a well-defined task | Adds coordination overhead, latency, and compounding-error risk with no proven need | Start with `AGT-001`/`AGT-002`; prove the workflow insufficient first |
| Letting the model self-report when it is "done" or "confused" as the sole loop exit | Self-assessed uncertainty is unauditable and inconsistent | Use deterministic step/cost/loop caps (`AGT-009`, `AGT-016`, `AGT-022`) |
| Storing agent state in a module-level variable or in-memory `Map` | Lost on every Autoscale scale-to-zero cycle or redeploy | Persist to Postgres via the `runs`/`plan_steps`/`checkpoints` schema (`AGT-018`) |
| Using the most capable (most expensive) model for every call in a pipeline | Inflates cost/latency for no accuracy gain on easy steps | Route by task class (`AGT-026`) |
| Executing a write/irreversible tool call before any row is committed | A crash mid-call leaves no record of what happened, risking double-execution or silent loss | Insert-then-execute-then-update pattern (`AGT-021`) |
| Uncapped handoff chains between agents | Infinite bounce loops between specialists | Hard `MAX_HANDOFF_DEPTH` with logging (`AGT-014`) |

## Definition of Done

- [ ] Technical spec includes a filled workflow-vs-agent decision table (`AGT-002`) for every agentic component.
- [ ] Every orchestration component is labeled with one of the eight canonical pattern names (`AGT-004`).
- [ ] Multi-agent justification section is present and complete wherever more than one agent exists (`AGT-012`).
- [ ] `runs`, `plan_steps`, `checkpoints` tables exist per the canonical schema (`AGT-018`) and are used for every run.
- [ ] Retry, timeout, circuit-breaker, and step/cost/loop caps are implemented with the named default values or a documented override (`AGT-022`).
- [ ] Model routing table is present in the spec and matches actual model calls in code (`AGT-026`).
- [ ] Cost/latency budget table is filled per task class and enforced in code, not only documented (`AGT-027`).
- [ ] Every write/irreversible tool call is preceded by a committed durable record (`AGT-021`).
- [ ] All four Autoscale non-viabilities relevant to this project have a stated workaround (`AGT-028`).

## Handoff notes

- Paste the filled workflow-vs-agent decision table (`AGT-002`) and the model-routing table (`AGT-026`) into the technical spec before handing to Claude for implementation.
- Attach the `runs`/`plan_steps`/`checkpoints` Drizzle schema (`AGT-018`) verbatim so Claude generates migrations against the canonical shape, not an invented one.
- State explicitly which of the four Autoscale non-viabilities (`AGT-028`) apply to this project and which workaround was chosen, so Replit Agent does not attempt an in-memory shortcut.
- Cross-reference [08 — Tool Contracts](./08-tool-contracts.md), [09 — Memory](./09-memory.md), and [11 — Prompt & Context Engineering](./11-prompt-context-engineering.md) rule IDs directly rather than restating their content.

## Sources

- [Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents) — workflow-vs-agent decision, five canonical patterns, model routing rationale
- [Anthropic, Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents) — subagent context-isolation pattern
- [OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) — agent definition, single-agent-first guidance, multi-agent split criteria
- [Microsoft Azure Architecture Center, AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns) — sequential/concurrent/group chat/handoff/magentic topologies, handoff-loop warning
- [Google ADK docs, Workflow Agents](https://google.github.io/adk-docs/agents/workflow-agents/) — deterministic workflow-agent primitives informing the shared-state pattern
- [LangChain, LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence) — checkpointer vs. store distinction, `MemorySaver` production warning, pruning guidance
- [LangChain, LangGraph Interrupts docs](https://docs.langchain.com/oss/python/langgraph/interrupts) — `interrupt()` checkpoint/resume mechanism
- [CallSphere, Building Resilient AI Agents](https://callsphere.ai/blog/building-resilient-ai-agents-circuit-breakers-retries-graceful-degradation) — concrete retry/timeout/circuit-breaker default values
- [Replit, Deployment types](https://docs.replit.com/features/publishing/deployment-types) — Autoscale/Reserved VM/Scheduled Deployment characteristics informing the not-viable flags
