---
id: data-governance-compliance
domain: Safety, Security & Governance
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 17. Data Governance & Compliance

> **Purpose.** Guarantee that every prototype touching regulated UAE/GCC client data classifies, minimises, redacts, logs, and documents that data in a way that survives a bank, government, or telco compliance review.
> **Read this when.** Research brief intake, technical spec drafting, data-model design, pre-demo compliance gate, handover.

## Scope

- In scope: data classification and handling rules, residency and model/provider selection under residency constraints, PII discovery/minimisation/redaction/retention, privacy-safe logging, audit trails, explainability/decision records, human accountability, bias/fairness testing, required documentation artifacts, AI incident response, and mapping to UAE/DIFC/ADGM/CBUAE and global frameworks.
- Out of scope: guardrail/prompt-injection mechanics (see [12 — Guardrails & Safety](./12-guardrails-safety.md)), general security/authz architecture (see [13 — Security & Authorization](./13-security-authz.md)), accessibility (see [18 — Accessibility & Bilingual](./18-accessibility-i18n.md)), Replit hosting/residency mechanics (see [20 — Replit & Deployment](./20-replit-deployment.md)), QA sign-off sequencing (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md)).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Data classification scheme | 4-tier: Public, Internal, Confidential, Restricted (incl. Sensitive/biometric) | Matches UAE National Cloud Security Policy's data-driven security principle ([UAE Legislation, National Cloud Security Policy](https://uaelegislation.gov.ae/en/policy/details/lsy-s-lotny-llamn-lsh-by)) |
| Default hosting for Confidential/Restricted | UAE/GCC in-region cloud (Azure UAE North/Central, AWS Bahrain/UAE, Oracle UAE); Replit only for synthetic/de-identified prototyping | Replit's default infra is US/India-hosted with no UAE/GCC region ([Replit docs, Information Security](https://docs.replit.com/teams/information-security/overview)) |
| Cross-border model API calls | Require a documented lawful-transfer basis before any Confidential/Restricted field reaches a non-UAE model API | PDPL Art. 22–23 cross-border transfer constraint ([PwC, Navigating Cross-Border Data Transfers](https://www.pwc.com/m1/en/publications/documents/2024/navigating-cross-border-data-transfers-key-regulations-in-the-middle-east.pdf)) |
| PII in prompts/logs | Redact/mask/tokenize before persistence or third-party model transmission unless a documented lawful basis exists | OWASP LLM02 mitigation; PDPL/DIFC minimisation duty ([OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)) |
| Audit trail | Append-only, `created_at/by`, `updated_at/by`, `deleted_at/by` on every mutable table from first commit | Matches DFSA systems-and-controls and DIFC Regulation 10 register expectations ([Thames Kay Consultancy, DFSA supervision and AI in the DIFC](https://www.thameskayconsultancy.com/regulations/dfsa/)) |
| Accountable owner | One named business owner per agent workflow, both studio-side and client-side | DFSA/CBUAE expect a named owner, not a committee ([CBUAE Rulebook, Outsourcing](https://rulebook.centralbank.ae/en/rulebook/outsourcing)) |
| Gap disclosure | Every undelivered control is written down and shared with the client, never silently omitted | Reviewers penalize undisclosed gaps far more than disclosed ones ([05-regulated.md research synthesis](https://www.pwc.com/m1/en/publications/documents/2024/navigating-cross-border-data-transfers-key-regulations-in-the-middle-east.pdf)) |

## Rules

### Data classification and handling

**`GOV-001` — Classify every data field at spec time** · `MUST`
Assign each data field in the technical spec's data model to one of four classes: Public, Internal, Confidential, Restricted (health/biometric/religious/ethnic/criminal-record data is always Restricted).
- *Why:* PDPL imposes heightened consent/safeguard obligations on sensitive/biometric data ([UAE Legislation, Federal Decree-Law No. 45 of 2021](https://uaelegislation.gov.ae/en/legislations/1972/download)).
- *How:* Add a `classification` column to the data-dictionary table in the technical spec; enforce via a Zod-validated column comment or a `data_classification` metadata table in Postgres.
- *Check:* Reviewer confirms every field in the schema maps to a classification; CI fails a migration that adds an unclassified column.

**`GOV-002` — Apply per-class handling rules** · `MUST`
Enforce this handling matrix for every data class: Public (no restriction), Internal (authenticated access only), Confidential (encrypted at rest/in transit, access-logged, redact before third-party model call), Restricted (Confidential rules plus explicit consent record and human sign-off before any agent processes it).
- *Why:* UAE National Cloud Security Policy requires security level aligned to data sensitivity ([UAE Legislation, National Cloud Security Policy](https://uaelegislation.gov.ae/en/policy/details/lsy-s-lotny-llamn-lsh-by)).
- *How:* Implement as a middleware/policy layer keyed on the `classification` column, not ad hoc per-endpoint checks.
- *Check:* A test suite asserts that a Restricted-class record cannot reach an unredacted third-party API call without a consent record present.

**`GOV-003` — Maintain a data-classification and residency statement per engagement** · `MUST`
Produce a one-page written statement of what data types the prototype touches, where each is processed/stored (including third-party model API region), and the lawful basis for any cross-border flow.
- *Why:* This is the first must-have-at-prototype item on the compliance-ready bar (see below).
- *How:* Template lives in `docs/compliance/data-classification-residency.md`, filled at spec approval.
- *Check:* File exists in the repo and is referenced in the handover pack (see [22 — Handover & IP](./22-handover-ip.md)).

### Residency and model/provider selection

**`GOV-004` — Default Confidential/Restricted workloads to UAE/GCC in-region hosting** · `MUST`
Route any Confidential or Restricted data through Azure UAE North/Central, AWS Bahrain/UAE, or Oracle UAE regions; do not process it on Replit's default US/India infrastructure without an explicit, written client waiver.
- *Why:* CBUAE Outsourcing Rulebook requires documented processing-site due diligence; government workloads classified sensitive require in-country hosting ([CBUAE Rulebook, Outsourcing](https://rulebook.centralbank.ae/en/rulebook/outsourcing); [UAE Legislation, National Cloud Security Policy](https://uaelegislation.gov.ae/en/policy/details/lsy-s-lotny-llamn-lsh-by)).
- *How:* Document target-state architecture diagram naming the actual client cloud/region even while prototyping on Replit; see [20 — Replit & Deployment](./20-replit-deployment.md) DEP-018 for trigger points.
- *Check:* The residency statement (GOV-003) names a specific region for every processing hop, including the model API.

**`GOV-005` — Record every model/provider endpoint as a cross-border transfer** · `MUST`
Treat every call to a non-UAE-hosted model API (OpenAI, Anthropic, etc.) as a cross-border personal-data transfer requiring a documented lawful basis.
- *Why:* No official PDPL "white list" of adequate countries exists yet; most transfers rely on contractual safeguards or documented exceptions ([PwC, Navigating Cross-Border Data Transfers](https://www.pwc.com/m1/en/publications/documents/2024/navigating-cross-border-data-transfers-key-regulations-in-the-middle-east.pdf)).
- *How:* Maintain a subprocessor register (GOV-016) listing each model vendor, its processing region, and the lawful-basis note.
- *Check:* Every model call site in the codebase traces to a subprocessor-register entry via a code comment or config key.

**`GOV-006` — Select DIFC/ADGM/federal jurisdiction explicitly per client** · `MUST`
Determine and document whether the client sits under DIFC, ADGM, or federal mainland jurisdiction before designing the data-protection control set.
- *Why:* Regulator, regime, and DIFC-specific Regulation 10 rules differ materially by jurisdiction ([DIFC, Regulation 10 overview](https://www.difc.com/business/registrars-and-commissioners/commissioner-of-data-protection/regulation-10); [ADGM Data Protection Regulations 2021](https://en.adgm.thomsonreuters.com/rulebook/data-protection-regulations)).
- *How:* Add a `jurisdiction` field to the engagement's compliance file with one of `federal-pdpl`, `difc`, `adgm`.
- *Check:* Reviewer confirms the jurisdiction field is set and the correct downstream rules (GOV-007 for DIFC) are applied.

**`GOV-007` — Apply DIFC Regulation 10 roles and register when jurisdiction is DIFC** · `MUST`
For any DIFC-jurisdiction engagement, model the client as **Deployer** (Controller) and the studio as **Operator** (Processor), and maintain a System register covering necessity/proportionality, data-subject access mechanisms, automated-decision flag, and third-party/location disclosure.
- *Why:* Regulation 10 mandates this register for autonomous/semi-autonomous systems, including generative/ML systems ([Clyde & Co, DIFC enacts landmark regulation](https://www.clydeco.com/en/insights/2023/09/difc-enacts-landmark-regulation-autonomous-systems); [DIFC, Regulation 10 overview](https://www.difc.com/business/registrars-and-commissioners/commissioner-of-data-protection/regulation-10)).
- *How:* Reuse the model/system card template (GOV-017) as the register entry; add a `high_risk_processing: true|false` flag per system.
- *Check:* Register entry exists for every DIFC-jurisdiction agent workflow before it processes real data.

### PII discovery, minimisation, redaction, retention

**`GOV-008` — Run automated PII discovery on ingestion** · `MUST`
Scan every new data source (uploaded file, API payload, database import) for PII/sensitive fields before it enters any prompt, log, or eval dataset.
- *Why:* Prevents undetected regulated fields from silently reaching a third-party model API (OWASP LLM02) ([OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)).
- *How:* Implement a PII-scan step (regex + named-entity classifier) as a pipeline stage before ingestion into the vector store or context window; fail closed if scan cannot run.
- *Check:* CI/integration test feeds a synthetic PII-laden fixture and asserts it is flagged before reaching the model-call boundary.

**`GOV-009` — Minimise fields passed into any prompt or tool call** · `MUST`
Pass only the fields a given prompt or tool call strictly needs; never pass a full record when a subset suffices.
- *Why:* Data minimisation is a PDPL/DIFC DPL requirement and reduces blast radius of any leak ([UAE Legislation, Federal Decree-Law No. 45 of 2021](https://uaelegislation.gov.ae/en/legislations/1972/download)).
- *How:* Define an explicit Zod projection schema per tool/prompt input; reject any object with extra keys (`.strict()`).
- *Check:* Static review confirms each tool's input schema is a strict subset of the source record, not a full-row pass-through.

**`GOV-010` — Redact or mask Confidential/Restricted fields before third-party model calls** · `MUST`
Redact, mask, or tokenize regulated fields before they reach a third-party LLM API unless a documented lawful transfer basis and client sign-off exist.
- *Why:* This is a non-negotiable compliance-ready-prototype item (see table below).
- *How:* Apply a redaction middleware keyed on `classification` (GOV-001) immediately before the outbound model-API call; log the redaction event, not the redacted value.
- *Check:* Integration test asserts a Restricted-class fixture never appears unredacted in the outbound request body.

**`GOV-011` — Define and enforce a retention schedule per data class** · `MUST`
Set an explicit retention period per data class and implement an automated deletion job; do not rely on a policy document alone.
- *Why:* PDPL and DIFC DPL both require personal data kept identifiable "for no longer than necessary" ([UAE Legislation, Federal Decree-Law No. 45 of 2021](https://uaelegislation.gov.ae/en/legislations/1972/download)).
- *How:* Implement a `pg-boss` scheduled job (see [20 — Replit & Deployment](./20-replit-deployment.md)) that hard-deletes or anonymises rows past their retention window, keyed on `created_at` and `classification`.
- *Check:* A test seeds an expired-retention row and asserts the deletion job removes or anonymises it.

### Privacy-safe logging

**`GOV-012` — Strip or hash PII before persisting prompts/responses to logs** · `MUST`
Log prompts and responses for audit/debugging, but strip or hash PII fields before persistent storage wherever feasible.
- *Why:* Logs are a common unguarded PII leak surface distinct from the primary data store.
- *How:* Apply the same redaction middleware (GOV-010) to the logging sink; store a redaction map keyed by request ID only in a separate, access-restricted table if reversibility is required.
- *Check:* Log-export sample is scanned by the PII discovery tool (GOV-008) and returns zero findings.

**`GOV-013` — Segregate logs behind access control with a documented retention period** · `MUST`
Restrict log access to authorized roles and set an explicit log-retention period distinct from primary-data retention.
- *Why:* Logs containing even redacted operational metadata are still an access-control surface.
- *How:* Separate schema/namespace for logs; role-based access via the app's auth layer (see [13 — Security & Authorization](./13-security-authz.md)).
- *Check:* Access-control test confirms a non-privileged role cannot query the log table/namespace.

### Audit trails, explainability, human accountability

**`GOV-014` — Implement an append-only audit log of agent actions and tool calls** · `MUST`
Record every agent action, tool call, and decision with actor identity and timestamp in an append-only structure; treat immutability hardening (write-once storage, hash-chaining) as a documented post-prototype upgrade.
- *Why:* Matches DFSA systems-and-controls and DIFC Regulation 10 register expectations ([Thames Kay Consultancy, DFSA supervision and AI in the DIFC](https://www.thameskayconsultancy.com/regulations/dfsa/)).
- *How:* Dedicated `audit_log` table with `created_at/by`, no `UPDATE`/`DELETE` grants for the application role, insert-only via a single logging function.
- *Check:* Database role permissions test confirms the application role cannot issue `UPDATE`/`DELETE` against `audit_log`.

**`GOV-015` — Persist a structured decision record for every consequential agent decision** · `MUST`
For any decision affecting credit, benefits eligibility, hiring, or access, persist: inputs, model/version, retrieved context, a confidence/uncertainty signal, and a human-readable rationale.
- *Why:* Required in substance by DIFC Regulation 10 notice/register provisions and the Dubai AI Ethics "Transparency" pillar ([Digital Dubai, AI Ethics Principles & Guidelines](https://www.digitaldubai.ae/docs/default-source/ai-principles-resources/ai-ethics.pdf)).
- *How:* Emit a `decision_record` row from the agent's decision node with a fixed schema (see Reference implementation); link to the audit log entry.
- *Check:* Every consequential-decision code path has a corresponding `decision_record` insert verified by an integration test.

**`GOV-016` — Maintain a subprocessor register with processing locations** · `MUST`
List every subprocessor (model API vendor, vector DB, hosting provider, observability tool) with its processing location and purpose.
- *Why:* Required for CBUAE outsourcing due diligence and DIFC Regulation 10's third-party disclosure requirement ([CBUAE Rulebook, Outsourcing](https://rulebook.centralbank.ae/en/rulebook/outsourcing)).
- *How:* `docs/compliance/subprocessors.md`, one row per vendor, updated whenever a new API/library with external data flow is added.
- *Check:* Every outbound network call in the codebase to a third-party host maps to a subprocessor-register row.

**`GOV-017` — Produce a model/system card per engagement** · `MUST`
Write a one-page model/system card: model(s) used, data sources, known limitations, intended use boundaries — mapped to DIFC Regulation 10 notice content and Dubai AI Ethics documentation fields.
- *Why:* This is a non-negotiable compliance-ready-prototype item and doubles as the Regulation 10 register entry (GOV-007).
- *How:* Template in `docs/compliance/model-card.md`; regenerate at every model/provider swap.
- *Check:* Model card exists, is dated, and is included in the handover pack (see [22 — Handover & IP](./22-handover-ip.md)).

**`GOV-018` — Draft a DPIA/AIA per engagement using the studio template** · `SHOULD`
Produce a draft Data Protection/AI Impact Assessment for engagements processing real Confidential/Restricted data; treat formal client compliance-function sign-off as a pilot/production gate, not a prototype gate.
- *Why:* Formal sign-off is deferrable; the draft itself is what a reviewer expects to see (see compliance-ready bar).
- *How:* Reuse one DPIA/AIA template across PDPL, DIFC, and Dubai self-assessment needs.
- *Check:* Draft DPIA/AIA file exists in `docs/compliance/` before any prototype touches real client data.

**`GOV-019` — Maintain a risk register per engagement** · `MUST`
Track identified AI-specific risks (hallucination, bias, data leak, prompt injection, model drift) with severity, likelihood, mitigation status, and owner.
- *Why:* SR 11-7-style model governance and NIST AI RMF's Manage function both require a living risk register, not a one-time assessment ([Federal Reserve, SR 11-7](http://www.federalreserve.gov/boarddocs/srletters/2011/sr1107.pdf); [NIST, AI RMF Generative AI Profile](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.600-1.pdf)).
- *How:* `docs/compliance/risk-register.md`, reviewed at every QA gate (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md)).
- *Check:* Risk register has at least one entry per OWASP LLM Top 10 category assessed as applicable/not applicable.

**`GOV-020` — Name one accountable business owner per agent workflow** · `MUST`
Assign a single named accountable owner (not a committee) on both the studio side and the client side for each agent workflow.
- *Why:* DFSA and CBUAE guidance expect a named senior-management owner ([Thames Kay Consultancy, DFSA supervision and AI in the DIFC](https://www.thameskayconsultancy.com/regulations/dfsa/)).
- *How:* Record owner names in the model/system card (GOV-017) and the risk register (GOV-019).
- *Check:* Both owner fields are non-empty before the prototype reaches a client demo.

**`GOV-021` — Require human-in-the-loop approval for consequential or irreversible agent actions** · `MUST`
Block autonomous execution of financial, legal, or citizen-impacting actions behind an explicit human approval gate.
- *Why:* Non-negotiable compliance-ready-prototype item; matches DFSA and Regulation 10 human-oversight expectations.
- *How:* Implement via the HITL approval-state machine defined in [14 — Human-in-the-Loop & Escalation](./14-hitl-escalation.md); do not duplicate that mechanism here.
- *Check:* No code path exists where a Restricted-class write executes without a prior `approval-responded: approved` state.

### Bias, fairness, and documentation

**`GOV-022` — Run a qualitative bias/fairness review against Dubai AI Ethics fairness sub-guidelines before go-live** · `MUST`
Document a review of training/retrieval data representativeness, bias in decision logic, and equitable treatment across groups, even if only qualitative at prototype stage.
- *Why:* Reviewers expect visible engagement with the Fairness pillar, not full statistical rigor, at prototype stage ([Digital Dubai, AI Ethics self-assessment tool](https://www.digitaldubai.ae/AIEthics)).
- *How:* Run the free Digital Dubai AI Ethics self-assessment tool and attach the resulting score/report to the risk register.
- *Check:* A dated fairness-review note exists in `docs/compliance/` referencing the self-assessment score.

**`GOV-023` — Escalate to statistically powered fairness testing for credit/HR/benefits use cases before production** · `SHOULD`
For use cases materially affecting credit, employment, or benefits eligibility, plan statistically powered fairness testing across protected attributes as a pre-production gate.
- *Why:* Qualitative review is acceptable at prototype but insufficient for production in these use cases (see compliance-ready bar).
- *How:* Record as a documented deferred item in the gap-disclosure template (below), with a named remediation owner and target milestone.
- *Check:* Gap-disclosure entry exists for any credit/HR/benefits prototype lacking statistical fairness testing.

### AI incident response

**`GOV-024` — Maintain an AI-specific incident runbook distinct from generic IT incident response** · `MUST`
Define response procedures for hallucination-caused harm, prompt-injection breach, and data leak via an agent tool, with severity classification aligned to OWASP LLM Top 10 categories.
- *Why:* Generic IT incident response does not cover model-specific failure modes ([OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)).
- *How:* `docs/compliance/ai-incident-runbook.md`: trigger detection, containment (kill switch on the agent's tool permissions), client notification SLA, post-mortem template referencing MITRE ATLAS tactics.
- *Check:* Runbook file exists and is referenced from the on-call/handover documentation.

### Framework mapping

**`GOV-025` — Map every engagement's control set to the applicable regulatory frameworks explicitly** · `MUST`
For each engagement, state in writing which of PDPL, DIFC Regulation 10, ADGM, CBUAE/joint Enabling Technologies guidance, EU AI Act, NIST AI RMF (+ Generative AI Profile), and ISO/IEC 42001 apply, and how the studio's controls satisfy each.
- *Why:* Enterprise clients benchmark against multiple frameworks simultaneously; an explicit mapping answers procurement questionnaires quickly ([SCA, Guidelines for Financial Institutions Adopting Enabling Technologies](https://www.sca.gov.ae/assets/download/f8f27306/guidelines-fiaet.aspx)).
- *How:* Single `docs/compliance/framework-mapping.md` table: framework → applicable (Y/N) → control(s) satisfying it → gap if any.
- *Check:* Table is complete for all eight frameworks listed above, with no blank "applicable" cells.

## Reference implementation

```sql
-- Audit log: append-only, no update/delete grants for the app role
CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  actor_type TEXT NOT NULL CHECK (actor_type IN ('user', 'agent', 'system')),
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  classification TEXT NOT NULL CHECK (classification IN ('public','internal','confidential','restricted')),
  metadata JSONB
);
REVOKE UPDATE, DELETE ON audit_log FROM app_role;
GRANT INSERT, SELECT ON audit_log TO app_role;

-- Decision record for consequential agent decisions
CREATE TABLE decision_record (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  workflow_name TEXT NOT NULL,
  model_id TEXT NOT NULL,
  model_version TEXT NOT NULL,
  inputs JSONB NOT NULL,
  retrieved_context JSONB,
  confidence_signal TEXT,
  rationale TEXT NOT NULL,
  human_approved_by TEXT,
  human_approved_at TIMESTAMPTZ,
  audit_log_id BIGINT REFERENCES audit_log(id)
);
```

```typescript
// Zod schema enforcing field-level classification and strict projection
import { z } from "zod";

const ClassificationEnum = z.enum(["public", "internal", "confidential", "restricted"]);

const CustomerProjectionForPrompt = z
  .object({
    customerId: z.string(),
    tier: z.string(),
    // deliberately excludes name, email, phone, national ID
  })
  .strict(); // rejects any extra key — enforces GOV-009 minimisation

type CustomerProjectionForPrompt = z.infer<typeof CustomerProjectionForPrompt>;

async function redactBeforeModelCall(record: Record<string, unknown>, classification: z.infer<typeof ClassificationEnum>) {
  if (classification === "confidential" || classification === "restricted") {
    return piiRedactor.redact(record); // GOV-010: redact/mask before third-party call
  }
  return record;
}
```

```mermaid
flowchart LR
  A[Data ingested] --> B{PII scan GOV-008}
  B -->|PII found| C[Classify field GOV-001]
  C --> D{Classification}
  D -->|Confidential/Restricted| E[Redact before model call GOV-010]
  D -->|Public/Internal| F[Pass through minimised projection GOV-009]
  E --> G[Model API call]
  F --> G
  G --> H[Decision record GOV-015]
  H --> I[Audit log GOV-014]
```

## The compliance-ready prototype bar

| Must be present at prototype stage | Can be explicitly deferred with a documented gap |
|---|---|
| Data classification & residency statement (GOV-003) | Formal DPIA/AIA sign-off by client compliance function (GOV-018) |
| PII redaction or documented lawful transfer basis (GOV-010) | Third-party red-team/penetration test report |
| Human-in-the-loop gate for consequential/irreversible actions (GOV-021) | ISO 42001/27001 or SOC 2 certification of the studio itself |
| Basic audit log with timestamps and actor identity (GOV-014) | Full immutable/tamper-evident audit trail infrastructure |
| Authenticated, least-privilege access | Statistically powered bias/fairness testing across protected attributes (GOV-023) |
| One-page model/system card (GOV-017) | Regulator-facing certification (DIFC Reg. 10 System certification once finalized) |
| Named accountable owner, studio and client side (GOV-020) | Full multi-region DR/business continuity architecture |
| Baseline security hygiene (no hardcoded secrets, TLS, pinned dependencies) | Complete WCAG 2.2 AA conformance audit |
| Accessibility and Arabic/RTL scaffolding for citizen-facing UI | Formalized subprocessor DPAs with every vendor (GOV-016 lists, but full DPA chain deferred) |
| A documented list of known gaps (see template below) | Tenancy hardening beyond logical isolation |

Rule of thumb: every control must be **visible and documented**, even where implementation depth is intentionally reduced ([05-regulated.md, compliance-ready prototype bar](https://www.pwc.com/m1/en/publications/documents/2024/navigating-cross-border-data-transfers-key-regulations-in-the-middle-east.pdf)).

### Gap-disclosure template

```markdown
## Known Gap: <short title>

- **Control area:** <e.g., statistically powered fairness testing>
- **Current state:** <what is implemented today, e.g., qualitative Dubai AI Ethics review completed>
- **Gap:** <what is missing, e.g., no protected-attribute statistical testing>
- **Risk if unaddressed:** <low/medium/high, one sentence>
- **Remediation plan:** <concrete next step>
- **Target milestone:** <pilot / pre-production / production>
- **Owner:** <named individual, studio or client side>
- **Disclosed to client on:** <date>
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| "Everything in a US SaaS region by default" | Fails UAE National Cloud Security Policy review for sensitive government/CBUAE data | Classify data first, route Confidential/Restricted to UAE/GCC in-region hosting (GOV-004) |
| Silent omission of an unfinished control | Reviewers penalize undisclosed gaps far more than disclosed ones | Use the gap-disclosure template for every deferred item |
| Logging full unredacted prompts/responses for debugging | Leaks PII through the log surface even if the primary store is clean | Redact before persisting logs (GOV-012); segregate log access (GOV-013) |
| One "AI governance committee" instead of a named owner | DFSA/CBUAE expect individual accountability | Name one owner per workflow, studio and client side (GOV-020) |
| Treating DPIA/AIA as a production-only artifact | Reviewers expect a draft even at prototype stage | Draft using the studio template before real data is processed (GOV-018) |
| Passing full customer records into every tool call | Violates minimisation; expands breach blast radius | Strict Zod projection schema per tool input (GOV-009) |

## Definition of Done

- [ ] Data-classification and residency statement written and stored in `docs/compliance/` (GOV-003).
- [ ] Every schema field tagged with a classification; CI blocks unclassified columns (GOV-001).
- [ ] PII discovery scan runs on ingestion with a passing test against a synthetic fixture (GOV-008).
- [ ] Redaction middleware verified to strip Confidential/Restricted fields before any third-party model call (GOV-010).
- [ ] Retention jobs implemented and tested for at least one data class (GOV-011).
- [ ] Audit log table has no `UPDATE`/`DELETE` grant for the app role (GOV-014).
- [ ] Decision records verified for every consequential-decision code path (GOV-015).
- [ ] Model/system card, subprocessor register, DPIA/AIA draft, and risk register all present in `docs/compliance/` (GOV-016/017/018/019).
- [ ] Named accountable owner recorded on both sides (GOV-020).
- [ ] AI incident runbook exists and is linked from handover docs (GOV-024).
- [ ] Framework-mapping table complete for all eight frameworks (GOV-025).
- [ ] Gap-disclosure entries exist for every deferred item, dated and shared with the client.

## Handoff notes

- Attach `docs/compliance/data-classification-residency.md`, `model-card.md`, `subprocessors.md`, and `risk-register.md` when handing this project to Claude for spec extension or Replit Agent for implementation.
- Tell Replit Agent explicitly which fields are Confidential/Restricted so it does not scaffold a naive full-record pass-through into prompts.
- When briefing a new engagement, state the client's jurisdiction (federal PDPL / DIFC / ADGM) up front — this determines which rule set (GOV-006, GOV-007) applies.
- Paste the gap-disclosure template directly into the client-facing handover pack; never leave it studio-internal only.

## Sources

- [UAE Legislation, Federal Decree-Law No. 45 of 2021 (PDPL)](https://uaelegislation.gov.ae/en/legislations/1972/download) — sensitive data, cross-border transfer rules.
- [PwC, Navigating Cross-Border Data Transfers in the Middle East](https://www.pwc.com/m1/en/publications/documents/2024/navigating-cross-border-data-transfers-key-regulations-in-the-middle-east.pdf) — no adequacy white list, lawful-basis requirement.
- [DIFC, Regulation 10 overview](https://www.difc.com/business/registrars-and-commissioners/commissioner-of-data-protection/regulation-10) — Deployer/Operator roles, register, High Risk Processing.
- [Clyde & Co, DIFC enacts landmark regulation for autonomous systems](https://www.clydeco.com/en/insights/2023/09/difc-enacts-landmark-regulation-autonomous-systems) — Regulation 10 scope and mechanics.
- [ADGM Data Protection Regulations 2021](https://en.adgm.thomsonreuters.com/rulebook/data-protection-regulations) — ADGM regime distinct from DIFC/federal.
- [UAE Legislation, National Cloud Security Policy](https://uaelegislation.gov.ae/en/policy/details/lsy-s-lotny-llamn-lsh-by) — data-driven cloud security principle.
- [CBUAE Rulebook, Outsourcing](https://rulebook.centralbank.ae/en/rulebook/outsourcing) — cloud outsourcing due diligence for banks.
- [SCA, Guidelines for Financial Institutions Adopting Enabling Technologies](https://www.sca.gov.ae/assets/download/f8f27306/guidelines-fiaet.aspx) — AI governance framework, monitoring, ethics.
- [Thames Kay Consultancy, DFSA supervision and AI in the DIFC](https://www.thameskayconsultancy.com/regulations/dfsa/) — named accountable owner, control environment.
- [Digital Dubai, AI Ethics Principles & Guidelines](https://www.digitaldubai.ae/docs/default-source/ai-principles-resources/ai-ethics.pdf) — Fairness/Accountability/Transparency/Humanity pillars.
- [Digital Dubai, AI Ethics self-assessment tool](https://www.digitaldubai.ae/AIEthics) — usable pre-delivery fairness self-check.
- [European Commission, AI Act timeline](https://ai-act-service-desk.ec.europa.eu/en/ai-act/timeline/timeline-implementation-eu-ai-act) — phased obligations through Aug 2027.
- [NIST, AI RMF Generative AI Profile (NIST.AI.600-1)](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.600-1.pdf) — GAI-specific risk checklist.
- [ISO/IEC 23894:2023](https://www.iso.org/standard/77304.html) — AI risk management guidance alongside ISO/IEC 42001.
- [Federal Reserve, SR 11-7 Supervisory Guidance on Model Risk Management](http://www.federalreserve.gov/boarddocs/srletters/2011/sr1107.pdf) — model inventory, validation, governance template.
- [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/) — PII disclosure and supply-chain mitigations.
