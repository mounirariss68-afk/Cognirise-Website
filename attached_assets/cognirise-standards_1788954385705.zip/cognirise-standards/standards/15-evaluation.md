---
id: evaluation
domain: Safety, Security & Governance
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 15. Evaluation

> **Purpose.** Guarantee that "this agent works reliably" is a claim backed by a versioned, trace-linked evidence set — never an assertion — and that no prompt/tool/model change ships without re-running that evidence set.
> **Read this when.** Spec (acceptance criteria → golden set derivation), implementation (promptfoo/Vitest wiring, CI gate), pre-demo QA (eval report artifact).

## Scope
- In scope: eval taxonomy, building the golden set from Gherkin scenarios, deterministic assertions before LLM-as-judge, judge design/calibration, trajectory and tool-choice evaluation, minimum coverage/passing thresholds before client demo, promptfoo and Vitest wiring, CI gates, production feedback loop into the golden set, the eval report artifact.
- Out of scope: OpenTelemetry span instrumentation and trace-ID propagation that eval scores attach to → see [16 — Observability & Cost](./16-observability-cost.md). Guardrail-specific red-team payloads and threat modeling → see [12 — Guardrails & Safety](./12-guardrails-safety.md) and [13 — Security & Authorization](./13-security-authz.md). Gherkin scenario authoring itself → journey design standard (JRN, forthcoming).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Eval unit | An eval scores a **trajectory** (system prompt, input, every tool call with args/results, retrieval results, final response), not just `(input, output)` | "An LLM eval is a function from (input, output) to a score. An agent eval is a function from trajectory to a score" ([Future AGI's guide to LLM agent evaluation](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)) |
| Scoring granularity | Multiple independent dimensions scored and gated separately, never one aggregate | "An aggregate 0.85 can hide a 0.62 on argument extraction behind a 0.97 on tool selection" ([Future AGI's guide](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)) |
| Golden-set source | Derived directly from the Gherkin scenarios written at journey-design time | Each `.feature` scenario translates to one JSONL row (expected trajectory/outcome) ([03-journeys-and-agents.md, A.8](../../research/03-journeys-and-agents.md)) |
| Assertion order | Deterministic/code-based checks run first (schema, exact match, argument validation); LLM-as-judge reserved for genuinely semantic dimensions | Keeps eval cost low enough to run on every PR ([03-journeys-and-agents.md, B.12](../../research/03-journeys-and-agents.md)) |
| Toolchain | `promptfoo` for prompt/LLM assertions, Vitest for deterministic units, Playwright for journey E2E | Canonical stack ([_CANON-CONVENTIONS.md](../_CANON-CONVENTIONS.md)) |
| Regression gate | No client-facing prompt/tool/model change ships without re-running the full eval suite against baseline | Mandatory regression gate ([01-standards-areas.md, D5](../../research/01-standards-areas.md)) |
| Dataset freshness | Real failing production traces promoted into the offline set on a recurring cadence | Prevents a static eval set from going stale ([03-journeys-and-agents.md, B.12](../../research/03-journeys-and-agents.md)) |

## Rules

### Eval taxonomy

**`EVAL-001` — Classify every eval as one of unit, component, trajectory, end-to-end journey, safety, or regression, and tag it accordingly in the suite** · `MUST`
Every eval case must declare its taxonomy tag: **unit** (a single deterministic function, e.g., a Zod schema or a tool's argument validator), **component** (a single agent/LLM call in isolation, e.g., relevance classifier accuracy), **trajectory** (full multi-step run scored on tool selection/argument extraction/result utilization/error recovery/plan coherence/task completion), **end-to-end journey** (Playwright-driven full user journey including UI), **safety** (guardrail/jailbreak/injection resistance), or **regression** (a case added specifically because it previously failed in production).
- *Why:* The six-dimension trajectory rubric and the broader eval-type distinction are what let CI gate on the right thing at the right layer rather than one undifferentiated pass/fail ([03-journeys-and-agents.md, B.12](../../research/03-journeys-and-agents.md)).
- *How:* Each eval case JSONL row and each Vitest/promptfoo test file carries a `tag` field/directory convention (`evals/unit/`, `evals/component/`, `evals/trajectory/`, `evals/journey/`, `evals/safety/`, `evals/regression/`).
- *Check:* CI report breaks results down by tag; a reviewer can see pass/fail per taxonomy category, not just a single suite-wide number.

**`EVAL-002` — Score trajectory evals on named independent dimensions, gated per-dimension in CI** · `MUST`
Trajectory evals must report at minimum: tool selection, argument extraction, result utilization/groundedness, error recovery, plan coherence, and task completion as separate scores, each with its own pass threshold.
- *Why:* Gating only on an aggregate hides a bad dimension behind good ones ([Future AGI's guide to LLM agent evaluation](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)).
- *How:* `evalReport.dimensions = { toolSelection, argumentExtraction, resultUtilization, errorRecovery, planCoherence, taskCompletion }`, each independently thresholded in the CI config.
- *Check:* CI fails if any single dimension is below its threshold, even when the mean of all dimensions passes.

### Building the golden set from Gherkin scenarios

**`EVAL-003` — Derive every golden-set row directly from a Gherkin scenario, never author eval cases independently of the journey spec** · `MUST`
Each `Given/When/Then` scenario in the project's `.feature` files must produce exactly one (or more, for compound scenarios) golden-set JSONL row, carrying the scenario's job type, expected tool sequence (where deterministic), and expected outcome label.
- *Why:* Keeps the prompt/spec and the eval harness pointing at the same source of truth; this is the explicit translation path from journey design to eval ([03-journeys-and-agents.md, A.8](../../research/03-journeys-and-agents.md)).
- *How:* A build-time script (`scripts/gherkin-to-eval.ts`) parses `.feature` files and emits/updates `evals/golden-set/<job-type>.jsonl`; manual edits to the JSONL that drift from the `.feature` file are flagged.
- *Check:* CI step diffs the generated JSONL against the committed one; a mismatch fails the build until the Gherkin source and the golden set are reconciled.

**`EVAL-004` — Cover the happy path, at least one ambiguous/clarification path, and at least one failure/escalation path per job type in the golden set** · `MUST`
The golden set for every job type must include no fewer than three scenario classes: happy path, ambiguous-input handling, and failure/escalation handoff.
- *Why:* Mirrors the mandatory Gherkin scenario coverage for journeys, so the eval set never under-tests the branching cases a deterministic flow would miss ([03-journeys-and-agents.md, A.8](../../research/03-journeys-and-agents.md)).
- *How:* `gherkin-to-eval.ts` build step fails if a job type's `.feature` file lacks a scenario tagged `@ambiguous` or `@escalation`.
- *Check:* Golden-set coverage report per job type shows at least one row per required scenario class.

**`EVAL-005` — Version the golden set alongside the prompts and tool schemas it evaluates** · `MUST`
The golden-set JSONL files must carry a version identifier that advances in lockstep with the prompt/tool-schema version they were authored against, per the studio's versioning discipline.
- *Why:* "Semantic versioning applied to... the eval dataset itself (so eval comparisons remain apples-to-apples across versions)" ([01-standards-areas.md, F5](../../research/01-standards-areas.md)).
- *How:* Filename convention `evals/golden-set/<job-type>.v<N>.jsonl`; the CI config pins which version the current prompt/tool version is evaluated against.
- *Check:* PR template requires stating which golden-set version a prompt/tool change was evaluated against; reviewer rejects a PR citing a stale version without justification.

### Deterministic assertions before LLM-as-judge

**`EVAL-006` — Run all deterministic/code-based checks before any LLM-as-judge call in a given eval case** · `MUST`
Schema validation, exact tool-name match, argument-schema validation, and any other code-computable check must execute first; an LLM-as-judge call is invoked only for the remaining genuinely semantic dimensions (groundedness, plan coherence, task completion where no code check suffices).
- *Why:* Keeps eval cost low enough to run on every PR and avoids using a nondeterministic judge where a deterministic check would do ([03-journeys-and-agents.md, B.12](../../research/03-journeys-and-agents.md)).
- *How:* Vitest test files implement the deterministic layer; `promptfoo` config's `assert` blocks list deterministic assertions (`is-json`, `contains`, custom Zod-backed assertions) ahead of `llm-rubric`/`model-graded` assertions in the same test case.
- *Check:* promptfoo config review confirms deterministic assertion types precede any `llm-rubric` assertion for the same test case; CI cost report shows judge-call volume bounded to the semantic-only subset.

**`EVAL-007` — Never substitute an LLM-as-judge call for a check that has a deterministic equivalent** · `MUST NOT`
If a dimension can be verified by exact match, schema validation, or a computable rule (e.g., "did the agent call the refund tool with the correct invoice ID"), it must not be scored by an LLM judge instead.
- *Why:* LLM-as-judge introduces its own variance and cost; using it where determinism is available wastes both and reduces reproducibility.
- *How:* Code review checklist item: for every `llm-rubric` assertion added, confirm no deterministic assertion could answer the same question.
- *Check:* Spot-check during PR review; promptfoo config comments justify each `llm-rubric` assertion's necessity.

### Judge design and calibration

**`EVAL-008` — Write every LLM-as-judge rubric as an explicit, versioned scoring guide, not a one-line prompt** · `MUST`
A judge prompt must define the scoring scale, what each score point means concretely, and at least one worked example per score band.
- *Why:* Azure's guidance confirms nondeterministic agent outputs require "scoring rubrics or language-model-as-judge evaluations rather than exact-match assertions" — but a rubric is only reliable if it is concrete ([Microsoft's Azure Architecture Center guidance](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- *How:* `evals/judges/<dimension>.judge.md` per dimension, versioned like a prompt, referenced by promptfoo's `llm-rubric` config.
- *Check:* Spec review rejects a judge assertion that references an inline one-line prompt string instead of a versioned judge file.

**`EVAL-009` — Calibrate every new or modified judge against a human-labeled sample before trusting its scores in CI** · `MUST`
Before a judge rubric is used to gate CI, run it against a sample of at least 20 cases with independent human labels and confirm agreement above a stated threshold.
- *Why:* An uncalibrated judge can systematically over- or under-score, silently invalidating every downstream CI gate that depends on it.
- *How:* `scripts/calibrate-judge.ts` runs the judge against a human-labeled calibration set and reports agreement (e.g., Cohen's kappa or simple accuracy against the human label).
- *Check:* Calibration report attached to the PR introducing/modifying a judge; CI blocks judge activation below the agreement threshold.

**`EVAL-010` — Re-run judge calibration whenever the underlying judge model is changed** · `MUST`
Swapping the model used for LLM-as-judge (e.g., routing the judge call to a different model tier) requires re-running EVAL-009's calibration, not an assumption that scores remain comparable.
- *Why:* Judge model swaps change scoring distribution; treating old and new judge scores as comparable silently corrupts the regression baseline.
- *How:* CI config ties the judge model identifier to the calibration report's model identifier; a mismatch fails the pipeline.
- *Check:* Automated check compares `judge_model` referenced in the calibration report against the model configured in the current promptfoo run.

### Trajectory and tool-choice evaluation

**`EVAL-011` — Score tool-choice correctness as a distinct dimension from task completion** · `MUST`
An agent that completes the task via the wrong tool sequence (e.g., a costlier or riskier path than the correct one) must be scored down on tool selection even if the final task-completion outcome looks correct.
- *Why:* Directly reflects the trajectory-eval philosophy that an agent eval scores the full trajectory, not just whether the end state happens to be acceptable ([Future AGI's guide to LLM agent evaluation](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)).
- *How:* Golden-set rows carry an `expected_tool_sequence` field (where deterministic); the trajectory evaluator diffs the realized sequence against it as a separate scored dimension from the final-output check.
- *Check:* Test case with a correct final answer but wrong tool sequence fails the tool-selection dimension in CI while potentially passing task-completion.

**`EVAL-012` — Attach eval scores to the same span/trace the trajectory was recorded on** · `MUST`
Every trajectory eval's dimension scores must be written back as attributes on the OpenTelemetry span for that run, cross-referenced to [16 — Observability & Cost](./16-observability-cost.md) · OBS-004.
- *Why:* "The trace tree and the score live on the same span," which is what makes production feedback (EVAL-017) and client-facing eval reports traceable to a real run ([Future AGI's guide to LLM agent evaluation](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)).
- *How:* Eval runner writes `gen_ai.evaluation.score.value`, `gen_ai.evaluation.score.label`, `gen_ai.evaluation.explanation` attributes on the corresponding span after scoring.
- *Check:* Trace inspection for an evaluated run shows evaluation attributes present on the relevant span.

**`EVAL-013` — Promote real failing production traces into the golden set on a recurring cadence, not ad hoc** · `MUST`
Clustering of failing production traces and promotion of representative failures back into the offline dataset must happen on a defined, recurring schedule (e.g., weekly), not only when someone remembers to do it.
- *Why:* This closed loop — offline eval → CI gate → production trace eval → clustering → promotion → re-optimization — is the documented mechanism that keeps the golden set from going stale ([03-journeys-and-agents.md, B.12](../../research/03-journeys-and-agents.md)).
- *How:* Scheduled job (Replit Scheduled Deployment or CI cron) queries production traces flagged as failing/low-scoring, clusters similar failures, and opens a PR proposing new golden-set rows.
- *Check:* Golden-set changelog shows dated promotions traceable to specific production trace IDs.

### Minimum coverage and passing thresholds before client demo

**`EVAL-014` — Meet the minimum coverage bar before any client demo: every job type has golden-set coverage per EVAL-004, and every trajectory dimension has a stated pass threshold** · `MUST`
No client demo may proceed until each job type's golden set covers happy/ambiguous/escalation paths and each of the six trajectory dimensions (EVAL-002) has an explicit, documented pass threshold — Cognirise's floor is **task completion ≥ 90%, tool selection ≥ 95%, groundedness/result utilization ≥ 90%, error recovery ≥ 85%, plan coherence ≥ 85%**, with any project-specific deviation requiring documented sign-off.
- *Why:* Establishes a concrete, non-negotiable floor the studio commits to before any client demo, consistent with the studio's mandatory-regression-gate philosophy ([01-standards-areas.md, D5](../../research/01-standards-areas.md)).
- *How:* `evals/thresholds.json` per project, defaulted from the studio floor above; CI reads this file to gate.
- *Check:* Pre-demo checklist requires a green CI run against `evals/thresholds.json` with no dimension below its threshold, or an explicit signed-off deviation note.

**`EVAL-015` — Treat a safety-eval failure as an automatic demo blocker regardless of other dimension scores** · `MUST`
A failing safety-tagged eval (jailbreak resistance, injection resistance, PII leakage) blocks the demo even if every trajectory dimension passes.
- *Why:* Safety failures are categorically different from quality regressions — passing functional evals must never mask a safety regression.
- *How:* CI pipeline treats `evals/safety/` results as a hard gate, evaluated and reported separately from `evals/trajectory/`.
- *Check:* CI configuration confirms the safety-eval job is a required check, not an informational one, on the deploy/demo pipeline.

### promptfoo and Vitest wiring

**`EVAL-016` — Wire promptfoo for LLM/prompt assertions and Vitest for deterministic units under one CI entry point** · `MUST`
The project must have a single CI command that runs both the Vitest deterministic suite and the promptfoo evaluation suite, failing the build if either fails.
- *Why:* Canonical stack requirement: `promptfoo` for prompt/LLM assertions + Vitest for deterministic units, no substitution without an escape hatch ([_CANON-CONVENTIONS.md](../_CANON-CONVENTIONS.md)).
- *How:* `package.json` script `"eval": "vitest run evals/unit evals/component && promptfoo eval -c evals/promptfoo.config.yaml"`; CI job invokes `npm run eval`.
- *Check:* CI log shows both Vitest and promptfoo executed in the same pipeline run, with a single pass/fail gate.

**`EVAL-017` — Structure the eval folder layout consistently across every project** · `MUST`
Use the fixed folder layout below so any consultant, Claude, or Replit Agent instance can locate and extend evals without re-deriving structure per project.
- *Why:* Cross-project consistency is what makes the eval harness reusable studio infrastructure rather than a bespoke artifact per client.
- *How:* See Reference implementation folder layout below; deviations require a documented reason in the technical spec.
- *Check:* Repo structure review confirms the layout matches the canonical tree before the project is handed to Replit Agent.

### CI gates and what blocks a release

**`EVAL-018` — Block merge on any Vitest unit/component failure, any promptfoo trajectory dimension below threshold, or any safety-eval failure** · `MUST`
The CI pipeline must be configured so that none of these three failure classes can be overridden by a manual merge without an explicit, logged waiver.
- *Why:* Operationalizes the mandatory regression gate: "no client-facing prompt/tool/model change ships without re-running the eval suite against the baseline dataset" ([01-standards-areas.md, D5](../../research/01-standards-areas.md)).
- *How:* Branch protection rules require the `eval` CI check to pass; a documented waiver process (recorded in the PR) is the only override path, and waivers are logged, never silent.
- *Check:* Repository branch-protection settings reviewed to confirm the `eval` check is required, not optional.

**`EVAL-019` — Re-run the full eval suite, not a subset, on every prompt, tool schema, or model routing change** · `MUST`
A change to a system prompt, tool schema, or model/routing configuration triggers the complete eval suite, not just the tests judged "related" by the author.
- *Why:* Prompt/tool changes have historically caused regressions in dimensions the author didn't anticipate; partial re-runs defeat the purpose of a regression gate.
- *How:* CI path-filter configuration treats any diff under `prompts/`, `tools/`, or model-routing config as triggering the full `npm run eval`, not a scoped subset.
- *Check:* CI trigger configuration reviewed; test PR touching only a system-prompt file confirms the full suite ran, not a partial one.

### Production feedback into the golden set

**`EVAL-020` — Attach a lightweight production feedback mechanism (thumbs up/down, or override/accept tracking) to every client-facing agent surface** · `MUST`
Every agent-facing UI must let the end user or a downstream reviewer flag an output as wrong, feeding into the same pipeline that clusters and promotes failures (EVAL-013).
- *Why:* Closes the loop from real usage back to the golden set, which is the mechanism that keeps eval debt from silently increasing between prototype and production ([01-standards-areas.md, D5](../../research/01-standards-areas.md)).
- *How:* A shadcn/ui feedback control tagging the relevant trace ID (see [16 — Observability & Cost](./16-observability-cost.md) · OBS-004) with a feedback label, written to a `production_feedback` table.
- *Check:* UI test confirms a feedback action writes a row referencing the correct trace ID.

**`EVAL-021` — Never promote a production trace into the golden set without PII redaction and human review of the proposed row** · `MUST`
Automated promotion (EVAL-013) must produce a pull request for human review, not a direct commit, and must pass the PII scrubber (see [12 — Guardrails & Safety](./12-guardrails-safety.md) · GRD-013) before inclusion.
- *Why:* Prevents real client/user PII from entering a versioned, potentially externally-shared eval dataset.
- *How:* Promotion job opens a PR with the candidate JSONL row; CI runs the PII scrubber against it as a required check before merge.
- *Check:* Test seeds a synthetic-PII production trace and asserts the promotion PR is blocked until redaction is applied.

### The eval report artifact given to the client

**`EVAL-022` — Produce a versioned eval report as a standing artifact of the handover package, not a one-off pre-demo screenshot** · `MUST`
Every client handover must include an eval report stating: golden-set version, per-dimension scores against the studio floor (EVAL-014), safety-eval results, and any explicitly waived threshold with justification.
- *Why:* This is the objective basis for telling a client "this works reliably," replacing an unfalsifiable assertion with evidence ([01-standards-areas.md, D5](../../research/01-standards-areas.md)).
- *How:* `evals/reports/eval-report-<date>-<golden-set-version>.md`, generated by the CI job on the demo-tagged commit, included in the handover ZIP alongside `SPEC.md` and the security/guardrail checklist.
- *Check:* Handover package review confirms the eval report is present, dated, and references the exact golden-set and prompt/tool versions demoed.

## Reference implementation

Folder layout:
```
evals/
  golden-set/
    invoice-reconciliation.v3.jsonl
    support-ticket-triage.v2.jsonl
  judges/
    groundedness.judge.md
    plan-coherence.judge.md
  unit/               # Vitest: schema validators, pure functions
  component/          # Vitest: single-call classifier/router accuracy
  trajectory/         # promptfoo: multi-step trajectory scoring
  journey/            # Playwright: full E2E journeys
  safety/             # promptfoo + Vitest: jailbreak/injection/PII probes
  regression/         # cases promoted from production failures
  reports/
    eval-report-2026-07-27-v3.md
  thresholds.json
  promptfoo.config.yaml
```

`evals/thresholds.json`:
```json
{
  "taskCompletion": 0.90,
  "toolSelection": 0.95,
  "resultUtilization": 0.90,
  "errorRecovery": 0.85,
  "planCoherence": 0.85
}
```

`evals/promptfoo.config.yaml` (excerpt):
```yaml
description: "Invoice reconciliation agent — trajectory eval"
prompts:
  - file://prompts/invoice-reconciliation.v3.txt
providers:
  - anthropic:claude-sonnet-4-5
tests:
  - vars: { case: "evals/golden-set/invoice-reconciliation.v3.jsonl" }
    assert:
      - type: is-json
      - type: javascript
        value: "output.matchedInvoiceId === context.vars.expected.matchedInvoiceId"
      - type: llm-rubric
        value: file://evals/judges/groundedness.judge.md
        threshold: 0.90
```

Gherkin-to-eval translation (one row per scenario):
```json
{
  "scenario": "Escalation - amount exceeds threshold",
  "job_type": "invoice-reconciliation",
  "tag": "trajectory",
  "input": { "invoice_amount": 1500 },
  "expected_tool_sequence": ["match_invoice", "create_pending_approval"],
  "expected_outcome": "escalated",
  "golden_set_version": "v3"
}
```

CI pipeline gate (conceptual):
```mermaid
flowchart LR
  A[PR opened: prompt/tool/model change] --> B[Vitest: unit + component]
  B --> C[promptfoo: trajectory evals]
  C --> D[promptfoo + Vitest: safety evals]
  D --> E{All dimensions >= thresholds.json AND safety pass?}
  E -->|No| F[Block merge]
  E -->|Yes| G[Merge allowed]
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Scoring only final output, ignoring tool-call trajectory | Hides wrong-but-lucky paths and silent tool misuse | Score trajectory dimensions independently (EVAL-002, EVAL-011) |
| Gating CI on a single aggregate score | A bad dimension hides behind good ones | Per-dimension thresholds (EVAL-002, EVAL-014) |
| Hand-writing eval cases independent of the Gherkin spec | Spec and eval drift apart over time | Derive golden set from `.feature` files (EVAL-003) |
| Using an LLM judge for exact-match-checkable facts | Wastes cost, adds nondeterminism where none is needed | Deterministic assertions first (EVAL-006, EVAL-007) |
| Swapping the judge model without recalibrating | Silently invalidates the regression baseline | Recalibrate on judge model change (EVAL-010) |
| Promoting raw production traces straight into the golden set | Leaks PII into a versioned dataset | PII-scrub + human review before promotion (EVAL-021) |
| Screenshotting a passing eval run once before demo, never again | No regression protection after the demo ships | Standing, versioned eval report per handover (EVAL-022) |

## Definition of Done

- [ ] Every eval case tagged with its taxonomy class (EVAL-001).
- [ ] Golden set generated from `.feature` files, covering happy/ambiguous/escalation paths per job type (EVAL-003, EVAL-004).
- [ ] Golden set and judges versioned in lockstep with prompts/tools (EVAL-005).
- [ ] Deterministic assertions precede every LLM-as-judge call (EVAL-006, EVAL-007).
- [ ] Every judge calibrated against a human-labeled sample before use in CI (EVAL-009, EVAL-010).
- [ ] Trajectory evals score all six dimensions with attached span attributes (EVAL-002, EVAL-012).
- [ ] Studio floor thresholds met or explicitly waived before demo (EVAL-014, EVAL-015).
- [ ] promptfoo + Vitest wired under one CI entry point with required branch protection (EVAL-016, EVAL-018).
- [ ] Full suite re-run (not a subset) on every prompt/tool/model change (EVAL-019).
- [ ] Production feedback mechanism live and feeding the promotion pipeline with PII redaction (EVAL-020, EVAL-021).
- [ ] Dated eval report included in the handover package (EVAL-022).

## Handoff notes

- Attach `evals/thresholds.json`, the golden-set JSONL files, and the latest eval report when handing this spec to Claude or Replit Agent.
- State explicitly which job types are in scope for this build so Claude derives golden-set rows from the correct `.feature` files.
- Call out any project-specific threshold deviation from the studio floor with its sign-off reference, so Replit Agent does not silently default to the studio floor when a stricter bar was agreed.
- Include the judge calibration reports alongside judge files so Claude does not need to re-derive rubric intent from the rubric text alone.

## Sources

- [Future AGI — LLM Agent Evaluation Complete Guide 2026](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/) — trajectory-as-function-of-score reframing, six-dimension rubric, span-attached scores, closed-loop promotion.
- [Microsoft Azure Architecture Center — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns) — rubric/LLM-as-judge over exact-match for nondeterministic agents.
- `/home/user/workspace/research/03-journeys-and-agents.md`, §A.8, §B.12 — Gherkin-to-eval translation, deterministic-before-judge ordering, CI wiring.
- `/home/user/workspace/research/01-standards-areas.md`, D5 — eval taxonomy, dataset-driven workflow, mandatory regression gate.
- `/home/user/workspace/_CANON-CONVENTIONS.md` — canonical promptfoo/Vitest/Playwright toolchain.
