---
id: handover-ip
domain: Delivery, QA & Client Handover
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [qa]
last_reviewed: 2026-07-27
---

# 22. Handover & IP

> **Purpose.** Ensure every client engagement ends with an honest demo, a complete handover pack, clean IP/licensing, and a documented boundary between prototype and production, so the client is never surprised by a gap discovered after signature.
> **Read this when.** Demo scripting, pre-handover packaging, contract/licensing review, post-engagement support-scope negotiation.

## Scope

- In scope: the demo script/environment standard, seeded demo data rules, the never-fake list and honest limitation disclosure, handover pack contents, knowledge transfer sessions, licensing/IP of AI-generated code, client data return/deletion, and post-handover support boundaries.
- Out of scope: the underlying compliance artifacts themselves (model card, DPIA/AIA, risk register — see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)), the release checklist and sign-off mechanics (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md)), Replit environment freeze mechanics (see [20 — Replit & Deployment](./20-replit-deployment.md)).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Demo data | Synthetic or explicitly client-approved anonymized data only | Aligns with the residency/PII rules in [17 — Data Governance & Compliance](./17-data-governance-compliance.md); prevents accidental real-data exposure in a client-facing session |
| Disclosure posture | Proactive, written disclosure of every known limitation before the client asks | Matches the compliance-ready-prototype "documented-deferred" pattern; protects trust and the studio's liability position |
| Handover pack format | A fixed, checklist-driven bundle, not an ad hoc export | Ensures nothing is forgotten regardless of which delivery lead runs the engagement |
| Generated-code IP | Client owns the delivered application code; Cognirise retains reusable internal tooling/accelerators under separate license | Standard studio-services IP split; must be stated explicitly in the SOW, not assumed |
| Post-handover support | Time-boxed, scoped warranty period defined in the SOW; anything beyond it is a new engagement | Prevents unscoped, unpaid "just one more fix" drift |

## Rules

### Demo script and environment standard

**`HAND-001` — Script every client demo as a sequence of named beats with expected agent behavior at each** · `MUST`
Write a demo script naming each beat (e.g., "happy path query," "ambiguous request," "tool failure/escalation") with the exact expected agent response, before the demo is delivered live.
- *Why:* An unscripted demo risks the presenter improvising around unverified behavior; a scripted one is fully covered by the E2E test suite (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md) QA-008).
- *How:* `docs/runbooks/demo-script.md`, one file per engagement, versioned alongside the codebase.
- *Check:* Every beat in the demo script has a corresponding `@demo-script`-tagged Playwright test.

**`HAND-002` — Include at least one deliberately imperfect beat showing graceful degradation, not only successes** · `MUST`
Script at least one moment in the demo where the agent hits a boundary (ambiguous input, tool unavailable, low-confidence answer) and show the designed graceful-degradation behavior rather than only showcasing successful paths.
- *Why:* A demo showing only perfect paths sets an unrealistic expectation and looks staged to a technically sophisticated regulated-sector buyer.
- *How:* Reuse the fallback/error-handling patterns defined in the UX error-handling standard (see [05 — UI/UX for Agentic Apps](./05-ux-ui.md)).
- *Check:* Demo script names at least one non-happy-path beat and its expected fallback behavior.

**`HAND-003` — Run every client demo from the frozen `demo` deployment, never from a live-editing session** · `MUST`
Present exclusively from the frozen `demo` environment defined in [20 — Replit & Deployment](./20-replit-deployment.md) DEP-021; never make live code changes during a client-facing session.
- *Why:* Live edits during a demo risk introducing an unverified regression in front of the client.
- *How:* Confirm the demo-freeze cutoff has passed and the `@demo-script` test suite is green before the session starts.
- *Check:* Demo runbook records the deployment URL and freeze timestamp used for each session.

### Seeded demo data rules

**`HAND-004` — Seed every demo environment with synthetic or explicitly client-approved anonymized data** · `MUST`
Populate demo databases exclusively with generated synthetic records or data the client has explicitly approved in writing for demo use after anonymization; never seed with unreviewed production exports.
- *Why:* Prevents accidental disclosure of real personal/financial/citizen data in a client-facing or recorded session, consistent with [17 — Data Governance & Compliance](./17-data-governance-compliance.md) residency and minimization rules.
- *How:* Maintain a seed script (`scripts/seed-demo.ts`) generating realistic-but-fake records; store the client's written anonymization approval, if used, in `docs/compliance/`.
- *Check:* Demo database contents reviewed against the seed script's expected output before each session; no unexplained records present.

**`HAND-005` — Make synthetic demo data realistic enough to exercise real edge cases, not trivially uniform** · `SHOULD`
Generate seed data with realistic variance (name formats including Arabic names, edge-case dates, boundary values) rather than obviously placeholder values like "Test User 1."
- *Why:* Uniform placeholder data hides bugs that only surface on realistic input variety (e.g., RTL name rendering, Hijri/Gregorian date edge cases).
- *How:* Seed script draws from a varied name/date/locale generator covering both English and Arabic records.
- *Check:* Sample of seeded records reviewed for realistic variance before first demo use.

**`HAND-006` — Clearly label all demo/synthetic data as such within the UI when there is any risk of confusion with production** · `SHOULD`
Add a visible environment indicator (banner, watermark, or footer label) identifying the environment as a demo with synthetic data.
- *Why:* Prevents a client stakeholder from mistakenly treating demo output as a live production record.
- *How:* Environment-aware banner component reading an `env.ts`-validated `DEPLOY_ENV` variable.
- *Check:* Demo environment screenshot shows the label; production/staging does not carry the "demo" label.

### Never-fake list and honest disclosure

**`HAND-007` — Never fake a capability the system does not actually have** · `MUST NOT`
Do not script, hardcode, or otherwise simulate agent output that the underlying model/pipeline cannot actually produce live (canned "AI-generated" answers, pre-recorded tool calls presented as live, fabricated latency/accuracy numbers).
- *Why:* This is a hard trust and, in regulated engagements, a legal/ethical boundary — misrepresenting system capability to a bank or government buyer risks the relationship and potential liability.
- *How:* Maintain the never-fake list (below) as a checklist reviewed before every demo script is finalized.
- *Check:* Demo script reviewer confirms every scripted beat reflects genuinely live system behavior, verified against the `@demo-script` E2E test run.

| Never fake | Instead |
|---|---|
| A capability the model/pipeline cannot actually perform live | Disclose it as a documented-deferred item (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) gap-disclosure template) |
| Accuracy, latency, or cost numbers | Report actual measured numbers from the eval/load-test reports (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md)) |
| A "live" tool call that is actually a hardcoded/mocked response | Either wire the real tool call or explicitly tell the client it is a stubbed integration and why |
| Security/compliance posture | State the actual compliance-ready-prototype bar status per item (met vs. documented-deferred) |
| Human involvement in an automated decision | Disclose exactly which steps are human-reviewed vs. fully automated (see [14 — Human-in-the-Loop & Escalation](./14-hitl-escalation.md)) |

**`HAND-008` — Disclose every known limitation in writing before or during the demo, not only if asked** · `MUST`
Present a written limitations summary (drawn from the gap-disclosure template in [17 — Data Governance & Compliance](./17-data-governance-compliance.md)) to the client alongside or before the live demo.
- *Why:* Proactive disclosure protects trust and the studio's liability position far better than a limitation surfacing unprompted during client testing.
- *How:* One-page "Current Limitations & Roadmap" document attached to the demo invite and referenced verbally during the session.
- *Check:* Limitations document exists, is dated to the current release, and was sent to the client contact before or at the start of the session.

### Handover pack contents

**`HAND-009` — Assemble a complete handover pack for every engagement reaching production handoff or extended pilot** · `MUST`
Include, at minimum: full repository access, all spec documents, the eval report, the model/system card, the risk and gap register, operational runbooks, the cost model, and a roadmap to production.
- *Why:* An incomplete handover forces the client (or a successor team) to reverse-engineer decisions the studio already made and documented.
- *How:* `docs/handover/` folder assembled incrementally throughout the engagement, not compiled from memory at the end.
- *Check:* Handover pack checklist (below) fully checked before the engagement is marked complete.

| Handover pack item | Source standard |
|---|---|
| Full repository (git history intact, README current) | [19 — Repository & Stack Conventions](./19-repo-conventions.md) |
| All spec documents (`docs/specs/`) | [03 — Specification](./03-specification.md) |
| Eval report(s), latest and historical | [15 — Evaluation](./15-evaluation.md), [21 — QA & Definition of Done](./21-qa-definition-of-done.md) |
| Model card and system card | [17 — Data Governance & Compliance](./17-data-governance-compliance.md) |
| Risk register and known-gaps disclosure | [17 — Data Governance & Compliance](./17-data-governance-compliance.md) |
| Subprocessor register | [17 — Data Governance & Compliance](./17-data-governance-compliance.md) |
| Operational runbooks (backup/restore, secret rotation, incident response) | [20 — Replit & Deployment](./20-replit-deployment.md), [17 — Data Governance & Compliance](./17-data-governance-compliance.md) |
| Cost model (actual token/infra cost, projected production cost at target volume) | [21 — QA & Definition of Done](./21-qa-definition-of-done.md) |
| Portability checklist and target-state architecture diagram | [20 — Replit & Deployment](./20-replit-deployment.md) |
| Roadmap to production (remaining documented-deferred items with target dates) | This file, HAND-010 |
| Dependency license review | This file, HAND-014 |

**`HAND-010` — Produce a roadmap-to-production document listing every documented-deferred item with an owner and target state** · `MUST`
Convert the compliance-ready-prototype gap-disclosure entries and any other known-deferred work into a roadmap document naming what remains, who owns closing it, and what "production-ready" looks like for each item.
- *Why:* Turns a list of caveats into an actionable plan the client can staff and budget against.
- *How:* Table format: item, current state, target state, owning party (Cognirise/client/joint), estimated effort.
- *Check:* Roadmap document has no item lacking an owning party or target state.

**`HAND-011` — Include actual, not estimated-at-kickoff, cost figures in the cost model** · `MUST`
Base the handover cost model on measured token/infrastructure spend from the eval and load-test runs (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md) QA-012), projected to the client's expected production volume.
- *Why:* Kickoff-stage cost estimates are frequently wrong once real usage patterns and model routing are in place; the client needs accurate figures to budget production.
- *How:* Pull cost telemetry from the observability backend for the most recent representative usage window; apply a documented volume-scaling assumption.
- *Check:* Cost model cites the specific telemetry window and scaling assumption used, not a round, unsourced estimate.

### Knowledge transfer sessions

**`HAND-012` — Run at least one structured knowledge-transfer session covering architecture, spec-to-code traceability, and operational runbooks** · `MUST`
Hold a scheduled walkthrough with the client's technical counterpart covering system architecture, how specs map to code (see [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-018), and how to execute each operational runbook.
- *Why:* A handover pack without a live walkthrough is frequently left unread; a session forces engagement and surfaces the client's actual follow-up questions.
- *How:* Session recorded (with client consent) and the recording added to the handover pack; agenda mirrors the handover pack contents table.
- *Check:* Session calendar invite and either a recording or written summary exist in `docs/handover/`.

**`HAND-013` — Confirm the client's technical counterpart can independently execute at least one runbook before the engagement closes** · `MUST`
Have the client's engineer run through the backup/restore or incident-response runbook themselves, with the studio observing, before handover is marked complete.
- *Why:* Passive walkthroughs do not verify actual transferred capability; a live run does.
- *How:* Schedule a "client-driven" runbook execution session as the final knowledge-transfer step.
- *Check:* Written confirmation (email or session note) that the client's engineer executed the runbook independently, with the outcome noted.

### Licensing and IP of AI-generated code

**`HAND-014` — Run a dependency license review before handover and flag any copyleft or non-permissive license** · `MUST`
Scan the full dependency tree for license type and flag any GPL/AGPL or otherwise non-permissive license for legal review before the client accepts the codebase.
- *Why:* An unreviewed copyleft dependency can create unexpected obligations for the client's downstream use of the code.
- *How:* Automated license-check tool (see [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-022) run as a final pre-handover CI job, with results attached to the handover pack.
- *Check:* License-review report attached to the handover pack shows zero unresolved copyleft flags, or an explicit legal sign-off on any accepted exception.

**`HAND-015` — State the IP ownership split explicitly in the SOW and restate it in the handover pack** · `MUST`
Confirm in writing that the client owns the delivered application code and specs, while Cognirise retains ownership of pre-existing internal tooling, accelerators, and this standards pack, licensed to the client only as embedded in the delivery.
- *Why:* Prevents later disputes over reuse rights, especially where the studio's canonical patterns and boilerplate are reused across engagements.
- *How:* Standard IP clause referenced from the SOW template; restated as a short paragraph in the handover pack's cover document.
- *Check:* Handover pack cover document contains the IP ownership paragraph matching the SOW's clause.

**`HAND-016` — Review third-party model/API provider terms for output-ownership and training-use clauses before handover** · `MUST`
Confirm the terms of every third-party model/API provider used (e.g., output ownership, whether client data is used for provider-side training) and summarize them for the client.
- *Why:* Regulated clients specifically ask whether their data trains a third party's foundation model; the studio must have a documented answer, not an assumption.
- *How:* One-paragraph summary per provider used, added to the model card (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)).
- *Check:* Model card's provider-terms section is populated for every model/provider in the subprocessor register, not left as a placeholder.

**`HAND-017` — Disclose that AI-assisted code generation was used in building the deliverable** · `MUST`
State plainly in the handover pack that Replit Agent/Claude Code or equivalent AI coding tools were used during development, consistent with the spec-traceability record already in the repository.
- *Why:* Some regulated-sector clients have internal policies requiring disclosure of AI-assisted development; withholding this is a trust risk disproportionate to any perceived benefit of silence.
- *How:* One-line disclosure in the handover pack cover document, cross-referencing the PR template's "Generated by" field (see [19 — Repository & Stack Conventions](./19-repo-conventions.md)).
- *Check:* Handover pack cover document contains the AI-assisted-development disclosure line.

### Client data return and deletion

**`HAND-018` — Return or delete all client data held outside the client's own environment at engagement close, per the client's instruction** · `MUST`
Confirm with the client whether any data processed during the engagement (demo seed data derived from real records, uploaded test files, observability traces containing client data) should be returned, exported, or deleted, and execute accordingly.
- *Why:* Matches the retention and data-minimization obligations in [17 — Data Governance & Compliance](./17-data-governance-compliance.md); an engagement close is a natural retention-review trigger.
- *How:* Data-return/deletion checklist covering: Replit deployment databases, observability backend traces, any local developer copies, shared-drive exports.
- *Check:* Written confirmation from the client (email or signed close-out form) acknowledging the return/deletion action taken.

**`HAND-019` — Purge or anonymize observability traces containing client data before revoking the studio's access to the deployment** · `MUST`
Ensure Langfuse/LangSmith trace data containing client-identifiable content is deleted or anonymized before the studio's access to the client's environment ends, unless the client explicitly requests retention for its own use.
- *Why:* Prevents client data from persisting indefinitely in a third-party observability vendor's system outside the client's control.
- *How:* Use the observability backend's data-deletion API/console function; document the deletion date.
- *Check:* Deletion confirmation (screenshot, API response, or vendor receipt) attached to the close-out record.

### Post-handover support boundaries

**`HAND-020` — Define the post-handover support window and scope explicitly in the SOW before the engagement starts** · `MUST`
State the exact duration (e.g., 2-4 weeks) and scope (bug fixes only vs. bug fixes plus minor enhancements) of any post-handover warranty support before work begins, not after.
- *Why:* Undefined post-handover scope leads to unscoped, unpaid "just one more fix" work that erodes engagement profitability and blurs accountability.
- *How:* Standard SOW clause naming the window, scope, and response-time expectation.
- *Check:* SOW on file for the engagement contains this clause before the kickoff date.

**`HAND-021` — Route any request outside the defined support window or scope to a new engagement, not ad hoc unscoped work** · `MUST`
Treat any client request for a new feature, scope change, or support beyond the SOW's defined window as the start of a new engagement discussion, not as an extension of the existing one.
- *Why:* Protects the boundary defined in HAND-020 from erosion via informal client requests.
- *How:* Standard response template acknowledging the request and proposing a scoping call for a new SOW.
- *Check:* Any post-window client request has a corresponding scoping-call record or new SOW draft, not a silent code change.

## Reference implementation

```markdown
<!-- docs/handover/00-cover.md -->
# Handover Pack — <client> — <engagement name>

## IP ownership
The client owns all application code, specifications, and configuration delivered
under this engagement. Cognirise retains ownership of pre-existing internal tooling,
accelerators, and the Cognirise standards pack, licensed to the client only as
embedded in this delivery. See SOW §<n> for the full clause.

## AI-assisted development disclosure
This deliverable was built using AI-assisted development tools (Replit Agent,
Claude Code) under human specification, review, and sign-off at every gate defined
in [21 — QA & Definition of Done](../standards/21-qa-definition-of-done.md).
Every generated code change traces to a spec section per
[19 — Repo Conventions](../standards/19-repo-conventions.md) REPO-018.

## Contents
1. Repository access — see README.md
2. Specifications — docs/specs/
3. Eval reports — docs/evals/reports/
4. Model card & system card — docs/compliance/model-card.md
5. Risk register & known gaps — docs/compliance/risk-register.md
6. Subprocessor register — docs/compliance/subprocessors.md
7. Runbooks — docs/runbooks/
8. Cost model — docs/handover/cost-model.md
9. Portability checklist & target architecture — docs/runbooks/target-architecture.md
10. Roadmap to production — docs/handover/roadmap.md
11. Dependency license review — docs/handover/license-review.md
```

```markdown
<!-- docs/handover/roadmap.md template -->
| Item | Current state | Target state | Owner | Est. effort |
|---|---|---|---|---|
| Arabic OCR for scanned documents | Documented-deferred (English only at prototype) | Full bilingual OCR pipeline | Cognirise | 3 weeks |
| Production-region hosting | Prototype on Replit (US) | Azure UAE North deployment | Client + Cognirise (joint) | 2 weeks |
| DIFC Reg 10 System registration | Not started | Registered System with DIFC | Client (legal) | Client-led |
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Hardcoding a "live-looking" tool response for the demo | Misrepresents actual system capability to the client | Wire the real call or disclose the stub explicitly (HAND-007) |
| Compiling the handover pack from memory the week of close-out | Items get forgotten; no audit trail of when artifacts were produced | Assemble `docs/handover/` incrementally throughout the engagement (HAND-009) |
| Silently absorbing post-handover feature requests as "quick fixes" | Erodes the support-window boundary and engagement profitability | Route out-of-scope requests to a new SOW discussion (HAND-021) |
| Leaving real client data in observability traces after access is revoked | Data persists outside client control indefinitely | Purge/anonymize traces before access ends (HAND-019) |
| Demoing only the happy path | Looks staged; hides real system boundaries from a sophisticated buyer | Script at least one graceful-degradation beat (HAND-002) |
| Treating the SOW's IP clause as understood rather than restating it | Leads to later disputes over reuse rights | Restate the IP split explicitly in the handover pack cover document (HAND-015) |

## Definition of Done

- [ ] Demo script written with named beats, including at least one graceful-degradation beat (HAND-001/002).
- [ ] Demo run from the frozen `demo` deployment with `@demo-script` tests green (HAND-003).
- [ ] Demo data confirmed synthetic or client-approved anonymized, with realistic variance (HAND-004/005).
- [ ] Never-fake list reviewed against the final demo script (HAND-007).
- [ ] Written limitations summary sent to the client before or at the demo (HAND-008).
- [ ] Full handover pack assembled per the contents table, with no missing item (HAND-009).
- [ ] Roadmap to production has an owner and target state for every item (HAND-010).
- [ ] Cost model uses measured, not estimated, figures (HAND-011).
- [ ] Knowledge-transfer session held and recorded/summarized (HAND-012).
- [ ] Client engineer independently executed at least one runbook (HAND-013).
- [ ] Dependency license review attached with zero unresolved copyleft flags (HAND-014).
- [ ] IP ownership and AI-assisted-development disclosure stated in the handover pack cover document (HAND-015/017).
- [ ] Third-party model/provider terms summarized in the model card (HAND-016).
- [ ] Client data return/deletion executed and confirmed in writing (HAND-018/019).
- [ ] Post-handover support window and scope defined in the SOW before kickoff (HAND-020).

## Handoff notes

- Start the `docs/handover/` folder at engagement kickoff, not at close-out — most handover-pack failures are items nobody thought to capture until it was too late.
- Treat the never-fake list as a hard constraint when scripting demos under time pressure; a compressed timeline is not a reason to relax disclosure standards.
- Cross-check the roadmap-to-production document against the compliance-ready-prototype gap-disclosure entries in [17 — Data Governance & Compliance](./17-data-governance-compliance.md) so nothing is disclosed in one place and omitted in the other.
- Confirm the SOW's IP and support-window clauses exist before kickoff; retrofitting them after delivery is a much harder negotiation.

## Sources

- [17 — Data Governance & Compliance](./17-data-governance-compliance.md) — compliance-ready-prototype bar and gap-disclosure template referenced throughout.
- [19 — Repository & Stack Conventions](./19-repo-conventions.md) — spec-to-code traceability and PR "Generated by" field underlying the AI-assisted-development disclosure.
- [20 — Replit & Deployment](./20-replit-deployment.md) — demo-freeze mechanics and portability checklist included in the handover pack.
- [21 — QA & Definition of Done](./21-qa-definition-of-done.md) — eval and cost/latency reports included in the handover pack and cost model.
