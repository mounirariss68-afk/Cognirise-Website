---
id: delivery-lifecycle
domain: Discovery & Spec
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 01. Delivery Lifecycle

> **Purpose.** Define the single governed pipeline every Cognirise engagement must follow, so research, specification, code generation, implementation, and QA are traceable end to end and no stage can silently invent scope.
> **Read this when.** Starting a new client engagement, re-baselining a prototype, or auditing whether a build followed the canonical process.

## Scope
- In scope: the seven-stage lifecycle (Stage 0–6), stage entry/exit criteria, required artifacts and their exact repo paths, stage owners, and the artifact traceability chain.
- In scope: the canonical project repo layout and re-baselining rules.
- Out of scope: the internal structure of the research brief itself — see [02 — Research Brief](./02-research-brief.md) · BRIEF-001. Out of scope: the internal structure of each spec document — see [03 — Specification](./03-specification.md) · SPEC-001. Out of scope: eval design mechanics — see the evaluation standard (EVAL prefix, separate file).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Pipeline shape | Fixed 7-stage sequence, Stage 0 → Stage 6, no stage skipping | Repeatable, auditable delivery across many client engagements |
| Traceability unit | Requirement ID (`REQ-###`) threaded through every artifact | Enables need → journey → requirement → spec → code → eval tracing |
| Stage ownership | Named owner per stage (role, not person) | Removes ambiguity about who signs off a gate |
| Artifact location | Fixed paths under `docs/`, `specs/`, `evals/`, `app/` | Claude and Replit Agent can locate artifacts without being told each time |
| Requirement origination | Only Stage 0/1 (qualify + brief) may introduce new requirements | Prevents Claude/Replit from inventing scope downstream |
| Re-baseline trigger | Any change to Product Brief scope, personas, or success metrics | Keeps downstream specs and code from silently drifting off-brief |

## Rules

### Stage sequencing and gating

**`LIFE-001` — Follow the fixed seven-stage sequence** · `MUST`
Every engagement passes through Stage 0 Qualify, Stage 1 Research Brief, Stage 2 Specification & Design, Stage 3 Code Generation, Stage 4 Implementation & Hardening, Stage 5 QA & Eval Gates, Stage 6 Demo & Handover, in that order.
- *Why:* a fixed sequence is what makes the pipeline repeatable across clients and lets any consultant pick up mid-engagement.
- *How:* track current stage as a field in `docs/lifecycle-status.md`; do not open Stage N+1 artifacts before Stage N's exit gate is checked off.
- *Check:* reviewer confirms `docs/lifecycle-status.md` shows stages completed in order with no gaps.

**`LIFE-002` — Do not open a stage without its entry criteria met** · `MUST NOT`
A stage's required inputs (from the table in the Reference implementation) must exist and be reviewed before work in that stage begins.
- *Why:* starting Stage 2 without an accepted Stage 1 brief is the single largest source of downstream rework.
- *How:* each stage's kickoff checklist references the prior stage's exit-gate checklist by file path.
- *Check:* reviewer opens the stage's kickoff checklist and confirms every listed input file exists and is marked accepted.

**`LIFE-003` — Every stage produces artifacts at fixed repo paths** · `MUST`
Artifacts are written to the exact paths defined in the Reference implementation repo layout, never to ad hoc locations.
- *Why:* Claude and Replit Agent are handed this standard as context and must be able to locate prior-stage artifacts deterministically.
- *How:* scaffold the repo layout at Stage 0 kickoff from the studio's project template.
- *Check:* `find docs specs evals app -maxdepth 2` against the expected tree; CI fails the build if a required path is missing at the relevant stage gate.

**`LIFE-004` — Every stage has one named owner role** · `MUST`
Each stage lists a single accountable owner role (not "the team"); that role signs the exit gate.
- *Why:* diffuse ownership is why gates get skipped under deadline pressure.
- *How:* owner role recorded in `docs/lifecycle-status.md` per stage, matching the table in the Reference implementation.
- *Check:* exit-gate checklist has a named signer field, not blank, not "TBD".

### Requirement traceability

**`LIFE-005` — Assign a requirement ID to every need before it enters a spec** · `MUST`
Every business need, journey step, or non-functional constraint that will drive a spec section, code module, or eval case gets a `REQ-###` ID at the point it is first captured (Stage 0 or Stage 1).
- *How:* `REQ-###` is minted in `docs/requirements-register.md`, one row per requirement, numbered sequentially per engagement.
- *Why:* a requirement without an ID cannot be traced to a spec section, code module, or eval case, and becomes unverifiable scope.
- *Check:* every row in `specs/traceability-matrix.md` (see [03 — Specification](./03-specification.md) · SPEC-010) has a non-empty `REQ-###`.

**`LIFE-006` — Maintain the full traceability chain for every requirement** · `MUST`
Every `REQ-###` must be traceable through: need (Stage 0/1) → journey step (`docs/journeys/<job-type>.md`) → requirement (`docs/requirements-register.md`) → spec section (`specs/*.md`, anchored heading) → code module (file path) → eval case (`evals/*.jsonl` row ID).
- *Why:* this is the mechanism that lets a reviewer answer "why does this code exist" and "is this feature tested" without re-deriving context from chat history, per [Anthropic's Claude Code best practices](https://www.anthropic.com/engineering/claude-code-best-practices) on self-contained specs.
- *How:* `specs/traceability-matrix.md` is a table with columns `req_id, journey_ref, spec_section, code_module, eval_case, status`.
- *Check:* CI script parses the matrix and confirms no row has an empty `code_module` once Stage 4 exit is claimed, and no row has an empty `eval_case` once Stage 5 exit is claimed.

**`LIFE-007` — Claude and Replit Agent MUST NOT introduce requirements not traceable to the brief** · `MUST NOT`
Any capability, screen, field, or behavior generated by Claude in Stage 2/3 or by Replit Agent in Stage 4 that is not backed by a `REQ-###` row is out of scope and must be flagged, not silently built.
- *Why:* this is the single named failure mode of an agent-generated pipeline — generative tools default to "helpfully" filling gaps with invented scope, which breaks client traceability and budget control.
- *How:* the Stage 2/3/4 handoff prompt to Claude/Replit Agent must include the instruction "if you believe a capability is needed that has no `REQ-###`, stop and add it to `docs/open-questions.md` rather than building it" (see [02 — Research Brief](./02-research-brief.md) · BRIEF-011 for the open-questions register format).
- *Check:* reviewer diffs generated code/spec content against `specs/traceability-matrix.md`; any feature with no matching `req_id` is rejected at the Stage 5 adversarial review (`LIFE-018`).

**`LIFE-008` — New requirements discovered mid-build go through Stage 1, not directly into code** · `MUST`
If Stage 3/4 work surfaces a genuinely new need, it is logged in `docs/requirements-register.md` as a proposed addition and routed back through a Stage 1 mini-brief update before implementation, unless it is a pure bug fix against an existing `REQ-###`.
- *Why:* prevents scope from entering the codebase without ever passing through research/spec scrutiny.
- *How:* proposed additions get a `REQ-###-PROPOSED` tag until accepted; only accepted requirements get implemented.
- *Check:* grep the codebase's PR descriptions for `REQ-###`; any PR citing a `PROPOSED` ID is blocked from merge until promoted.

### Re-baselining

**`LIFE-009` — Re-baseline when scope, personas, or success metrics change** · `MUST`
If the Product Brief's stated business goal, target personas, or success metrics change after Stage 2 has started, the engagement must re-run Stage 1 (updated brief) and re-issue affected Stage 2 specs before Stage 3/4 work continues on the changed area.
- *Why:* continuing to build against a stale brief is the primary cause of client-facing demo mismatches.
- *How:* bump `specs/*.md` frontmatter `version` field and log the change in `docs/changelog.md` with the triggering `REQ-###`.
- *Check:* reviewer confirms no code module tied to a changed `REQ-###` was modified before its owning spec file's version was bumped.

**`LIFE-010` — A prototype must be re-baselined, not patched, after a Stage 0 assumption is invalidated** · `MUST`
If a Stage 0 qualification assumption (deterministic-vs-agentic call, primary persona, regulatory posture) proves wrong during Stage 4/5, treat this as a re-entry to Stage 0, not a Stage 4 patch.
- *Why:* patching architecture-level assumptions inside implementation produces unreviewable, undocumented drift; see the regulated-client caution that reviewers penalize undisclosed gaps far more than disclosed ones ([05-regulated.md](../../research/05-regulated.md) research file, "compliance-ready prototype" bar).
- *How:* open a new `docs/lifecycle-status.md` entry marked `re-baseline: <date>`, referencing the invalidated assumption's `REQ-###` or Stage 0 qualification note.
- *Check:* reviewer finds a `re-baseline` log entry for any Stage 0 assumption that changed after Stage 2 sign-off.

### Repo layout and artifact ownership

**`LIFE-011` — Scaffold the canonical repo layout at Stage 0** · `MUST`
Every engagement repo uses the fixed top-level layout in the Reference implementation; no engagement invents its own top-level structure.
- *Why:* Claude Code and Replit Agent perform better with a predictable, previously-seen layout, and cross-project engineer rotation depends on it.
- *How:* copy from the studio's project template at Stage 0 kickoff.
- *Check:* `docs/`, `specs/`, `evals/`, `app/`, `CLAUDE.md` all present before Stage 1 begins.

**`LIFE-012` — Each stage's artifacts are the exclusive source of truth for that stage's decisions** · `MUST`
Decisions made in Stage 2 specs are not re-litigated informally in Stage 3/4 chat; if Stage 4 disagrees with a spec decision, it must update the spec file, not just the code.
- *Why:* otherwise the spec becomes documentation theater instead of authoritative — see [03 — Specification](./03-specification.md) · SPEC-024 for the spec-authority-over-code rule this reinforces.
- *How:* any Stage 4 code change that contradicts a spec section requires a corresponding spec edit in the same PR.
- *Check:* PR review confirms spec and code diffs are co-located when a spec-level decision changes.

### Stage-specific standards linkage

**`LIFE-013` — Stage 1 outputs must satisfy the research brief standard before Stage 2 opens** · `MUST`
The Stage 1 exit gate is the acceptance criteria defined in [02 — Research Brief](./02-research-brief.md) · BRIEF-020, not a subjective "looks done" call.
- *Why:* keeps the gate mechanically checkable rather than a judgment call under deadline pressure.
- *How:* Stage 1 exit checklist is literally the BRIEF-020 checklist, copy-referenced.
- *Check:* `docs/research-brief.md` frontmatter has `status: accepted` and cites which BRIEF acceptance items passed.

**`LIFE-014` — Stage 2 outputs must satisfy the specification taxonomy before Stage 3 opens** · `MUST`
The Stage 2 exit gate requires all seven spec documents defined in [03 — Specification](./03-specification.md) · SPEC-001 to exist and be marked `status: accepted`.
- *Why:* Stage 3 code generation against an incomplete spec set reproduces the exact ambiguity this lifecycle exists to prevent.
- *How:* `specs/` directory listing checked against the SPEC-001 required document set.
- *Check:* CI script fails if any of Product Brief, Functional Spec, Technical Spec, Data Spec, Agent Spec, Eval Plan, Risk Register is missing or not `accepted`.

**`LIFE-015` — Stage 4 (Replit) work follows the Replit Agent workflow standard, not ad hoc prompting** · `MUST`
Implementation in Replit uses Plan mode against the Stage 3-generated code/spec before executing changes; see the Replit & deployment standard (DEP prefix) for mode selection and checkpoint discipline.
- *Why:* Replit Agent re-deciding architecture already settled upstream is a named failure mode.
- *How:* Stage 4 kickoff prompt to Replit Agent includes `specs/technical-spec.md` and `specs/agent-spec.md` verbatim as Plan-mode context.
- *Check:* Replit Agent's plan output is saved to `docs/replit-plan-<date>.md` and diffed against the technical spec before execution is approved.

### Stage 5/6 gating

**`LIFE-016` — Stage 5 cannot be waived under deadline pressure** · `MUST NOT`
No engagement proceeds to Stage 6 demo without a completed eval run, guardrail checklist, and accessibility checklist, regardless of client timeline pressure.
- *Why:* this is the gate most likely to be skipped and the one whose absence is most visible to a regulated client reviewer.
- *How:* Stage 6 kickoff script blocks on `evals/latest-run-report.md` existing with a `pass` status.
- *Check:* CI/build script literally refuses to generate the demo handover package (`LIFE-020`) if the eval report is missing or failing.

**`LIFE-017` — Every "done" claim at Stage 5 must be backed by a runnable artifact** · `MUST`
Test output, eval report, or screenshot — not a verbal assertion — is required to close any Stage 5 checklist item.
- *How:* Definition of Done checklist items link directly to the file/output that proves them.
- *Why:* verification-with-evidence is the generalized QA discipline recommended in [Anthropic's Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices).
- *Check:* reviewer opens each DoD checklist item's linked artifact and confirms it exists and supports the claim.

**`LIFE-018` — Run an adversarial fresh-context review before Stage 5 exit** · `MUST`
A reviewer (subagent or human) without prior involvement in the build checks the diff/build against `specs/traceability-matrix.md`, flagging only correctness/requirement gaps.
- *Why:* a fresh-context review catches drift that the implementing agent/consultant is blind to by construction.
- *How:* store the review output at `docs/adversarial-review-<date>.md`.
- *Check:* Stage 5 exit gate requires this file to exist and list zero unresolved gaps, or documented waivers with client sign-off for each.

**`LIFE-019` — Stage 6 demo scripts must show a deliberate failure/escalation beat, not only the happy path** · `MUST`
The Stage 6 demo script includes at least one beat demonstrating graceful ambiguity handling and one demonstrating escalation/failure handling.
- *Why:* demos that only show the happy path collapse under an obvious client-posed edge case.
- *How:* demo script template in `docs/demo-script.md` has fixed sections `happy_path`, `ambiguity_beat`, `escalation_beat`.
- *Check:* reviewer confirms all three sections are populated with a reference to the underlying journey artifact.

**`LIFE-020` — Handover package is generated only after Stage 5 exit, never assembled manually ad hoc** · `MUST`
The Stage 6 handover package is produced by a fixed checklist/script pulling from known paths (spec files, eval report, guardrail checklist, `CLAUDE.md`/`AGENTS.md`, deployment runbook), not hand-assembled per client.
- *Why:* manual assembly is where handover packages lose critical operational knowledge.
- *How:* `docs/handover-checklist.md` lists every required file path; a script verifies presence before zipping.
- *Check:* handover zip contents diffed against the checklist; missing items block delivery.

## Reference implementation

### Canonical project repo layout

```text
project-root/
├── CLAUDE.md                      # studio + project conventions for Claude Code
├── AGENTS.md                      # cross-tool equivalent for Replit Agent / other agents
├── docs/
│   ├── lifecycle-status.md        # current stage, owner, gate status per stage
│   ├── qualification.md           # Stage 0 output
│   ├── research-brief.md          # Stage 1 output — see BRIEF-001
│   ├── requirements-register.md   # REQ-### master list
│   ├── journeys/
│   │   └── <job-type>.md          # service blueprint + state machine + sequence diagrams (A.7/A.8)
│   ├── open-questions.md          # unresolved assumptions, proposed-but-unapproved requirements
│   ├── changelog.md                # spec version bumps, re-baseline log
│   ├── demo-script.md             # Stage 6 demo beats
│   ├── handover-checklist.md      # Stage 6 handover package manifest
│   ├── adversarial-review-<date>.md
│   └── replit-plan-<date>.md
├── specs/
│   ├── product-brief.md
│   ├── functional-spec.md
│   ├── technical-spec.md
│   ├── data-spec.md
│   ├── agent-spec.md
│   ├── eval-plan.md
│   ├── risk-register.md
│   └── traceability-matrix.md     # REQ → journey → spec → code → eval
├── evals/
│   ├── datasets/
│   │   └── <job-type>.jsonl
│   └── latest-run-report.md
├── app/                            # Next.js App Router application (canonical stack)
│   ├── (routes)/
│   ├── lib/
│   └── ...
└── .claude/
    └── skills/                     # studio-reusable SKILL.md files
```

### Lifecycle stage table

| Stage | Entry criteria | Required inputs | Produced artifacts | Owner | Exit gate |
|---|---|---|---|---|---|
| 0 — Qualify | Client intake call held | Client ask, sector, rough budget/timeline | `docs/qualification.md` (deterministic-vs-agentic call, sector/regulatory flags, prototype-vs-production statement) | Delivery lead | Qualification doc accepted; regulatory flags set if UAE/GCC gov/bank/telco (see [05-regulated.md](../../research/05-regulated.md)) |
| 1 — Research Brief (Perplexity) | Stage 0 accepted | `docs/qualification.md` | `docs/research-brief.md`, `docs/requirements-register.md` (seed), evidence tables with citations | Consultant | Meets [02 — Research Brief](./02-research-brief.md) · BRIEF-020 acceptance criteria |
| 2 — Specification & Design (Claude) | Stage 1 accepted | `docs/research-brief.md`, `docs/requirements-register.md` | All seven `specs/*.md` files, `docs/journeys/*.md`, `specs/traceability-matrix.md` (populated to spec-section level) | Consultant + Claude | All spec docs `status: accepted` per [03 — Specification](./03-specification.md) · SPEC-001 |
| 3 — Code Generation (Claude) | Stage 2 accepted | `specs/technical-spec.md`, `specs/agent-spec.md`, `specs/data-spec.md`, `CLAUDE.md` | `app/` source tree, `specs/traceability-matrix.md` (populated to code-module level) | Claude (Claude Code) | Code compiles/typechecks; every `REQ-###` in scope has a `code_module` entry |
| 4 — Implementation & Hardening (Replit) | Stage 3 code exists | `app/` tree, `specs/technical-spec.md`, `docs/replit-plan-<date>.md` | Deployed Replit app, `.replit` config, secrets inventory (values excluded) | Replit Agent + consultant | App deploys; Plan-mode task list matches technical spec with no unexplained deviation |
| 5 — QA & Eval Gates | Stage 4 deployed | `evals/datasets/*.jsonl`, guardrail/accessibility checklists | `evals/latest-run-report.md`, `docs/adversarial-review-<date>.md` | QA owner | Eval suite passes thresholds; adversarial review has zero unresolved gaps |
| 6 — Demo & Handover | Stage 5 passed | `docs/demo-script.md`, all Stage 0–5 artifacts | Handover zip per `docs/handover-checklist.md` | Delivery lead | Client sign-off recorded in `docs/changelog.md` |

### Lifecycle diagram

```mermaid
flowchart TD
    S0["Stage 0 — Qualify\nowner: Delivery lead"] -->|qualification.md accepted| S1["Stage 1 — Research Brief\n(Perplexity)\nowner: Consultant"]
    S1 -->|BRIEF-020 acceptance met| S2["Stage 2 — Specification & Design\n(Claude)\nowner: Consultant + Claude"]
    S2 -->|all 7 specs accepted| S3["Stage 3 — Code Generation\n(Claude)\nowner: Claude"]
    S3 -->|REQ-### traced to code_module| S4["Stage 4 — Implementation & Hardening\n(Replit)\nowner: Replit Agent + consultant"]
    S4 -->|deployed, plan matches spec| S5["Stage 5 — QA & Eval Gates\nowner: QA owner"]
    S5 -->|evals pass, adversarial review clean| S6["Stage 6 — Demo & Handover\nowner: Delivery lead"]

    S2 -.re-baseline on scope/persona/metric change.-> S1
    S4 -.invalidated Stage 0 assumption.-> S0
    S3 -.new capability with no REQ-###.-> OQ["docs/open-questions.md"]
    S4 -.new capability with no REQ-###.-> OQ
    OQ -.promoted after review.-> S1
```

### Traceability matrix row shape

```markdown
| req_id  | journey_ref                        | spec_section                              | code_module                     | eval_case          | status   |
|---------|-------------------------------------|--------------------------------------------|----------------------------------|---------------------|----------|
| REQ-014 | docs/journeys/invoice-reconcile.md#escalation | specs/functional-spec.md#FR-014 | app/lib/agents/reconcile.ts | evals/datasets/invoice.jsonl#row-14 | in-progress |
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Starting Stage 3 code generation while Stage 2 specs are still in draft | Code inherits ambiguity from unresolved spec sections, compounding rework | Enforce `LIFE-014`: block Stage 3 kickoff until all seven specs are `status: accepted` |
| Letting Replit Agent "helpfully" add a settings page not in the spec | Silent scope invention breaks client traceability and budget control | Enforce `LIFE-007`: any un-traced feature is flagged to `docs/open-questions.md`, not built |
| Patching a wrong architecture assumption directly in Stage 4 code | Produces undocumented drift invisible to the traceability matrix | Enforce `LIFE-010`: re-enter Stage 0, log a re-baseline event |
| Skipping the Stage 5 eval gate to hit a demo deadline | Ships an unverified "done" claim, the exact failure mode this lifecycle prevents | Enforce `LIFE-016`: handover package generation is scripted and blocked without a passing eval report |
| Assembling the handover zip by hand from memory | Omits operational knowledge (e.g., secrets handling) the client's team needs | Enforce `LIFE-020`: generate handover package only from the fixed checklist |
| One "mega markdown file" per stage instead of the fixed repo layout | Claude/Replit Agent can't reliably locate prior-stage context | Enforce `LIFE-003`/`LIFE-011`: scaffold and keep the fixed repo layout |

## Definition of Done

- [ ] `docs/lifecycle-status.md` exists and shows the current stage with a named owner.
- [ ] Every artifact required by the current stage's entry criteria exists at its canonical path.
- [ ] `specs/traceability-matrix.md` has no row with a missing `req_id`.
- [ ] No code module or spec section exists without a traceable `REQ-###`.
- [ ] Any scope change since the last accepted spec version is logged in `docs/changelog.md` with a re-baseline entry if applicable.
- [ ] Stage 5 exit requires `evals/latest-run-report.md` (pass) and `docs/adversarial-review-<date>.md` (zero unresolved gaps) before Stage 6 begins.
- [ ] Stage 6 handover package matches `docs/handover-checklist.md` exactly.

## Handoff notes

- When starting Stage 2 with Claude, paste `docs/research-brief.md` and `docs/requirements-register.md` verbatim; do not summarize them.
- When starting Stage 3, paste `specs/technical-spec.md`, `specs/agent-spec.md`, and `CLAUDE.md`; instruct Claude explicitly per `LIFE-007` to flag rather than invent any capability without a `REQ-###`.
- When starting Stage 4 in Replit, use Plan mode first and paste the same technical/agent specs before allowing any code execution, per `LIFE-015`.
- Always attach the current `specs/traceability-matrix.md` to any handoff so the receiving agent can self-check its output against existing `REQ-###` rows.
- Flag regulated-client engagements (UAE/GCC gov/bank/telco) at Stage 0 so Stage 1 research includes the regulatory angle from the outset — see [05-regulated.md](../../research/05-regulated.md).

## Sources

- [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) — self-contained specs, verification-with-evidence, fresh-context review.
- [Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents) — structured note-taking and context handoff patterns underlying artifact-based traceability.
- [Awesome Testing — Mermaid diagrams: When AI Meets Documentation](https://www.awesome-testing.com/2025/09/mermaid-diagrams) — Mermaid as promptable, diffable diagrams-as-code.
- research file [03-journeys-and-agents.md](../../research/03-journeys-and-agents.md), sections A.7/A.8 — journey artifacts and executable-style specs feeding the traceability chain.
- research file [05-regulated.md](../../research/05-regulated.md) — compliance-ready prototype bar and re-baseline triggers for regulated clients.
