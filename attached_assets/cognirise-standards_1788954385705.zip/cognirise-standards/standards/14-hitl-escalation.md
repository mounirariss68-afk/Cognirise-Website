---
id: hitl-escalation
domain: Safety, Security & Governance
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 14. Human-in-the-Loop & Escalation

> **Purpose.** Guarantee that consequential or irreversible agent actions pause for human judgment, and that the pause/resume mechanism is durable, auditable, and never silently bypassed.
> **Read this when.** Journey design (escalation triggers, checkpoint UX), technical spec (interrupt/resume implementation, SLA sweep), pre-demo QA.

## Scope
- In scope: action classification by reversibility/impact, approval gate patterns, interrupt/resume with durable state, timeout/default-deny behavior, escalation routing and SLAs, oversight for regulated consequential decisions, accountability/decision-log records, batch approval rules, tool-scoped autonomy earned by evidence.
- Out of scope: which tools carry which risk tier and how that tier is enforced at the code level → see [13 — Security & Authorization](./13-security-authz.md) · SEC-004/SEC-006. Content-level guardrails (moderation, refusal templates) → see [12 — Guardrails & Safety](./12-guardrails-safety.md). Trust-calibration UX copy and journey mapping → user journeys standard (JRN, forthcoming).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Escalation trigger source | System-defined thresholds (confidence, dollar amount, data sensitivity, novelty, regulatory flag) — never the agent self-assessing its own confusion | "The agent does not decide whether it is confused. The system defines when human review is required" ([Applied AI's analysis of human-in-the-loop as architecture](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/)) |
| Gate scope | Scoped to the specific tool invocation, not the whole agent turn | Orchestration can proceed autonomously for low-risk actions around a paused high-risk one ([Microsoft's Azure Architecture Center guidance on AI agent orchestration patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)) |
| State durability | Every pending approval and its full context snapshot persisted in Postgres, never in-process memory | In-memory checkpointers lose all state on Autoscale scale-to-zero or redeploy ([03-journeys-and-agents.md, B.7/B.8](../../research/03-journeys-and-agents.md)) |
| Timeout behavior | Explicit SLA deadline with a pre-configured safe default (auto-reject high-risk / auto-approve-with-flag for low-risk-but-stale) — never an indefinite pending state | SLA enforcement via a scheduled sweep is the documented pattern ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)) |
| Autonomy allocation | Per-tool, not per-session or global | "Human intervention... tied to two triggers — failure-threshold breaches and high-risk actions — rather than a blanket setting" ([OpenAI's practical guide to building agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)) |
| Target human-review share | 10–15% of actions/queries routed to a human in a well-tuned system | Measured across 240 production deployments ([Applied AI's analysis](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/)) |

## Rules

### Classification by reversibility and impact

**`HITL-001` — Classify every agent action by reversibility and impact before it is wired to any autonomy tier** · `MUST`
Every action a tool can take must be tagged with a reversibility class (`reversible | reversible-with-cost | irreversible`) and an impact class (`low | medium | high`, considering financial, data-sensitivity, and reputational dimensions) in the permission matrix (see [13 — Security & Authorization](./13-security-authz.md) · SEC-004).
- *Why:* Reversibility and impact are the two axes OpenAI names for tool-safeguard risk rating, and Azure's guidance on scoping HITL gates to specific tool invocations depends on this classification existing first ([01-standards-areas.md, D1](../../research/01-standards-areas.md); [Microsoft's Azure Architecture Center guidance](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- *How:* Extend `tool_policies` with `reversibility` and `impact` columns alongside `risk_tier`; `risk_tier` is derived from the combination, not set independently.
- *Check:* Spec review confirms every tool row has both fields populated and `risk_tier` is a documented function of the two.

**`HITL-002` — Set escalation triggers as deterministic thresholds, never as agent self-assessment** · `MUST`
Escalation must fire on threshold-based (confidence below a cutoff), domain-based (dollar amount, data sensitivity), pattern-based (novel/unusual input), or regulatory (anything requiring an audit trail) triggers defined in code — never on the model reporting "I am unsure."
- *Why:* Self-assessed uncertainty is an unreliable and unauditable escalation trigger; deterministic triggers are consistent and reviewable ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)).
- *How:* `escalationTriggers.ts` evaluates confidence score, amount, sensitivity tag, and novelty score against configured thresholds after each plan step, independent of any model-emitted "confidence" field the model itself asserts.
- *Check:* Test injects a low-confidence but model-claimed-high-confidence response and asserts the deterministic trigger still fires escalation.

### Approval gate patterns

**`HITL-003` — Implement the three named approval patterns — Approve, Guidance (edit-and-approve), Reject-with-reason — as distinct UI and state-machine paths** · `MUST`
Every checkpoint must support: **Approve** (execute as proposed), **Edit-and-approve** (human modifies parameters, then executes the modified action), and **Reject-with-reason** (action does not execute; reason is captured and returned to the agent as context).
- *Why:* These map to the documented **Approval**, **Guidance**, and **Validation** HITL patterns, each with measured effectiveness in production (e.g., one Approval-pattern deployment blocked 100% of dangerous operations while allowing 100% of legitimate ones) ([03-journeys-and-agents.md, B.7](../../research/03-journeys-and-agents.md)).
- *How:* `pending_approvals.status` enum extended to `pending | approved | edited_approved | rejected | expired`; edited payload stored in a `resolution_payload` JSONB column distinct from the original `tool_call_json`.
- *Check:* UI test exercises all three resolution paths against a single pending approval and confirms the correct downstream execution (or non-execution) for each.

**`HITL-004` — Require a reason on every rejection, and feed it back to the agent as context, not as a silent dead-end** · `MUST`
A rejected approval must capture a human-readable `resolution_note`, which the resuming agent run receives as input for its next step.
- *Why:* "On escalation, hand the human rich context... so they don't start from scratch" applies symmetrically on resume: the agent must receive rich context back ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)).
- *How:* `resolution_note` is a required (non-null) field on rejection in the approval-resolution API route's Zod schema.
- *Check:* Attempting to reject without a note fails Zod validation in an integration test.

### Interrupt and resume implementation with durable state

**`HITL-005` — Persist the full trajectory snapshot to durable storage at the moment of pausing, before returning control** · `MUST`
When a high-risk tool call triggers a checkpoint, the system must write the tool-call payload, current plan state, and conversation/context snapshot to Postgres before the process returns or exits — never rely on holding this in process memory while awaiting a human response.
- *Why:* In-memory checkpointers (`MemorySaver`/`InMemorySaver`) "store checkpoints in RAM... When the process restarts, all checkpoints are lost," which happens routinely on Autoscale scale-to-zero ([03-journeys-and-agents.md, B.7/B.8](../../research/03-journeys-and-agents.md)).
- *How:* `pending_approvals` row includes `tool_call_json`, `risk_tier`, `handoff_context` (JSONB snapshot of plan_steps + session state), `sla_deadline`; if using LangGraph, use `PostgresSaver`/`AsyncPostgresSaver`, never `MemorySaver`, in any environment that isn't a single long-lived process.
- *Check:* Integration test triggers a checkpoint, kills and restarts the process, then resumes from the approval row and asserts the trajectory context is fully intact.

**`HITL-006` — Resume execution from the persisted snapshot, not by replaying the agent's prior reasoning** · `MUST`
On approval, the paused run must resume from exactly the persisted state (the specific tool call, with any edits applied) rather than re-invoking the full agent loop from the beginning.
- *Why:* "Mandatory gates make the orchestration synchronous at that step, so persist state at these checkpoints to resume operation without a replay of prior agent work" ([Microsoft's Azure Architecture Center guidance](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- *How:* A webhook-triggered resume endpoint or background worker reads `pending_approvals.resolution_payload`/`tool_call_json` and executes the tool call directly, then re-enters the agent loop at the next plan step — using LangGraph's `interrupt()`/`Command` resume mechanism if LangGraph is in use.
- *Check:* Trace inspection confirms no duplicate LLM calls for already-completed plan steps after a resume.

**`HITL-007` — Keep `thread_id`/session identifiers stable and bounded in length across pause and resume** · `MUST`
The identifier used to key checkpoint/approval state must remain the same UUID across the pause-resume cycle and respect any backing-store length limits.
- *Why:* `PostgresSaver`-style checkpointers require `thread_id` under 255 characters; identity drift across pause/resume breaks state lookup ([03-journeys-and-agents.md, B.8](../../research/03-journeys-and-agents.md)).
- *How:* Generate the `thread_id`/`job_id` UUID once at job creation; every checkpoint and approval row references the same value.
- *Check:* Schema constraint enforces UUID type/length; test confirms resume lookup succeeds using the original identifier.

### Timeout and default-deny behaviour

**`HITL-008` — Assign every pending approval an explicit SLA deadline at creation time** · `MUST`
No `pending_approvals` row may be created without a computed `sla_deadline`, derived from the action's risk tier and the escalation-routing SLA table (HITL-011).
- *Why:* Defines the enforcement boundary for HITL-009's default-deny sweep; matches the studio's SLA-driven checkpoint design ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)).
- *How:* `sla_deadline = created_at + slaTable[risk_tier]`, computed in the same insert transaction that creates the approval row.
- *Check:* Schema-level `NOT NULL` constraint on `sla_deadline`; insert without it fails.

**`HITL-009` — Apply a pre-configured safe default when an approval passes its SLA deadline unresolved, never leave it indefinitely pending** · `MUST`
A scheduled sweep must apply auto-reject for high-risk actions and auto-approve-with-flag for low-risk-but-stale actions when `sla_deadline` passes with no human resolution, and must notify the relevant channel.
- *Why:* This is the direct, buildable SLA-enforcement mechanism documented for Replit: "sweeps this table for rows past `sla_deadline` and applies the pre-configured safe default... then notifies" ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)).
- *How:* Replit Scheduled Deployment cron (e.g., every 5 minutes) running a sweep script; default-deny is the fallback for any risk tier not explicitly configured otherwise.
- *Check:* Test advances a fixture's `sla_deadline` into the past, runs the sweep, and asserts the correct default (reject for high-risk, approve-with-flag for low-risk) was applied and logged.

**`HITL-010` — Default to deny/reject when the safe-default policy for a risk tier is unconfigured or ambiguous** · `MUST`
If a tool's risk tier has no explicit timeout-default policy defined, the sweep must reject/deny rather than approve.
- *Why:* Fail-safe design: an unconfigured high-impact action must never silently execute by default.
- *How:* `slaDefaultPolicy[risk_tier] ?? "reject"` — the fallback value in the sweep's policy lookup is `"reject"`, not `"approve"`.
- *Check:* Test removes a risk tier's policy entry and asserts the sweep denies rather than throwing or approving.

### Escalation routing and SLAs

**`HITL-011` — Maintain an explicit escalation-routing table (risk tier → SLA deadline → notification channel → fallback reviewer)** · `MUST`
Every project must define, in the technical spec, the SLA per risk tier and the notification/escalation path (e.g., email, Slack webhook, on-call queue) if the primary reviewer doesn't respond.
- *Why:* Graceful degradation of the human queue itself — priority tiers, timeout-with-safe-default policies, backlog visibility — is a named design requirement, not an operational afterthought ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)).
- *How:* `docs/escalation-routing.md` per project: table of `risk_tier | sla | primary_channel | fallback_channel | fallback_after`.
- *Check:* Spec review confirms the table exists and every `tool_policies.risk_tier` value in use has a corresponding row.

**`HITL-012` — Monitor and periodically retune escalation criteria against observed accuracy, treating escalation policy as a tunable system** · `SHOULD`
Log every checkpoint decision (approved/rejected/expired) and review escalation-trigger accuracy on a recurring cadence, adjusting thresholds based on observed outcomes.
- *Why:* Monthly refinement of escalation criteria measurably shrank one production system's human-review share from 10–15% down to 8–10% over time — escalation policy is a monitored system, not a one-time prompt instruction ([03-journeys-and-agents.md, A.6](../../research/03-journeys-and-agents.md)).
- *How:* A recurring review of `pending_approvals` outcome distribution against `escalationTriggers.ts` thresholds; threshold changes go through the same versioning discipline as prompts (see the versioning standard, forthcoming).
- *Check:* Project retrospective/runbook references at least one documented threshold adjustment with its rationale, once past initial pilot volume.

### Oversight for consequential decisions in regulated contexts

**`HITL-013` — Require a human-in-the-loop approval gate for every financial, legal, or citizen-impacting irreversible action, with no exceptions at prototype stage** · `MUST`
Any action affecting money movement, legal standing, or a citizen's access to a government service must route through an approval gate (HITL-003) regardless of the agent's confidence or the demo timeline.
- *Why:* This is one of the ten non-negotiable, "survive a review" items for a compliance-ready prototype in UAE/GCC regulated engagements ([05-regulated.md, §4](../../research/05-regulated.md)).
- *How:* `tool_policies` seed data for any such action defaults `min_autonomy_tier` to the approval-required tier; overriding requires an explicit, logged decision (HITL-018).
- *Check:* Threat/permission review confirms no financial/legal/citizen-impacting tool has `min_autonomy_tier` set to autopilot without a documented override.

**`HITL-014` — Name a single accountable business owner per agent workflow, never a diffuse committee** · `MUST`
Every agent workflow must have one named accountable owner recorded in the project documentation, consistent with DFSA/CBUAE supervisory expectations.
- *Why:* DFSA expects AI used in regulated activity to "have a named accountable senior-management owner (not a diffuse committee)" ([05-regulated.md, §1.6](../../research/05-regulated.md)); this is also a non-negotiable prototype-stage item ([05-regulated.md, §4](../../research/05-regulated.md)).
- *How:* `owner` field in the workflow's model/system card (see [15 — Evaluation](./15-evaluation.md) eval-report artifact and the data governance standard's model card template).
- *Check:* Handover package review confirms every agent workflow's system card names exactly one individual owner.

**`HITL-015` — Persist a structured decision record for every consequential decision, including inputs, model/version, retrieved context, confidence signal, and rationale** · `MUST`
Consequential decisions (credit, benefits eligibility, hiring, access) must produce a queryable decision record distinct from the raw conversation log.
- *Why:* Required in substance by DIFC Regulation 10 notice/register provisions and the Dubai AI Ethics "Transparency" pillar ([05-regulated.md, §3](../../research/05-regulated.md)).
- *How:* `decision_records` table: `decision_id, job_id, inputs_snapshot, model_id, model_version, retrieved_context_refs, confidence, rationale_text, decided_by (agent|human), created_at`.
- *Check:* Integration test for a consequential-decision job path asserts a `decision_records` row is created with all required fields populated.

### Accountability records and decision logs

**`HITL-016` — Link every approval resolution back to the audit log entry it authorized** · `MUST`
The `pending_approvals` resolution and the corresponding [13 — Security & Authorization](./13-security-authz.md) · SEC-020 audit-log row for the resulting tool execution must share a common reference key.
- *Why:* Without this link, an auditor cannot trace "who approved this" to "what actually happened" — breaking the accountability chain the audit-log requirement exists to create.
- *How:* `audit_log.approval_id` foreign key referencing `pending_approvals.id`, populated whenever a tool execution followed an approval gate.
- *Check:* Test executes an approved high-risk action and asserts the resulting audit-log row's `approval_id` matches the approval record.

**`HITL-017` — Retain decision records and approval history for the period required by the governance standard, not shorter** · `MUST`
Do not prune or delete `pending_approvals`/`decision_records` rows on a schedule shorter than the retention period defined by the data governance standard.
- *Why:* Cross-references the retention requirement so HITL data isn't accidentally pruned by a generic "delete old rows" job tuned only for cost, not compliance.
- *How:* Checkpoint/approval pruning jobs (see [03-journeys-and-agents.md, B.8](../../research/03-journeys-and-agents.md)) exclude `decision_records` and resolved `pending_approvals` from any retention window shorter than the governance standard's minimum (see the data governance standard, GOV, forthcoming).
- *Check:* Pruning job configuration reviewed against the governance standard's retention table before it is scheduled.

### Batch approval rules

**`HITL-018` — Permit batch approval only for actions of identical risk tier and identical tool, with each item individually visible before confirmation** · `MUST`
A human reviewer may approve multiple pending items in one action only if they share the same tool and risk tier, and the UI lists each item's key parameters individually — never a single opaque "approve all" for mixed-risk batches.
- *Why:* Prevents a low-risk batch UI pattern from being reused to rubber-stamp a mixed batch containing a high-risk outlier.
- *How:* Batch-approval endpoint validates all submitted `pending_approvals.id`s share `tool_name` and `risk_tier` before processing; UI renders a checklist, not a single button, for batches above a configured size.
- *Check:* Test submits a batch containing one high-risk and one low-risk item and asserts the endpoint rejects the mixed batch.

**`HITL-019` — Log a single batch-approval record referencing every individual item it resolved** · `MUST`
Batch approvals must not collapse into a single audit entry that obscures which individual items were included.
- *Why:* Preserves per-item accountability (HITL-016) even when the human action was a single batch click.
- *How:* `batch_approvals` table (`batch_id, resolved_by, resolved_at`) with a join table linking `batch_id` to each `pending_approvals.id` it covered.
- *Check:* Test resolves a 5-item batch and asserts 5 individually queryable links back to the batch record.

### Autonomy granted per tool, earned by evidence

**`HITL-020` — Default every new tool to the lowest autonomy tier (assist/approval-required) at first deployment** · `MUST`
A newly introduced tool must start with `min_autonomy_tier` requiring human approval, regardless of how similar it seems to an already-promoted tool.
- *Why:* "Autonomy is granted per tool and earned by evidence" — no tool inherits trust from another tool's track record.
- *How:* `tool_policies` insert defaults `min_autonomy_tier` to the approval-required constant unless an explicit, reviewed promotion record exists.
- *Check:* CI test on `tool_policies` seed data flags any newly added row that skips the default tier without a linked promotion record (HITL-021).

**`HITL-021` — Promote a tool to a higher autonomy tier only via a logged decision citing observed accept-rate or eval evidence** · `MUST`
Raising `min_autonomy_tier` for a tool requires a recorded justification referencing either a rolling human accept-rate threshold from `agent_actions`/`pending_approvals` history or a passing eval report (see [15 — Evaluation](./15-evaluation.md)).
- *Why:* Ties autonomy promotion to the trust-building/steady-state model rather than to convenience or deadline pressure ([03-journeys-and-agents.md, A.4/A.5](../../research/03-journeys-and-agents.md)).
- *How:* `tool_policy_promotions` table: `tool_name, previous_tier, new_tier, justification, evidence_ref, approved_by, promoted_at`.
- *Check:* Any diff raising `min_autonomy_tier` in a PR must reference a `tool_policy_promotions` row; PR template includes this as a required field.

**`HITL-022` — Re-demote a tool's autonomy tier automatically if its rejection/override rate crosses a regression threshold** · `SHOULD`
If the observed rejection or human-override rate for a promoted tool exceeds a configured threshold over a rolling window, automatically revert it to the previous, more conservative tier and alert the accountable owner.
- *Why:* Evidence-based autonomy must degrade as readily as it is earned; this closes the loop so a regression doesn't sit undetected.
- *How:* Scheduled job computes rolling override rate per tool from `agent_actions`; on threshold breach, updates `tool_policies.min_autonomy_tier` and notifies via the escalation-routing table (HITL-011).
- *Check:* Test seeds a synthetic high-override-rate history for a tool and asserts the scheduled job demotes it and logs the demotion.

## Reference implementation

Approval and decision-record schema (Drizzle/Postgres):
```typescript
export const pendingApprovals = pgTable("pending_approvals", {
  id: uuid("id").primaryKey().defaultRandom(),
  jobId: uuid("job_id").notNull(),
  toolCallJson: jsonb("tool_call_json").notNull(),
  riskTier: text("risk_tier", { enum: ["low", "medium", "high"] }).notNull(),
  handoffContext: jsonb("handoff_context").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  slaDeadline: timestamp("sla_deadline").notNull(),
  status: text("status", {
    enum: ["pending", "approved", "edited_approved", "rejected", "expired"],
  }).notNull().default("pending"),
  resolutionPayload: jsonb("resolution_payload"),
  resolutionNote: text("resolution_note"),
  resolvedBy: text("resolved_by"),
});

export const decisionRecords = pgTable("decision_records", {
  decisionId: uuid("decision_id").primaryKey().defaultRandom(),
  jobId: uuid("job_id").notNull(),
  inputsSnapshot: jsonb("inputs_snapshot").notNull(),
  modelId: text("model_id").notNull(),
  modelVersion: text("model_version").notNull(),
  retrievedContextRefs: jsonb("retrieved_context_refs"),
  confidence: doublePrecision("confidence"),
  rationaleText: text("rationale_text").notNull(),
  decidedBy: text("decided_by", { enum: ["agent", "human"] }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
```

SLA sweep (Replit Scheduled Deployment, pseudocode):
```typescript
async function slaSweep() {
  const overdue = await db.select().from(pendingApprovals)
    .where(and(eq(pendingApprovals.status, "pending"), lt(pendingApprovals.slaDeadline, new Date())));
  for (const item of overdue) {
    const defaultAction = SLA_DEFAULT_POLICY[item.riskTier] ?? "reject"; // HITL-010
    await resolveApproval(item.id, defaultAction, "SLA_TIMEOUT_DEFAULT");
    await notify(ESCALATION_ROUTING[item.riskTier].fallbackChannel, item);
  }
}
```

State machine (Mermaid) for a checkpoint lifecycle:
```mermaid
stateDiagram-v2
  [*] --> planning
  planning --> executing
  executing --> awaiting_approval: risk_tier requires gate
  awaiting_approval --> executing: approved / edited_approved
  awaiting_approval --> failed: rejected
  awaiting_approval --> failed: expired (default-deny)
  awaiting_approval --> executing: expired (default-approve-with-flag, low risk)
  executing --> done
  executing --> failed
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Asking the model "are you confident enough to proceed?" | Self-assessed confusion is unauditable and unreliable | System-defined deterministic triggers (HITL-002) |
| Gating the whole agent turn instead of the specific tool call | Blocks low-risk work that should proceed autonomously | Scope gates to tool invocations (core decision, HITL-001) |
| Holding pending-approval state only in process memory | Lost on Autoscale scale-to-zero or redeploy | Durable Postgres persistence at pause time (HITL-005) |
| Leaving a stale approval pending indefinitely | Blocks the job forever, no operational SLA | SLA deadline + safe-default sweep (HITL-008, HITL-009) |
| "Approve all" button for a mixed batch of risk tiers | Rubber-stamps a high-risk outlier alongside routine items | Same-tool, same-tier batches only, itemized (HITL-018) |
| Promoting a tool's autonomy because "it's basically the same as tool X" | Autonomy earned by evidence, not by analogy | Logged promotion citing accept-rate/eval evidence (HITL-021) |

## Definition of Done

- [ ] Every tool tagged with reversibility and impact class feeding a documented `risk_tier` (HITL-001).
- [ ] Escalation triggers are deterministic and code-enforced, not model self-assessed (HITL-002).
- [ ] All three approval patterns (approve, edit-and-approve, reject-with-reason) implemented and tested (HITL-003, HITL-004).
- [ ] Pause/resume backed by durable Postgres state; survives a process restart in test (HITL-005, HITL-006, HITL-007).
- [ ] Every pending approval has an SLA deadline and a configured (or default-deny) timeout policy (HITL-008, HITL-009, HITL-010).
- [ ] Escalation-routing table present in the spec and covers every risk tier in use (HITL-011).
- [ ] Financial/legal/citizen-impacting actions gated with no autopilot override absent a logged decision (HITL-013).
- [ ] Named accountable owner recorded per agent workflow (HITL-014).
- [ ] Decision records captured for consequential decisions (HITL-015).
- [ ] Audit log entries linked to their authorizing approval (HITL-016).
- [ ] New tools default to approval-required; promotions logged with evidence (HITL-020, HITL-021).

## Handoff notes

- Attach the escalation-routing table and `tool_policies` seed data when handing this spec to Claude or Replit Agent — autonomy tiers must be seeded correctly from day one, not left to default framework behavior.
- Specify explicitly whether the target framework is LangGraph (use `interrupt()`/`PostgresSaver`) or a hand-rolled loop (use the `pending_approvals` pattern) so Claude generates the matching persistence code.
- Call out every financial/legal/citizen-impacting tool by name so Replit Agent does not default it to a higher autonomy tier during implementation.
- Include the decision-record schema in the spec for any workflow touching credit, benefits, hiring, or access decisions.

## Sources

- [Applied AI — Human-in-the-Loop as Architecture](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/) — deterministic triggers, HITL pattern effectiveness, escalation-accuracy benchmarks.
- [Microsoft Azure Architecture Center — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns) — tool-scoped gates, synchronous checkpoint persistence.
- [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) — failure-threshold and high-risk-action escalation triggers.
- `/home/user/workspace/research/03-journeys-and-agents.md`, §A.4–A.6, §B.7, §B.8 — trust-building arcs, autonomy sliders, checkpoint/interrupt implementation, durable state.
- `/home/user/workspace/research/05-regulated.md`, §1.6, §3, §4 — DFSA accountable-owner expectations, decision-record requirements, compliance-ready prototype bar.
- `/home/user/workspace/research/01-standards-areas.md`, D1, D3 — escalation trigger table, HITL design standard.
