---
id: rag
domain: Retrieval
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 10. Retrieval-Augmented Generation (RAG)

> **Purpose.** Lock in one retrieval architecture — ingestion through generation — so every RAG build is implementable without redesign, auditable for a bank/government reviewer, and evaluable against a fixed bar.
> **Read this when.** Designing or implementing any agent capability that answers from a document corpus, knowledge base, or bilingual (Arabic/English) content store.

## Scope

- In scope: retrieval decision criteria, ingestion pipeline, chunking, embeddings, pgvector storage/indexing, query-stage transformation and reranking, grounded generation, evaluation, security/governance for retrieval, and the pgvector-to-managed-service scale path.
- Out of scope: durable agent state and long-lived conversational memory — see [09 — Memory](./09-memory.md) · `MEM-001`. Tool-calling contracts for retrieval-as-a-tool — see [08 — Tool Contracts](./08-tool-contracts.md) · `TOOL-001`. General prompt/context engineering beyond retrieval assembly — see [11 — Prompt & Context Engineering](./11-prompt-context-engineering.md) · `CTX-001`. PDPL/Regulation 10/residency policy detail beyond retrieval-layer controls — see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) · `GOV-001`.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Vector store | Postgres + `pgvector`, `halfvec(1536)`, HNSW | One database, native RLS, proven to tens of millions of chunks ([pgvector GitHub](https://github.com/pgvector/pgvector)) |
| Chunking | Recursive/structure-aware, 400–800 tokens, 10–15% overlap, contextual header prepended | Highest-ROI lever; cuts retrieval failure 49% before reranking ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)) |
| Embedding model | OpenAI `text-embedding-3-large` (or Voyage-3 / Cohere Embed v4 for domain-specific) | Hosted, MRL-truncatable, no self-hosting burden at prototype scale |
| Hybrid search | pgvector HNSW + Postgres full-text, fused with RRF (`k=60`) | Lexical + semantic consistently beats either alone ([Tiger Data hybrid search guide](https://www.tigerdata.com/docs/build/examples/hybrid-search)) |
| Reranker | Cohere Rerank (default), BGE-reranker-v2-m3 self-hosted when residency-constrained | Two-stage retrieve-then-rerank is universal best practice ([reranker comparison](https://ianas.fr/en/blog/2026/06/07/reranker-comparatif-cohere-bge-jina-voyage/)) |
| Multi-tenancy | Postgres Row-Level Security, not app-layer filters | RLS survives a missed `WHERE` clause; app filters do not ([Pradeep Bhandari, pgvector RLS](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide)) |
| Scale trigger | Migrate vector workload off pgvector past ~10–20M chunks or when p50 query latency exceeds 300ms under load | See §10 decision matrix |
| Arabic/multilingual | Validate embedding + reranker on an in-language eval set; do not trust MTEB alone | MTEB multilingual score does not guarantee Arabic quality ([RAG source, §3.3](../../research/04-rag.md)) |

## Rules

### Retrieval decision standard

**`RAG-001` — Require RAG for any corpus-backed answer** · `MUST`
Any agent capability that answers questions from a document corpus, knowledge base, policy set, or content store larger than what fits reliably in a single context window MUST use RAG, not full-corpus context stuffing.
- *Why:* Full-corpus stuffing is linear-cost per call, non-auditable (no relevance ranking, no citation provenance), and degrades on needle-in-haystack tasks as length grows ([RAG source, §7.5](../../research/04-rag.md)).
- *How:* Route the capability through the retrieval pipeline defined in this file; do not pass raw document sets into the system prompt.
- *Check:* Reviewer confirms no code path concatenates a full document set into a single LLM call for corpora exceeding roughly 20 pages.

**`RAG-002` — Use long-context to widen post-retrieval budget, not to skip retrieval** · `MUST NOT`
Do not treat a long-context model as a substitute for retrieval; use the larger window to admit more reranked candidates into the generation call.
- *Why:* Long context reduces chunking-boundary penalty and lets more reranked context through, but it does not restore relevance ranking or reduce per-call token cost ([RAG source, §7.5](../../research/04-rag.md)).
- *How:* Keep the retrieve → rerank → assemble pipeline; only change the token budget in §5.5 assembly.
- *Check:* Spec names a fixed top-k and token budget even when the target model has a 1M-token window.

**`RAG-003` — Prefer direct tool calls over RAG for structured, queryable data** · `SHOULD`
When the answer lives in a structured system (a database table, an API, a ticketing system) rather than unstructured prose, expose it as a tool call, not as an ingested-and-chunked document.
- *Why:* Chunking a CSV export of a live table produces stale, ungrounded answers versus a direct query against the source of truth.
- *How:* Define a `TOOL`-contract function (see [08 — Tool Contracts](./08-tool-contracts.md)) that queries the system directly; reserve RAG for prose/document corpora.
- *Check:* Design review rejects any RAG ingestion source that is itself a live relational table with a stable schema and existing API.

**`RAG-004` — Justify agentic retrieval loops only for multi-hop or ambiguous queries** · `SHOULD`
Default to single-shot retrieve → rerank → generate; permit an iterative retrieve → assess → reformulate → retrieve loop only when a query router or classifier flags the query as multi-hop, comparative, or under-specified.
- *Why:* Agentic loops add latency and cost per iteration; most queries resolve correctly in one retrieval pass ([RAG source, §5.3](../../research/04-rag.md)).
- *How:* Implement the loop as plan → retrieve → synthesize → identify gaps → retrieve again → terminate, with a hard cap on iteration count, total tokens, and wall-clock time ([RAG source, §7.3](../../research/04-rag.md)).
- *Check:* Every agentic retrieval loop in code has an enforced max-iteration constant and a budget check before each additional retrieval call.

### Pipeline architecture

**`RAG-005` — Structure the pipeline as five independently deployable stages** · `MUST`
Implement ingestion, chunking, embedding, indexing, and query/generation as separable modules communicating through Postgres tables, not as one monolithic script.

```mermaid
flowchart LR
    subgraph Ingestion
        A[Connector] --> B[Parser]
        B --> C[Normalizer]
    end
    C --> D[(raw_documents)]
    D --> E[Chunker]
    E --> F[Contextual Header LLM]
    F --> G[Embedder]
    G --> H[(documents / chunks + pgvector)]
    subgraph Query
        I[Query Rewrite / Router] --> J[Hybrid Search: HNSW + FTS + RRF]
        J --> K[Reranker]
        K --> L[Context Assembly + MMR]
        L --> M[Grounded Generation]
        M --> N[Groundedness Check]
    end
    H --> J
    N --> O[Cited Answer]
```

- *Why:* Sources fail independently from parsing, which fails independently from loading; coupling them forces full re-crawls on any downstream error ([RAG source, §1.1](../../research/04-rag.md)).
- *How:* Each stage reads/writes Postgres state with a `status` column; no stage holds required in-memory state across requests (Autoscale-safe per canon §2).
- *Check:* Killing the process after any stage completes and restarting resumes without reprocessing completed work.

**`RAG-006` — Mandate the module/folder layout** · `MUST`
Use this layout for every RAG implementation on the canonical stack:

```
src/rag/
  ingestion/connectors/     # drive.ts, notion.ts, s3.ts — one file per source
  ingestion/parsers/        # docling.ts, unstructured.ts, reducto.ts, vision-ocr.ts
  ingestion/{normalize,dedupe,sync}.ts
  chunking/strategies/      # recursive.ts, structure-aware.ts, table.ts, code.ts
  chunking/{contextual-header,parent-document}.ts
  embeddings/{provider,quantize}.ts
  query/{rewrite,router,hybrid-search,rerank,assemble}.ts
  generation/{prompt,groundedness}.ts
  schema.ts                 # Drizzle schema — documents, chunks
  db/migrations/
  eval/golden-set/
  eval/ci-gate.ts
```
- *Why:* A fixed layout lets Claude and Replit Agent locate and extend any stage without re-deriving structure per project.
- *How:* Scaffold this tree at project init; do not collapse stages into a single `rag.ts` file.
- *Check:* `find src/rag -maxdepth 2 -type d` matches the tree above.

### Ingestion

**`RAG-007` — Separate fetch, parse, and load into independently retryable stages** · `MUST`
Connector (fetch), parser (document understanding), and loader (chunk + embed + upsert) are distinct stages, each with its own idempotency key.
- *Why:* Rate limits and auth expiry (fetch) fail independently from bad OCR (parse) and DB/embedding timeouts (load); coupling forces a full re-crawl on any single failure ([RAG source, §1.1](../../research/04-rag.md)).
- *How:* Connector modules write raw bytes + `source_id`, `source_uri`, `content_hash`, `fetched_at`, `etag` into a `raw_documents` staging table; a separate worker polls `status = 'pending'` rows and transitions status transactionally.
- *Check:* Re-running the loader after a parser failure does not re-fetch from the source connector.

**`RAG-008` — Run ingestion as a background worker, not inline request compute** · `MUST`
Long-running crawls and parses execute in a `pg-boss` job on Postgres, never inside a request-response cycle on Autoscale.
- *Why:* Replit Autoscale compute has no durable in-memory state and is unsuited to long-running crawls; a Postgres-backed queue survives restarts ([RAG source, §1.1](../../research/04-rag.md); canon §2 Autoscale constraint).
- *How:* Enqueue one `pg-boss` job per document per sync pass; use a Reserved VM worker or Replit Scheduled Deployment to process the queue.
- *Check:* No HTTP route handler performs parsing or embedding synchronously for documents over ~5 pages.

**`RAG-009` — Tier parsers by document complexity, not one library for everything** · `MUST`
Route documents through a cheap pre-classifier (page count, text-layer presence, table density) to the appropriate parser tier.

| Tier | Trigger | Parser |
|---|---|---|
| 1 — clean digital text | Has text layer, low table density | Docling or Unstructured OSS (no per-page cost) |
| 2 — table-heavy / complex layout | High table density, merged cells, mixed layout | Reducto or LlamaParse |
| 3 — scanned / non-standard | No text layer, handwriting, low volume | Vision-model OCR (Claude/GPT-4o/Gemini) fallback with a retry budget |

- *Why:* Docling/Unstructured are free and self-hosted but degrade on messy scans and complex tables; Reducto reports 99.24% extraction accuracy in healthcare and benchmarks on RD-TableBench for merged-cell tables with bounding-box citations ([Reducto Parse API docs](https://llms.reducto.ai/document-parsing-api)); vision-OCR is flexible but costly per page.
- *How:* Implement `parsers/router.ts` that inspects the file, assigns a tier, and calls the matching parser module from `parsers/`.
- *Check:* A test corpus containing one clean PDF, one table-heavy PDF, and one scanned PDF each route to the correct parser tier.

**`RAG-010` — Normalize before chunking** · `MUST`
Normalize whitespace, Unicode (NFKC), encoding, and heading/table markup into a consistent markdown-like intermediate representation before any chunking occurs.
- *Why:* Embedding models and BM25 tokenizers are sensitive to inconsistent whitespace/encoding; normalization also makes hash-based deduplication reliable ([RAG source, §1.3](../../research/04-rag.md)).
- *How:* `normalize.ts` applies `String.prototype.normalize('NFKC')`, collapses whitespace, and converts parser output (Docling/Unstructured elements) into markdown before it reaches `dedupe.ts`.
- *Check:* Re-parsing the same source document twice with trivial whitespace differences produces an identical `content_hash`.

**`RAG-011` — Deduplicate at exact and near-duplicate levels** · `MUST`
Deduplicate using SHA-256 exact-content hashing, plus MinHash/LSH or embedding-cosine-similarity (threshold >0.97) for near-duplicates.
- *Why:* Exact hashing catches unchanged re-syncs; near-duplicate detection catches reformatted or re-exported versions of the same document that exact hashing misses ([dedup at scale guide](https://shayangeek.com/en/deduplicating-documents-at-scale/)).
- *How:* Store `content_hash` per document and per chunk; skip re-embedding when the hash is unchanged since the last sync; run cosine-similarity clustering as a batch job for corpora under a few hundred thousand documents.
- *Check:* Ingesting the same document twice under a different filename does not create duplicate chunk rows.

**`RAG-012` — Use native change signals for incremental sync, hash comparison as fallback** · `MUST`
Fetch metadata only (ETag, `modifiedTime`, webhook events) to detect changes before re-fetching full content; fall back to content-hash comparison when no native signal exists.
- *How:* Maintain `documents.content_hash`, `documents.version`, `documents.last_synced_at`; on each sync pass compare metadata-only signals first, and only re-parse/re-chunk/re-embed documents that changed ([RAG source, §1.5](../../research/04-rag.md)).
- *Why:* Bounds both API cost and embedding cost versus full re-crawls on every sync.
- *Check:* A sync pass against an unchanged source corpus issues zero embedding API calls.

**`RAG-013` — Cascade deletes and version changes through chunks, never diff chunk-by-chunk** · `MUST`
Foreign-key `chunks.document_id` to `documents.id` with `ON DELETE CASCADE`; on a document version change, delete all chunks for the old version and re-insert inside one transaction.
- *Why:* Diffing chunk-by-chunk is fragile against re-chunking-strategy changes; full delete-and-reinsert per version is simpler and safer, and HNSW supports incremental inserts natively so no index rebuild is required ([RAG source, §1.6](../../research/04-rag.md)).
- *How:* Wrap delete + re-insert in a single Postgres transaction; let the HNSW index absorb inserts asynchronously.
- *Check:* Hard-deleting a source document removes all its chunk rows and they no longer appear in hybrid search results.

### Chunking canon

**`RAG-014` — Default to structure-aware recursive chunking at 400–800 tokens, 10–15% overlap** · `MUST`
Split on paragraph → sentence → token boundaries recursively, respecting document structure (headings, tables, code blocks), targeting 400–800 tokens per chunk with 10–15% overlap for prose.
- *Why:* Fixed-size chunking cuts across semantic boundaries and breaks tables/code; recursive structure-first chunking is the strongest general default ([RAG source, §2.1](../../research/04-rag.md)).
- *How:* Implement `chunking/strategies/structure-aware.ts` using parser-emitted structure (headings, table boundaries) from the normalized markdown; validate chosen sizes against the golden eval set in §8, not a universal number.
- *Check:* No chunk in the eval corpus splits mid-sentence across a heading boundary; chunk token counts fall in the 400–800 range for at least 90% of prose chunks.

**`RAG-015` — Prepend a contextual chunk header before embedding and full-text indexing** · `MUST`
For every chunk, generate a 50–100 token LLM context blurb naming the source document, section, entity, and time period, and prepend it to the chunk text before both embedding and BM25 indexing.
- *Why:* Anthropic's Contextual Retrieval reduced top-20 retrieval failure rate from 5.7% (baseline) to 3.7% with contextual embeddings alone (35% reduction), to 2.9% combined with contextual BM25 (49% reduction), and to 1.9% combined with reranking (67% reduction) ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)).
- *How:* At ingest time, call a fast/cheap model (Claude Haiku or GPT-4o-mini) with the full document plus the chunk: "Give a short succinct context (50–100 tokens) situating this chunk within the document, for the purpose of improving search retrieval. Answer only with the context." Use prompt caching on the full document to cut cost — contextualization costs ~$1.02 per million document tokens one-time with caching, cutting latency >2x and cost up to 90% versus uncached generation ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)).
- *Check:* `chunks.content` for every row begins with a generated context blurb distinct from the raw source text; ingest cost per document is logged and matches the expected per-token rate.

**`RAG-016` — Implement parent-document (small-to-big) retrieval when generation needs more context than optimal retrieval chunk size** · `SHOULD`
Embed and search small child chunks for precision, but resolve to the larger parent chunk/section for generation.
- *How:* Add `chunks.parent_chunk_id` referencing a larger stored parent chunk; after top-k child match, join to fetch the parent for context assembly (see Reference implementation schema).
- *Why:* Small chunks maximize match precision; larger parents give the LLM enough surrounding context to answer fully ([RAG source, §2.3](../../research/04-rag.md)).
- *Check:* A query matching a child chunk returns the parent chunk's full text to the generation step, not just the child chunk.

**`RAG-017` — Never split a table or code block across chunk boundaries** · `MUST`
Treat each table as one chunk (or one chunk per logical row-group for very large tables) preserving markdown/HTML table structure; chunk code along function/class boundaries using an AST-aware splitter.
- *Why:* Flattening tables to plain text destroys row/column relationships both embedding models and LLMs need; fixed-token splitting fragments function bodies mid-logic ([RAG source, §2.5](../../research/04-rag.md)).
- *How:* `chunking/strategies/table.ts` uses parser-emitted table boundaries as hard split points; `chunking/strategies/code.ts` uses a language-aware AST parser (e.g., tree-sitter) to split on top-level declarations.
- *Check:* No chunk in the corpus contains a `<table>`/markdown-table fragment that is missing its header row or split mid-row.

### Embeddings

**`RAG-018` — Default to a hosted embedding model; self-host only past documented volume** · `MUST`
Default to OpenAI `text-embedding-3-large`, Voyage-3, Cohere Embed v4, or Gemini Embedding for a lean build; self-host BGE-M3/Qwen3-Embedding only once volume justifies GPU/CPU inference cost, or residency requires it (see `RAG-030`).

| Model | MTEB (approx.) | Dimensions | Notes |
|---|---:|---:|---|
| Gemini Embedding | ~68.3 | 3072 | Strong multilingual + multimodal |
| Qwen3-Embedding-8B | ~70.6 | 4096 | Open-source, self-hostable, strong multilingual |
| Jina Embeddings v4 | ~71.7 | 1024–2048 | Multimodal, multi-vector modes, visually-rich docs ([Jina v4 paper](https://aclanthology.org/2025.mrl-main.36.pdf)) |
| Voyage 3/4 (large) | ~66.8 | 1024–2048 | Domain-specific legal/finance variants |
| Cohere Embed v4 | ~65.2 | 1536 | 128K context, multimodal, markets Arabic coverage |
| OpenAI `text-embedding-3-large`/`-small` | ~64.6 | 3072 / 1536 | Ubiquitous, native Matryoshka truncation, default |
| BGE-M3 (BAAI) | ~63.0 | 1024 | Open-source, dense+sparse+ColBERT in one model, self-hostable, markets Arabic coverage |
| Nomic-embed-text-v1.5 | ~59.4 | 768 | Budget option, native Matryoshka |

*(Scores are directional per-benchmark snapshots — validate against your own retrieval eval set; see [MTEB leaderboard comparison](https://app.ailog.fr/en/blog/guides/choosing-embedding-models).)*
- *Why:* Self-hosting adds GPU/ops burden not justified below meaningful scale; hosted models cover the vast majority of prototype and early-production needs ([RAG source, §3.1](../../research/04-rag.md)).
- *Check:* Spec names one embedding model and one fallback; no ingestion code calls two different embedding models for the same corpus without a documented migration plan.

**`RAG-019` — Truncate via Matryoshka Representation Learning before adding infrastructure to compensate for dimension size** · `SHOULD`
Use MRL-trained models (OpenAI v3, Nomic, Gemini) to truncate embedding dimensions (e.g., 3072 → 1024 or 512) before reaching for a separate ANN infrastructure to handle full-dimension cost.
- *Why:* Truncation cuts storage and index build/query cost roughly linearly with dimension at minimal, measurable quality loss ([pgvector GitHub — halfvec and binary quantization](https://github.com/pgvector/pgvector)).
- *How:* Store the truncated dimension directly in the `embedding halfvec(N)` column; validate recall delta on the eval set (§8) before shipping.
- *Check:* Recall@10 on the golden set after truncation is within an agreed tolerance (default: within 2 percentage points) of the untruncated baseline.

**`RAG-020` — Use `halfvec` by default; add binary quantization only with re-ranking against full precision** · `MUST`
Store embeddings as `halfvec` (2 bytes/dimension) by default. If binary quantization (`bit` via `binary_quantize()`) is used for extreme scale, always rerank top candidates against full-precision vectors to recover lost recall.
- *Why:* `halfvec` halves memory footprint with negligible recall loss; binary quantization is far more aggressive and requires a full-precision recovery pass ([pgvector GitHub](https://github.com/pgvector/pgvector)).
- *Check:* The `embedding` column type in the schema is `halfvec`, not `vector`, unless a documented exception states otherwise.

**`RAG-021` — Validate Arabic/multilingual retrieval quality in-language, not via MTEB alone** · `MUST`
For Arabic or mixed Arabic/English corpora, use models explicitly benchmarked on multilingual retrieval (Gemini Embedding, Qwen3-Embedding, Cohere Embed v4, BGE-M3, Jina v4), and validate against an in-language Arabic eval set before committing.
- *Why:* MTEB multilingual scores do not guarantee strong Arabic-specific performance; UAE/GCC citizen-facing deployments require validated bilingual quality, not an assumption ([RAG source, §3.3](../../research/04-rag.md); see [18 — Accessibility & Bilingual](./18-accessibility-i18n.md) · `A11Y-001` for RTL/bilingual UX requirements).
- *How:* Build a minimum 30-question Arabic-language subset of the golden set (§8) alongside the English set; run the same recall@k/nDCG metrics on both and report separately.
- *Check:* The evaluation report in §8 shows Arabic-subset recall@k alongside English-subset recall@k, not a blended average that could mask an Arabic-specific gap.

**`RAG-022` — Rerank before upgrading the embedding model** · `SHOULD`
When retrieval quality is insufficient, add or tune a reranker (§5.4) and verify chunking/hybrid-search quality before switching or fine-tuning the embedding model.
- *Why:* Most retrieval quality gaps are chunking, hybrid-search, or reranking gaps, not embedding-model gaps; fine-tuning requires a labeled relevance dataset and ongoing retraining discipline that most engagements cannot sustain ([RAG source, §3.4](../../research/04-rag.md)).
- *How:* Use the diagnostic pattern in `RAG-032`: strong recall + weak MRR means add/tune a reranker; only pursue embedding changes after reranking is in place and still insufficient.
- *Check:* Design review confirms a reranker is deployed and evaluated before any embedding-model change or fine-tuning proposal is approved.

### Storage and indexing

**`RAG-023` — Use the canonical Drizzle schema and DDL for documents/chunks** · `MUST`
Implement `documents` and `chunks` tables exactly as below (extend, do not replace).

```typescript
// src/rag/schema.ts
import { pgTable, uuid, text, integer, jsonb, timestamp, customType, unique, index } from "drizzle-orm/pg-core";

const halfvec = customType<{ data: number[]; driverData: string }>({
  dataType(config) { return `halfvec(${(config as { dimensions: number }).dimensions})`; },
  toDriver(value: number[]) { return `[${value.join(",")}]`; },
});

export const documents = pgTable("documents", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id").notNull(),
  sourceUri: text("source_uri").notNull(),
  contentHash: text("content_hash").notNull(),
  version: integer("version").notNull().default(1),
  metadata: jsonb("metadata").default({}),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }).defaultNow(),
}, (t) => ({ tenantSourceUnique: unique().on(t.tenantId, t.sourceUri) }));

export const chunks = pgTable("chunks", {
  id: uuid("id").primaryKey().defaultRandom(),
  documentId: uuid("document_id").notNull().references(() => documents.id, { onDelete: "cascade" }),
  tenantId: uuid("tenant_id").notNull(),
  parentChunkId: uuid("parent_chunk_id"),
  chunkIndex: integer("chunk_index").notNull(),
  content: text("content").notNull(),          // includes prepended contextual header
  contentHash: text("content_hash").notNull(),
  embedding: halfvec("embedding", { dimensions: 1536 } as any),
  sensitivityLevel: text("sensitivity_level").notNull().default("standard"), // ACL filtering, RAG-043
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
}, (t) => ({
  tenantIdx: index("chunks_tenant_idx").on(t.tenantId),
  documentIdx: index("chunks_document_idx").on(t.documentId),
}));
```

Raw DDL (equivalent migration; `fts_vector`/generated column and indexes are not yet expressible in Drizzle's TS schema, so hand-write this migration file):

```sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  source_uri TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  version INT NOT NULL DEFAULT 1,
  metadata JSONB DEFAULT '{}',
  deleted_at TIMESTAMPTZ,
  last_synced_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (tenant_id, source_uri)
);

CREATE TABLE chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL,
  parent_chunk_id UUID REFERENCES chunks(id),
  chunk_index INT NOT NULL,
  content TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  embedding halfvec(1536),
  sensitivity_level TEXT NOT NULL DEFAULT 'standard',
  fts_vector TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Build HNSW after initial bulk load for best performance
CREATE INDEX CONCURRENTLY ON chunks
  USING hnsw (embedding halfvec_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX CONCURRENTLY ON chunks USING GIN (fts_vector);
CREATE INDEX ON chunks (tenant_id);
CREATE INDEX ON chunks (document_id);
CREATE INDEX ON chunks (sensitivity_level);
```
- *Why:* A fixed schema means Claude and Replit Agent extend rather than reinvent the storage layer per engagement.
- *Check:* The migration applies cleanly and `\d chunks` in `psql` matches the columns above.

**`RAG-024` — Default to HNSW; use IVFFlat only when build time/memory is the binding constraint** · `MUST`
Build an HNSW index (`m = 16`, `ef_construction = 64`) as the default; use IVFFlat only for very large one-time bulk loads on a memory-constrained instance.
- *Why:* HNSW needs no training pass, supports incremental inserts natively, and gives a better speed/recall curve than IVFFlat at the cost of slower builds and higher RAM ([pgvector official README](https://github.com/pgvector/pgvector)).
- *How:* `CREATE INDEX CONCURRENTLY` to avoid blocking writes; raise `maintenance_work_mem` so the HNSW graph fits in memory during build; set query-time recall via `SET hnsw.ef_search = 100;`; reindex (`REINDEX INDEX CONCURRENTLY`) rather than relying on vacuum alone to maintain graph quality ([pgvector GitHub](https://github.com/pgvector/pgvector)).
- *Check:* `\d chunks` in `psql` shows an `hnsw` index on `embedding`; index build used `CONCURRENTLY`.

**`RAG-025` — Fuse hybrid search with Reciprocal Rank Fusion** · `MUST`
Combine Postgres full-text search with vector similarity, fused via RRF with smoothing constant `k=60`, rather than relying on either alone.
- *Why:* Lexical search excels at exact keyword/identifier/rare-term matches; vector search excels at semantic/paraphrase matches; fusing both consistently outperforms either alone and is what Anthropic's contextual retrieval layers on top of ([Tiger Data hybrid search tutorial](https://www.tigerdata.com/docs/build/examples/hybrid-search)).
- *How:*
```sql
WITH vector_results AS (
  SELECT id, RANK() OVER (ORDER BY embedding <=> $1) AS rank
  FROM chunks
  WHERE tenant_id = current_setting('app.current_tenant_id')::uuid
  ORDER BY embedding <=> $1 LIMIT 50
),
text_results AS (
  SELECT id, RANK() OVER (ORDER BY ts_rank_cd(fts_vector, query) DESC) AS rank
  FROM chunks, plainto_tsquery('english', $2) query
  WHERE fts_vector @@ query
    AND tenant_id = current_setting('app.current_tenant_id')::uuid
  LIMIT 50
)
SELECT COALESCE(v.id, t.id) AS id,
       COALESCE(1.0/(60+v.rank), 0) + COALESCE(1.0/(60+t.rank), 0) AS rrf_score
FROM vector_results v FULL OUTER JOIN text_results t ON v.id = t.id
ORDER BY rrf_score DESC LIMIT 20;
```
- *Check:* The hybrid-search query returns results from both the vector-only and text-only candidate sets, verified by a test case where the answer chunk only lexically matches (rare identifier) and one where it only semantically matches (paraphrase).

**`RAG-026` — Push metadata filters into the query, never post-filter** · `MUST`
Store filterable metadata (`tenant_id`, `document_type`, `date`, ACL tags, `sensitivity_level`) as native indexed Postgres columns, and apply filters inside the same query as the vector/text search.
- *Why:* Post-filtering after ANN search wastes the index's candidate budget — a filtered-out top result means one fewer usable candidate reaches reranking ([RAG source, §4.3](../../research/04-rag.md)).
- *How:* Add `WHERE` clauses on indexed columns inside the CTEs in `RAG-025`, not as a filter on the final result set.
- *Check:* `EXPLAIN ANALYZE` on the hybrid query shows the filter applied before or during the index scan, not as a separate downstream filter node.

**`RAG-027` — Enforce multi-tenant isolation with Postgres Row-Level Security** · `MUST`
Enable RLS on `documents` and `chunks`; every session sets `app.current_tenant_id` before querying.
```sql
ALTER TABLE chunks ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON chunks
  USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_docs ON documents
  USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

-- Per request/transaction in application code:
SET LOCAL app.current_tenant_id = '...';
```
- *Why:* Application-level `WHERE tenant_id = ?` filtering is bypassable by a bug in any code path, including background workers; RLS makes isolation the database's responsibility so a missed clause cannot leak rows ([Pradeep Bhandari, pgvector multi-tenancy RLS](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide)). This composes correctly with HNSW: the ANN scan happens, then RLS filters visible rows, so no cross-tenant vector content ever leaks through index internals.
- *Check:* A test query executed with `app.current_tenant_id` set to tenant A returns zero rows belonging to tenant B, even when the query issuer omits an explicit tenant filter.

**`RAG-028` — Monitor index health after batch operations** · `SHOULD`
Run `ANALYZE`/`VACUUM` on `chunks` after large batch deletes (full document re-syncs); periodically `REINDEX INDEX CONCURRENTLY` the HNSW index under high churn.
- *Why:* HNSW graphs can degrade slightly under heavy churn; vacuum alone is often slow to reclaim bloat on vector columns ([pgvector GitHub](https://github.com/pgvector/pgvector)).
- *Check:* A scheduled job runs `ANALYZE chunks;` after each bulk re-sync job completes.

### Query stage

**`RAG-029` — Gate query rewriting/HyDE/decomposition/multi-query behind a complexity router** · `SHOULD`
Apply query rewriting, HyDE, decomposition, or multi-query expansion only for queries a router or classifier flags as complex, conversational, or multi-part; use direct single-query retrieval otherwise.

| Technique | What it does | When to use |
|---|---|---|
| Query rewriting | Reformulates a vague/conversational query into a retrieval-optimized query | Chat-style apps with underspecified or context-dependent queries |
| Multi-query | Generates paraphrases, retrieves for each, merges | Recall improvement when phrasing under-matches |
| Query decomposition | Splits a multi-part question into sub-questions | Multi-hop or comparison questions |
| HyDE | Embeds an LLM-generated hypothetical answer instead of the raw query | Short/keyword queries against long-form answers |
| Self-querying / filter extraction | Extracts structured filters (dates, entities) from natural language into `WHERE` clauses | Corpora with strong metadata where users express filters conversationally |

- *Why:* Each technique adds an LLM call (latency + cost) before retrieval starts; reserving them for genuinely complex queries avoids paying that cost on simple factual lookups ([RAG source, §5.1](../../research/04-rag.md)).
- *How:* Implement `query/router.ts` as an LLM function-call or lightweight classifier producing a `complexity: "simple" | "complex"` label before choosing the retrieval path.
- *Check:* A latency trace of a simple factual query shows no extra LLM call before the hybrid-search query executes.

**`RAG-030` — Route explicitly between multiple retrieval sources** · `MUST`
In agentic applications with more than one retrieval source (structured DB, vector index, web search, graph), use an explicit router step to select which source(s) to query per request rather than always querying all of them.
- *Why:* Always-query-everything wastes latency/cost and can surface irrelevant candidates from an unrelated source into the reranking stage ([RAG source, §5.2](../../research/04-rag.md)).
- *How:* Implement routing as LLM function-calling with one tool per source, following [08 — Tool Contracts](./08-tool-contracts.md) · `TOOL-001`.
- *Check:* A query that only concerns structured data (e.g., "what is the account balance") does not trigger a vector-store retrieval call in the trace.

**`RAG-031` — Two-stage retrieve-then-rerank with a default provider** · `MUST`
Retrieve a wide candidate set (top 50–150) via hybrid search, then rerank down to top 5–20 with a cross-encoder before generation. Default reranker: Cohere Rerank.

| Reranker | Type | Notes |
|---|---|---|
| Cohere Rerank | Hosted cross-encoder | Default; contributed the 49%→67% failure-rate jump in Anthropic's evaluation ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)) |
| Voyage Rerank | Hosted cross-encoder | Comparable tier, pairs with Voyage embeddings |
| BGE-reranker-v2-m3 | Self-hosted cross-encoder | Use when residency (`RAG-035`) precludes a third-party API call |
| Jina Reranker | Hosted | Multilingual reranking support |

- *Why:* Bi-encoders trade precision for first-stage speed; cross-encoders jointly encode query+document for higher precision at a cost too high for first-stage retrieval over a large corpus — hence the two-stage design ([reranker comparison analysis](https://ianas.fr/en/blog/2026/06/07/reranker-comparatif-cohere-bge-jina-voyage/)).
- *Check:* `query/rerank.ts` calls a reranker on the RRF-fused candidate set before context assembly; retrieval candidate count is 50–150, generation candidate count is 5–20.

**`RAG-032` — Diagnose retrieval failures using the recall/MRR pattern before changing components** · `SHOULD`
Use this diagnostic before proposing a pipeline change: strong recall + weak MRR → the right chunk is present but ranked low → add/tune reranker. Strong precision + weak recall → retriever too conservative → improve chunking or add hybrid search.
- *Why:* Prevents guessing which of chunking, indexing, or reranking is at fault ([Crux Digits retrieval quality guide](https://cruxdigits.nl/blog/rag-evaluation-retrieval-quality/)).
- *Check:* Any pipeline-change proposal in a review cites which metric pattern (per §8.1) motivated the change.

**`RAG-033` — Enforce a fixed token budget for context assembly** · `MUST`
Allocate a fixed share (20–40%) of the model's context window to retrieved context per generation call; fill in reranked-priority order and stop rather than truncate mid-chunk; account for system prompt, user query, and citation-format instructions in the same budget.
- *Why:* Unbounded context assembly makes cost and latency unpredictable and risks truncating a chunk mid-fact ([RAG source, §5.5](../../research/04-rag.md)).
- *How:* `query/assemble.ts` computes a token count per candidate chunk and stops admitting chunks once the budget is reached, never slicing a chunk's text.
- *Check:* A test with an oversized candidate set confirms assembly stops at a whole-chunk boundary at or under the configured budget.

**`RAG-034` — Apply MMR after reranking to control near-duplicate context** · `SHOULD`
Apply Maximal Marginal Relevance or a near-duplicate filter after reranking to avoid feeding the LLM several near-identical chunks.
- *Why:* Documents commonly repeat key facts across sections; feeding several near-duplicates wastes token budget without adding information ([RAG source, §5.6](../../research/04-rag.md)).
- *Check:* A test corpus with a repeated fact across three sections yields at most one of those three chunks in the final assembled context.

**`RAG-035` — Carry full provenance through every pipeline stage** · `MUST`
Carry `document_id`, `chunk_id`, `source_uri`, and page/character-offset provenance through ingestion, chunking, retrieval, reranking, and generation.
- *Why:* Generation cannot attach a verifiable citation without provenance surviving every transformation ([RAG source, §5.7](../../research/04-rag.md)).
- *How:* Include `chunk_id` and `source_uri` in every candidate object passed between pipeline stages; never strip them for a "cleaner" prompt.
- *Check:* The final generation call's context payload includes `chunk_id` for every chunk, traceable back to a `chunks` row.

### Generation

**`RAG-036` — Enforce grounding via structured output, not prompt instructions alone** · `MUST`
Require the generation step to answer only from supplied context, attach a citation to every factual claim, and expose a structured `has_sufficient_evidence: boolean` field — enforced through a JSON schema plus a post-hoc groundedness check, not prompt wording alone.
- *Why:* Prompt-only grounding instructions are not reliably followed; structured output plus a verification pass catches violations prompt instructions alone would miss ([RAG source, §6.1](../../research/04-rag.md)).
- *How:* Define a Zod schema for the answer with a `claims: { text: string; chunkIds: string[] }[]` array and `hasSufficientEvidence: boolean`, generated via the Vercel AI SDK's `generateObject`.
- *Check:* Every `claims[]` entry in a sampled generation output has at least one `chunkId` that exists in the assembled context.

**`RAG-037` — Refuse when evidence is insufficient** · `MUST`
When `hasSufficientEvidence` is false, the agent MUST return an explicit refusal or hedge, never a fabricated best-guess answer.
- *Why:* Gives the model a low-cost, well-defined way to decline instead of hallucinating a plausible answer ([RAG source, §6.2](../../research/04-rag.md)).
- *Check:* A test query with no matching corpus content returns a refusal response, not a fabricated answer with invented citations.

**`RAG-038` — Run an automated groundedness check before returning an answer** · `MUST`
Run a second-pass groundedness/faithfulness check (LLM-as-judge or NLI-style classifier) against the cited chunks before returning the answer, especially in production.
- *Why:* This is the generation-side complement to retrieval recall/precision metrics — retrieval can be perfect and generation can still fabricate ([Future AGI RAG evaluation metrics guide](https://futureagi.com/blog/rag-evaluation-metrics-2025/)).
- *How:* Definitions to apply consistently: **faithfulness** — does the whole answer avoid fabrication relative to context; **groundedness** — is each sentence/claim individually supported (finer-grained than faithfulness); **answer relevance** — is the answer on-topic ([RAG source, §6.4](../../research/04-rag.md)).
- *Check:* A groundedness score is logged per generation call in production tracing (see [16 — Observability & Cost](./16-observability-cost.md) · `OBS-001`), and any answer scoring below the threshold in §8 is flagged.

### Evaluation

**`RAG-039` — Build a golden question set of at least 50 questions before shipping** · `MUST`
Construct a golden set combining manually curated questions (from real user queries/support tickets, minimum 30) and synthetically generated question-answer-source triples (minimum 20), covering both English and, where applicable, an Arabic-language subset per `RAG-021`.
- *Why:* A complete evaluation program needs both realistic and systematic coverage; below ~50 questions, metric noise makes CI gating unreliable ([RAG source, §8.3](../../research/04-rag.md)).
- *How:* Generate synthetic triples with an LLM prompted against sampled corpus chunks; store the set under `src/rag/eval/golden-set/` as versioned JSON/JSONL.
- *Check:* `golden-set/` contains at least 50 question entries, each with an expected answer-bearing `chunk_id` or document reference.

**`RAG-040` — Track at least one retrieval metric and one generation metric, with committed minimum thresholds** · `MUST`
Every evaluation run reports both retrieval and generation metrics; Cognirise commits to the following minimum passing thresholds before a RAG feature ships to a client demo or pilot.

| Stage | Metric | Minimum threshold | What it measures |
|---|---|---:|---|
| Retrieval | Recall@10 | ≥ 0.85 | Fraction of answer-bearing chunks appearing in top 10 |
| Retrieval | Precision@5 | ≥ 0.60 | Fraction of top-5 retrieved chunks actually relevant |
| Retrieval | MRR | ≥ 0.70 | Rank position of first relevant result |
| Generation | Faithfulness | ≥ 0.90 | Whole-answer non-fabrication rate |
| Generation | Groundedness | ≥ 0.85 | Per-claim supported-by-context rate |
| Generation | Answer relevance | ≥ 0.85 | On-topic rate |

- *Why:* Tracking only generation hides retrieval regressions; tracking only retrieval misses fabrication ([Future AGI RAG evaluation metrics guide](https://futureagi.com/blog/rag-evaluation-metrics-2025/)). These thresholds are the studio's committed floor, not aspirational targets — a build that cannot clear them is not demo-ready.
- *How:* Use Ragas or DeepEval to compute these metrics against the golden set; log results per pipeline version.
- *Check:* CI eval report shows all six metrics with pass/fail status against the table above.

**`RAG-041` — Block merges that regress the committed thresholds via a CI gate** · `MUST`
Run the golden-set evaluation as a CI gate on every pipeline-affecting change (chunking strategy, embedding model, reranker swap, prompt change); block the merge if any metric in `RAG-040` regresses below its threshold.
- *Why:* Prevents silent quality regressions between prototype and later iterations ([RAG source, §8.3](../../research/04-rag.md)).
- *How:* Wire DeepEval's pytest-style runner (or a Vitest wrapper calling Ragas via a Python sidecar) into the CI pipeline as a required check.
- *Check:* A deliberately degraded chunking change (e.g., halving overlap) fails the CI gate in a test run.

**`RAG-042` — Sample production traffic into the same evaluation pipeline for drift detection** · `SHOULD`
Continuously sample live queries and their retrieved/generated outputs into the offline evaluation pipeline via tracing (Langfuse/Phoenix/LangSmith), rather than relying solely on the static golden set.
- *Why:* Corpus growth, embedding-model deprecations, and query-distribution shifts degrade quality in ways a static offline set cannot catch ([RAG source, §8.4](../../research/04-rag.md)).
- *How:* Emit OpenTelemetry GenAI semantic-convention spans for every retrieval and generation call per canon §2 observability default; route a sampled percentage into a recurring re-scoring job.
- *Check:* A dashboard exists showing weekly recall/groundedness trend on sampled production traffic, not just the last CI run.

### Security and governance

**`RAG-043` — Enforce ACL-aware retrieval in SQL, never as a prompt instruction or post-filter** · `MUST`
Permission checks MUST happen inside or before the similarity/full-text search query (via RLS and indexed `sensitivity_level`/ACL columns), never as an instruction to the LLM or a filter applied after chunks are already returned.
- *Why:* An LLM instructed "only use documents the user is allowed to see" can still leak content in reasoning traces or be bypassed by prompt injection; RLS makes the database itself refuse to return unauthorized rows ([Pradeep Bhandari, pgvector multi-tenancy RLS](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide); [RAG source, §9.1](../../research/04-rag.md)).
- *How:* Extend the RLS policy in `RAG-027` with an ACL predicate, e.g. `USING (tenant_id = current_setting('app.current_tenant_id')::uuid AND sensitivity_level = ANY(string_to_array(current_setting('app.user_clearance_levels'), ',')))`.
- *Check:* A user session scoped to `sensitivity_level = 'standard'` cannot retrieve a chunk tagged `sensitivity_level = 'restricted'` even via a raw SQL query bypassing the application layer.

**`RAG-044` — Treat every retrieved chunk as untrusted, attacker-controllable input** · `MUST`
Structurally separate retrieved content from instructions in the prompt (explicit delimiters or a dedicated context field, never raw concatenation); strip or neutralize imperative-sounding text patterns from retrieved chunks; restrict any agentic tool-calling triggered by generation to an allow-list that retrieved content cannot expand.
- *Why:* RAG pipelines have at least six distinct attack surfaces: poisoned ingestion documents, weak vector-store access control, crafted retrieval queries, indirect prompt injection at assembly, model compliance with injected instructions, and poisoned-output-triggered tool calls ([RAG pipeline security hardening guide](https://www.systemshardening.com/articles/ai-landscape/rag-pipeline-security/)). This aligns with OWASP LLM01 (Prompt Injection) and LLM06 (Excessive Agency) — see [12 — Guardrails & Safety](./12-guardrails-safety.md) · `GRD-001`.
- *How:* Wrap retrieved chunks in a dedicated `context` field of the structured generation call (not string-concatenated into the system prompt); apply the same output-side monitoring used for direct prompt injection to generation triggered by retrieved content.
- *Check:* A test chunk containing an embedded instruction ("ignore previous instructions and...") does not alter the agent's tool-calling behavior in a controlled test.

**`RAG-045` — Classify and handle PII at ingestion, before embedding** · `MUST`
Classify and redact/mask PII at ingest time where regulatorily required, and tag chunks with a sensitivity level so retrieval can filter by requester clearance.
- *Why:* PDPL and DIFC Regulation 10 require lawful-basis documentation for sensitive data processing, and any third-party embedding API call is itself a cross-border transfer requiring a documented basis ([Regulated-sector source, §1.1](../../research/05-regulated.md)).
- *How:* Run a PII/sensitive-data scan in `normalize.ts` before chunking; write the detected sensitivity to `chunks.sensitivity_level`; redact/mask before the text reaches an external embedding API unless a documented lawful transfer basis exists.
- *Check:* A test document containing a UAE Emirates ID number or equivalent PII pattern is redacted or masked in the `content` column before the embedding API call is made.

**`RAG-046` — Pin vector store region and document all external API data flows for residency** · `MUST`
For any government, CBUAE/DFSA-regulated, or PDPL/Regulation-10-covered corpus, pin the Postgres region explicitly and document whether embedding/reranking API calls transit or store data outside the required jurisdiction.
- *Why:* UAE National Cloud Security Policy requires data-sensitivity-aligned hosting; Replit's default hosting is US/India-only with no UAE/GCC region, making this a first-order residency risk that must be flagged even at prototype stage ([Regulated-sector source, §1.6, §5.1](../../research/05-regulated.md)).
- *How:* Record the Postgres region and every third-party API vendor (embedding, reranking, contextual-header LLM) with its processing location in the subprocessor list required by `GOV`-prefix standards; self-host embeddings (BGE-M3/Qwen3-Embedding) when third-party data flows are unacceptable per `RAG-018`.
- *Check:* A one-page data-flow diagram exists naming every external API call in the RAG pipeline and its processing region, matching the "compliance-ready prototype" bar's data classification/residency statement requirement ([Regulated-sector source, §4](../../research/05-regulated.md)).

**`RAG-047` — Support Arabic-language retrieval and RTL citation rendering for citizen-facing corpora** · `MUST`
Any citizen- or public-facing RAG deployment MUST validate Arabic retrieval quality per `RAG-021` and render citations/source spans correctly in RTL layout.
- *Why:* UAE government and citizen-facing deployments require Arabic-first content parity, not translated-label-only support ([Regulated-sector source, §3, Arabic/bilingual RTL row](../../research/05-regulated.md)).
- *How:* Coordinate with [18 — Accessibility & Bilingual](./18-accessibility-i18n.md) · `A11Y-001` for RTL component behavior; ensure citation UI components (chunk highlight, source span) mirror correctly under `dir="rtl"`.
- *Check:* A citizen-facing demo renders an Arabic-language answer with correctly positioned, RTL-mirrored citation markers.

### Scale-up decision matrix

**`RAG-048` — Apply explicit numeric triggers before moving off pgvector** · `MUST`

| Situation | Recommendation | Trigger |
|---|---|---|
| Early-stage app, Postgres already in use | Stay on pgvector | < 10M chunks, p50 query latency < 300ms |
| Approaching pgvector's proven ceiling | Plan migration | > 10–20M chunks, or p50 query latency > 300ms under production load, or HNSW build time exceeds maintenance window |
| Need sub-10ms p50 at 100M+ vectors, cost-sensitive at scale | Turbopuffer, Qdrant, or Pinecone | > 100M vectors, or sub-10ms p50 SLA required |
| Zero pipeline code desired, fastest time-to-value, control tradeoff acceptable | Ragie/Vectara (bundled) or cloud-native (Bedrock KB/Azure AI Search/Vertex AI Search) if already on that cloud | Engineering capacity, not cost or control, is the binding constraint |
| Heavy visually-rich/table-heavy documents needing best-in-class parsing | LlamaCloud (LlamaParse) or Reducto for ingestion, any vector store | Parser tier-3 fallback rate (`RAG-009`) exceeds ~15% of ingested volume |
| Strict data residency, cannot send data to third-party APIs | Self-hosted pgvector + self-hosted embedding model (BGE-M3/Qwen3-Embedding) | Residency requirement per `RAG-046` precludes any external API call |
| Multi-hop reasoning across entity relationships needed | Add GraphRAG on top of the base pipeline, not as a replacement | Baseline vector/hybrid + rerank demonstrably fails on multi-hop/holistic queries in eval (§8) |
| Already deeply invested in one hyperscaler | Use that cloud's native managed option | Existing AWS/Azure/GCP commitment makes integration surface the deciding factor |

*(Category groupings per [Atlan Enterprise RAG Platforms Comparison 2026](https://atlan.com/know/enterprise-rag-platforms-comparison/) and [Turbopuffer](https://turbopuffer.com/); verify current vendor pricing before committing.)*
- *Why:* pgvector with HNSW + `halfvec` is proven to tens of millions of vectors on well-resourced managed Postgres; beyond that, query latency and index build/maintenance time become the limiting factor ([RAG source, §11.1](../../research/04-rag.md)).
- *Check:* Any proposal to introduce a managed vector DB or RAG-as-a-service cites which row of this table triggered the recommendation, with the measured metric (chunk count or p50 latency) attached.

**`RAG-049` — Sequence scale-up changes: split vector store, harden ingestion, add reranking/contextual retrieval, then GraphRAG, then formal eval gates** · `SHOULD`
When scaling past pgvector, follow this order: (1) move the `embedding` column workload to a purpose-built vector DB while keeping `documents`/`chunks` metadata in Postgres; (2) move parsing to a dedicated service and run ingestion as an async worker fleet; (3) add reranking and contextual retrieval if not already present — typically the highest-ROI upgrade; (4) add GraphRAG or agentic multi-hop retrieval only after the vector/hybrid+rerank baseline is evaluated and found insufficient; (5) introduce Ragas/DeepEval CI gates before further pipeline changes ship; (6) consider a managed end-to-end RAG service if engineering capacity, not cost, becomes the bottleneck ([RAG source, §11.2](../../research/04-rag.md)).
- *Check:* A scale-up plan document lists these six steps in order with a completion status for each.

## Reference implementation

See `RAG-006` for the mandated module layout, `RAG-023` for the Drizzle schema and DDL, `RAG-025` for the RRF hybrid-search SQL, and `RAG-027` for the RLS policy. The Mermaid pipeline diagram in `RAG-005` is the canonical architecture diagram to reuse in specs and handoffs.

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Single monolithic `ragPipeline()` function doing fetch, parse, chunk, embed, and query | One failure (e.g., embedding API timeout) forces re-running the whole pipeline, including expensive re-parsing | Separate stages per `RAG-007`, each independently retryable via staged status columns |
| Fixed-size chunking with no structure awareness | Splits tables and code mid-block, destroying row/column and logic relationships | Structure-aware recursive chunking per `RAG-014`, never split tables/code per `RAG-017` |
| Embedding raw chunk text with no contextual header | Leaves 5.7% baseline top-20 retrieval failure rate on the table when a 49% reduction is available for one LLM call per chunk | Contextual chunk headers per `RAG-015` |
| Application-layer `WHERE tenant_id = ?` as the only isolation control | One missed clause in one code path (including a background worker) leaks cross-tenant data | Postgres RLS per `RAG-027` |
| Filtering ACL/tenant scope after the vector search returns results | Wastes the ANN index's candidate budget and risks a race where unauthorized content briefly exists in application memory | Push filters into the query per `RAG-026`, enforce via RLS per `RAG-043` |
| Treating retrieved chunk text as trusted prompt content | Indirect prompt injection from a poisoned document can hijack agent behavior | Structurally separate context from instructions per `RAG-044` |
| Shipping a RAG feature with no golden set or CI eval gate | Chunking/embedding/reranker changes silently regress quality with no detection until a client notices | Golden set + CI gate per `RAG-039`–`RAG-041` |
| Assuming a long-context model removes the need for retrieval | Linear per-call token cost, no citation provenance, degraded needle-in-haystack accuracy at scale | RAG remains default per `RAG-001`/`RAG-002`; long context only widens the post-retrieval budget |
| Reaching for a managed vector DB before hitting any documented trigger | Adds infra/ops cost and migration risk with no quality or scale benefit yet needed | Apply the numeric triggers in `RAG-048` before migrating |
| Using MTEB leaderboard rank alone to pick an embedding model for an Arabic corpus | MTEB multilingual score does not guarantee in-language Arabic quality | Validate on an in-language Arabic eval subset per `RAG-021` |

## Definition of Done

- [ ] Ingestion implemented as separate connector/parser/loader stages with idempotency keys (`RAG-007`), running as background jobs, not inline requests (`RAG-008`)
- [ ] Parser tiering in place and tested against clean, table-heavy, and scanned document samples (`RAG-009`)
- [ ] Exact + near-duplicate deduplication implemented (`RAG-011`); incremental sync via native change signals with hash fallback (`RAG-012`); deletes/version changes cascade transactionally (`RAG-013`)
- [ ] Chunking uses structure-aware recursive strategy at 400–800 tokens with contextual headers prepended before embedding and full-text indexing (`RAG-014`, `RAG-015`); tables/code never split across chunks (`RAG-017`)
- [ ] Embedding model chosen and documented with fallback; Arabic/multilingual quality validated on an in-language eval subset if applicable (`RAG-018`, `RAG-021`)
- [ ] Drizzle schema and DDL match the canonical structure; HNSW index built with documented parameters; RLS enabled on `documents` and `chunks` (`RAG-023`, `RAG-024`, `RAG-027`)
- [ ] Hybrid search (HNSW + full-text) fused via RRF; metadata filters pushed into the query (`RAG-025`, `RAG-026`)
- [ ] Reranking stage in place with a named default provider; token budget for context assembly enforced; MMR/diversity applied; provenance carried end-to-end (`RAG-031`, `RAG-033`, `RAG-034`, `RAG-035`)
- [ ] Generation enforces structured, cited output with an explicit insufficient-evidence refusal path and an automated groundedness check (`RAG-036`–`RAG-038`)
- [ ] Golden question set (≥50 questions, English + Arabic subset if applicable) built and passing the committed thresholds in `RAG-040`; CI regression gate wired in (`RAG-039`, `RAG-041`)
- [ ] Production tracing sampling live traffic into the eval pipeline for drift detection (`RAG-042`)
- [ ] ACL-aware retrieval enforced in SQL via RLS, not prompt instructions or post-filtering (`RAG-043`); retrieved content treated as untrusted with prompt-injection mitigations in place (`RAG-044`)
- [ ] PII classified/redacted at ingestion; data-flow/residency diagram documented naming every external API's processing region (`RAG-045`, `RAG-046`)
- [ ] Scale-up decision matrix consulted and cited if any managed vector DB/RAG service is proposed (`RAG-048`)

## Handoff notes

- Paste this file's Core decisions table and the Mermaid diagram (`RAG-005`) as the first context block when asking Claude to design a new RAG feature — it fixes the architecture before any code is written.
- Attach the Drizzle schema and DDL (`RAG-023`) verbatim to any Replit Agent implementation task; do not let the agent regenerate the schema from scratch.
- When commissioning ingestion work, specify the parser tier expected for the actual document sample set (`RAG-009`) — do not leave parser choice to the agent's default.
- Always include the RAG Design Spec (below) filled in by the consultant before handing a RAG build to Claude or Replit Agent for implementation.
- Flag `RAG-046` (residency) explicitly to the client whenever the corpus includes government, financial, or PDPL/Regulation-10-covered personal data — this is a first-order risk even at prototype stage per [05 — Regulated Sector source](../../research/05-regulated.md).

---

## RAG Design Spec template

*The consultant fills in this section during Stage 2 (spec) for every RAG feature. Copy this block into the feature's spec document; do not leave fields blank — write "N/A, because <reason>" if a field does not apply.*

```markdown
### RAG Design Spec — <feature name>

**1. Retrieval decision** — Why RAG, not long-context/tool-call/loop-only (RAG-001–004); corpus size and 12-month growth.

**2. Corpus and sources** — Connectors (RAG-007); doc types and volume per parser tier, Tier 1/2/3 % (RAG-009); change-detection signal (RAG-012); languages present and RTL requirement (RAG-047).

**3. Chunking** — Size/overlap and justification if off-default (RAG-014); contextual header model (RAG-015); parent-document retrieval Y/N + why (RAG-016); table/code-heavy content handling (RAG-017).

**4. Embeddings** — Model chosen (RAG-018); dimensionality/quantization (RAG-019–020); Arabic/multilingual validation plan and result (RAG-021).

**5. Storage and indexing** — Expected chunk count at 12 months (feeds RAG-048 trigger); multi-tenant Y/N and RLS fields beyond tenant_id (RAG-027, RAG-043); sensitivity levels/ACL tags needed (RAG-045).

**6. Query and generation** — Query complexity distribution and router plan (RAG-029–030); reranker (RAG-031); token budget (RAG-033); citation/RTL UI requirements (RAG-035, RAG-047).

**7. Evaluation** — Golden set size and source, manual vs. synthetic split (RAG-039); any deviation from RAG-040 thresholds, with sign-off.

**8. Security and residency** — Data classification/residency statement (RAG-046); PII types and redaction approach (RAG-045); named accountable owner, studio side and client side.

**9. Scale plan** — Which RAG-048 matrix row applies today, and the trigger that would change it.

**10. Known gaps** — Explicitly deferred items and remediation plan, per the compliance-ready prototype bar ([Regulated-sector source, §4](../../research/05-regulated.md)).
```

---

## Sources

- [Anthropic — Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval) — contextual chunk headers, reported failure-rate reductions, cost
- [pgvector GitHub — official README](https://github.com/pgvector/pgvector) — HNSW/IVFFlat parameters, halfvec, binary quantization
- [Tiger Data — hybrid search with BM25 and vector similarity](https://www.tigerdata.com/docs/build/examples/hybrid-search) — hybrid search rationale
- [Pradeep Bhandari — pgvector multi-tenancy RLS guide](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide) — RLS-based tenant isolation
- [Reducto — Document Parsing API](https://llms.reducto.ai/document-parsing-api) — parser tiering, accuracy benchmarks
- [Unstructured-IO/unstructured GitHub](https://github.com/Unstructured-IO/unstructured) — OSS parsing library
- [Reranker for RAG: Cohere, BGE, Jina, Voyage Compared](https://ianas.fr/en/blog/2026/06/07/reranker-comparatif-cohere-bge-jina-voyage/) — reranker comparison
- [Jina Embeddings v4 / late interaction (ACL 2025)](https://aclanthology.org/2025.mrl-main.36.pdf) — multilingual/multimodal embedding notes
- [MTEB leaderboard comparison](https://app.ailog.fr/en/blog/guides/choosing-embedding-models) — embedding model scores
- [Microsoft GraphRAG — official docs](https://microsoft.github.io/graphrag/) — GraphRAG query modes and adoption criteria
- [RAG Pipeline Security: Hardening Retrieval-Augmented Generation](https://www.systemshardening.com/articles/ai-landscape/rag-pipeline-security/) — prompt injection attack surfaces
- [Atlan — Enterprise RAG Platforms Comparison 2026](https://atlan.com/know/enterprise-rag-platforms-comparison/) — managed vector DB/RAG service landscape
- [Turbopuffer — official site](https://turbopuffer.com/) — large-scale vector store option
- [Future AGI — RAG Evaluation Metrics 2026](https://futureagi.com/blog/rag-evaluation-metrics-2025/) — retrieval/generation metric definitions
- [Crux Digits — From Offline Test Set to Production: RAG Retrieval Quality](https://cruxdigits.nl/blog/rag-evaluation-retrieval-quality/) — recall/MRR diagnostic pattern
- [Shayan Geek — Deduplicating Documents at Scale](https://shayangeek.com/en/deduplicating-documents-at-scale/) — dedup approach
- [Regulated-sector research brief, §1, §3, §4, §5](../../research/05-regulated.md) — PDPL/Regulation 10 cross-border basis, PII/residency controls, compliance-ready prototype bar, Replit residency constraints
