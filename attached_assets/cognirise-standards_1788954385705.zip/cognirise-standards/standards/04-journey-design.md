---
id: journey-design
domain: Journey & Service Design
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 04. Journey Design

> **Purpose.** Give agentic products a journey model that survives non-determinism — outcomes and checkpoints stay stable even though the agent's path to them varies run to run.
> **Read this when.** Research brief and spec stages, before any UI/UX or agent-architecture work begins; revisit at QA to write eval cases from the same artifacts.

## Scope

- In scope: JTBD framing, service blueprints with a human/agent line of agency, task decomposition, first-run vs. steady-state trust arcs, per-tool autonomy levels, escalation/handoff design and SLAs, failure-path journeys, and the mandatory journey artifact set (journey map, blueprint, Mermaid state machine, Mermaid sequence diagram, Gherkin scenarios).
- Out of scope: UI rendering of any of these artifacts — see [05 — UI/UX for Agentic Apps](./05-ux-ui.md). Agent orchestration internals (workflow patterns, tool design, multi-agent topology) — see 07 — Agent Architecture. Guardrail and approval mechanics beyond the journey layer — see the HITL and guardrails standards.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Journey unit of analysis | The **job** (JTBD), not the screen flow or conversation transcript | Agent paths vary per run; outcomes and checkpoints must not |
| Autonomy declaration | Per **tool**, not per product or session | A single agent mixes low- and high-risk actions; a global slider either over- or under-restricts |
| Escalation trigger | Systemic (threshold/domain/pattern/regulatory), never self-assessed by the agent | Self-reported confusion is unauditable and inconsistent |
| Human handoff / checkpoint distinction | Checkpoint (pause, resume) is the default; escape hatch (terminal handoff) only for unrecoverable failure | Preserves partial progress and user trust |
| Mandatory artifact set per job type | Journey map + service blueprint + Mermaid `stateDiagram-v2` + Mermaid `sequenceDiagram` + Gherkin `.feature` file | Each artifact is machine-readable and becomes eval-case input |
| Trust arc | Two explicit modes: first-run (low autonomy, over-explain) and steady-state (reduced friction, exception-only surfacing) | Trust must be earned and observed, not assumed at ship time |

## Rules

### Job framing and decomposition

**`JRN-001` — Model every journey around a job, not a screen flow** · `MUST`
Define each journey by its job-to-be-done: the outcome the user is hiring the agent to accomplish, expressed as a `desired_outcome` and a set of `success_criteria`, independent of the specific conversational or tool-call path the agent takes to get there.
- *Why:* the agent's internal path is non-deterministic between runs; a fixed screen-by-screen journey map cannot describe it and produces acceptance criteria that fail on every valid but different trajectory.
- *How:* persist a `jobs` table (`job_type`, `desired_outcome`, `success_criteria` JSONB, `status` enum `not_started | in_progress | needs_human | done | failed`) separate from the raw message/event log, per the [journeys and agents research](../../research/03-journeys-and-agents.md) A.1 pattern.
- *Check:* every job type in the product has a corresponding `jobs` row schema and at least one Gherkin scenario file (JRN-016) referencing its `job_type`.

**`JRN-002` — Decompose tasks to a deliberate granularity, never by default** · `MUST`
Choose flat decomposition (independent subtasks run in parallel) for low-interdependency jobs, and hierarchical decomposition (goal → sub-goals → delegated sub-agents) for ambiguous, complex jobs. Reject both a single giant subtask and micro-tasks numbering beyond what a human reviewer could sanity-check in one sitting.
- *Why:* "a plan with one giant sub-task is no better than no plan at all... twenty micro-tasks overwhelms the context window and adds overhead."
- *How:* emit a structured `plan_steps` table (`id`, `description`, `depends_on[]`, `status`) from the planning step; this becomes both the durable execution ledger and the progress-UI source of truth (see [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-004).
- *Check:* `plan_steps` row count per job falls inside a reviewed range (typically 3–12); any plan outside that range requires an explicit design note.

### Service blueprint and line of agency

**`JRN-003` — Blueprint every job with a line of visibility and a line of agency** · `MUST`
Produce a service blueprint per job type mapping customer actions, frontstage actions, backstage agent/tool actions, and support processes across time — classical service-design swimlanes — then add a second boundary, the **line of agency**, marking which backstage actions the agent may take autonomously versus which require a human to approve.
- *Why:* the service blueprint is the standard tool for forcing explicit frontstage/backstage/support-process ownership; agentic systems need a second boundary because "agent" is a new kind of actor that can occupy either side of the line of visibility.
- *How:* maintain the blueprint as a living Markdown + Mermaid artifact at `docs/service-blueprint/<job-type>.md`, swimlanes: User / Agent (frontstage) / Agent (backstage: tool calls) / Human-in-the-loop / External system.
- *Check:* every backstage step in the blueprint has an explicit actor annotation (`agent-auto`, `agent-checkpoint`, `human`); no step is left unannotated.

**`JRN-004` — Encode the line of agency as a per-tool risk tier in code, not just in the diagram** · `MUST`
Attach a `risk_tier` (`low | medium | high`) attribute to every tool definition; the blueprint's line-of-agency annotation and the code's `risk_tier` must be the same value, checked programmatically.
- *Why:* a blueprint that says "human approves" but code that executes autonomously is a documentation lie that regulators and auditors will find.
- *How:* store `tool_policies (tool_name, min_autonomy_tier, risk_tier)`; add a CI check that diffs blueprint annotations against `tool_policies` rows.
- *Check:* CI job fails if any tool's `risk_tier` diverges from its blueprint annotation.

### Trust arcs

**`JRN-005` — Design first-run and steady-state as two distinct, declared experience modes** · `MUST`
First-run: over-explain, show the plan before acting, force the lowest autonomy tier regardless of any stored trust signal, seek explicit confirmation before any consequential action, and demonstrate value on a low-risk task quickly. Steady-state: once trust is calibrated, reduce friction, batch confirmations, and surface only exceptions.
- *Why:* trust calibration and feedback loops are core design primitives distinct from prior reactive-assistant UX; over-trust is as harmful as under-trust.
- *How:* add a `trust_level` (int 0–3) per user, incremented by explicit "promote to autopilot" action or a rolling accept-rate over an `agent_actions` table (`accepted`/`rejected`/`modified`); store `first_run_complete` boolean; force `autonomy=assist` for a user's first N jobs regardless of stored `trust_level`.
- *Check:* a new user's first N job runs are provably capped at `assist` autonomy by inspecting `sessions.autonomy_mode` history; `trust_level` only increases via a logged event, never silently.

**`JRN-006` — Log every autonomy override as a trust signal** · `MUST`
Every time a user manually overrides the system-suggested autonomy tier (up or down), log the override with job type and tool name; treat override frequency as the primary steady-state trust signal, not a vanity metric.
- *Why:* override frequency is the observed accept-rate that the trust arc (JRN-005) is gated on — without logging it, `trust_level` promotion has no evidentiary basis.
- *How:* write to `agent_actions` on every override with `outcome` and `previous_tier`/`new_tier`.
- *Check:* `agent_actions` table has non-zero rows for any user above `trust_level` 0.

### Autonomy levels

**`JRN-007` — Declare autonomy per tool, never per product or session alone** · `MUST NOT` (declaring a single global autonomy setting as the only control)
Every tool carries its own `min_autonomy_tier`; a session-level autonomy mode (assist/co-pilot/autopilot) is a ceiling applied on top of, not a replacement for, per-tool policy.
- *Why:* Azure's architecture guidance scopes human-in-the-loop gates "to specific tool invocations rather than full agent outputs so orchestration can proceed autonomously for low-risk actions" — autonomy is tool-scoped, not global.
- *How:* at execution time, check `min(session.autonomy_mode, tool_policies.min_autonomy_tier)`; if the tool's risk exceeds what the resolved mode allows, insert a `pending_approvals` row and pause (see JRN-010).
- *Check:* a session in `co-pilot` mode still pauses on every `high` risk-tier tool call; automated test asserts this per tool.

**`JRN-008` — Define the three autonomy tiers with unambiguous behavioral contracts** · `MUST`
- **Assist**: agent drafts/suggests only; the human performs the action.
- **Co-pilot**: agent performs reversible/low-risk actions automatically; every medium/high-risk action pauses at a checkpoint for approval.
- **Autopilot**: agent executes end-to-end within a bounded, pre-approved scope, with post-hoc audit rather than pre-approval, and automatic escalation the instant it leaves that scope.
- *Why:* production analysis of 240 LLM/agent deployments found 40.4% used human-in-the-loop by deliberate design, and well-designed systems route only 10–15% of queries to a human — autonomy tiers must be precise enough to hit that ratio deliberately, not accidentally.
- *How:* implement as an enum on `sessions.autonomy_mode`; the tier's contract (not its label) determines pause behavior — never let a UI label diverge from the enforced behavior.
- *Check:* three fixture jobs, one per tier, each demonstrate the exact contracted pause/no-pause behavior in an integration test.

**`JRN-009` — Autopilot requires a declared, bounded scope and automatic escalation on scope exit** · `MUST`
Define autopilot's bounded scope explicitly (job types, tools, dollar/data thresholds) at the time it is granted; any tool call or job condition outside that scope automatically demotes the run to a checkpoint, it does not proceed autonomously "this once."
- *Why:* autopilot without a bounded, checked scope is unlabeled full autonomy — the single highest-risk state a regulated client will flag first.
- *How:* store scope as a JSONB policy on the autopilot grant; check every tool call and job attribute against it before execution.
- *Check:* a test job that starts in-scope and then triggers an out-of-scope tool call is provably intercepted before execution, not after.

### Escalation, handoff, and SLAs

**`JRN-010` — Distinguish a checkpoint from an escape hatch** · `MUST`
A **checkpoint** pauses the run, lets a human decide, and resumes the same run with guidance. An **escape hatch** hands off completely and ends the workflow. Default to checkpoints for anything reversible; reserve escape hatches for terminal failures only.
- *Why:* defaulting to escape hatches discards partial progress and forces users to restart, which is the single most trust-destroying failure mode in agentic products.
- *How:* checkpoints write to `pending_approvals` and pause; the same run resumes on approval. Escape hatches set `jobs.status = 'failed'` and surface a distinct terminal UI state (see [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-XXX error states).
- *Check:* count of jobs resolved via checkpoint vs. escape hatch is tracked; escape-hatch rate above a reviewed threshold triggers a design review.

**`JRN-011` — Escalation triggers must be systemic, never self-assessed by the agent** · `MUST NOT` (letting the agent decide unilaterally whether it is confused)
Define escalation triggers as one or more of: threshold-based (confidence below a cutoff), domain-based (dollar amount, data sensitivity), pattern-based (novel/unusual input), and regulatory (anything requiring an audit trail). The system, not the agent's self-report, decides when human review is required.
- *Why:* "the agent does not decide whether it is confused. The system defines when human review is required" — self-assessed uncertainty is an unreliable, unauditable escalation trigger.
- *How:* implement each trigger as a deterministic code check evaluated after each plan step, independent of any model-generated confidence claim; log which trigger fired.
- *Check:* every escalation event in the audit log names a specific systemic trigger; zero escalations are logged with only a model self-report as the cause.

**`JRN-012` — Hand off with rich context, never a bare notification** · `MUST`
When escalating, populate a `handoff_context` payload containing the original request, actions already taken, data retrieved, and the specific decision needed, so the human reviewer does not re-query the agent or start from scratch.
- *Why:* rich-context handoff is a documented effective HITL pattern; a bare "needs review" notification forces re-derivation of context the system already has.
- *How:* snapshot `plan_steps`, tool-call results, and session state into `pending_approvals.handoff_context` (JSONB) at the moment of escalation.
- *Check:* a human reviewer can resolve a pending approval without querying any other system or the agent again — verified by review-time instrumentation.

**`JRN-013` — Enforce escalation SLAs with a scheduled sweep and a documented safe default** · `MUST`
Every `pending_approvals` row carries a `sla_deadline`. A scheduled job sweeps for rows past deadline and applies a pre-configured safe default per risk tier (e.g., auto-reject high-risk, auto-approve-with-flag for stale low-risk), then notifies.
- *Why:* an approval queue with no timeout policy becomes an unbounded liability queue; explicit safe defaults make the failure mode of an unattended queue predictable and reviewable rather than silent.
- *How:* a cron/Scheduled Deployment sweep (e.g., every 5 minutes) checks `sla_deadline < now()` and `status = 'pending'`, applies the default, writes `resolution_note`, and notifies the accountable owner.
- *Check:* no `pending_approvals` row remains `pending` past `sla_deadline` for longer than one sweep interval, verified by a monitoring query.

**`JRN-014` — Track escalation rate as a tuned, monitored system property** · `SHOULD`
Log every checkpoint decision; review escalation-rate and escalation-accuracy monthly and refine triggers (JRN-011) based on observed outcomes, treating the escalation policy as a living system, not a one-time prompt instruction.
- *Why:* documented practice shrank human-review share from 10–15% down to 8–10% over time purely by refining escalation criteria against logged outcomes.
- *How:* a monthly report over `agent_actions`/`pending_approvals` broken down by trigger type and resolution outcome.
- *Check:* a dated review artifact exists showing escalation-rate trend and at least one trigger tuning decision per quarter, once in production.

### Failure-path journeys

**`JRN-015` — Author a failure-path journey for every job type, not only the happy path** · `MUST`
For each job type, design and document at minimum: the happy path, one ambiguous/needs-clarification path, and one failure/escalation path, each with its own service-blueprint swimlane annotations and its own terminal UI state.
- *Why:* failure is a first-class, expected mode for probabilistic systems, not an edge case; a journey model that only covers the happy path cannot be tested or trusted.
- *How:* every `docs/journeys/<job-type>.md` file must contain sections for all three paths; each maps to a Gherkin scenario (JRN-016).
- *Check:* every job type has ≥3 Gherkin scenarios covering happy/ambiguous/failure paths; CI fails a job-type addition without all three.

### Mandatory artifact set

**`JRN-016` — Ship the full artifact set per job type: journey map, blueprint, state machine, sequence diagram, Gherkin** · `MUST`
Every job type in scope for a Cognirise prototype ships, in the repo, as plain text: (1) a journey map summarizing outcome milestones, (2) the service blueprint (JRN-003), (3) a Mermaid `stateDiagram-v2` of the agent's control flow, (4) a Mermaid `sequenceDiagram` per scenario showing exact actor-to-actor calls including pause/resume points, and (5) a Gherkin `.feature`-style file with Given/When/Then scenarios covering happy, ambiguous, and failure paths.
- *Why:* traditional linear journey maps under-represent branching and non-determinism; this five-artifact set is text-based, diff-able in git, directly consumable by an LLM code-generator, and directly convertible into eval cases — no artifact is redundant with another.
- *How:* one folder per job type at `docs/journeys/<job-type>/` containing `journey-map.md`, `service-blueprint.md`, `state-machine.mmd`, `sequence-<scenario>.mmd`, `scenarios.feature`.
- *Check:* CI asserts all five files exist per registered job type before the job type can be marked implementation-ready.

**`JRN-017` — Keep the Mermaid state machine and the code state machine in lockstep** · `MUST`
Every state named in the `stateDiagram-v2` diagram must exist in the code's state enum/transition table, and vice versa; do not let the diagram drift into documentation-only status.
- *Why:* the diagram is meant to double as the literal implementation contract — drift defeats the purpose of using diagrams-as-code at all.
- *How:* add a unit test that parses the Mermaid states (or maintains a shared JSON/YAML source both the diagram and the code generate from) and asserts set equality against the code's state enum.
- *Check:* CI fails on any state present in one artifact and absent in the other.

**`JRN-018` — Write every Gherkin scenario so it becomes an eval case, not documentation** · `MUST`
Each Given/When/Then scenario must be translatable, without rewriting, into a row in the offline eval dataset (expected trajectory / expected outcome), per the evaluation standard.
- *Why:* specification-driven, test-first workflows measurably improve LLM code-generation reliability; Gherkin's structured natural language is parseable unambiguously by both a human reviewer and an LLM implementer, and by extension by an eval harness.
- *How:* each scenario's `Given`/`When`/`Then` maps to eval fields `setup`/`trigger`/`assertion`; store scenarios as `.feature` Markdown alongside a generated `eval-cases.jsonl` for the same job type — see the evaluation standard for the harness contract.
- *Check:* every scenario file has a corresponding row in `eval-cases.jsonl`; a script verifies 1:1 coverage and fails CI otherwise.

**`JRN-019` — Use event storming to define agent/sub-agent boundaries before writing the blueprint** · `SHOULD`
For multi-agent jobs, run an event-storming pass (domain events, commands, aggregates) before deciding how many agents/sub-agents are needed and what each owns; agent boundaries should follow bounded contexts, not an org chart or an arbitrary split of the plan.
- *Why:* applying event storming plus domain-driven design to multi-agent systems is a documented pattern for defining agent roles/boundaries aligned with business needs, and prevents boundary decisions that later require expensive re-architecture.
- *How:* run the workshop virtually (shared doc, sticky-note board) and capture the output as a short section in the job's `journey-map.md` before drafting the blueprint.
- *Check:* any job type with ≥2 agents/sub-agents has a documented event-storming rationale for the split, reviewable by a peer.

## Reference implementation

### Schema (Postgres / Drizzle)

```sql
CREATE TYPE job_status AS ENUM ('not_started','in_progress','needs_human','done','failed');
CREATE TYPE autonomy_tier AS ENUM ('assist','co_pilot','autopilot');
CREATE TYPE risk_tier AS ENUM ('low','medium','high');
CREATE TYPE approval_status AS ENUM ('pending','approved','rejected','expired');

CREATE TABLE jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_type TEXT NOT NULL,
  user_id UUID NOT NULL,
  desired_outcome TEXT NOT NULL,
  success_criteria JSONB NOT NULL,
  status job_status NOT NULL DEFAULT 'not_started',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE plan_steps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES jobs(id),
  description TEXT NOT NULL,
  depends_on UUID[] NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'queued',
  seq INT NOT NULL
);

CREATE TABLE tool_policies (
  tool_name TEXT PRIMARY KEY,
  min_autonomy_tier autonomy_tier NOT NULL,
  risk_tier risk_tier NOT NULL
);

CREATE TABLE pending_approvals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES jobs(id),
  tool_call_json JSONB NOT NULL,
  risk_tier risk_tier NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  sla_deadline TIMESTAMPTZ NOT NULL,
  status approval_status NOT NULL DEFAULT 'pending',
  handoff_context JSONB NOT NULL,
  resolved_by UUID,
  resolution_note TEXT
);

CREATE TABLE agent_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES jobs(id),
  tool_name TEXT NOT NULL,
  outcome TEXT NOT NULL, -- accepted | rejected | modified
  previous_tier autonomy_tier,
  new_tier autonomy_tier,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

### Mermaid `stateDiagram-v2` — canonical job control flow

```mermaid
stateDiagram-v2
    [*] --> Planning
    Planning --> Executing
    Executing --> AwaitingApproval: high-risk tool call
    AwaitingApproval --> Executing: approved
    AwaitingApproval --> Failed: rejected / SLA expired (safe default)
    Executing --> NeedsHuman: systemic escalation trigger
    NeedsHuman --> Executing: guidance provided (checkpoint)
    NeedsHuman --> Failed: escape hatch (terminal)
    Executing --> Done: success criteria met
    Failed --> [*]
    Done --> [*]
```

### Mermaid `sequenceDiagram` — checkpoint pause/resume

```mermaid
sequenceDiagram
    actor User
    participant Agent
    participant Tool
    participant Reviewer as Human Reviewer

    User->>Agent: submit job (desired_outcome)
    Agent->>Agent: plan (emit plan_steps)
    Agent->>Tool: low-risk tool call
    Tool-->>Agent: result
    Agent->>Agent: evaluate risk_tier of next step
    Agent->>Reviewer: pending_approval (handoff_context)
    Note over Agent,Reviewer: run paused, state persisted to Postgres
    Reviewer-->>Agent: approve / reject
    Agent->>Tool: execute approved action
    Tool-->>Agent: result
    Agent-->>User: job done / needs_human / failed
```

### Gherkin — worked example: UAE government benefits-eligibility re-verification (regulated sector)

This example instantiates JRN-016 for a regulated use case: a government social-services department agent that re-verifies a citizen's benefits eligibility annually, drawing on the [regulated-sector research](../../research/05-regulated.md) requirement for human oversight gates on any "citizen-impacting action" and structured decision records.

```gherkin
Feature: Annual benefits eligibility re-verification
  # job_type: benefits_reverification
  # Regulated: DIFC Reg. 10-style notice/register applies if hosted in DIFC scope;
  # federal PDPL cross-border transfer basis required for any non-UAE model API call.

  Scenario: Happy path — eligibility confirmed, co-pilot mode
    Given the citizen's income and household records are unchanged since last verification
    And the session autonomy_mode is "co_pilot"
    When the agent cross-checks income, residency, and household records against source systems
    Then the agent proposes "eligibility confirmed, no change" as a low-risk action
    And the action executes automatically because risk_tier is "low"
    And a decision_record is persisted with inputs, model/version, and rationale

  Scenario: Ambiguous — conflicting household size across two source systems
    Given household size differs between the civil registry and the social-services database
    When the agent detects the discrepancy
    Then the agent raises a Guidance checkpoint with both conflicting values shown
    And the workflow pauses awaiting a human reviewer's selection
    And the human's chosen value is written back with resolved_by and resolution_note

  Scenario: Escalation — income change reduces eligibility (regulatory + domain trigger)
    Given the citizen's re-verified income exceeds the eligibility threshold
    When the agent completes the eligibility calculation
    Then the agent creates a pending_approval row with risk_tier "high"
    And handoff_context includes the original request, prior eligibility status, and the calculation trail
    And the workflow does not notify the citizen of a benefits change until a human approves
    And if unresolved past sla_deadline, the safe default is "escalate to senior caseworker", never "auto-deny"

  Scenario: Failure — source system unavailable
    Given the civil registry API is unreachable after 3 retries
    When the agent cannot complete the eligibility check
    Then the agent sets job status to "needs_human" via a checkpoint, not an escape hatch
    And the citizen's current benefits remain unchanged pending manual verification
    And the caseworker queue shows this job as blocked with the specific failed dependency named
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Journey map as a fixed screen-by-screen flow | Cannot represent non-deterministic agent paths; breaks on the first valid-but-different trajectory | Model by job/outcome (JRN-001), use state machine + sequence diagram for control flow |
| Single global autonomy toggle for the whole product | Mixes low- and high-risk tools under one setting; either over-restricts or under-restricts | Per-tool `min_autonomy_tier` (JRN-007) |
| Agent self-reports "I'm not confident" as the escalation trigger | Unauditable, inconsistent, gameable | Systemic threshold/domain/pattern/regulatory triggers (JRN-011) |
| Escape-hatch-by-default on any uncertainty | Discards partial progress, forces restart, destroys trust | Checkpoint-by-default; escape hatch only for terminal failure (JRN-010) |
| Handoff notification with no context ("needs review") | Forces reviewer to re-derive context the system already has | Rich `handoff_context` snapshot (JRN-012) |
| Unbounded approval queue with no SLA | Becomes an invisible liability; failures are silent | Scheduled SLA sweep with documented safe default per risk tier (JRN-013) |
| Only documenting the happy path | Failure is treated as an edge case instead of a first-class journey | Author ambiguous + failure paths for every job type (JRN-015) |
| Mermaid diagrams that drift from the actual code state machine | Diagram becomes decorative documentation, not a contract | Lockstep test asserting state-set equality (JRN-017) |
| Autopilot granted without a bounded, checked scope | Unlabeled full autonomy — the top compliance red flag | Declared scope + automatic demotion on scope exit (JRN-009) |

## Definition of Done

- [ ] Every job type has a `jobs` schema entry and the full five-artifact set (JRN-016) committed to the repo.
- [ ] Every backstage blueprint step has an actor annotation, and it matches the corresponding `tool_policies.risk_tier` in code (JRN-004).
- [ ] First-run mode is provably forced to `assist` for a new user's first N jobs (JRN-005).
- [ ] Every tool has a `min_autonomy_tier` and `risk_tier`; no product-wide-only autonomy control exists (JRN-007).
- [ ] Every escalation trigger in the audit log names a systemic cause, never a bare model self-report (JRN-011).
- [ ] Every `pending_approvals` row has an `sla_deadline` and the scheduled sweep is deployed and tested (JRN-013).
- [ ] Every job type has ≥3 Gherkin scenarios (happy, ambiguous, failure) and each maps 1:1 to an eval-case row (JRN-018).
- [ ] The Mermaid state machine and code state enum pass the lockstep equality test (JRN-017).

## Handoff notes

- Attach the job type's full `docs/journeys/<job-type>/` folder (all five artifacts) when handing a feature to Claude or Replit Agent — the state machine and Gherkin file are sufficient for it to scaffold the control flow and test fixtures directly.
- State explicitly which autonomy tier the first release ships in per tool; do not let the implementer infer autonomy from prose.
- Flag any job type touching regulated/citizen/financial data and cross-reference the specific regulated-sector requirement it must satisfy (see [05-regulated.md](../../research/05-regulated.md)) alongside the journey artifacts.
- Pass the `tool_policies` table definition and the `pending_approvals`/SLA sweep design together — they are not implementable independently.

## Sources

- [Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents) — stopping conditions, checkpoint/transparency principles
- [Wikipedia: Service blueprint](https://en.wikipedia.org/wiki/Service_blueprint) — classical blueprint swimlane structure
- [InnoEdge AI Service Blueprint Builder](https://www.innoedge.com.hk/ai-design-thinking-and-innovation-agents-service-blueprint-builder/) — AI-extended blueprint pattern
- [Max Gherman, Planning & Task Decomposition notes](https://www.max-gherman.dev/design/anatomy-of-ai-agent/planning-and-task-decomposition/) — decomposition granularity rule
- [Palwe, UX strategies for agentive AI in 2025 and beyond](https://www.computersciencejournals.com/ijcai/article/189/6-2-40-536.pdf) — trust calibration and feedback loops
- [Applied AI, Human-in-the-Loop as Architecture](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/) — HITL production statistics, systemic escalation triggers, Approval/Guidance/Validation patterns
- [Microsoft / Azure Architecture Center, AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns) — tool-scoped gating, checkpoint state persistence
- [OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) — escalation triggers tied to failure threshold and high-risk actions
- [DZone, Designing Scalable Multi-Agent AI Systems](https://dzone.com/articles/multi-agent-ai-ddd-event-storming) — event storming for agent boundaries
- [Awesome Testing, Mermaid diagrams: When AI Meets Documentation](https://www.awesome-testing.com/2025/09/mermaid-diagrams) — diagrams-as-code, LLM-generatable Mermaid
- [arXiv, Understanding Specification-Driven Code Generation with LLMs](https://arxiv.org/html/2601.03878v1) — spec-driven, test-first LLM code generation
- [Replit, Deployment types](https://docs.replit.com/features/publishing/deployment-types) — Scheduled Deployment for SLA sweep
- [Regulated-sector readiness research brief](../../research/05-regulated.md) — human oversight gates, decision records, citizen-impacting action controls used in the worked example
