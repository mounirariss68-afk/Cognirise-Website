---
id: accessibility-i18n
domain: UX, Design & Human Factors
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 18. Accessibility & Internationalisation

> **Purpose.** Guarantee every prototype meets WCAG 2.2 AA, correctly exposes streaming/agentic UI to assistive technology, and treats Arabic/RTL as a first-class locale rather than a translation afterthought.
> **Read this when.** UI/component design, implementation of streaming and tool-call surfaces, i18n setup, pre-demo QA gate.

## Scope

- In scope: WCAG 2.2 AA baseline and the criteria AI surfaces most often fail, ARIA live-region patterns, keyboard operability of agent controls, screen-reader handling of tool-call timelines/citations, focus management during async updates, motion/reduced-motion, Arabic/RTL i18n, translation vs. locale-aware prompting, UAE government design-system expectations, and a testing matrix.
- Out of scope: general AI-state visual design tokens (see [06 — Design System](./06-design-system.md)), agent status/progressive-disclosure UX patterns beyond their accessibility exposure (see [05 — UI/UX for Agentic Apps](./05-ux-ui.md)), data-residency implications of localisation (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Accessibility floor | WCAG 2.2 Level AA on every citizen- or client-facing surface | Current TDRA/UAE Design System standard; satisfies both 2.1 AA and 2.2 AA federal references ([TDRA, UAE Design System](https://dgov.tdra.gov.ae/services/design-system-for-federal-governments-websites); [UAE National Policy for Digital Accessibility](https://assets.u.ae/api/public/content/84ec9317f73249c8a2594d76705d3c46?v=8a2f9df6)) |
| i18n library | `next-intl`, full RTL support | Canonical stack default (see `_CANON-CONVENTIONS.md`) |
| Arabic locale status | First-class, not a translated afterthought | Expected by UAE government and UAE Design System content guidelines ([UAE Design System](https://designsystem.gov.ae/)) |
| Streaming announcement | `aria-live="polite"` by default; `role="alert"`/`aria-live="assertive"` only for errors | Prevents interrupting screen-reader users mid-read while ensuring errors are not missed ([W3C ARIA19 Technique](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)) |
| Touch target size | Minimum 44×44px for approval/deny/stop controls; 24×24px CSS minimum per WCAG 2.5.8 | Approval controls are frequent, high-stakes taps ([designsystem.gov.ae, Accessibility guideline](https://designsystem.gov.ae/guidelines/accessibility)) |
| Text expansion budget | 30–40% extra space reserved for Arabic and other translated strings | Prevents clipping/overlap on locale switch ([DeveloperUX, 5 Challenges in Multilingual AI UX Design](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/)) |
| CSS layout model | Logical properties (`margin-inline-start`, `padding-inline-end`, etc.), never physical `left`/`right` | Only reliable way to mirror layout automatically for RTL |

## Rules

### WCAG 2.2 AA baseline and AI-surface failure points

**`A11Y-001` — Build to WCAG 2.2 AA on every prototype surface, not 2.1** · `MUST`
Treat WCAG 2.2 Level AA as the floor for all citizen-, client-, and government-facing UI, satisfying both federal policy documents that still cite 2.1 AA and the current TDRA/UAE Design System 2.2 reference.
- *Why:* Some federal policy still cites 2.1 AA as the floor while TDRA and designsystem.gov.ae reference 2.2 — building to 2.2 satisfies both ([UAE National Policy for Digital Accessibility](https://assets.u.ae/api/public/content/84ec9317f73249c8a2594d76705d3c46?v=8a2f9df6); [TDRA, UAE Design System](https://dgov.tdra.gov.ae/services/design-system-for-federal-governments-websites)).
- *How:* Run axe-core against every page/route in CI; treat any AA-level violation as a build-blocking failure.
- *Check:* `axe` CI job reports zero AA violations on the route list in the test plan.

**`A11Y-002` — Meet 2.4.11 Focus Not Obscured on every approval/streaming surface** · `MUST`
Ensure keyboard-focused approval-gate buttons and dialogs are never hidden behind a sticky streaming-response footer or floating status strip.
- *Why:* This is one of the WCAG 2.2 criteria most frequently failed by agentic UIs with persistent streaming footers ([W3C, What's New in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/)).
- *How:* Reserve a scroll-margin or z-index rule so any focused interactive element scrolls fully into view above sticky elements.
- *Check:* Playwright keyboard-navigation test tabs to every approval control and asserts it is not occluded by another element's bounding box.

**`A11Y-003` — Meet 2.5.8 Target Size (Minimum) on all approve/deny/stop/feedback controls** · `MUST`
Size approve, deny, stop-run, and thumbs up/down controls to at least 24×24 CSS px per WCAG 2.5.8, with 44×44px as the studio default for primary approval actions.
- *Why:* These are frequent, high-stakes taps where mis-taps have real consequences ([designsystem.gov.ae, Accessibility guideline](https://designsystem.gov.ae/guidelines/accessibility)).
- *How:* Encode as a Tailwind utility class/design token (`min-h-11 min-w-11` for primary actions) applied by the shared component library, not per-instance styling.
- *Check:* Visual regression test measures rendered control dimensions against the 44×44px default.

**`A11Y-004` — Provide a non-drag alternative for any reorderable plan step (2.5.7)** · `MUST`
If plan steps, checklist items, or agent task lists are reorderable via drag, provide button-based (move up/down) alternatives.
- *Why:* WCAG 2.2's Dragging Movements criterion; drag-only reordering excludes motor-impaired and screen-reader users ([W3C, What's New in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/)).
- *How:* Every drag-enabled list component ships paired "Move up"/"Move down" icon buttons with `aria-label`.
- *Check:* Keyboard-only test reorders a list item without triggering any pointer/drag event.

**`A11Y-005` — Never re-request information already collected earlier in a flow (3.3.7)** · `MUST`
Persist and reuse prior user inputs across a multi-step agent flow; do not re-prompt for data the agent already captured.
- *Why:* WCAG 2.2 Redundant Entry criterion; also wastes user effort and signals a broken agent memory model.
- *How:* Store collected fields in session/workflow state (Postgres-backed per the canonical stack); pre-fill or skip steps whose fields are already populated.
- *Check:* E2E test completes a multi-step flow and asserts no field is prompted twice.

**`A11Y-006` — Avoid CAPTCHA-style cognitive tests gating access to an AI feature (3.3.8/3.3.9)** · `MUST NOT`
Do not place a cognitive-function-test-based CAPTCHA between the user and an AI feature without an accessible alternative authentication path.
- *Why:* Blocks assistive-tech users and agent-assisted users from reaching the feature at all ([W3C, What's New in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/)).
- *How:* Prefer WebAuthn/passkey or email-link authentication; if CAPTCHA is contractually required, pair it with an accessible fallback (audio challenge, support-assisted verification).
- *Check:* Manual screen-reader pass confirms an alternative path exists to complete authentication.

**`A11Y-007` — Keep "how this AI works" help entry points in a consistent location (3.2.6)** · `MUST`
Place AI-disclosure/help entry points ("How this assistant works," limitations) in the same location across all pages of a given surface.
- *Why:* WCAG 2.2 Consistent Help criterion; also supports the AI-disclosure obligations in [17 — Data Governance & Compliance](./17-data-governance-compliance.md).
- *How:* Implement as a shared layout-level component, not a per-page custom placement.
- *Check:* Visual/DOM snapshot test confirms identical help-entry DOM position across sampled pages.

### ARIA live regions for streaming output and errors

**`A11Y-008` — Wrap streaming assistant output in `aria-live="polite"`** · `MUST`
Render the streaming response container with `aria-live="polite"` and `aria-atomic` set appropriately, present in the DOM at initial page load.
- *Why:* Screen readers only announce dynamically injected content correctly when the live region exists at load time; `polite` avoids interrupting the user's current reading ([W3C ARIA19 Technique](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)).
- *How:* Mount an empty `<div aria-live="polite" aria-atomic="false">` in the initial server-rendered HTML; stream content into it via the AI SDK's `useChat`.
- *Check:* Screen-reader manual pass (NVDA/VoiceOver) confirms incremental announcement without cutting off in-progress reading.

**`A11Y-009` — Use `role="alert"` / `aria-live="assertive"` only for errors and critical interruptions** · `MUST`
Reserve assertive live regions for error states and safety-critical interruptions; never use assertive for normal streaming content.
- *Why:* Assertive regions interrupt the screen reader immediately — overuse causes alert fatigue and drowns out genuine errors ([W3C ARIA19 Technique](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)).
- *How:* Separate DOM container for error/interrupt messages, distinct from the streaming-content container.
- *Check:* Automated test asserts only the error container carries `role="alert"`/`assertive`; the streaming container never does.

**`A11Y-010` — Batch live-region updates; do not re-announce the full growing message on every token** · `MUST`
Announce only completed sentences/chunks, not a re-read of the entire message on every streamed token.
- *Why:* Naive `aria-live` updates on every token cause the screen reader to restart reading from the top repeatedly, making the surface unusable.
- *How:* Debounce live-region text updates to sentence or paragraph boundaries (e.g., update on `. ` / `\n` detection) rather than per-token.
- *Check:* Manual screen-reader pass confirms announcements occur at sentence granularity, not per character/token.

**`A11Y-011` — Expose tool-call timelines to screen readers as a structured, navigable list, not a visual-only strip** · `MUST`
Mark up the agent activity timeline (status strip, expandable step cards) with semantic list/heading structure and `aria-label`s naming each step's verb and status.
- *Why:* Sighted users get a glanceable status strip; screen-reader users need equivalent structured access to the same information, not a silent `<div>` soup.
- *How:* Use `<ol>`/`<li>` for the timeline with each item's status exposed via `aria-label` (e.g., "Step 2 of 4: Reading 3 files — done").
- *Check:* Screen-reader pass navigates the timeline by list semantics and hears each step's verb + status.

**`A11Y-012` — Expose citations as discoverable, labeled links, not bare superscript markers** · `MUST`
Render inline citation markers as `<a>` elements with an accessible name identifying the source (not just "[1]"), reachable via standard link navigation.
- *Why:* Screen-reader users navigating by link list must be able to distinguish citation targets from each other without visual context.
- *How:* `<a href="#source-3" aria-label="Source 3: World Bank population data">[3]</a>`, paired with a visually hidden or on-screen source list.
- *Check:* Screen-reader link-list navigation announces a distinct, meaningful name for every citation.

### Keyboard operability of agent controls

**`A11Y-013` — Every agent control (approve, deny, stop, pause, edit-plan) must be reachable and operable by keyboard alone** · `MUST`
No agent control may be pointer-only; all controls must have a visible focus indicator and standard activation via Enter/Space.
- *Why:* Baseline WCAG 2.1.1 Keyboard requirement, frequently broken by custom AI-state components built without keyboard handlers.
- *How:* Build agent controls on native `<button>`/`<a>` elements or fully keyboard-annotated Radix primitives (per canonical stack shadcn/ui), never a bare `<div onClick>`.
- *Check:* Playwright keyboard-only test suite operates the full approval/stop/pause flow with no mouse events.

**`A11Y-014` — Maintain a visible focus indicator through every async state transition** · `MUST`
Keep a visible focus ring on the active control across loading, streaming, and error state transitions; never let focus silently drop to `<body>` on re-render.
- *Why:* Async re-renders common in streaming UIs frequently destroy and recreate DOM nodes, losing focus — a top AI-surface accessibility failure.
- *How:* Use React `key` stability on interactive elements across state transitions; if a node must remount, explicitly re-focus it via `ref.current.focus()`.
- *Check:* Playwright test triggers a streaming state change and asserts `document.activeElement` remains the expected control.

### Screen-reader handling of async updates and focus management

**`A11Y-015` — Move focus deliberately after a user-initiated action completes; never move focus on a background/agent-initiated update** · `MUST`
Shift focus to a newly revealed panel/result only when the user explicitly triggered it (e.g., clicked "Run"); background agent updates must not steal focus from the user's current position.
- *Why:* Unsolicited focus movement disorients screen-reader and keyboard users; this is a top failure mode in agentic UIs with autonomous background updates.
- *How:* Gate any `element.focus()` call behind a check for the triggering action's origin (user click vs. background poll/stream).
- *Check:* Screen-reader pass confirms focus stays put during a background agent update and moves only after explicit user action.

**`A11Y-016` — Announce task completion and errors for background/long-running jobs via a persistent status region** · `MUST`
For jobs exceeding ~15–30 seconds that run in the background, announce completion/error through a persistent `aria-live="polite"` status region (e.g., a notification-center entry), not only a visual toast.
- *Why:* Visual-only toasts are invisible to screen-reader users who have moved focus elsewhere during a long-running task.
- *How:* Route background-job completion events through the same live-region pattern as A11Y-008, scoped to a notifications container.
- *Check:* Screen-reader pass confirms job completion is announced without requiring the user to be focused on the job's origin page.

### Motion and reduced motion

**`A11Y-017` — Respect `prefers-reduced-motion` for all AI-state animation** · `MUST`
Disable or substantially reduce "thinking" pulses, shimmer, and streaming ellipsis animation when the user's OS/browser signals `prefers-reduced-motion: reduce`.
- *Why:* Baseline WCAG 2.3.3 consideration; AI-state motion vocabulary (see [06 — Design System](./06-design-system.md)) is exactly the kind of ambient animation this preference targets.
- *How:* CSS media query `@media (prefers-reduced-motion: reduce) { .ai-state-pulse { animation: none; } }`; replace with a static label change instead.
- *Check:* Visual regression test with the media feature forced confirms animation classes are suppressed.

**`A11Y-018` — Stop all AI-state motion within one frame of the underlying activity stopping** · `MUST`
Never leave a "thinking" or "streaming" animation looping after the agent has finished or errored.
- *Why:* Orphaned looping animation signals false liveness and is disorienting for users relying on motion as a status cue.
- *How:* Tie animation class application directly to the AI-state token (`idle`/`thinking`/`streaming`/`done`/`error`) as a single source of truth, not an independent timer.
- *Check:* Automated test asserts the animation class is removed within one render cycle of the state transitioning to `done`/`error`.

### Internationalisation — Arabic as a first-class locale

**`A11Y-019` — Ship Arabic as a fully parallel locale, not a translated label pass** · `MUST`
Provide Arabic content parity (not just translated UI chrome) for any citizen- or government-facing surface, including agent-generated content, error messages, and help text.
- *Why:* Expected by UAE government and consistent with UAE Design System content guidelines ([UAE Design System](https://designsystem.gov.ae/)).
- *How:* Route all user-facing strings through `next-intl` message catalogs; treat missing-Arabic-string as a build warning, not a silent English fallback in production builds for government clients.
- *Check:* CI script diffs the `en` and `ar` message catalogs and fails on missing keys for government-client builds.

**`A11Y-020` — Use CSS logical properties exclusively for directional layout** · `MUST`
Write all spacing, border, and positioning rules with logical properties (`margin-inline-start`, `padding-inline-end`, `border-start-start-radius`, `inset-inline-start`) instead of physical `left`/`right`/`margin-left`, etc.
- *Why:* Logical properties automatically mirror for `dir="rtl"` without duplicated CSS or JS-based flipping logic.
- *How:* Enforce via a stylelint rule banning physical directional properties in Tailwind config/custom CSS; Tailwind's RTL-aware utilities (`ms-*`, `me-*`, `ps-*`, `pe-*`) replace `ml-*`/`mr-*`/`pl-*`/`pr-*`.
- *Check:* Lint job fails on any `margin-left`/`margin-right`/`left:`/`right:` usage outside an explicitly justified exception file.

**`A11Y-021` — Set `dir="rtl"` and `lang="ar"` at the document root for Arabic sessions, not per-component** · `MUST`
Apply direction and language attributes at the `<html>` root based on the active locale; never apply RTL styling piecemeal per component.
- *Why:* Root-level `dir` ensures native browser bidi algorithm, form controls, and scrollbars behave correctly; piecemeal RTL causes mixed-direction bugs.
- *How:* `next-intl` locale-aware root layout sets `<html lang={locale} dir={locale === 'ar' ? 'rtl' : 'ltr'}>`.
- *Check:* E2E test switches locale to Arabic and asserts `document.documentElement.dir === 'rtl'`.

**`A11Y-022` — Isolate embedded LTR content (code, numerals, English brand names) inside RTL text with Unicode isolation** · `MUST`
Wrap embedded LTR fragments (code snippets, URLs, English proper nouns) inside Arabic paragraphs with `<bdi>` or `unicode-bidi: isolate` to prevent bidi algorithm corruption.
- *Why:* Mixed bidirectional text without isolation reorders punctuation and embedded Latin-script tokens incorrectly, a common failure in agent-generated bilingual output.
- *How:* Render any code block, tool name, or citation URL inside Arabic response text with `<bdi>{value}</bdi>`.
- *Check:* Visual regression test on a mixed Arabic/English agent response confirms correct token order and punctuation placement.

**`A11Y-023` — Use Arabic-Indic or Western Arabic numerals consistently per locale convention, and always use the Gregorian or Hijri calendar the client specifies** · `MUST`
Confirm with the client which numeral system (Western Arabic ٠-٩ vs. Eastern Arabic 0-9) and calendar (Gregorian/Hijri) their audience expects, and apply it consistently via `Intl.NumberFormat`/`Intl.DateTimeFormat` with the `ar` locale and explicit `numberingSystem`/`calendar` options.
- *Why:* UAE government content commonly uses Western Arabic numerals with the Gregorian calendar, but this is not universal across GCC audiences — an unconfirmed default causes real content errors, not just cosmetic ones.
- *How:* `new Intl.NumberFormat('ar-AE', { numberingSystem: 'latn' })`; `new Intl.DateTimeFormat('ar-AE', { calendar: 'gregory' })`; store the confirmed choice in the project's i18n config.
- *Check:* Snapshot test confirms numeral/date rendering matches the client-confirmed convention.

**`A11Y-024` — Select an Arabic-optimized typeface with adequate glyph coverage and diacritic support** · `MUST`
Use a font stack with verified Arabic script support (e.g., Noto Sans Arabic, IBM Plex Sans Arabic, or the client's mandated government typeface) rather than relying on system fallback.
- *Why:* Generic Latin-first web fonts frequently render Arabic with poor letterform joining or missing diacritics, damaging perceived quality and legibility.
- *How:* Load a verified Arabic font via `next/font` alongside the Latin font, pairing them in the design token set; test rendering at body-text size for joining correctness.
- *Check:* Visual review confirms correct letter joining and diacritic rendering in a full Arabic paragraph sample.

**`A11Y-025` — Budget 30–40% extra layout space for Arabic and other translated strings** · `MUST`
Size buttons, labels, chat bubbles, and form fields with auto-resizing/flexible containers, not fixed pixel widths tuned only to English string length.
- *Why:* Arabic and other translated strings routinely run 30–40% longer than English source strings; fixed-width containers clip or overlap ([DeveloperUX, 5 Challenges in Multilingual AI UX Design](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/)).
- *How:* Use `min-w-fit`/flexible flex/grid layouts; run a pseudo-localization pass (artificially expand strings by 40%) before every locale-sensitive UI ships.
- *Check:* Automated pseudo-localization test renders every screen at +40% string length and asserts no clipping/overlap via visual regression.

**`A11Y-026` — Distinguish translating model output from locale-aware prompting; prefer the latter for generation, the former only for fixed UI strings** · `MUST`
For agent-generated content, instruct the model to generate directly in the target locale (locale-aware prompting) rather than generating in English and machine-translating the output; reserve string translation for fixed UI chrome.
- *Why:* Post-hoc translation of generated content loses register, cultural appropriateness, and often mistranslates domain terms; native-locale generation with a capable Arabic-fluent model produces materially better output.
- *How:* Pass the target locale into the system prompt's `<output_language>` directive and instruct the model to compose natively in Arabic when `locale === 'ar'`, rather than piping English output through a translation API.
- *Check:* Eval suite (see [15 — Evaluation](./15-evaluation.md)) includes Arabic-locale test cases scored for fluency/register, not just literal accuracy against a translated reference.

**`A11Y-027` — Verify the selected model/embedding stack has adequate Arabic capability before committing to it for citizen-facing use** · `MUST`
Confirm Arabic language quality (dialect handling, MSA fluency, embedding retrieval accuracy) for any model or embedding model used in a citizen-facing Arabic surface before architecture sign-off.
- *Why:* Model Arabic capability varies significantly by provider and is a first-order UX quality risk for the priority government/GCC use case.
- *How:* Run a small Arabic-specific eval set (see [15 — Evaluation](./15-evaluation.md)) against candidate models during model-selection (see [07 — Agent Architecture](./07-agent-architecture.md)) before committing.
- *Check:* Model-selection ADR references an Arabic-quality eval score, not just an English-language benchmark.

### UAE government design-system expectations

**`A11Y-028` — Align government-facing prototypes with the UAE Design System's accessibility guideline defaults** · `MUST`
Apply the UAE Design System's concrete component requirements: minimum 44×44px touch targets, 24–32px minimum icon sizes, tested color-contrast ratios, full keyboard navigability with visible focus states, captions/WebVTT for video, and ARIA labeling per component.
- *Why:* This is the mandatory reference for federal government websites and the accessibility bar TDRA reviewers apply ([designsystem.gov.ae, Accessibility guideline](https://designsystem.gov.ae/guidelines/accessibility); [TDRA FAQ](https://designsystem.gov.ae/resources/frequently-asked-questions)).
- *How:* Adopt the UAE Design System's component specs as the base Tailwind/shadcn token overrides for any government-client project (see [06 — Design System](./06-design-system.md)).
- *Check:* Component audit checklist cross-references each UAE Design System requirement against the implemented component library.

## Reference implementation

```tsx
// app/[locale]/layout.tsx — root-level dir/lang per A11Y-021
import { NextIntlClientProvider } from "next-intl";

export default async function LocaleLayout({
  children,
  params: { locale },
}: {
  children: React.ReactNode;
  params: { locale: "en" | "ar" };
}) {
  const dir = locale === "ar" ? "rtl" : "ltr";
  return (
    <html lang={locale} dir={dir}>
      <body>
        <NextIntlClientProvider locale={locale}>{children}</NextIntlClientProvider>
      </body>
    </html>
  );
}
```

```tsx
// StreamingAnswer.tsx — live region pattern per A11Y-008/009/010
export function StreamingAnswer({ text, isError }: { text: string; isError: boolean }) {
  return (
    <>
      <div aria-live="polite" aria-atomic="false" className="sr-announce-region">
        {/* update only at sentence boundaries, not per token */}
        {getAnnouncedSentences(text)}
      </div>
      <div aria-hidden={false} className="answer-body">
        {text}
      </div>
      {isError && (
        <div role="alert" aria-live="assertive">
          Something went wrong retrieving this answer. Try again or contact support.
        </div>
      )}
    </>
  );
}
```

```css
/* Logical properties per A11Y-020 — mirrors automatically under dir="rtl" */
.approval-card {
  padding-inline: 1rem;
  margin-inline-start: 0.5rem;
  border-start-start-radius: 0.5rem;
}

@media (prefers-reduced-motion: reduce) {
  .ai-state-pulse,
  .ai-state-shimmer {
    animation: none !important;
  }
}
```

```typescript
// Locale-aware prompting per A11Y-026
function buildSystemPrompt(locale: "en" | "ar") {
  return `
<output_language>
Respond natively in ${locale === "ar" ? "Modern Standard Arabic" : "English"}.
Do not translate from English internally — compose directly in the target language.
</output_language>
`;
}
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| `aria-live="assertive"` on the main streaming container | Interrupts screen-reader reading on every update; alert fatigue | `polite` for streaming, `assertive`/`role="alert"` only for errors (A11Y-008/009) |
| Re-announcing the full message on every token | Screen reader restarts reading from the top repeatedly | Batch announcements at sentence/paragraph boundaries (A11Y-010) |
| Physical `left`/`right`/`margin-left` CSS | Breaks mirroring under `dir="rtl"`, requires duplicated RTL overrides | Logical properties exclusively (A11Y-020) |
| Machine-translating English model output to Arabic | Loses register, mistranslates domain terms | Locale-aware prompting — generate natively in Arabic (A11Y-026) |
| Fixed-width buttons/labels sized to English string length | Arabic/translated strings clip or overlap | Flexible containers + pseudo-localization testing (A11Y-025) |
| Custom `<div onClick>` for approve/stop controls | Not keyboard operable, breaks WCAG 2.1.1 | Native `<button>`/keyboard-annotated Radix primitives (A11Y-013) |
| Background agent update silently steals keyboard focus | Disorients screen-reader/keyboard users mid-task | Focus moves only on explicit user-triggered actions (A11Y-015) |
| Bare `[1]` superscript citation markers | Screen-reader link list can't distinguish sources | Labeled `<a>` with descriptive `aria-label` (A11Y-012) |

## Definition of Done

- [ ] `axe` CI job passes with zero AA violations across the test route list (A11Y-001).
- [ ] Playwright keyboard-only suite operates approve/deny/stop/pause without mouse events (A11Y-013).
- [ ] Screen-reader manual pass (NVDA or VoiceOver) completed for streaming, error, and tool-call timeline surfaces (A11Y-008/009/011).
- [ ] Focus-retention test passes across at least one streaming state transition (A11Y-014).
- [ ] `prefers-reduced-motion` verified to suppress AI-state animation (A11Y-017).
- [ ] Arabic message catalog has 100% key parity with English for government-client builds (A11Y-019).
- [ ] Stylelint reports zero physical-direction CSS properties outside the justified exception file (A11Y-020).
- [ ] Pseudo-localization pass at +40% string length shows no clipping/overlap (A11Y-025).
- [ ] Arabic-locale eval cases included in the model-selection eval suite (A11Y-027).
- [ ] UAE Design System component audit checklist completed for government-client projects (A11Y-028).

## Handoff notes

- Paste the WCAG 2.2 SC table and the testing matrix below directly into any spec handed to Claude for UI generation.
- Tell Replit Agent explicitly which locale is primary for a given client (`ar` vs. `en`) and confirm numeral/calendar convention before it scaffolds date/number formatting.
- Attach the pseudo-localization test script and axe CI config when handing off implementation so accessibility gates run from the first commit, not retrofitted later.
- Flag any use case in credit/HR/benefits/citizen services explicitly — these require the full Arabic-quality eval pass before model sign-off (A11Y-027).

## Testing matrix

| Layer | Tool | What it checks | Cadence |
|---|---|---|---|
| Automated static/DOM | `axe-core` (via `@axe-core/playwright`) | WCAG 2.2 A/AA rule violations across all routes | Every CI run |
| Automated interaction | Playwright | Keyboard-only operability, focus retention across async updates, non-drag reorder alternative | Every CI run |
| Automated visual | Playwright + pseudo-localization script | +40% string-length clipping/overlap, RTL mirroring correctness | Every PR touching UI or locale strings |
| Automated i18n parity | Custom CI script (catalog diff) | English/Arabic message-key parity | Every PR touching message catalogs |
| Manual screen reader | NVDA (Windows) + VoiceOver (macOS/iOS) | Live-region announcement correctness, timeline/citation navigability, form labeling | Before every client demo; full pass at each QA gate (see [21 — QA & Definition of Done](./21-qa-definition-of-done.md)) |
| Manual bilingual review | Native Arabic-speaking reviewer | Register, dialect appropriateness, cultural correctness of agent-generated Arabic output | Before every client demo involving Arabic-facing surfaces |
| Manual component audit | UAE Design System checklist | Touch target size, icon size, contrast ratios, captioning | Once per project at design-system lock, re-verified at QA gate |

## Sources

- [W3C, What's New in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) — new success criteria relevant to agent control surfaces.
- [W3C ARIA19 Technique](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19) — live-region patterns for dynamically injected content.
- [TDRA, UAE Design System](https://dgov.tdra.gov.ae/services/design-system-for-federal-governments-websites) — federal accessibility mandate.
- [designsystem.gov.ae, Accessibility guideline](https://designsystem.gov.ae/guidelines/accessibility) — concrete component requirements (touch targets, icon sizes, contrast).
- [designsystem.gov.ae, FAQ](https://designsystem.gov.ae/resources/frequently-asked-questions) — accessibility guideline clarifications.
- [UAE National Policy for Digital Accessibility](https://assets.u.ae/api/public/content/84ec9317f73249c8a2594d76705d3c46?v=8a2f9df6) — WCAG 2.1 AA floor reference, superseded in practice by 2.2.
- [ICP, Digital Accessibility Statement](https://icp.gov.ae/en/digital-accessibility-statement/) — federal digital accessibility statement.
- [DeveloperUX, 5 Challenges in Multilingual AI UX Design](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/) — text expansion, cultural context, low-resource-language issues.
- [UAE Design System](https://designsystem.gov.ae/) — content and Arabic-first guidance for UAE government surfaces.
