---
id: qa-definition-of-done
domain: Delivery, QA & Client Handover
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [qa]
last_reviewed: 2026-07-27
---

# 21. QA & Definition of Done

> **Purpose.** Guarantee "done" for an agentic prototype is an unambiguous, verifiable state assembled from every other standard, not a subjective judgment call made under deadline pressure.
> **Read this when.** Pre-demo gate, sprint/milestone close, release sign-off.

## Scope

- In scope: the single consolidated Definition of Done, the four gates (spec complete, build complete, eval passed, demo ready), the test pyramid for agentic apps, manual test scripts, performance/cost verification, security/injection test pass, accessibility pass, bilingual pass, the release checklist, and sign-off ownership.
- Out of scope: the content of each underlying check (eval methodology in [15 — Evaluation](./15-evaluation.md), security/injection test detail in [13 — Security & Authorization](./13-security-authz.md), accessibility test detail in [18 — Accessibility & Bilingual](./18-accessibility-i18n.md), compliance artifact content in [17 — Data Governance & Compliance](./17-data-governance-compliance.md)) — this file gates and sequences those checks, it does not redefine them.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Gate structure | Four sequential gates: Spec Complete → Build Complete → Eval Passed → Demo Ready | Matches the studio's research→spec→code→Replit pipeline; each gate blocks the next |
| Verification standard | Every "done" claim backed by a runnable check (test output, eval report, screenshot), never an assertion | Generalizes Claude Code's verification-with-evidence discipline ([Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)) |
| Test pyramid shape | Unit (Vitest) > integration/tool-contract > eval (`promptfoo`) > E2E (Playwright), with fewer but higher-value tests at the top | Agentic nondeterminism makes E2E and eval tests expensive to maintain; push coverage down the pyramid where possible |
| Sign-off | Named human sign-off per gate, never an automated pass alone | Consistent with the accountable-owner principle in [17 — Data Governance & Compliance](./17-data-governance-compliance.md) |
| Adversarial review | A fresh-context reviewer (subagent or human) checks the diff against spec criteria before Demo Ready | Prevents self-graded "looks done to me" sign-off ([Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)) |

## Rules

### The four gates

**`QA-001` — Do not begin implementation until the Spec Complete gate passes** · `MUST`
Require a spec (`docs/specs/SPEC-###`) with acceptance criteria, out-of-scope statement, and an end-to-end verification step before any implementation PR opens against it.
- *Why:* Implementation without a passed spec gate produces unreviewable, untraceable work, contradicting [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-018.
- *How:* Spec Complete checklist: acceptance criteria present, out-of-scope listed, data classification noted (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV-001), deployment type chosen (see [20 — Replit & Deployment](./20-replit-deployment.md) DEP-001).
- *Check:* PR referencing the spec is blocked from merge if the spec file lacks any of the four required elements.

**`QA-002` — Do not begin eval runs until the Build Complete gate passes** · `MUST`
Require all unit and integration tests green, lint/typecheck clean, and manual smoke test passed before running the eval suite against a build.
- *Why:* Running expensive eval suites against a broken build wastes time and produces misleading regression signals.
- *How:* CI pipeline stage ordering: lint/typecheck → unit → integration → (gate) → eval → E2E.
- *Check:* CI pipeline configuration enforces this stage order; eval stage does not run if any prior stage fails.

**`QA-003` — Do not schedule a client demo until the Eval Passed gate passes** · `MUST`
Require the eval suite to meet or exceed the baseline thresholds defined in the spec before a demo is booked with the client.
- *Why:* Prevents demoing a regression that would have been caught by the eval-gated deploy checklist.
- *How:* Eval report (see [15 — Evaluation](./15-evaluation.md)) attached to the release checklist with pass/fail per metric.
- *Check:* Release checklist item "eval report attached and passing" is a hard blocker for demo scheduling.

**`QA-004` — Do not mark Demo Ready until every item in the consolidated Definition of Done (below) is checked** · `MUST`
Complete the full consolidated DoD checklist — functional, security, accessibility, bilingual, performance/cost, compliance — before the Demo Ready gate is granted.
- *Why:* This is the single point where all other standards' individual DoDs are confirmed together; skipping it is how safety/accessibility checks get silently dropped under deadline pressure.
- *How:* Use the consolidated checklist verbatim; do not substitute a partial or ad hoc list.
- *Check:* QA lead signs the consolidated DoD checklist with a name and date before the demo is confirmed on the client's calendar.

### Test pyramid for agentic apps

**`QA-005` — Structure tests as a pyramid: unit > tool-contract/integration > eval > E2E** · `MUST`
Write the majority of tests as fast, deterministic Vitest unit tests; use tool-contract/integration tests for tool-call correctness; reserve `promptfoo` eval suites for LLM-behavior assertions; reserve Playwright E2E for full user-journey verification.
- *Why:* Agentic nondeterminism makes E2E and eval tests slow and flaky if overused; pushing coverage down the pyramid keeps CI fast and signal-rich.
- *How:* Target ratio guideline: unit tests cover all deterministic logic (parsers, Zod schemas, redaction, retention jobs); integration tests cover every tool contract's input/output shape; eval suites cover model/prompt-quality assertions; E2E covers the demo script's happy/degraded/error paths only.
- *Check:* Test-count report by layer reviewed at each QA gate; a project with more E2E tests than integration tests triggers a pyramid-shape review.

**`QA-006` — Cover every tool contract with a dedicated integration test independent of the LLM** · `MUST`
Test each tool's input validation, success path, and error path by calling the tool function directly, not only through an end-to-end agent run.
- *Why:* Isolates tool-logic bugs from model-behavior variance, making failures fast to diagnose.
- *How:* Vitest test file per tool under `lib/agents/tools/__tests__/`, asserting Zod schema rejection on malformed input and correct output shape on valid input.
- *Check:* Every tool file in `lib/agents/` has a corresponding test file; CI coverage report confirms no untested tool.

**`QA-007` — Gate every prompt/tool/model change behind the eval regression suite** · `MUST`
Re-run the full `promptfoo` eval suite against the baseline dataset for any change to a system prompt, tool schema, or model/routing choice; block merge on any metric regression below the documented threshold.
- *Why:* This is the mandatory regression gate referenced in the studio's evaluation standard (see [15 — Evaluation](./15-evaluation.md)); restated here as a QA-gate blocker.
- *How:* CI job runs `promptfoo eval` on PRs touching `lib/agents/prompts/` or `lib/agents/tools/`.
- *Check:* CI blocks merge if the eval report shows a regression exceeding the documented tolerance.

**`QA-008` — Cover the demo script's three required beats with Playwright E2E tests** · `MUST`
Write E2E tests for the happy path, one "agent handles ambiguity gracefully" beat, and one "agent escalates/fails gracefully" beat, matching the demo script (see [22 — Handover & IP](./22-handover-ip.md)).
- *Why:* Ensures the exact beats shown live to the client are automatically re-verified, not just manually spot-checked once.
- *How:* Playwright test suite tagged `@demo-script`, run before every demo-freeze (see [20 — Replit & Deployment](./20-replit-deployment.md) DEP-021).
- *Check:* `@demo-script` tagged tests pass in the CI run immediately preceding the documented demo-freeze cutoff.

### Manual test scripts

**`QA-009` — Maintain a written manual test script covering paths automation does not reach** · `MUST`
Document a manual test script for subjective/perceptual checks: tone appropriateness, Arabic register quality, visual polish, and any workflow too costly to automate at prototype stage.
- *Why:* Automation cannot fully substitute for human judgment on tone, cultural appropriateness, and visual quality.
- *How:* `docs/runbooks/manual-test-script.md`, structured as numbered steps with expected outcomes, run by a human before each Demo Ready gate.
- *Check:* Manual test script has a dated, initialed completion record attached to the release checklist.

**`QA-010` — Include a native Arabic-speaking reviewer step in the manual test script for any bilingual surface** · `MUST`
Add an explicit manual-script step where a native Arabic speaker reviews agent-generated Arabic output for register, dialect appropriateness, and cultural correctness.
- *Why:* Automated eval scores do not fully capture register/cultural appropriateness (see [18 — Accessibility & Bilingual](./18-accessibility-i18n.md) A11Y-026).
- *How:* Assign this step to a specific named reviewer per engagement, recorded in the manual test script.
- *Check:* Manual test script's Arabic-review step has a named reviewer and a pass/fail note attached.

### Performance and cost verification

**`QA-011` — Verify p50/p95 latency against the spec's budget before Demo Ready** · `MUST`
Run a load test or representative usage simulation and compare p50/p95 latency to the budget defined in the technical spec (see [07 — Agent Architecture](./07-agent-architecture.md)).
- *Why:* Demo-day latency spikes break the perceived reliability of a live client demo.
- *How:* k6/Playwright-based load script exercising the primary agent flow at expected demo concurrency.
- *Check:* Load-test report attached to the release checklist shows p50/p95 within the spec's budget.

**`QA-012` — Verify per-request cost against the spec's budget before Demo Ready** · `MUST`
Confirm actual token/cost telemetry from a representative test run matches or is below the cost-per-request budget in the spec.
- *Why:* Prevents a surprise invoice and confirms the model-routing decision (see [07 — Agent Architecture](./07-agent-architecture.md)) holds under realistic load.
- *How:* Pull cost telemetry from the observability backend (Langfuse/LangSmith) for the load-test run window.
- *Check:* Cost report attached to the release checklist shows actual cost per request within the documented budget.

**`QA-013` — Verify hard stop conditions on agent loops are enforced** · `MUST`
Test that max-turn, max-tool-call, and timeout limits actually terminate a runaway agent loop rather than existing only as unused config.
- *Why:* Prevents unbounded consumption / denial-of-wallet failures (OWASP LLM10) from reaching a client demo ([OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)).
- *How:* Integration test forces a tool to return a retry-triggering error repeatedly and asserts the loop terminates at the configured limit.
- *Check:* Test passes showing the agent halts and surfaces an error/escalation rather than looping indefinitely.

### Security and injection test pass

**`QA-014` — Run structured adversarial tests against the OWASP LLM Top 10 and Agentic Top 10 before any demo involving real or realistic data** · `MUST`
Execute a documented adversarial test set covering prompt injection (direct and indirect), sensitive-information disclosure, excessive agency, and system-prompt leakage at minimum.
- *Why:* This is a required pre-demo check per [13 — Security & Authorization](./13-security-authz.md); restated here as a QA-gate blocker, not merely a recommendation.
- *How:* Reuse the red-team payload library maintained under [13 — Security & Authorization](./13-security-authz.md); run against the demo environment, not just staging.
- *Check:* Security test report attached to the release checklist, dated within the current release cycle.

**`QA-015` — Verify least-privilege tool scoping with a permission-boundary test** · `MUST`
Test that no agent tool can perform an action outside its documented, minimum-necessary permission scope.
- *Why:* OWASP LLM06 Excessive Agency mitigation; a tool with excess permission is a standing risk regardless of prompt-level guardrails ([OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)).
- *How:* Integration test attempts an out-of-scope action via a crafted tool-call payload and asserts rejection at the authorization layer, not just the prompt layer.
- *Check:* Test suite includes at least one negative-permission test per write-capable tool.

**`QA-016` — Confirm baseline security hygiene before every release** · `MUST`
Verify no hardcoded secrets, TLS/HTTPS enforced, dependency list pinned, and no default/public deployment of anything touching non-synthetic data.
- *Why:* Non-negotiable compliance-ready-prototype item (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)).
- *How:* Reuse the CI secret-scan and license-check jobs from [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-022 and [20 — Replit & Deployment](./20-replit-deployment.md) DEP-006 as release-checklist inputs.
- *Check:* CI job results for secret-scan and dependency-pin verification are green at release time, not just at some earlier commit.

### Accessibility pass

**`QA-017` — Run the full accessibility testing matrix before Demo Ready for any citizen- or client-facing surface** · `MUST`
Execute the axe CI pass, Playwright keyboard/focus tests, and at least one manual screen-reader pass per the testing matrix in [18 — Accessibility & Bilingual](./18-accessibility-i18n.md) before granting Demo Ready.
- *Why:* Restates A11Y's testing matrix as a hard QA-gate blocker rather than an optional pass.
- *How:* Attach the axe report, Playwright accessibility test results, and the manual screen-reader pass notes to the release checklist.
- *Check:* Release checklist accessibility section has all three artifacts attached and dated within the current release cycle.

### Bilingual pass

**`QA-018` — Run the bilingual pass covering message-catalog parity, RTL rendering, and pseudo-localization before Demo Ready** · `MUST`
Confirm English/Arabic message-key parity, correct RTL mirroring, and no clipping/overlap at +40% string expansion per [18 — Accessibility & Bilingual](./18-accessibility-i18n.md).
- *Why:* A missed Arabic string or broken RTL layout is highly visible and damaging in a live government/bank demo.
- *How:* Reuse the catalog-diff CI script and pseudo-localization visual regression test from [18 — Accessibility & Bilingual](./18-accessibility-i18n.md).
- *Check:* Release checklist bilingual section shows zero catalog-parity gaps and zero pseudo-localization clipping failures.

### Release checklist and sign-off

**`QA-019` — Complete the release checklist in full before the Demo Ready gate is granted** · `MUST`
Attach every artifact named in the consolidated DoD (below) to the release checklist; a missing artifact blocks sign-off regardless of how minor it seems.
- *Why:* This is the single source of truth a reviewer checks; partial checklists are how gaps silently ship.
- *How:* `docs/runbooks/release-checklist.md`, one instance per release/demo, filled in and archived (not overwritten) each time.
- *Check:* Archived release checklist exists for every past client demo, retrievable for audit.

**`QA-020` — Require a fresh-context adversarial review before Demo Ready sign-off** · `MUST`
Have a reviewer (subagent or human) who did not author the implementation check the diff/build against the spec's stated acceptance criteria, flagging only correctness/requirement gaps.
- *Why:* Self-graded "looks done to me" review misses the same blind spots that produced the bug in the first place ([Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).
- *How:* Assign a reviewer distinct from the implementer for the final pre-demo pass; document findings in the adversarial-review report template.
- *Check:* Adversarial review report attached to the release checklist, with reviewer name distinct from implementer name(s).

**`QA-021` — Name a single accountable sign-off owner per gate, distinct from the implementer** · `MUST`
Require: Spec Complete signed by the delivery lead; Build Complete signed by the lead engineer; Eval Passed signed by the QA lead; Demo Ready signed by the delivery lead, with client-side awareness where the client has a named counterpart.
- *Why:* Distributes accountability across the pipeline rather than concentrating "done" judgment in the implementer alone, consistent with [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV-020.
- *How:* Sign-off table (see Reference implementation) with named individual, date, and gate per row.
- *Check:* Sign-off table has no blank owner field for any gate reached.

## Reference implementation

```markdown
<!-- docs/runbooks/release-checklist.md -->
# Release Checklist — <project> — <release/demo date>

## Gate 1: Spec Complete
- [ ] Acceptance criteria present in docs/specs/SPEC-###
- [ ] Out-of-scope statement present
- [ ] Data classification noted (GOV-001)
- [ ] Deployment type chosen (DEP-001)
- Signed off by: __________ Date: __________

## Gate 2: Build Complete
- [ ] Lint/typecheck clean
- [ ] Unit tests green
- [ ] Integration/tool-contract tests green
- [ ] Manual smoke test passed
- Signed off by: __________ Date: __________

## Gate 3: Eval Passed
- [ ] Eval report attached, meets/exceeds baseline thresholds
- [ ] No unresolved regression vs. baseline dataset
- Signed off by: __________ Date: __________

## Gate 4: Demo Ready
### Functional
- [ ] E2E tests for happy/ambiguity/escalation beats pass (@demo-script)
- [ ] Manual test script completed, including Arabic-review step

### Performance & cost
- [ ] p50/p95 latency within spec budget
- [ ] Per-request cost within spec budget
- [ ] Hard stop conditions verified

### Security
- [ ] OWASP LLM/Agentic Top 10 adversarial test report attached
- [ ] Least-privilege permission-boundary tests pass
- [ ] Baseline security hygiene confirmed (secrets, TLS, pinned deps)

### Accessibility
- [ ] axe CI report attached, zero AA violations
- [ ] Manual screen-reader pass completed

### Bilingual
- [ ] Message-catalog parity 100%
- [ ] Pseudo-localization pass clean at +40%

### Compliance
- [ ] Data-classification/residency statement current
- [ ] Model/system card, subprocessor register, risk register current
- [ ] Known-gaps disclosure current and shared with client

### Review
- [ ] Adversarial review report attached, reviewer distinct from implementer

Signed off by: __________ Date: __________
```

```mermaid
flowchart LR
  A[Spec Complete] -->|delivery lead signs| B[Build Complete]
  B -->|lead engineer signs| C[Eval Passed]
  C -->|QA lead signs| D[Demo Ready]
  D -->|delivery lead signs| E[Client Demo]
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| "It works on my machine" as the sole verification | No runnable evidence attached; not reproducible | Attach test output, eval report, or screenshot for every DoD claim (QA-004) |
| Running the eval suite before the build is green | Wastes cycles, produces misleading regression signal | Enforce gate order: Build Complete before Eval Passed (QA-002) |
| Self-review only, no fresh-context check | Misses the same blind spots that caused the bug | Require a distinct adversarial reviewer (QA-020) |
| Skipping accessibility/bilingual pass "just for this demo" | Exactly how gaps silently ship under deadline pressure | Treat the full consolidated DoD as non-negotiable (QA-004) |
| E2E tests as the primary test layer | Slow, flaky under agentic nondeterminism | Push coverage down the pyramid: unit/integration first (QA-005) |
| One person signing off all four gates | Concentrates judgment, removes accountability distribution | Named, distinct sign-off owner per gate (QA-021) |

## Definition of Done

- [ ] All four gates (Spec Complete, Build Complete, Eval Passed, Demo Ready) passed in order with named sign-offs (QA-001–QA-004, QA-021).
- [ ] Test pyramid shape reviewed; no E2E-test-count inversion (QA-005).
- [ ] Every tool contract has a dedicated integration test (QA-006).
- [ ] Eval regression suite green against baseline for any prompt/tool/model change (QA-007).
- [ ] Demo-script E2E beats (`@demo-script`) passing (QA-008).
- [ ] Manual test script completed with a named Arabic-review step for bilingual surfaces (QA-009/010).
- [ ] Performance (p50/p95) and cost verified against spec budgets (QA-011/012).
- [ ] Hard stop conditions on agent loops verified (QA-013).
- [ ] Security adversarial test report and permission-boundary tests attached (QA-014/015).
- [ ] Baseline security hygiene confirmed (QA-016).
- [ ] Full accessibility testing matrix run and attached (QA-017).
- [ ] Bilingual pass (catalog parity, RTL, pseudo-localization) attached (QA-018).
- [ ] Release checklist fully completed and archived (QA-019).
- [ ] Adversarial review report attached with a reviewer distinct from the implementer (QA-020).

## Handoff notes

- Attach the filled release checklist to every handover pack (see [22 — Handover & IP](./22-handover-ip.md)); it is the single artifact a client compliance reviewer will ask for first.
- When asking Replit Agent or Claude to "finish" a feature, point it at the specific gate it needs to satisfy next rather than a vague "make it done."
- If any gate cannot be passed on schedule, use the gap-disclosure template from [17 — Data Governance & Compliance](./17-data-governance-compliance.md) rather than silently lowering the bar.
- Archive every release checklist — do not overwrite the previous one — so a client audit can review the full history of gate sign-offs.

## Sources

- [Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) — verification-with-evidence discipline, adversarial fresh-context review, end-to-end verification step.
- [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/) — Excessive Agency and Unbounded Consumption categories underlying QA-013/QA-015.
