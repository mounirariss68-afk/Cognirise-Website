---
id: memory
domain: Agent Architecture & Orchestration
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 09. Memory

> **Purpose.** Prevent context-window overflow, "forgotten" instructions mid-session, unbounded token spend from re-sent history, and unlawful retention of personal data by fixing a four-tier memory model, write/retrieval policies, and a durable Postgres schema.
> **Read this when.** Designing any agent that must recall information across turns, sessions, or jobs; any spec involving personalization, long-running jobs, or data-subject deletion requests.

## Scope
- In scope: the four-tier memory model, compaction/summarization triggers, semantic/episodic/procedural memory typing, write and retrieval policies with provenance and TTL, the memory-vs-RAG boundary, forgetting/deletion, Postgres/Drizzle schema, and multi-tenant isolation.
- Out of scope: thread-scoped run state (checkpoints, plan steps) — see [07 — Agent Architecture](./07-agent-architecture.md) · AGT-016–020; retrieval-augmented generation over external document corpora not tied to agent memory — see the retrieval standard (RAG); system-prompt construction — see [11 — Prompt & Context Engineering](./11-prompt-context-engineering.md); PII handling in logs generally — see the data governance standard (GOV).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Backing store | Postgres-native (`pgvector` + relational tables), same instance as checkpoints | Avoids a separate vector database service; simplifies backup and operational surface on a single Replit deployment |
| Memory tiers | Four: working context, scratchpad/notes, session state, long-term store | Matches the distinct retrieval questions each tier answers; do not collapse tiers |
| Compaction trigger | Token-count threshold checked via provider usage metadata, not a fixed turn count | Token consumption, not turn count, is what threatens the context window |
| Memory type model | Episodic, semantic, procedural — tracked as a `memory_type` column, not separate services | One schema, three logical types, per the LangMem taxonomy |
| Write authority | Only explicit, tool-mediated writes; never implicit inference-time writes without a tool call | Provenance and auditability require a recorded write action |
| Retention default | TTL required on every long-term memory row; no row without an expiry or an explicit "permanent" justification | Prevents silent unbounded accumulation and supports deletion-request compliance |

## Rules

### The four-tier model

**`MEM-001` — Structure agent memory into exactly four tiers; do not collapse or skip a tier** · `MUST`

| Tier | Definition | Lifetime | Backing |
|---|---|---|---|
| Working context | The current LLM call's context window: system prompt, recent messages, active tool results | Single call | In-memory during the call only; never the durable copy |
| Scratchpad / notes | Structured, agent-written notes for cross-context continuity within one job (e.g., a to-do list, key facts gathered so far) | One job/run | `scratchpad` column on the job/run row |
| Session state | Cross-thread-within-session but bounded state: conversation summaries, user preferences expressed this session, `trust_level`/`autonomy_mode` | One session (may span multiple runs) | `session_summaries`, `sessions` tables |
| Long-term store | Facts, preferences, and shared knowledge that outlive a single job or session | Until TTL expiry or deletion request | `long_term_memory` table with embeddings |

- *Why:* Mirrors the LangGraph distinction between thread-scoped checkpointer state and cross-thread store state ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)), and Letta's OS-inspired three-tier model (Core/Archival/Recall) generalized to a fourth, even-shorter-lived working-context tier that never touches disk ([AgentMarketCap, Agent Memory Architecture Wars](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production)).
- *How:* Each tier is a distinct table or column set (below); no tier's data is duplicated into another tier's table.
- *Check:* Schema review confirms each of the four tiers maps to exactly one named table/column, and no code path writes session-tier data into the long-term table without going through the write policy (`MEM-006`).

**`MEM-002` — Choose retrieval architecture by the retrieval question, not by defaulting to a framework** · `MUST`

| Retrieval question | Weak approach | Use instead |
|---|---|---|
| "What did this user tell me?" | — | Vector-similarity retrieval (`pgvector`) works well |
| "What's the most recent/current fact about this entity?" (temporal reasoning, contradiction resolution) | Vector-only retrieval — "has no native concept of time" | Temporal/decay-weighted retrieval: prefer most-recently-written row per `(user_id, fact_key)`, or an explicit `valid_from`/`superseded_by` pair |
| "What should the agent actively remember vs. archive?" | Single flat table with no tiering | Agent-managed tiered promotion/demotion (only for genuinely long-running, self-managing agents — see `MEM-003`) |

- *Why:* Benchmark data on LongMemEval shows vector-first systems scoring only 49–55% on temporal-reasoning subtasks "because vector search has no native concept of time," while temporal-graph and well-engineered RAG-only approaches score 63.8–94.87% depending on engineering effort ([AgentMarketCap, Agent Memory Architecture Wars](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production)).
- *How:* Add `valid_from`/`superseded_by` columns to `long_term_memory` (see `MEM-011`); read path always filters `superseded_by IS NULL` unless explicitly querying history.
- *Check:* A test that writes two conflicting facts for the same `(user_id, fact_key)` at different times asserts the read path returns only the newer one.

**`MEM-003` — Reserve agent-managed tiered memory (self-directed promote/demote) for genuinely long-running, self-managing agents only** · `SHOULD NOT`
Do not build a Letta-style agent-managed memory tier (where the agent itself decides via tool calls what moves between tiers) for typical bounded-job apps.
- *Why:* Agent-managed tiering adds latency and token overhead per memory operation that is "not justified for typical bounded-job Replit apps" (source research, B.11) — reserve it for products needing weeks/months-persistent, autonomously self-managing assistants.
- *How:* Default to system-managed (code-driven) promotion/demotion rules (e.g., "promote to long-term if referenced in 2+ sessions") rather than giving the model a `promote_to_long_term` tool by default.
- *Check:* Spec review confirms a documented justification exists before any project introduces agent-directed memory tool calls.

### Compaction and summarization

**`MEM-004` — Trigger compaction on a token-count threshold, not a fixed turn count** · `MUST`
Track conversation token count via provider usage metadata; once it crosses a documented threshold (studio default: 70% of the model's effective context window), summarize and truncate.
- *Why:* Compaction "suits tasks needing extensive back-and-forth conversational flow"; the trigger must track actual context pressure, not an arbitrary turn count that may under- or over-trigger depending on message size ([Anthropic, Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).
- *How:*
```typescript
async function maybeCompact(sessionId: string, currentTokenCount: number, contextWindow: number) {
  if (currentTokenCount / contextWindow < 0.7) return;
  const messages = await loadMessages(sessionId);
  const { text: summary } = await generateText({
    model: anthropic("claude-sonnet-4-5"),
    prompt: `Summarize this conversation, preserving architectural decisions, unresolved issues, and key facts. Discard redundant tool output:\n${JSON.stringify(messages)}`,
  });
  await db.insert(sessionSummaries).values({ sessionId, summary, coveredUpToMessageId: messages.at(-1)!.id });
  await truncateWorkingMessages(sessionId, keepLastN: 5);
}
```
- *Check:* Simulate a conversation exceeding the threshold; confirm a `session_summaries` row is written and the working message array shrinks to `[summary, last_k_messages]`.

**`MEM-005` — Preserve architectural decisions and unresolved issues in compaction; discard redundant tool output** · `MUST`
The compaction prompt MUST explicitly instruct preservation of decisions/unresolved items and explicit discarding of raw, repeated tool payloads.
- *Why:* Directly stated in the source research (B.3): "preserving architectural decisions/unresolved issues while discarding redundant tool output."
- *How:* Use a fixed compaction prompt template (versioned per [11 — Prompt & Context Engineering](./11-prompt-context-engineering.md)) rather than an ad hoc "summarize this" instruction per project.
- *Check:* Eval case feeds a transcript with a known decision and a known unresolved issue through compaction; assert both appear in the resulting summary.

### What must never enter long-term memory

**`MEM-006` — Only explicit, tool-mediated writes may create or update long-term memory; no implicit inference-time writes** · `MUST`
The model MUST call a dedicated `memory_write` tool (or equivalent) to create/update a long-term memory row; no code path may silently persist model output into long-term memory without that tool call.
- *Why:* Provenance and auditability require a recorded, attributable write action — an implicit write has no actor, no timestamp discipline, and no reviewability.
- *How:* `memory_write` tool schema requires `factKey`, `factValue`, `sourceRunId`, and `ttl` (or `permanentJustification`); see `MEM-011` schema.
- *Check:* Grep the codebase for any direct `INSERT INTO long_term_memory` outside the `memory_write` tool's execute function; none should exist.

**`MEM-007` — The following categories MUST NOT enter long-term memory** · `MUST NOT`
- Raw secrets, API keys, credentials, or session tokens, under any circumstance.
- Full raw tool-call transcripts or full conversation logs (these belong in the run-scoped audit trail, not long-term memory — see [07 — Agent Architecture](./07-agent-architecture.md) · AGT-017).
- Unredacted PII beyond what is strictly necessary for the memory's stated purpose (see the data governance standard, GOV, for redaction rules).
- Any fact the end user has explicitly asked to be forgotten (see `MEM-013`) until a new, separate consent is given.
- Speculative or unconfirmed model inferences about a user presented as fact (e.g., inferred sensitive attributes) without an explicit confirmation step.
- *Why:* Long-term memory is the highest-persistence, highest-blast-radius store in the system; the categories above are exactly the ones that convert a memory feature into a data-protection or security liability.
- *How:* `memory_write`'s Zod schema rejects payloads matching secret-shaped patterns (regex for API key formats, JWT shape) at the boundary; a PII classifier runs before write and blocks or requires explicit override with a logged justification.
- *Check:* Fuzz-test `memory_write` with synthetic secrets and raw PII payloads; confirm rejection in every case without an override flag.

### Semantic, episodic, procedural memory

**`MEM-008` — Tag every long-term memory row with one of three memory types: semantic, episodic, or procedural** · `MUST`

| Type | Definition | Example |
|---|---|---|
| Semantic | Facts, preferences, beliefs about an entity | "Customer prefers email over SMS notifications" |
| Episodic | Past interactions/events | "On 2026-06-14, customer disputed invoice #4471" |
| Procedural | Instructions the agent can use to update its own operating behavior | "For this customer, always confirm refund amount before executing" |

- *Why:* This three-type taxonomy is documented directly in LangMem's memory model, each type produced by an LLM-based "Memory Manager" from conversation transcripts ([AgentMarketCap, Agent Memory Architecture Wars](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production)).
- *How:* `memory_type` enum column on `long_term_memory` (see `MEM-011`).
- *Check:* Query distribution of `memory_type` values per tenant; any row with a null/invalid type fails a nightly data-quality check.

### Write and retrieval policies

**`MEM-009` — Every memory write records provenance: who wrote it, from which run, and why** · `MUST`
`long_term_memory` rows MUST include `source_run_id`, `written_by` (`agent` | `human_reviewer` | `system_migration`), and a short `justification` string.
- *Why:* Without provenance, a bad memory write cannot be traced back to the run that caused it, blocking both debugging and deletion-request fulfillment.
- *How:* See schema in `MEM-011`; `memory_write` tool always populates these fields from the current run context.
- *Check:* Every row in `long_term_memory` has non-null `source_run_id` and `written_by`; a query for orphaned rows returns zero.

**`MEM-010` — Every long-term memory row MUST carry a TTL or an explicit, reviewed permanent-retention justification** · `MUST`
No row may be written without either an `expires_at` timestamp or a `permanent_justification` string that has passed data-governance review.
- *Why:* Prevents silent unbounded accumulation and gives the deletion/forgetting mechanism (`MEM-013`) a default expiry to fall back on.
- *How:* `memory_write` tool schema makes `ttl` required unless `permanentJustification` is supplied; a Scheduled Deployment cron nightly deletes rows past `expires_at`.
- *Check:* Attempt to write a memory row with neither field populated; schema validation rejects it.

**`MEM-011` — Use this canonical Postgres/Drizzle schema for memory tables** · `MUST`
```typescript
// schema/memory.ts
import { pgTable, uuid, text, jsonb, timestamp, vector, index, uniqueIndex } from "drizzle-orm/pg-core";

export const longTermMemory = pgTable("long_term_memory", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id").notNull(),
  userId: uuid("user_id").notNull(),
  memoryType: text("memory_type", { enum: ["semantic", "episodic", "procedural"] }).notNull(),
  factKey: text("fact_key").notNull(),           // e.g. "notification_preference"
  factValue: jsonb("fact_value").notNull(),       // structured value
  embedding: vector("embedding", { dimensions: 1536 }), // pgvector, for semantic retrieval
  validFrom: timestamp("valid_from").notNull().defaultNow(),
  supersededBy: uuid("superseded_by"),            // self-reference: points to the row that replaced this one
  sourceRunId: uuid("source_run_id").notNull(),
  writtenBy: text("written_by", { enum: ["agent", "human_reviewer", "system_migration"] }).notNull(),
  justification: text("justification").notNull(),
  expiresAt: timestamp("expires_at"),
  permanentJustification: text("permanent_justification"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  tenantUserIdx: index("ltm_tenant_user_idx").on(t.tenantId, t.userId),
  factKeyIdx: index("ltm_fact_key_idx").on(t.userId, t.factKey),
  activeUniqueIdx: uniqueIndex("ltm_active_unique_idx").on(t.userId, t.factKey).where(sql`superseded_by IS NULL`),
}));

export const sessionSummaries = pgTable("session_summaries", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: uuid("session_id").notNull(),
  summary: text("summary").notNull(),
  coveredUpToMessageId: uuid("covered_up_to_message_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => ({
  sessionIdx: index("session_summaries_session_idx").on(t.sessionId),
}));

export const scratchpads = pgTable("scratchpads", {
  runId: uuid("run_id").primaryKey(), // one scratchpad per run; FK to runs.id
  notes: jsonb("notes").notNull().default({}),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
```
- *Why:* Encodes the temporal-decay pattern (`valid_from`/`superseded_by`) recommended to close the gap to graph-based temporal reasoning without adopting a new framework, and keeps embeddings in the same Postgres instance as checkpoints via `pgvector` ([AgentMarketCap, Agent Memory Architecture Wars](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production)).
- *How:* Apply via Drizzle migrations; enable the `pgvector` extension (`CREATE EXTENSION IF NOT EXISTS vector;`) before this migration runs.
- *Check:* `\d long_term_memory` shows the `superseded_by` self-reference and the partial unique index on active rows; inserting a second active row for the same `(user_id, fact_key)` without superseding the first fails the unique constraint.

**`MEM-012` — Retrieval reads MUST scope to tenant and user, and MUST exclude superseded rows by default** · `MUST`
Every read query against `long_term_memory` filters `WHERE tenant_id = ? AND user_id = ? AND superseded_by IS NULL` unless explicitly querying history for audit purposes.
- *Why:* Enforces both the temporal-correctness rule (`MEM-002`) and the multi-tenant isolation rule (`MEM-014`) at the query level, not only at the application-logic level.
- *How:* Wrap all memory reads in a single `getActiveMemory(tenantId, userId, factKey?)` repository function; forbid direct table access elsewhere.
- *Check:* Static analysis/lint rule flags any raw query against `long_term_memory` outside the repository module.

### Forgetting, deletion, and the RAG boundary

**`MEM-013` — Support hard deletion of a data subject's memory on request, cascading across all four tiers** · `MUST`
A `forget_user(userId)` operation MUST delete or irrecoverably anonymize rows in `long_term_memory`, `session_summaries`, and `scratchpads` for that user, and MUST log the deletion event itself (retaining only the fact that a deletion occurred, not the deleted content).
- *Why:* Data-subject deletion requests are a compliance requirement in regulated GCC/EU-adjacent client environments (per `_CANON-CONVENTIONS.md` §1's regulated-environment default); a memory architecture that cannot cleanly delete a user's data is not deployable for such clients.
- *How:*
```typescript
async function forgetUser(userId: string) {
  await db.transaction(async (tx) => {
    await tx.delete(longTermMemory).where(eq(longTermMemory.userId, userId));
    await tx.delete(sessionSummaries).where(inSessionsOf(userId));
    await tx.delete(scratchpads).where(inRunsOf(userId));
    await tx.insert(deletionLog).values({ userId, deletedAt: new Date(), requestedVia: "data_subject_request" });
  });
}
```
- *Check:* Run `forgetUser` against a seeded test user; confirm zero rows remain across all three tables and exactly one `deletion_log` row exists.

**`MEM-014` — Memory and RAG are architecturally distinct; do not conflate a document corpus with agent memory** · `MUST`
Long-term memory stores facts *about* users/entities written by the agent or a human reviewer. RAG (see the retrieval standard) retrieves passages from an external, typically read-only document corpus (policies, manuals, knowledge bases) not authored by the agent. A single `pgvector` instance may back both, but they MUST be separate tables with separate write paths.
- *Why:* Conflating the two creates an unreviewable write path into what should be a curated knowledge base, and pollutes agent memory retrieval with irrelevant document chunks.
- *How:* `long_term_memory` (this file) vs. `document_chunks`/`kb_embeddings` (owned by the retrieval standard) are never the same table; retrieval queries never join across them implicitly.
- *Check:* Schema review confirms no shared table between the memory and RAG standards; each has its own migration file and its own write-authority rule.

**`MEM-015` — Isolate memory strictly by tenant; no query may span tenants even for shared model routing** · `MUST`
Every memory table includes `tenant_id`; every index and every application-level query includes it as a filter predicate, not only as a stored column.
- *Why:* Cognirise builds for regulated multi-client environments (banks, government departments); cross-tenant memory leakage is a severe compliance failure, not merely a bug.
- *How:* Enforce via Postgres row-level security (RLS) policies keyed on `tenant_id` in addition to application-level filtering, as defense in depth.
- *Check:* Attempt a cross-tenant read using another tenant's `user_id` under a different `tenant_id` session context; RLS denies the row even if application code has a bug.

## Reference implementation

Memory tier data flow (Mermaid):
```mermaid
flowchart LR
    A[Working context<br/>current call window] -->|compaction trigger, MEM-004| B[Session summaries<br/>session-scoped]
    A -->|update_notes tool| C[Scratchpad<br/>job-scoped]
    A -->|memory_write tool, MEM-006| D[Long-term memory<br/>cross-session]
    D -->|retrieval, MEM-012| A
    B -->|session resume| A
    C -->|job resume| A
```

Folder layout:
```
src/
  lib/
    memory/
      schema.ts              # long_term_memory, session_summaries, scratchpads (MEM-011)
      repository.ts           # getActiveMemory, forgetUser (MEM-012, MEM-013)
      compaction.ts            # maybeCompact (MEM-004, MEM-005)
    tools/
      memory-write.ts          # the only write path into long_term_memory (MEM-006)
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Storing full conversation transcripts as "long-term memory" | Bloats context on every retrieval, mixes audit log with curated memory | Store distilled facts via `memory_write`; keep transcripts in the run-scoped audit trail (`AGT-017`) |
| Letting the model write directly to a memory table via raw SQL/ORM calls in its generated code path | No provenance, no schema enforcement, no PII filter | Route every write through the `memory_write` tool (`MEM-006`) |
| Treating vector similarity as sufficient for "what is currently true" queries | Vector search has no concept of recency; contradicts itself on preference changes | Add `valid_from`/`superseded_by` and prefer the latest row (`MEM-002`) |
| One shared table for both RAG document chunks and user memory facts | Unreviewable write path into the knowledge base; irrelevant retrieval noise | Separate tables, separate write authority (`MEM-014`) |
| Memory rows with no TTL and no permanent-retention justification | Unbounded accumulation; blocks clean deletion-request fulfillment | Require TTL or reviewed justification on every write (`MEM-010`) |
| Deletion request handled by deleting only the "obvious" table | Leaves residual data in scratchpads/summaries, failing compliance | Cascade `forget_user` across all three durable memory tables (`MEM-013`) |

## Definition of Done

- [ ] All four memory tiers are implemented as distinct tables/columns, none collapsed (`MEM-001`).
- [ ] Retrieval architecture choice is documented against the retrieval-question table (`MEM-002`).
- [ ] Compaction trigger is token-threshold-based and preserves decisions/unresolved issues (`MEM-004`, `MEM-005`).
- [ ] No implicit writes into `long_term_memory`; all writes go through `memory_write` (`MEM-006`).
- [ ] Secrets, raw transcripts, unredacted PII, and unconfirmed inferences are blocked at the write boundary (`MEM-007`).
- [ ] Every long-term row has `memory_type`, provenance fields, and a TTL or justification (`MEM-008`, `MEM-009`, `MEM-010`).
- [ ] Schema matches the canonical DDL, including the `superseded_by` partial unique index (`MEM-011`).
- [ ] `forget_user` cascades across all three durable tables and logs the deletion event (`MEM-013`).
- [ ] Memory and RAG tables are architecturally separate (`MEM-014`).
- [ ] Row-level security enforces tenant isolation on every memory table (`MEM-015`).

## Handoff notes

- Paste the canonical memory schema (`MEM-011`) verbatim so Claude generates migrations against the exact shape, including the partial unique index.
- State which memory types (semantic/episodic/procedural) this project actually needs — do not let Replit Agent populate all three by default if only one is in scope.
- Flag explicitly whether this client requires data-subject deletion support (`MEM-013`) at spec time; it changes the schema and the required `forget_user` endpoint from day one.
- Cross-reference [07 — Agent Architecture](./07-agent-architecture.md) for run-scoped state and the retrieval standard (RAG) for document-corpus retrieval — do not duplicate either here.

## Sources

- [LangChain, LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence) — checkpointer vs. store distinction underlying the four-tier split
- [Anthropic, Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents) — compaction, structured note-taking, context-as-finite-resource principle
- [AgentMarketCap, Agent Memory Architecture Wars: LangMem vs Letta vs Custom RAG](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production) — LongMemEval benchmark data, LangMem three-type taxonomy, Letta tiered model, Postgres-native recommendation
