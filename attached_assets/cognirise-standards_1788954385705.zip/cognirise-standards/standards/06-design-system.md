---
id: design-system
domain: Design System
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [design, implementation, qa]
last_reviewed: 2026-07-27
---

# 06. Design System

> **Purpose.** Give every Cognirise prototype one token architecture and component inventory so agentic UI states, bilingual/RTL layouts, and government/banking-grade visual polish are consistent across engagements instead of rebuilt from scratch each time.
> **Read this when.** Design stage, before any shadcn/ui component is styled; implementation stage, when wiring Tailwind config; QA, when checking contrast/motion/RTL conformance.

## Scope

- In scope: token architecture (colour, type, spacing, radius, elevation, motion) as CSS variables wired into Tailwind; the default professional palette with light/dark modes and WCAG AA contrast; typography scale and font strategy; AI-specific state tokens and components; motion vocabulary tied to agent activity; density/layout grid; the mandatory component inventory; RTL/bilingual typography rules; chart/data-viz conventions.
- Out of scope: which surface (chat/canvas/dashboard/etc.) to use for a given task — see [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-001. Behavioral rules for HITL, streaming, and error states — see [05 — UI/UX for Agentic Apps](./05-ux-ui.md); this file only defines their visual tokens and component shells. Full WCAG 2.2 success-criteria mapping — see the A11Y standard; this file only carries the contrast/target-size/motion tokens that satisfy it.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Token mechanism | CSS variables (`--color-*`, `--space-*`, etc.) mapped into `tailwind.config` | Single source of truth; enables runtime theme/light-dark/RTL switching without rebuilding Tailwind |
| Default palette | Nexus (from [design-foundations](../../skills/design-foundations/SKILL.md)) — warm neutral base, one teal accent, semantic error/warning/success | Professional, accessible, appropriate for government/banking without client-specific branding |
| Contrast floor | WCAG AA (4.5:1 body, 3:1 large text) on every token pairing, light and dark | Non-negotiable baseline for regulated/government clients |
| Confidence/status signaling | Label + icon + color on every AI-state token; never color alone | Matches [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-008 |
| Motion | Tied to agent activity; stops within one frame of activity stopping; respects `prefers-reduced-motion` | Motion must signal real state, not fake liveness |
| Font strategy | System-safe sans-serif stack for Latin + a bundled Arabic-supporting font for RTL locales | Matches canonical stack's `next-intl`/full-RTL requirement |
| Density | Two modes — compact (ops/dashboard) and comfortable (conversational) — as a token-level setting | Density is a design decision, not a one-off style override |
| Chart palette | Derived from the Nexus accent for sequential data; the 8-colour categorical sequence from design-foundations for categorical data | Keeps data viz inside the same design system as the UI |

## Rules

### 1. Token architecture

**`DS-001` — Define all design tokens as CSS variables at the `:root`/theme layer, never as hardcoded Tailwind literals** · `MUST`
Every colour, spacing, radius, elevation, and motion value used in a component must resolve through a CSS variable, wired into `tailwind.config.ts` under `theme.extend`.
- *Why:* CSS variables are the only mechanism that supports runtime light/dark switching, per-tenant theming, and RTL-aware logical properties without a rebuild.
- *How:* declare tokens in `app/globals.css` under `:root` and `.dark`; reference them in Tailwind config as `colors: { background: 'var(--color-background)', ... }`; never write a raw hex value in a component's `className`.
- *Check:* a lint rule (`no-raw-color` via a custom ESLint rule or Tailwind plugin) flags any hex/rgb literal in `className` or inline `style`.

**`DS-002` — Namespace tokens by category with a consistent prefix** · `MUST`
Use `--color-*`, `--space-*`, `--radius-*`, `--elevation-*`, `--motion-*`, `--font-*` prefixes; never mix categories under one prefix.
- *Why:* consistent namespacing lets tooling (Tailwind IntelliSense, Storybook token docs) enumerate and validate the full token set mechanically.
- *How:* see the Reference implementation token file below for the exact variable list.
- *Check:* a token-audit script parses `globals.css` and confirms every declared variable matches one of the six approved prefixes.

**`DS-003` — Ship both a light and a dark theme for every token category, switchable at runtime** · `MUST`
No token may be defined only for light mode; dark-mode values must be declared for every light-mode token.
- *Why:* government/banking clients frequently mandate dark-mode support for ops/dashboard surfaces; retrofitting dark mode after ship is expensive.
- *How:* `.dark` class selector overriding the same variable names declared in `:root`, toggled via a theme provider (e.g., `next-themes`).
- *Check:* the token-audit script confirms 1:1 variable coverage between `:root` and `.dark` blocks.

### 2. Colour and contrast

**`DS-004` — Use the Nexus palette as the default professional palette unless the client provides brand colour direction** · `MUST`
Adopt the warm-neutral background/surface/text scale with a single teal (`#01696F` light / `#4F98A3` dark) accent and error/warning/success semantics from [design-foundations](../../skills/design-foundations/SKILL.md), for both light and dark modes.
- *Why:* this palette is pre-validated for restraint (1 accent + neutrals) and is appropriate for regulated/government/banking contexts without looking like a generic SaaS product or an over-branded consumer app.
- *How:* copy the exact hex values from the Reference implementation table below directly into the token file; do not approximate or "improve" them without an explicit client brand mandate.
- *Check:* design review confirms the palette matches the Nexus values exactly unless a documented client brand override exists.

**`DS-005` — Verify every text/background pairing meets WCAG AA contrast, in both modes, before shipping any screen** · `MUST`
Body text pairings must reach 4.5:1; large text (18px+ or 14px+ bold) must reach 3:1. Test every token pairing actually used, not just the primary text/background pair.
- *Why:* this is the accessibility floor for any government-adjacent surface and a hard requirement per [design-foundations](../../skills/design-foundations/SKILL.md).
- *How:* run an automated contrast audit (e.g., `axe-core` or a contrast-checker script) against the full token pairing matrix as part of CI, not just a manual spot-check.
- *Check:: CI fails if any shipped text/background token pairing falls below its required ratio in either theme.

**`DS-006` — Never encode meaning in colour alone; pair every semantic colour with a text label or icon** · `MUST NOT`
Status, confidence, and error/success/warning states must be distinguishable without colour — via icon shape, text label, or pattern.
- *Why:* satisfies WCAG 1.4.11 non-text contrast and colourblind accessibility (approximately 8% of men have red-green deficiency); directly required by [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-008.
- *How:* every semantic-colour component variant (`<Badge variant="error">`, `<ConfidenceLabel>`) ships with a paired icon and text string as part of its default render, not as an optional prop.
- *Check:* a colourblind-simulation pass (e.g., a Chrome DevTools vision-deficiency emulation) confirms every status/confidence UI element remains distinguishable with colour removed.

**`DS-007` — Derive any client-brand override from the primary accent, never introduce unrelated hues ad hoc** · `SHOULD`
When a client mandates brand colours, set their primary as the accent, desaturate to build surfaces, keep semantic colours (red=error, green=success) recognizable, and rebuild both light and dark modes from that single accent.
- *Why:* prevents a client override from producing an internally inconsistent palette that fails contrast or clashes with semantic colours.
- *How:* follow the [design-foundations](../../skills/design-foundations/SKILL.md) custom-palette derivation procedure; re-run the DS-005 contrast audit on the derived palette before shipping.
- *Check:* a derived client palette passes the same automated contrast audit as the default Nexus palette before it replaces it.

### 3. Typography

**`DS-008` — Use a professional sans-serif stack for UI/product surfaces; reserve serif for editorial-only headings if ever used** · `MUST`
Default every Cognirise prototype's UI, dashboard, and product typography to sans-serif; do not introduce a serif typeface for body or UI text.
- *Why:* sans-serif performs better at small sizes and is the correct default for UI, dashboards, and product interfaces per [design-foundations](../../skills/design-foundations/SKILL.md).
- *How:* set `--font-sans` as the default font-family token applied to `body`; only override for an explicit editorial/marketing sub-surface, never inside the product UI.
- *Check:* design review confirms zero serif usage inside any dashboard, chat, canvas, or admin surface.

**`DS-009` — Cap the type scale at 3–4 text styles and 2 fonts, 2–3 weights each** · `MUST`
Use a fixed hierarchy: display/hero, section heading, body, caption — each mapped to one content role consistently across every surface.
- *Why:* proportional, restrained scales keep hierarchy legible; excess styles dilute meaning and increase implementation drift across surfaces.
- *How:* declare `--font-size-display`, `--font-size-heading`, `--font-size-body`, `--font-size-caption` tokens; map to Tailwind's `text-*` utilities via `theme.extend.fontSize`.
- *Check:* a token audit confirms no more than 4 distinct font-size tokens are referenced across the component inventory, and no more than 2 font-family tokens exist.

**`DS-010` — Use a bundled, Arabic-supporting font for RTL locales; never fall back to a Latin-only font for Arabic text** · `MUST`
Select a webfont with full Arabic glyph coverage (e.g., IBM Plex Sans Arabic, Noto Sans Arabic, or an equivalent with matching Latin companion) and load it for the `ar` locale; do not rely on system font substitution.
- *Why:* Arabic is a first-class locale for Cognirise's UAE/GCC client base, per the canonical stack's i18n row; system-substituted Arabic fonts render inconsistently across OSes and often fail basic legibility/weight-matching against the Latin companion font.
- *How:* set `--font-sans-ar` as a distinct token loaded conditionally by `next-intl` locale, paired with a Latin companion font at matching weight/x-height.
- *Check:* rendering the same UI in `ar` locale shows no fallback-to-system-font flash and no visible weight/size mismatch against the English version.

**`DS-011` — Set line-height and measure per script, not by a single fixed Latin default** · `MUST`
Body line-height for Latin text: 1.5–1.6×; Arabic script typically requires slightly increased line-height (1.6–1.8×) for comfortable reading given its connected letterforms and diacritics.
- *Why:* applying a Latin-tuned line-height to Arabic text produces cramped, harder-to-read paragraphs.
- *How:* a `--leading-body-ltr` and `--leading-body-rtl` token pair, selected by the active locale's direction.
- *Check:* Arabic body text visually reviewed for adequate line separation at the locale's line-height token; no diacritic clipping between lines.

### 4. AI-specific state tokens and components

**`DS-012` — Define a fixed AI-state token set covering idle/thinking/streaming/tool-running/awaiting-approval/blocked/error/done** · `MUST`
Each state gets its own colour, icon, and motion signature, reused identically across chat, canvas, and dashboard surfaces — never redefined per surface.
- *Why:* Shopify Polaris and other production design systems now ship dedicated AI-state layers rather than reusing generic loading/spinner tokens for everything; consistency here is what lets users build a stable mental model of what the agent is doing.
- *How:* declare `--state-idle`, `--state-thinking`, `--state-streaming`, `--state-tool-running`, `--state-awaiting-approval`, `--state-blocked`, `--state-error`, `--state-done` as colour tokens, each paired with a named icon and motion token (DS-016) in a single `agent-states.ts` config object.
- *Check:* every AI-state indicator in the product resolves from the shared `agent-states.ts` config; no surface defines its own ad hoc state colour.

**`DS-013` — Ship an `AgentStatusIndicator` component as the single rendering path for all eight states** · `MUST`
Build one component that accepts a state enum and renders the correct colour/icon/motion combination; do not let individual surfaces hand-roll their own status dot or spinner.
- *Why:* a single rendering path guarantees the DS-012 token set is actually applied everywhere, and makes future state additions a one-file change.
- *How:* `<AgentStatusIndicator state="tool-running" toolName="search_docs" />` — see Reference implementation for the component signature.
- *Check:* a grep across the codebase for raw `<Spinner>`/ad hoc status-dot markup outside `AgentStatusIndicator` returns zero results.

**`DS-014` — Ship a canonical `ToolCallCard`, `CitationChip`, `ConfidenceLabel`, `ApprovalBar`, and `TraceTimeline` component, each defined once** · `MUST`
These five components are the AI-specific vocabulary every Cognirise prototype needs; define each once in the shared component library and import everywhere, per [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-005/UX-007/UX-008/UX-014.
- *Why:* redefining these per-feature is the single most common source of visual/behavioral drift in agentic products; the UX standard's rules only hold if the components are structurally shared, not just visually similar.
- *How:* place all five under `components/agent/` with typed props matching the AI SDK message-part shapes; document each in Storybook (or an equivalent static catalogue) with all state variants.
- *Check:* a component-inventory audit (DS-024) confirms exactly one implementation of each of the five components exists in the codebase.

**`DS-015` — Give skeleton loaders a shape token per content type; never use a single generic skeleton** · `MUST`
Define `--skeleton-card`, `--skeleton-table-row`, `--skeleton-paragraph` shape tokens (dimensions/border-radius/count), selected by the expected response schema before the first token streams.
- *Why:* shape-matched skeletons reduce perceived latency and prevent layout shift, per [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-021.
- *How:* a `<Skeleton variant="card" | "table-row" | "paragraph" | "citation">` component reading the shape tokens.
- *Check:* every structured-output surface's loading state uses a shape-matched `<Skeleton>` variant, never the bare default rectangle.

### 5. Motion

**`DS-016` — Tie every motion token to a specific agent-activity state, and stop it within one frame of that activity ending** · `MUST`
Subtle pulse/shimmer for "thinking," a breathing dot or animated ellipsis for "streaming," a distinct labeled spinner for "tool running" (name the tool), and a static icon (no motion) for terminal states (done/error).
- *Why:* motion should map to real activity; orphaned looping animations after the underlying activity has stopped falsely signal continued liveness and erode trust.
- *How:* drive motion purely from the `AgentStatusIndicator`'s `state` prop — unmount/stop the animation class the instant `state` transitions to a terminal value; never use a fixed-duration CSS animation loop independent of state.
- *Check:* an automated test transitions state to `done`/`error` and asserts the motion class is removed within one animation frame.

**`DS-017` — Respect `prefers-reduced-motion` on every AI-state and transition animation without exception** · `MUST`
Provide a reduced-motion fallback (opacity/colour change only, no movement/scale/shimmer) for every motion token.
- *Why:* motion-sensitive users must not be forced to experience agent-activity animations; this is a baseline accessibility requirement, not optional polish.
- *How:* wrap motion CSS in `@media (prefers-reduced-motion: no-preference)`; define a static fallback state (colour/opacity change only) outside that query.
- *Check:* toggling OS-level reduced-motion and re-testing every AI-state transition confirms no movement/scale/shimmer occurs, only static or opacity changes.

**`DS-018` — Cap transition durations to 150–300ms for UI chrome and 600–800ms for data-reveal animations** · `MUST`
UI state transitions (hover, focus, approval-bar appearance) use 150–300ms; chart/data-reveal animations (bars growing, counters ticking) use 600–800ms.
- *Why:* faster UI-chrome transitions feel responsive; slower data-reveal timing gives the eye time to register a meaningful change without feeling sluggish.
- *How:* `--motion-duration-ui: 200ms` and `--motion-duration-data: 700ms` tokens, applied via Tailwind's `transition-duration` utilities.
- *Check:* a motion audit confirms no UI-chrome transition exceeds 300ms and no data-reveal animation exceeds 800ms.

### 6. Density and layout grid

**`DS-019` — Support two density modes — compact and comfortable — as a token-level setting, not a one-off style** · `MUST`
Compact density (reduced padding/line-height) for high-frequency power-user surfaces (ops dashboards showing many concurrent agent runs); comfortable density for conversational surfaces.
- *Why:* density should be systematized once and applied consistently, not re-decided per screen.
- *How:* a `data-density="compact"|"comfortable"` attribute at the layout root, switching `--space-*` token values via CSS attribute selectors.
- *Check:* toggling density at the root re-flows spacing consistently across every component without any component-local density logic.

**`DS-020` — Use an 8px base spacing unit and a 12-column responsive grid** · `MUST`
All `--space-*` tokens are multiples of 8px (4px permitted only for the tightest icon/label gaps); page layout uses a 12-column grid with defined breakpoints.
- *Why:* an 8px base unit keeps spacing visually consistent and maps cleanly onto Tailwind's default spacing scale; a 12-column grid supports both dashboard (dense, multi-panel) and conversational (single-column, wide-margin) layouts from one system.
- *How:* Tailwind's default spacing scale (`4, 8, 12, 16, 24, 32, 48, 64px`) mapped to `--space-*` tokens; `grid-cols-12` with `container` breakpoints at `sm/md/lg/xl/2xl`.
- *Check:* a spacing audit confirms no arbitrary pixel value (e.g., `13px`, `22px`) appears in any component's spacing classes.

### 7. Component inventory

**`DS-021` — Ship the full mandatory component inventory with every Cognirise prototype, regardless of client** · `MUST`
Every prototype includes, at minimum, these components before first demo: `AgentStatusIndicator`, `ToolCallCard`, `CitationChip`, `ConfidenceLabel`, `ApprovalBar`, `DiffView`, `DryRunPreview`, `RunControlBar`, `UndoAffordance`, `Skeleton` (all variants), `StatusStrip`, `ActivityTimeline`, `TraceTimeline`, `RunHistoryTable`, `ArtifactsPane`, `PermissionsPanel`, `UsageMeter`, `AuditLogTable`, `TenantSwitcher`, `SuggestedPrompts`, `ModePicker`, `FeedbackControl`, `StateBanner` (all five variants).
- *Why:* this is the concrete component-level manifestation of the behavioral rules in [05 — UI/UX for Agentic Apps](./05-ux-ui.md); shipping the inventory guarantees the UX standard is implementable, not aspirational.
- *How:* scaffold all listed components from a shared `@cognirise/agent-ui` internal package (or a copy-in component set if no shared package exists yet) at project start, before feature-specific screens are built.
- *Check:* a project cannot be marked "demo-ready" in QA until every component in this inventory exists in the codebase, even if some render minimal/placeholder states for features not yet built.

**`DS-022` — Build every component on shadcn/ui primitives (Radix) — never introduce a second component library** · `MUST`
All custom AI-specific components (DS-014, DS-021) compose shadcn/ui primitives (`Button`, `Badge`, `Card`, `Dialog`, `Popover`, `Sheet`, `Tabs`, `Table`, `Separator`, `ScrollArea`, `Tooltip`, `HoverCard`) rather than a competing UI kit.
- *Why:* the canonical stack fixes shadcn/ui + Radix as the styling layer; a second component library fragments theming, accessibility behavior, and bundle size.
- *How:* install shadcn/ui components via its CLI into `components/ui/`; compose AI-specific components in `components/agent/` on top of them.
- *Check:* a dependency audit confirms no second component library (MUI, Chakra, Ant Design, etc.) is present in `package.json`.

**`DS-023` — Every custom component ships with documented state variants, not just a happy-path render** · `MUST`
`ToolCallCard` documents `input-streaming`, `input-available`, `output-available`, `output-error`; `ConfidenceLabel` documents `low`/`medium`/`high`; `StateBanner` documents all five variants — each as a distinct, viewable entry.
- *Why:* undocumented state variants are the ones that get skipped in implementation and only discovered missing during a client demo.
- *How:* a Storybook story (or equivalent static catalogue page) per state variant for every component in the DS-021 inventory.
- *Check:* the component catalogue has at least one story per documented state variant; a reviewer can view every state without running the full app.

**`DS-024` — Run a component-inventory audit before every client demo** · `MUST`
Confirm all DS-021 components exist, resolve tokens from DS-001–DS-020, and have no duplicate implementations.
- *Why:* this is the single gate that catches token/component drift before a client sees it.
- *How:* a checklist script cross-referencing the component directory against the DS-021 list and the token-audit script from DS-002.
- *Check:* the audit script passes with zero missing components and zero duplicate implementations before demo sign-off.

### 8. RTL and bilingual typography

**`DS-025` — Build every component with CSS logical properties, never physical left/right properties** · `MUST`
Use `margin-inline-start`, `padding-inline-end`, `text-align: start`, etc., instead of `margin-left`, `padding-right`, `text-align: left`; in Tailwind, use RTL-aware utilities (`ms-*`, `me-*`, `ps-*`, `pe-*`) instead of `ml-*`/`mr-*`/`pl-*`/`pr-*`.
- *Why:* physical properties require a separate RTL override for every component; logical properties flip automatically with `dir="rtl"`, halving the RTL implementation and QA burden.
- *How:* enforce via an ESLint rule banning `ml-`, `mr-`, `pl-`, `pr-`, `text-left`, `text-right` Tailwind classes in favour of their logical equivalents.
- *Check:* the lint rule fails CI on any physical-direction utility class in new code.

**`DS-026` — Mirror icon and control order in RTL, not just text direction** · `MUST`
Directional icons (arrows, chevrons, the Stop/Pause/Approve-Deny button order) must visually mirror in RTL layouts; icons that represent inherently non-directional concepts (e.g., a citation marker) must not mirror.
- *Why:* flipping only text direction while leaving control order and directional icons untouched produces a jarring, half-localized interface that reads as unfinished to Arabic-speaking users.
- *How:: wrap directional icons in a component that applies `rtl:scale-x-[-1]` or swaps to a mirrored icon variant; apply `dir="rtl"` at the root so Flexbox/Grid order (`flex-row` → visually reversed) handles control order automatically.
- *Check:* a visual RTL review confirms the `ApprovalBar` button order and all directional icons mirror correctly; the `CitationChip` icon does not mirror.

**`DS-027` — Budget layout for 30–40% string-length expansion in Arabic and translated UI strings** · `MUST`
No fixed-width container holding translatable text; use `min-w`/`max-w` with wrapping, never a hardcoded pixel width sized to the English string.
- *Why:* Arabic and other translated strings routinely run 30–40% longer than their English source; fixed-width containers clip or overlap under this expansion.
- *How:* apply the DS-020 spacing/grid tokens with flexible (`flex-1`, `min-w-0`) containers; run a pseudo-localization pass (mechanically lengthen every string by 40%) before ship, per [05 — UI/UX for Agentic Apps](./05-ux-ui.md) · UX-055.
- *Check:* the pseudo-localization pass shows no clipped or overlapping text across the DS-021 component inventory.

**`DS-028` — Pair every Arabic numeral display with the client's expected numeral system, and keep numeric data tabular** · `MUST`
Confirm with the client whether Eastern Arabic numerals (٠١٢٣...) or Western Arabic numerals (0123...) are expected in the `ar` locale — UAE government and banking clients commonly expect Western numerals in digital UI even in Arabic text — and default numeric-data typography to `tabular-nums`.
- *Why:* assuming the wrong numeral system for a government/banking client is a visible, credibility-damaging error; tabular numerals keep financial/data tables aligned.
- *How:* a locale-specific numeral-formatting utility (`Intl.NumberFormat` with the confirmed numbering system) applied at the data layer, not per component; `font-variant-numeric: tabular-nums` token on all numeric table/KPI cells.
- *Check:: the confirmed numeral system is documented in the project's locale spec and matches what actually renders in the `ar` locale build.

### 9. Chart and data-viz conventions

**`DS-029` — Derive chart colours from the same design system as the UI — never introduce unrelated chart-only hues** · `MUST`
Sequential data uses monochromatic shades of the Nexus accent; categorical data uses the 8-colour categorical sequence from [design-foundations](../../skills/design-foundations/SKILL.md); diverging data uses teal (`#20808D`) positive / red (`#A13544`) negative.
- *Why:* chart colours that don't relate to the product's palette look bolted-on and break the "one design system" mental model the AI-state tokens (DS-012) are trying to build.
- *How:: a `chartColors` token array exported from the same token file as the UI colours, consumed by the charting library's series-colour config.
- *Check:* a design review confirms every chart in the product draws its palette from the shared `chartColors` array, never a library default palette.

**`DS-030` — Cap charts at 5 series; use small multiples beyond that; never use 3D charts or pie charts with 5+ slices** · `MUST NOT` (3D charts, dual-axis charts, pie charts with 5+ slices)
Beyond 5 comparable series, split into small multiples rather than overloading one chart.
- *Why:* charts with too many series or dual axes are measurably harder to read correctly and are a common source of misleading data presentation.
- *How:: enforce as a design-review checklist item on every new chart component; provide a `<SmallMultiples>` layout helper for the >5-series case.
- *Check:* design review rejects any chart with more than 5 series in one view, any 3D rendering, any dual-axis chart, or any pie chart with 5+ slices.

**`DS-031` — Label data directly on the chart where legible; use `tabular-nums` for every numeric axis and value label** · `SHOULD`
Prefer direct labeling over a separate legend when it doesn't clutter the chart; always apply tabular numerals to axis labels and value callouts.
- *Why:: direct labeling reduces the eye-movement cost of correlating a legend to a data point; tabular numerals keep columns of numbers visually aligned.
- *How:: chart component defaults to direct labels for ≤5 series; falls back to a legend only when direct labels would overlap; apply the `--font-numeric` (tabular) token to all numeric text in charts.
- *Check:* a spot check of shipped charts confirms tabular alignment on any numeric column and direct labeling used wherever it doesn't visually collide.

**`DS-032` — Title every chart with the insight, not the chart's contents** · `SHOULD`
Chart titles state a finding ("Approval turnaround improved 23% after SLA sweep launch") rather than a description ("Approval Turnaround Chart").
- *Why:: an insight-stated title tells the reader what to look for before they parse the chart; a content-described title makes them do the work the chart should be doing.
- *How:: enforce as a copy-review checklist item alongside the DS-030 chart-review gate.
- *Check:* design/copy review confirms chart titles are phrased as findings, not descriptions.

## Reference implementation

### Token file (`app/globals.css`)

```css
:root {
  /* --- colour: background/surface/text (Nexus, light) --- */
  --color-background: #F7F6F2;
  --color-surface: #F9F8F5;
  --color-surface-alt: #FBFBF9;
  --color-border: #D4D1CA;
  --color-text: #28251D;
  --color-text-muted: #7A7974;
  --color-text-faint: #BAB9B4;
  --color-primary: #01696F;
  --color-primary-hover: #0C4E54;
  --color-error: #A12C7B;
  --color-warning: #964219;
  --color-success: #437A22;

  /* --- AI-specific state tokens --- */
  --state-idle: var(--color-text-faint);
  --state-thinking: #C9A227;         /* amber pulse */
  --state-streaming: var(--color-primary);
  --state-tool-running: #4F98A3;
  --state-awaiting-approval: var(--color-warning);
  --state-blocked: #7A7974;
  --state-error: var(--color-error);
  --state-done: var(--color-success);

  /* --- spacing (8px base) --- */
  --space-1: 4px;  --space-2: 8px;  --space-3: 12px; --space-4: 16px;
  --space-6: 24px; --space-8: 32px; --space-12: 48px; --space-16: 64px;

  /* --- radius --- */
  --radius-sm: 6px; --radius-md: 10px; --radius-lg: 16px; --radius-full: 9999px;

  /* --- elevation --- */
  --elevation-1: 0 1px 2px rgba(40,37,29,0.06);
  --elevation-2: 0 4px 12px rgba(40,37,29,0.10);
  --elevation-3: 0 12px 32px rgba(40,37,29,0.14);

  /* --- motion --- */
  --motion-duration-ui: 200ms;
  --motion-duration-data: 700ms;
  --motion-ease: cubic-bezier(0.2, 0, 0, 1);

  /* --- typography --- */
  --font-sans: "Satoshi", "Inter", system-ui, sans-serif;
  --font-sans-ar: "IBM Plex Sans Arabic", "Noto Sans Arabic", var(--font-sans);
  --font-numeric: var(--font-sans);
  --font-size-display: 2.5rem;
  --font-size-heading: 1.5rem;
  --font-size-body: 1rem;
  --font-size-caption: 0.8125rem;
  --leading-body-ltr: 1.55;
  --leading-body-rtl: 1.7;
}

.dark {
  --color-background: #171614;
  --color-surface: #1C1B19;
  --color-surface-alt: #201F1D;
  --color-border: #393836;
  --color-text: #CDCCCA;
  --color-text-muted: #797876;
  --color-text-faint: #5A5957;
  --color-primary: #4F98A3;
  --color-primary-hover: #227F8B;
  --color-error: #D163A7;
  --color-warning: #BB653B;
  --color-success: #6DAA45;

  --state-thinking: #E8AF34;
  --state-streaming: var(--color-primary);
  --state-tool-running: #4F98A3;
  --state-awaiting-approval: var(--color-warning);
  --state-error: var(--color-error);
  --state-done: var(--color-success);
}

@media (prefers-reduced-motion: reduce) {
  * { animation-duration: 0.001ms !important; transition-duration: 0.001ms !important; }
}
```

### Tailwind wiring (`tailwind.config.ts`)

```ts
import type { Config } from "tailwindcss";

export default {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "var(--color-background)",
        surface: "var(--color-surface)",
        "surface-alt": "var(--color-surface-alt)",
        border: "var(--color-border)",
        text: "var(--color-text)",
        "text-muted": "var(--color-text-muted)",
        primary: { DEFAULT: "var(--color-primary)", hover: "var(--color-primary-hover)" },
        error: "var(--color-error)",
        warning: "var(--color-warning)",
        success: "var(--color-success)",
        state: {
          idle: "var(--state-idle)",
          thinking: "var(--state-thinking)",
          streaming: "var(--state-streaming)",
          "tool-running": "var(--state-tool-running)",
          "awaiting-approval": "var(--state-awaiting-approval)",
          blocked: "var(--state-blocked)",
          error: "var(--state-error)",
          done: "var(--state-done)",
        },
      },
      borderRadius: {
        sm: "var(--radius-sm)", md: "var(--radius-md)", lg: "var(--radius-lg)", full: "var(--radius-full)",
      },
      fontFamily: { sans: ["var(--font-sans)"], "sans-ar": ["var(--font-sans-ar)"] },
      transitionDuration: { ui: "var(--motion-duration-ui)", data: "var(--motion-duration-data)" },
    },
  },
  plugins: [],
} satisfies Config;
```

### `AgentStatusIndicator` component signature

```tsx
// components/agent/agent-status-indicator.tsx
type AgentState =
  | "idle" | "thinking" | "streaming" | "tool-running"
  | "awaiting-approval" | "blocked" | "error" | "done";

const STATE_CONFIG: Record<AgentState, { label: string; icon: React.ComponentType; motion: "pulse" | "breathe" | "spin" | "none" }> = {
  idle: { label: "Idle", icon: CircleIcon, motion: "none" },
  thinking: { label: "Thinking", icon: SparkleIcon, motion: "pulse" },
  streaming: { label: "Responding", icon: DotIcon, motion: "breathe" },
  "tool-running": { label: "Running tool", icon: ToolIcon, motion: "spin" },
  "awaiting-approval": { label: "Awaiting approval", icon: PauseIcon, motion: "none" },
  blocked: { label: "Blocked", icon: BlockIcon, motion: "none" },
  error: { label: "Error", icon: AlertIcon, motion: "none" },
  done: { label: "Done", icon: CheckIcon, motion: "none" },
};

export function AgentStatusIndicator({ state, toolName }: { state: AgentState; toolName?: string }) {
  const cfg = STATE_CONFIG[state];
  return (
    <span className={`inline-flex items-center gap-2 text-state-${state}`}>
      <cfg.icon className={cfg.motion !== "none" ? `motion-${cfg.motion}` : ""} aria-hidden />
      <span className="text-caption">{toolName ? `${cfg.label}: ${toolName}` : cfg.label}</span>
    </span>
  );
}
```

### RTL-safe layout primitive

```tsx
// components/agent/approval-bar.tsx (excerpt, RTL-safe)
<div className="flex items-center gap-2 ms-auto"> {/* ms- not ml- */}
  <Button className="min-h-6 min-w-6">Approve</Button>
  <Button variant="destructive" className="min-h-6 min-w-6">Deny</Button>
</div>
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Hardcoded hex values inside component `className`/`style` | Breaks theme switching, RTL, and client re-branding | Resolve every colour through a CSS variable token (DS-001) |
| Reusing the generic loading spinner for every AI state | Fails to distinguish thinking/streaming/tool-running/error to the user | Dedicated AI-state token set + `AgentStatusIndicator` (DS-012, DS-013) |
| A second component library alongside shadcn/ui | Fragments theming, a11y behavior, bundle size | Compose everything on shadcn/ui + Radix primitives (DS-022) |
| Physical-direction Tailwind classes (`ml-4`, `text-left`) | Requires a manual RTL override per component | Logical-property utilities (`ms-4`, `text-start`) (DS-025) |
| Fixed-width containers sized to the English string | Clips/overlaps under Arabic or translated text expansion | Flexible, wrapping containers budgeted for +40% length (DS-027) |
| Motion that keeps looping after the agent finishes | Falsely signals continued activity, erodes trust | Motion stops within one frame of state reaching a terminal value (DS-016) |
| Ignoring `prefers-reduced-motion` on AI-state animations | Forces motion on motion-sensitive users | Static/opacity-only fallback under the media query (DS-017) |
| Chart palettes unrelated to the product's colour system | Looks bolted-on, breaks the single-design-system mental model | Derive chart colours from the shared token file (DS-029) |
| 3D charts, dual-axis charts, pie charts with 5+ slices | Measurably harder to read correctly, misleading | Small multiples, single-axis, capped series count (DS-030) |
| Assuming Eastern Arabic numerals without client confirmation | Visible, credibility-damaging localization error for government/banking clients | Confirm numeral system explicitly; default to tabular numerals (DS-028) |
| Defining the same AI-specific component (e.g., `ToolCallCard`) twice in one codebase | Guarantees visual/behavioral drift between features | One canonical implementation per component, audited (DS-014, DS-024) |

## Definition of Done

- [ ] Every colour, spacing, radius, elevation, and motion value in the codebase resolves through a token; the raw-literal lint rule passes (DS-001).
- [ ] Light and dark themes have 1:1 token coverage; the token-audit script passes (DS-003).
- [ ] Every shipped text/background pairing passes WCAG AA contrast in both themes, verified by the automated contrast audit (DS-005).
- [ ] No status/confidence/error UI element relies on colour alone; the colourblind-simulation pass confirms this (DS-006).
- [ ] The full DS-021 component inventory exists in the codebase before the project is marked demo-ready, with documented state variants (DS-021, DS-023).
- [ ] `AgentStatusIndicator` is the sole rendering path for all eight AI states; no ad hoc spinners/status dots exist elsewhere (DS-013).
- [ ] All AI-state and transition motion respects `prefers-reduced-motion` and stops within one frame of the underlying activity ending (DS-016, DS-017).
- [ ] RTL build uses only logical-property utilities, mirrors directional icons and control order correctly, and survives a +40% pseudo-localization pass without clipping (DS-025, DS-026, DS-027).
- [ ] Numeral system for the `ar` locale is explicitly confirmed with the client and documented (DS-028).
- [ ] All charts derive their palette from the shared token file, cap at 5 series, and avoid the banned chart types (DS-029, DS-030).

## Handoff notes

- Attach this file's token CSS block and Tailwind config excerpt verbatim when asking Claude or Replit Agent to scaffold a new prototype — do not describe the palette in prose and let it re-derive hex values.
- State explicitly whether the client has provided brand colours; if not, instruct the implementer to use the Nexus palette exactly as specified in DS-004, not an approximation.
- Confirm the Arabic numeral system (Eastern vs. Western) with the client before implementation starts and pass that decision along with this file — DS-028 cannot be resolved by the implementer alone.
- Pass the DS-021 component inventory list alongside any feature spec so the implementer scaffolds shared components once, not per feature.

## Sources

- [Polaris Goes Stable — Shopify](https://www.shopify.com/partners/blog/polaris-goes-stable-the-future-of-shopify-app-development-is-here) — first-class AI states in production design systems
- [Creating a Skeleton UI Loading Animation (ProtoPie)](https://www.protopie.io/blog/how-to-create-a-skeleton-ui-loading-animation) — shape-matched skeleton rationale
- [Chatbot Tool Usage (Vercel AI SDK)](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage) — typed message-part states informing the `ToolCallCard` variants
- [What's New in WCAG 2.2 (W3C WAI)](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) — target size and focus-visibility tokens
- [5 Challenges in Multilingual AI UX Design (DeveloperUX)](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/) — text-expansion budget and RTL considerations
- [Designing Trust in AI Outputs: 7 UX Patterns for Uncertainty (Creative Alive)](https://creativealive.com/designing-trust-ai-outputs-ux-patterns-uncertainty/) — colour+label confidence signaling basis for DS-006
- [Regulated-sector readiness research brief](../../research/05-regulated.md) — WCAG 2.2 AA baseline, Arabic/RTL parity, UAE Design System expectations for government-adjacent surfaces
- [Design Foundations skill](../../skills/design-foundations/SKILL.md) — Nexus palette values, chart colour sequence, typography scale, and font-strategy rules reused directly in this standard
