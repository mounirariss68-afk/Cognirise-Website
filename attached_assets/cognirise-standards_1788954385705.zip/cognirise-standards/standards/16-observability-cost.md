---
id: observability-cost
domain: Safety, Security & Governance
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 16. Observability & Cost

> **Purpose.** Make every agent run debuggable after the fact, every eval score traceable to a real trace, and every dollar/token spent attributable to a run and a tenant — so "why did the agent do that" and "what did this cost" are always answerable.
> **Read this when.** Technical spec (instrumentation checklist, cost/latency budget table), implementation (OTel wiring, Langfuse/LangSmith setup), ongoing operation (dashboards, alerting).

## Scope
- In scope: OpenTelemetry GenAI semantic conventions, span/attribute naming, trace/run ID propagation to the UI, what must/must never be logged, Langfuse/LangSmith wiring on the canonical stack, cost and token accounting per run and per tenant, latency budgets and percentile targets, alerting thresholds, mandatory dashboards, log retention.
- Out of scope: eval score computation and judge design → see [15 — Evaluation](./15-evaluation.md) (this standard only covers where eval scores attach as span attributes, OBS-004). PII scrubbing logic itself → see [12 — Guardrails & Safety](./12-guardrails-safety.md) · GRD-012/013 (this standard covers what must never be logged, OBS-006). Retention *policy* ownership → the data governance standard (GOV, forthcoming); this standard aligns to it but does not set it.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Instrumentation baseline | OpenTelemetry GenAI semantic conventions for every LLM call, tool execution, and agent handoff span | Vendor-neutral conventions keep traces portable across observability backends ([OpenTelemetry GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/)) |
| Backend | Langfuse (self-hostable, framework-agnostic) or LangSmith (if LangGraph/LangChain-native) — never no backend | Canonical stack: OTel GenAI conventions → Langfuse (or LangSmith) ([_CANON-CONVENTIONS.md](../_CANON-CONVENTIONS.md)) |
| Trace/run ID propagation | Every trace/run ID surfaced to the UI and attached to the feedback control | Closes the loop from production feedback to a specific trace (see [15 — Evaluation](./15-evaluation.md) · EVAL-020) |
| Cost attribution | Token usage and cost logged per run and rolled up per tenant, not just globally | Cost/latency budget standard requires evidence-based, per-client cost visibility ([01-standards-areas.md, B5](../../research/01-standards-areas.md)) |
| Never-log list | Raw PII, secrets, and full tool-call payloads containing unredacted sensitive fields never reach logs/traces in plaintext | Direct extension of the PII/secrets rules in [12](./12-guardrails-safety.md)/[13](./13-security-authz.md) into the observability layer |
| Retention | Aligned to the governance standard's minimum, never shorter for compliance-relevant traces | Prevents cost-driven pruning jobs from silently violating audit/retention obligations |

## Rules

### Mandatory instrumentation: OpenTelemetry GenAI semantic conventions

**`OBS-001` — Instrument every LLM call, tool execution, and agent handoff as an OpenTelemetry span** · `MUST`
No agent operation may run uninstrumented; every model call, every tool invocation, and every multi-agent handoff must produce a span.
- *Why:* OpenTelemetry maintains dedicated GenAI semantic-convention categories (events, metrics, model spans, agent spans) precisely so agent instrumentation targets a vendor-neutral spec rather than an ad hoc logging format ([OpenTelemetry GenAI semantic conventions repository](https://github.com/open-telemetry/semantic-conventions/blob/main/docs/gen-ai/README.md)).
- *How:* Use the OpenTelemetry SDK for Node.js (`@opentelemetry/api`) with spans created at each LLM SDK call site, each tool handler entry/exit, and each `transfer_to()` handoff.
- *Check:* Trace inspection for a completed job shows a span for every LLM call, tool call, and handoff recorded in the job's `plan_steps`.

**`OBS-002` — Use OTel GenAI conventional attribute names, not project-invented equivalents** · `MUST`
Spans must use the standard GenAI semantic-convention attribute names: `gen_ai.operation.name`, `gen_ai.request.model`, `gen_ai.response.model`, `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, and the `invoke_agent` span name for agent-invocation spans.
- *Why:* Using the spec's actual field names (not project-specific aliases) is what keeps traces portable across backends and forward-compatible if the observability vendor changes ([OpenTelemetry GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/); [03-journeys-and-agents.md, B.13](../../research/03-journeys-and-agents.md)).
- *How:* Central `otel/genaiAttributes.ts` constants module exporting the exact attribute-name strings, imported everywhere spans are created — never hand-typed inline.
- *Check:* Static grep confirms no span-attribute-setting call site uses a literal string outside the shared constants module.

**`OBS-003` — Instrument guardrail and moderation checks as sibling spans under the same parent as the generation call they guard** · `MUST`
Moderation, relevance-classifier, and safety-classifier calls (see [12 — Guardrails & Safety](./12-guardrails-safety.md) · GRD-009/GRD-011) must appear as their own spans nested under the same parent span as the guarded generation, not folded silently into it.
- *Why:* Makes the guardrail pipeline itself auditable from the trace tree, matching the parallel-dispatch pattern the guardrails standard mandates.
- *How:* `moderation.ts` and `inputGuard.ts` open their own child spans (`gen_ai.operation.name = "moderation_check"` / `"relevance_classification"`) under the run's parent span.
- *Check:* Trace tree for a run shows moderation/classification spans as visible siblings, not absent or merged into the generation span.

### Span and attribute naming

**`OBS-004` — Write eval scores back as attributes on the span they evaluate** · `MUST`
Every scored trajectory (see [15 — Evaluation](./15-evaluation.md) · EVAL-012) must have `gen_ai.evaluation.score.value`, `gen_ai.evaluation.score.label`, and `gen_ai.evaluation.explanation` written onto the corresponding span.
- *Why:* "The trace tree and the score live on the same span," which is the integration point that lets a reviewer see quality and execution detail together ([Future AGI's guide to LLM agent evaluation](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)).
- *How:* Eval runner (promptfoo custom provider or a post-run hook) looks up the run's trace/span ID and calls the tracing backend's attribute-update API.
- *Check:* Querying a recently evaluated trace in Langfuse/LangSmith shows evaluation attributes present on the correct span.

**`OBS-005` — Name spans consistently by operation type across the whole project, per a documented naming table** · `MUST`
Every project must document its span-naming table (operation type → span name) in the technical spec, reusing the OTel GenAI conventional names where they exist and extending consistently where they don't (e.g., `checkpoint_write`, `approval_gate_wait`).
- *Why:* Consistent naming is what makes cross-run dashboard aggregation and alerting (OBS-014/015) possible without per-run manual mapping.
- *How:* `docs/observability/span-naming.md` table checked into the repo, enforced by the shared attributes module (OBS-002).
- *Check:* Spec review confirms the naming table exists and matches the attribute constants module.

### Trace and run IDs propagated to the UI for feedback linkage

**`OBS-006` — Propagate the run's trace ID (or root span ID) to the client UI on every agent response** · `MUST`
Every agent-facing UI response must carry a `trace_id`/`run_id` reference accessible to the frontend, not just retained server-side.
- *Why:* This is the mechanism that links a user's feedback action (see [15 — Evaluation](./15-evaluation.md) · EVAL-020) back to the exact trace that produced the response.
- *How:* API route response payload includes a `traceId` field; the frontend feedback component reads it and attaches it to the `production_feedback` write.
- *Check:* Integration test confirms an agent response payload includes a non-null `traceId` matching an actual span in the tracing backend.

**`OBS-007` — Never expose the raw trace ID as the only identifier without also logging the mapping to job/user context server-side** · `MUST`
The trace ID surfaced to the UI must be resolvable server-side back to `job_id`, `user_id` (or tenant), and `session_id` for support/debugging purposes.
- *Why:* A bare trace ID with no server-side context mapping is unusable for support triage or audit follow-up.
- *How:* `traces` metadata table (or the tracing backend's native metadata fields) stores `trace_id → job_id, tenant_id, session_id`.
- *Check:* Support runbook test: given a `trace_id` from a user bug report, confirm the on-call engineer can resolve it to the originating job within one query.

### What must be logged versus never logged

**`OBS-008` — Log, at minimum, per span: model/provider identity, token usage, latency, tool name and arguments (redacted per OBS-010), and outcome** · `MUST`
Every LLM-call and tool-call span must carry these fields at minimum, regardless of project-specific additions.
- *Why:* This is the baseline capture set needed to debug "why did the agent do that" and to compute cost/latency metrics (OBS-011/012) ([03-journeys-and-agents.md, B.13](../../research/03-journeys-and-agents.md)).
- *How:* Shared span-creation helper enforces these fields are set before a span closes; missing fields fail a lint/test check.
- *Check:* A sampled span from any project is checked against this field list in code review of the instrumentation module.

**`OBS-009` — Never log raw secrets, API keys, or unredacted credentials in any span, log line, or trace attribute** · `MUST NOT`
No span attribute, structured log field, or error message may contain a raw credential value, even in a debug-level log.
- *Why:* Extends [13 — Security & Authorization](./13-security-authz.md) · SEC-013/SEC-014's secrets discipline into the observability layer, where accidental logging is a common leak vector.
- *How:* Shared logging/tracing utility runs a secret-pattern scrubber (matching known credential shapes and any value sourced from a Secrets-backed environment variable) before any attribute is written.
- *Check:* Automated log-scan job (regex for common key formats, e.g., `sk-`, `AKIA`, JWT shape) run against a sample of recent traces; zero matches required.

**`OBS-010` — Never log raw PII in span attributes or log lines; apply the same scrubber used for persistence and display** · `MUST NOT`
Tool-call arguments, user input, and model output written into spans/logs must pass the PII scrubber (see [12 — Guardrails & Safety](./12-guardrails-safety.md) · GRD-012/013) before being attached as attributes.
- *Why:* Logs and traces are a persistence surface like any other; PII redaction obligations apply equally here, and observability backends are frequently a lower-scrutiny surface than the primary database.
- *How:* The shared span-attribute helper (OBS-002) calls `piiScrubber.ts` on any free-text field before setting it as an attribute.
- *Check:* Integration test feeds a synthetic-PII tool argument and asserts the resulting span attribute is redacted.

**`OBS-011` — Never log full unredacted tool-call payloads for high-risk/sensitive tools; log a redacted summary plus a reference to the durable, access-controlled record** · `MUST`
For tools tagged `risk_tier: high` or handling sensitive data categories, the trace span should carry a redacted summary and a reference ID (e.g., the `decision_records` or `audit_log` row ID from [14](./14-hitl-escalation.md)/[13](./13-security-authz.md)), not the full raw payload.
- *Why:* Keeps the observability backend (often a separate vendor/service) from becoming a second, less-controlled copy of sensitive operational data.
- *How:* `toolRiskGate.ts` branches on `risk_tier` when constructing span attributes, substituting a summary + `audit_log_id` reference for high-risk tools.
- *Check:* Trace inspection for a high-risk tool call shows a reference ID and summary, not the full raw payload, in the span attributes.

### Langfuse/LangSmith wiring on the canonical stack

**`OBS-012` — Wire Langfuse (default) or LangSmith (if the project is LangGraph/LangChain-native) via SDK call from the existing Replit process, without standing up a separate collector** · `MUST`
Export OTel-shaped spans to Langfuse or LangSmith directly from the Node/Python process already running on Replit; do not attempt to self-host a separate OTel collector unless a documented escape-hatch trigger applies.
- *Why:* Both integrate via an SDK call without needing a separately hosted collector, which fits Replit's single-process deployment model ([03-journeys-and-agents.md, B.13](../../research/03-journeys-and-agents.md)).
- *How:* Langfuse SDK initialized once at process startup with `LANGFUSE_PUBLIC_KEY`/`LANGFUSE_SECRET_KEY` from Replit Secrets; OTLP exporter configured to point at Langfuse's ingestion endpoint.
- *Check:* Startup log confirms the tracing SDK initialized successfully; a test run appears in the Langfuse/LangSmith project dashboard within the expected ingestion delay.

**`OBS-013` — Fall back to structured JSON logging into a Postgres `traces` table if no external observability vendor is approved yet, using OTel GenAI field names** · `SHOULD`
Where a client engagement has not yet approved an external observability vendor, log structured span-shaped JSON rows into Postgres using the same GenAI semantic-convention field names, so migration to Langfuse/LangSmith later requires no field renaming.
- *Why:* Keeps the project forward-compatible with full OTel adoption without blocking early-stage delivery on a vendor approval ([03-journeys-and-agents.md, B.13](../../research/03-journeys-and-agents.md)).
- *How:* `traces` table schema mirrors `gen_ai.*` attribute names as column names or a JSONB attributes column using those keys.
- *Check:* Schema review confirms field names match the GenAI semantic-convention vocabulary, not project-invented equivalents.

### Cost and token accounting per run and per tenant

**`OBS-014` — Log input, output, and cached token counts per call, rolled up per job and per tenant** · `MUST`
`gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, and cache-hit metadata must be captured per call and aggregated into per-job and per-tenant cost views.
- *Why:* "Monitor token consumption per agent and per orchestration run so optimization effort targets the actual cost drivers, not guesses" ([Microsoft's Azure Architecture Center guidance](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)); per-tenant rollup is required for multi-client cost accountability.
- *How:* `jobs` table (or `traces`) sums `usage.*` fields per job; a scheduled aggregation job rolls per-job totals into a `tenant_cost_daily` table.
- *Check:* Query `tenant_cost_daily` for a known test tenant and confirm the total matches the sum of that tenant's individual run costs.

**`OBS-015` — Compute and expose cost-per-request alongside token counts, using current provider pricing** · `MUST`
Cost (not just token count) must be computable per run from a maintained provider-pricing table, not left as a token count the reader must convert manually.
- *Why:* Cost is the actual budget-relevant figure tied to the cost/latency budget standard's per-request cost target ([01-standards-areas.md, B5](../../research/01-standards-areas.md)).
- *How:* `pricingTable.ts` mapping model ID → input/output/cache pricing, updated when providers change pricing; cost computed at aggregation time, not hardcoded per run.
- *Check:* Test asserts a known token count and model ID produce the expected computed cost per the current pricing table.

### Latency budgets and percentile targets

**`OBS-016` — Set explicit p50/p95 latency targets per operation type in the technical spec, before implementation** · `MUST`
Every project's technical spec must state target p50 and p95 latency for at least: end-to-end job completion, individual LLM call, individual tool call, and time-to-first-token for streaming responses.
- *Why:* Explicit per-request latency budgets set at spec time are required by the cost/latency budget standard, mapped to AWS Well-Architected guidance to engineer for cost and latency deliberately, not incidentally ([01-standards-areas.md, B5](../../research/01-standards-areas.md)).
- *How:* `docs/observability/latency-budget.md` table: `operation | p50 target | p95 target`; defaults from the resilience timeout tiers (`LLM_CALL=45s`, `TOOL_EXECUTION=15s`, `WEB_SEARCH=10s`, `DATABASE_QUERY=5s`, `TOTAL_REQUEST=120s`) unless the spec states otherwise ([03-journeys-and-agents.md, B.9](../../research/03-journeys-and-agents.md)).
- *Check:* Spec review confirms the latency-budget table exists before implementation begins.

**`OBS-017` — Compute and surface p50/p95 latency per operation type from real trace data, not from spot checks** · `MUST`
Latency percentiles must be computed from the aggregated span duration data in the tracing backend, refreshed on a recurring cadence, not asserted from a handful of manual test runs.
- *Why:* Percentile claims based on spot checks are not statistically meaningful and cannot detect tail-latency regressions.
- *How:* Langfuse/LangSmith's native latency dashboards, or a scheduled query against the `traces` table computing `percentile_cont(0.5)`/`percentile_cont(0.95)` grouped by operation type.
- *Check:* Dashboard (OBS-019) shows p50/p95 per operation type updated within the last 24 hours.

### Alerting thresholds

**`OBS-018` — Configure alerts for latency-budget breaches, cost-per-tenant anomalies, and safety-eval/guardrail-tripwire spikes** · `MUST`
At minimum, alert when: p95 latency for any operation exceeds its budget (OBS-016) for a sustained window, a tenant's daily cost exceeds a configured threshold, or the rate of guardrail tripwires ([12 — Guardrails & Safety](./12-guardrails-safety.md) · GRD-010) spikes above baseline.
- *Why:* Guards against the two named failure modes the cost/latency standard exists to prevent — demo-day latency spikes and denial-of-wallet from unbounded/malicious usage ([01-standards-areas.md, B5](../../research/01-standards-areas.md)) — plus a safety-regression signal.
- *How:* Langfuse/LangSmith alerting rules, or a scheduled query against `tenant_cost_daily`/`traces` piped to the escalation-routing channel defined in [14 — Human-in-the-Loop & Escalation](./14-hitl-escalation.md) · HITL-011.
- *Check:* Test fixture simulates a cost spike/latency breach and confirms the configured alert fires to the correct channel.

**`OBS-019` — Route alert notifications through the same escalation-routing channels used for HITL, not a separate undocumented Slack channel** · `SHOULD`
Reuse the escalation-routing table's notification channels for observability alerts so the studio and client have one place to look for anything requiring attention.
- *Why:* Reduces the chance an alert is missed because it landed in a channel nobody monitors.
- *How:* Alert configuration references the same webhook/channel identifiers defined in `docs/escalation-routing.md`.
- *Check:* Configuration review confirms alert destinations match the escalation-routing table's channels.

### Dashboards every prototype ships with

**`OBS-020` — Ship four mandatory dashboards with every prototype: run/trace explorer, cost-per-tenant, latency percentiles, and guardrail/safety-event summary** · `MUST`
Every client handover must include, at minimum, a working dashboard for: (1) individual trace/run inspection, (2) cost per tenant over time, (3) p50/p95 latency per operation type, (4) guardrail tripwire and safety-eval failure counts over time.
- *Why:* These four views are the minimum set that lets a client's own team answer "is it working, what does it cost, is it fast enough, is it safe" without engaging the studio for every question — directly supporting the demo/handover standard's operational runbook expectations ([01-standards-areas.md, G2](../../research/01-standards-areas.md)).
- *How:* Langfuse/LangSmith native dashboards for (1) and (3); a lightweight internal dashboard (Next.js admin route reading `tenant_cost_daily` and `traces`) for (2) and (4) if not natively available in the chosen backend.
- *Check:* Handover package review confirms all four dashboards are live and reachable with credentials handed to the client.

### Log retention aligned to the governance standard

**`OBS-021` — Set trace/log retention to match the data governance standard's minimum, and never let a cost-driven pruning job override it** · `MUST`
Any scheduled job that prunes old traces/checkpoints for storage-cost reasons must read its retention window from the governance standard's configuration, not from an independently chosen "delete after N days" value.
- *Why:* Prevents the same failure mode flagged in [14 — Human-in-the-Loop & Escalation](./14-hitl-escalation.md) · HITL-017 — a cost-tuned pruning job silently violating a compliance retention requirement — from recurring at the observability layer.
- *How:* Pruning job reads `retentionConfig.traces` from the shared governance-standard configuration module rather than a hardcoded constant.
- *Check:* Code review confirms the pruning job's retention window is sourced from the shared config, not a literal value in the job's own file.

**`OBS-022` — Document the configured retention window and its rationale in the handover package's security/observability section** · `MUST`
State explicitly how long traces, logs, and cost records are retained and why, so the client's compliance/security reviewer does not have to infer it from code.
- *Why:* Matches the compliance-ready-prototype principle that every control should be visible and documented, even where implementation depth is intentionally scoped ([05-regulated.md, §4](../../research/05-regulated.md)).
- *How:* One paragraph plus a table in the handover package: `data category | retention window | source of requirement`.
- *Check:* Handover package review confirms the retention section is present and matches the actual pruning-job configuration.

## Reference implementation

Folder layout:
```
src/
  otel/
    genaiAttributes.ts     # OBS-002: shared attribute-name constants
    spanHelpers.ts         # OBS-008..011: field enforcement + scrubbing
    tracingInit.ts         # OBS-012: Langfuse/LangSmith SDK bootstrap
  cost/
    pricingTable.ts         # OBS-015
    tenantCostRollup.ts      # OBS-014
docs/
  observability/
    span-naming.md          # OBS-005
    latency-budget.md        # OBS-016
  escalation-routing.md      # referenced by OBS-019
```

Shared attribute constants:
```typescript
export const GenAIAttr = {
  OPERATION_NAME: "gen_ai.operation.name",
  REQUEST_MODEL: "gen_ai.request.model",
  RESPONSE_MODEL: "gen_ai.response.model",
  INPUT_TOKENS: "gen_ai.usage.input_tokens",
  OUTPUT_TOKENS: "gen_ai.usage.output_tokens",
  EVAL_SCORE_VALUE: "gen_ai.evaluation.score.value",
  EVAL_SCORE_LABEL: "gen_ai.evaluation.score.label",
  EVAL_EXPLANATION: "gen_ai.evaluation.explanation",
} as const;
```

Span creation with enforced scrubbing (OBS-009, OBS-010):
```typescript
import { trace } from "@opentelemetry/api";
import { scrubPii, scrubSecrets } from "../guardrails/piiScrubber";
import { GenAIAttr } from "./genaiAttributes";

export function withToolSpan<T>(
  toolName: string,
  riskTier: "low" | "medium" | "high",
  args: Record<string, unknown>,
  fn: () => Promise<T>
): Promise<T> {
  const tracer = trace.getTracer("cognirise-agent");
  return tracer.startActiveSpan(`invoke_tool.${toolName}`, async (span) => {
    const safeArgs = riskTier === "high"
      ? { summary: summarize(args), audit_log_ref: null } // OBS-011, filled post-execution
      : scrubPii(scrubSecrets(args));
    span.setAttribute("gen_ai.tool.name", toolName);
    span.setAttribute("gen_ai.tool.args", JSON.stringify(safeArgs));
    try {
      const result = await fn();
      span.setAttribute("gen_ai.tool.outcome", "success");
      return result;
    } catch (err) {
      span.setAttribute("gen_ai.tool.outcome", "error");
      throw err;
    } finally {
      span.end();
    }
  });
}
```

Per-tenant cost rollup (SQL):
```sql
CREATE TABLE tenant_cost_daily (
  tenant_id TEXT NOT NULL,
  day DATE NOT NULL,
  input_tokens BIGINT NOT NULL DEFAULT 0,
  output_tokens BIGINT NOT NULL DEFAULT 0,
  cached_tokens BIGINT NOT NULL DEFAULT 0,
  cost_usd NUMERIC(12,4) NOT NULL DEFAULT 0,
  PRIMARY KEY (tenant_id, day)
);
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Inventing project-specific attribute names instead of GenAI semconv names | Traces stop being portable across backends/vendors | Use the shared `genaiAttributes.ts` constants (OBS-002) |
| Logging full tool-call arguments for a high-risk financial tool | Sensitive data duplicated into a lower-scrutiny observability backend | Redacted summary + audit-log reference (OBS-011) |
| Computing "cost" as raw token count without a pricing table | Misleads budget decisions, can't track actual spend | Maintain `pricingTable.ts`, compute real cost (OBS-015) |
| Asserting p95 latency from three manual test runs | Statistically meaningless, misses tail regressions | Compute percentiles from aggregated trace data (OBS-017) |
| A cost-driven pruning job deleting traces older than 7 days regardless of compliance need | Silently violates governance retention requirements | Source retention window from shared governance config (OBS-021) |
| Alerts routed to a personal Slack DM nobody else can see | Single point of failure for incident response | Route through the shared escalation-routing channels (OBS-019) |

## Definition of Done

- [ ] Every LLM call, tool call, and handoff produces a span using GenAI semantic-convention attribute names (OBS-001, OBS-002).
- [ ] Guardrail/moderation checks appear as sibling spans, not hidden inside the generation span (OBS-003).
- [ ] Eval scores written back as span attributes (OBS-004).
- [ ] Trace ID propagated to the UI and resolvable server-side to job/tenant context (OBS-006, OBS-007).
- [ ] No secrets or raw PII present in any span/log sampled during review (OBS-009, OBS-010, OBS-011).
- [ ] Langfuse or LangSmith wired via SDK with no separate collector required (OBS-012).
- [ ] Token usage and cost computed and rolled up per job and per tenant using a maintained pricing table (OBS-014, OBS-015).
- [ ] Latency budget table defined in the spec and p50/p95 dashboards populated from real trace data (OBS-016, OBS-017).
- [ ] Alerts configured for latency, cost, and safety-event thresholds, routed through shared escalation channels (OBS-018, OBS-019).
- [ ] Four mandatory dashboards live and included in the handover package (OBS-020).
- [ ] Retention window sourced from the governance standard and documented in the handover package (OBS-021, OBS-022).

## Handoff notes

- Attach `docs/observability/span-naming.md` and `docs/observability/latency-budget.md` when handing this spec to Claude or Replit Agent so instrumentation matches the project's declared conventions from the first commit.
- State which backend (Langfuse or LangSmith) applies before code generation begins — this determines the SDK wiring, not a post-hoc swap.
- Provide the current `pricingTable.ts` values for the model(s) in use so cost dashboards are accurate at first deploy, not placeholder zeros.
- Include the governance standard's retention window value explicitly in the spec so the pruning job is configured correctly the first time.

## Sources

- [OpenTelemetry GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/) and [repository](https://github.com/open-telemetry/semantic-conventions/blob/main/docs/gen-ai/README.md) — span/attribute naming baseline.
- [Future AGI — LLM Agent Evaluation Complete Guide 2026](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/) — eval-score-as-span-attribute integration pattern.
- [Microsoft Azure Architecture Center — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns) — per-agent token/cost monitoring guidance.
- `/home/user/workspace/research/03-journeys-and-agents.md`, §B.9, §B.13, §B.14 — timeout tiers, OTel/Langfuse/LangSmith wiring on Replit, cost/caching/routing.
- `/home/user/workspace/research/01-standards-areas.md`, B5, D4, G2 — cost/latency budget standard, observability/tracing/cost telemetry standard, handover dashboard expectations.
- `/home/user/workspace/research/05-regulated.md`, §4 — visible, documented controls principle applied to retention.
