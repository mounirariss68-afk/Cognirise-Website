---
id: specification
domain: Discovery & Spec
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 03. Specification

> **Purpose.** Define the exact document set, requirement-ID scheme, and traceability standard that keeps Claude-generated specs authoritative over Claude/Replit-generated code.
> **Read this when.** Authoring Stage 2 specification documents, translating journeys into Gherkin scenarios, or reviewing whether generated code has drifted from spec.

## Scope
- In scope: the seven-document spec set and required sections for each, requirement ID scheme, traceability matrix format, Gherkin-as-eval-fixture standard, non-functional requirement budgets, interface/contract specification, assumption/open-question registers, change control, and spec-authority rules.
- Out of scope: how requirements are first captured from research — see [02 — Research Brief](./02-research-brief.md) · BRIEF-001. Out of scope: overall stage sequencing and repo layout — see [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-011.
- Out of scope: agent architecture pattern selection (owned by [07 — Agent Architecture](./07-agent-architecture.md)) and eval-harness mechanics (owned by [15 — Evaluation](./15-evaluation.md)) — this file only specifies where their outputs are declared and referenced.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Document set | Fixed seven: Product Brief, Functional Spec, Technical Spec, Data Spec, Agent Spec, Eval Plan, Risk Register | One taxonomy across every engagement, no per-project invention |
| Requirement ID scheme | `REQ-###` global per engagement, `FR-###`/`NFR-###`/`AR-###` sub-typed within Functional/Technical/Agent specs | Enables the traceability chain from [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-005 |
| Functional requirement format | Gherkin Given/When/Then, one scenario set per job type | Scenarios double as both spec and eval fixture, per specification-driven code-generation research |
| NFR defaults | Fixed budget table (latency, cost/task, availability, accessibility, security) unless explicitly overridden | Prevents each engagement from re-deriving NFR budgets from scratch |
| Spec authority | Spec is the source of truth; code diverging from spec requires a spec edit in the same change, not a silent code-only fix | Prevents generated code from becoming ungoverned once it exists |
| Versioning | Semantic version per spec file in frontmatter, bumped on any accepted change | Matches prompts-as-code discipline; makes eval comparisons apples-to-apples |

## Rules

### Document set and required sections

**`SPEC-001` — Produce exactly seven spec documents per engagement** · `MUST`
Every engagement's `specs/` directory contains: `product-brief.md`, `functional-spec.md`, `technical-spec.md`, `data-spec.md`, `agent-spec.md`, `eval-plan.md`, `risk-register.md`. No additional top-level spec documents; sub-details go in referenced appendices, not new top-level files.
- *Why:* a fixed taxonomy is what makes handoff to Replit implementation and cross-engagement QA/traceability consistent, per the studio's documented spec-taxonomy failure mode of "each engagement invents its own spec structure."
- *How:* scaffold all seven from the studio's spec templates at Stage 2 kickoff, even if some start as stubs.
- *Check:* `ls specs/*.md` matches exactly this set (plus `traceability-matrix.md`); CI fails Stage 2 exit if any is missing.

**`SPEC-002` — Product Brief carries forward and locks the Stage 1 brief decisions** · `MUST`
`product-brief.md` contains: Business Goal, Personas, Success Metrics, Non-Goals, Prototype-vs-Production Statement — copied from the accepted `docs/research-brief.md`, not re-authored from scratch.
- *Why:* re-authoring invites silent scope drift between Stage 1 and Stage 2.
- *How:* Product Brief sections are a direct copy-with-attribution from the research brief; any change requires updating both files together.
- *Check:* diff `product-brief.md` sections against `docs/research-brief.md`; any unexplained divergence is rejected.

**`SPEC-003` — Functional Spec required sections** · `MUST`
`functional-spec.md` contains, per job type: Job Description (JTBD framing), Actors, Preconditions, Gherkin Scenarios (happy/ambiguous/failure paths minimum), Acceptance Criteria, Out-of-Scope statement, UI/journey cross-reference.
- *Why:* this is the layer Claude and Replit Agent read to know exactly what user-facing behavior is required, matching Anthropic's guidance that useful specs "name the files and interfaces involved, state what is out of scope."
- *How:* one `##` section per job type; use the Gherkin template in Reference implementation.
- *Check:* every job type listed in `docs/requirements-register.md` has a matching `##` section here.

**`SPEC-004` — Technical Spec required sections** · `MUST`
`technical-spec.md` contains: Architecture Overview (with agent-vs-workflow decision per job type, cross-referencing the AGT standard), Data Flow Diagram, API/Tool Contract Summary (cross-referencing `agent-spec.md` for full contracts), Model/Routing Choices, Non-Functional Requirements table, Deployment Topology, Out-of-Scope statement, End-to-end Verification Step.
- *Why:* mirrors [Anthropic's Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) requirement that specs "end with an end-to-end verification step that proves the feature works."
- *How:* NFR table uses the fixed budget categories from `SPEC-015`.
- *Check:* section "End-to-end Verification Step" is non-empty and names a concrete, runnable check.

**`SPEC-005` — Data Spec required sections** · `MUST`
`data-spec.md` contains: Entity List with field-level definitions, Schema DDL (Postgres/Drizzle, per canonical stack), Data Classification (PII/sensitive tiers), Retention & Deletion Policy, Cross-Border/Residency Statement (if regulated client), Migration/Seed Data Plan.
- *Why:* data classification and residency must be decided before Stage 3 code generation touches real or synthetic data, per the regulated-client engineering controls (data classification & residency, PII discovery, retention) documented in [05-regulated.md](../../research/05-regulated.md).
- *How:* Data Classification table columns: `field, entity, classification (public/internal/sensitive/pii), residency_constraint, retention_period`.
- *Check:* every entity in the DDL has a matching row in the Data Classification table.

**`SPEC-006` — Agent Spec required sections** · `MUST`
`agent-spec.md` contains: Agent/Workflow Inventory (one row per agent or workflow, with the agent-vs-workflow justification), Tool Contracts (name, description, input/output schema, risk tier, idempotency requirement), Memory Architecture reference, Guardrail/Escalation Triggers, Cost/Latency Budget per agent.
- *Why:* tool contracts and risk tiers are what downstream guardrail and HITL standards (GRD, HITL prefixes) hook into; specifying them here keeps that decision traceable to the spec, not buried in code.
- *How:* Tool Contracts table format matches the tool-spec template referenced by the tool-contract standard (TOOL prefix); do not duplicate that standard's rules here — reference it.
- *Check:* every tool referenced in generated code (Stage 3) has a matching row in this table.

**`SPEC-007` — Eval Plan required sections** · `MUST`
`eval-plan.md` contains: Eval Dimensions (minimum: task completion, tool-call correctness, groundedness), Dataset Sources (per job type, cross-referencing Gherkin scenarios), Pass Thresholds per dimension, Regression Gate Policy, CI Wiring Summary.
- *Why:* aggregate-only pass/fail hides per-dimension regressions; per-dimension thresholds are required so a bad dimension can't hide behind good ones.
- *How:* Pass Thresholds table: `dimension, threshold, evaluator_type (code/llm-judge/human)`.
- *Check:* every Gherkin scenario in `functional-spec.md` has a corresponding row in Dataset Sources.

**`SPEC-008` — Risk Register required sections** · `MUST`
`risk-register.md` contains: Risk Inventory (risk, likelihood, impact, mitigation, owner), Regulatory Posture Statement (which frameworks apply — PDPL, DIFC Reg 10, EU AI Act, OWASP LLM Top 10, etc.), Compliance-Ready Prototype Checklist (must-have vs. deferrable-with-gap items), Named Accountable Owner.
- *Why:* consolidates compliance touchpoints into one pre-delivery gate rather than scattered concerns discovered late, matching the studio's cross-cutting compliance-gate pattern.
- *How:* for regulated (gov/bank/telco) clients, populate the Compliance-Ready Prototype Checklist directly from the must-have/deferrable lists in [05-regulated.md](../../research/05-regulated.md).
- *Check:* Regulatory Posture Statement is non-empty for every engagement (state "no sector-specific regulation identified" explicitly if true, never leave blank).

### Requirement ID scheme and traceability

**`SPEC-009` — Use sub-typed requirement IDs within the global REQ-### scheme** · `MUST`
Functional requirements are `FR-###`, non-functional requirements are `NFR-###`, agent and tool requirements are `AR-###` — each also mapped 1:1 to a parent `REQ-###` from `docs/requirements-register.md`.
- *Why:* sub-typing lets a reviewer filter by requirement class while the parent `REQ-###` keeps the single traceability thread from [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-005 intact.
- *How:* `docs/requirements-register.md` gains a `sub_type_id` column populated at Stage 2.
- *Check:* every `FR-###`/`NFR-###`/`AR-###` cited in a spec has a matching `req_id` row in the register.

**`SPEC-010` — Populate the traceability matrix to spec-section granularity at Stage 2 exit** · `MUST`
`specs/traceability-matrix.md` rows must have a non-empty `spec_section` (an anchored heading, e.g., `specs/functional-spec.md#FR-014`) for every `REQ-###` in scope before Stage 2 exit.
- *Why:* this is the mid-chain link the lifecycle standard depends on; without it, code-module and eval-case columns have nothing to anchor to.
- *How:* spec authors add the row when they write the section, not retroactively.
- *Check:* CI script cross-checks `docs/requirements-register.md` against `specs/traceability-matrix.md`; any `REQ-###` missing a `spec_section` blocks Stage 2 exit.

**`SPEC-011` — Requirement IDs are immutable once referenced by a spec section** · `MUST NOT`
Do not renumber or reuse a `REQ-###`/`FR-###`/`NFR-###`/`AR-###` once it has been cited anywhere; deprecate instead.
- *Why:* renumbering breaks the traceability matrix and any eval dataset or code comment that cites the old ID.
- *How:* deprecated IDs get a `status: deprecated` flag in the register and a `superseded_by` pointer.
- *Check:* grep for any ID reused with a different meaning across `docs/changelog.md` history.

### Functional requirements as Gherkin/eval fixtures

**`SPEC-012` — Write every functional requirement as a Gherkin scenario, minimum three paths per job type** · `MUST`
Each job type in `functional-spec.md` has at minimum: one happy-path scenario, one ambiguous/needs-clarification scenario, one failure/escalation scenario, each tagged with its `FR-###`.
- *Why:* Gherkin's Given/When/Then structure expresses branching behavior unambiguously for both a human reviewer and an LLM implementer, and specification-driven, test-first workflows measurably improve LLM code-generation reliability, per the [arXiv research on specification-driven code generation](https://arxiv.org/html/2601.03878v1) cited in the journey-design research.
- *How:* use the Gherkin template in Reference implementation; store as `.feature`-style fenced blocks inside `functional-spec.md`, one per job type.
- *Check:* every job type has ≥3 scenarios; every scenario has an `FR-###` tag.

**`SPEC-013` — Every Gherkin scenario becomes exactly one eval dataset row** · `MUST`
Each scenario's Given/When/Then maps to one row in `evals/datasets/<job-type>.jsonl` with fields `scenario_id (= FR-###)`, `input`, `expected_outcome_or_trajectory`, `rubric_or_assertion`.
- *Why:* this is what makes the spec directly usable as both the coding-LLM's context and the eval harness's acceptance criteria, avoiding a second, drifting definition of "correct behavior."
- *How:* Stage 2 spec authors generate the JSONL row at the same time they write the scenario, not deferred to Stage 5.
- *Check:* row count in `evals/datasets/<job-type>.jsonl` matches scenario count in `functional-spec.md` for that job type.

**`SPEC-014` — Do not write a functional requirement as free prose without a Gherkin scenario** · `MUST NOT`
If a requirement cannot be phrased as a Given/When/Then scenario, treat that as a signal it is actually a non-functional requirement or an architecture decision, and file it in `technical-spec.md` instead.
- *Why:* prose-only functional requirements can't be mechanically turned into eval fixtures, breaking `SPEC-013`.
- *How:* Functional Spec review checklist item: "every FR-### has a Gherkin block."
- *Check:* grep `functional-spec.md` for `FR-###` tags without an adjacent Gherkin block.

### Non-functional requirement budgets

**`SPEC-015` — Set NFR budgets from the fixed default table unless explicitly overridden** · `MUST`
`technical-spec.md`'s NFR table must cover at minimum these categories with values: Latency (p50/p95 per request type), Cost per task/request, Availability (uptime target), Accessibility (WCAG level), Security (auth model, data-at-rest/in-transit encryption).
- *Why:* without explicit budgets set at spec time, agentic loops silently balloon cost/latency and accessibility/security get treated as afterthoughts.
- *How:* use the default budget table in Reference implementation; any deviation must be justified inline in the same table row.
- *Check:* NFR table has a non-empty value in every required category; no row reads "TBD."

**`SPEC-016` — Government-adjacent or citizen-facing engagements default to WCAG 2.2 AA** · `MUST`
Set the Accessibility NFR to WCAG 2.2 Level AA as the floor for any UAE government or citizen-facing engagement, per the current UAE Design System reference standard.
- *Why:* WCAG 2.2 AA satisfies both the current TDRA/UAE Design System guidance and older policy documents that still cite 2.1 AA as a floor, per [05-regulated.md](../../research/05-regulated.md).
- *How:* set explicitly in the NFR table row, do not leave as a generic "accessible" statement.
- *Check:* NFR table's Accessibility row names "WCAG 2.2 AA" verbatim for gov/citizen-facing engagements.

**`SPEC-017` — Every agent loop declares a hard step cap and cost ceiling in the NFR table** · `MUST`
The Cost category must include, per agent: max iterations/tool calls per run, and a per-job token/cost ceiling, both enforced in code — never left to the model to self-terminate.
- *Why:* unbounded agent loops are a named denial-of-wallet and reliability risk.
- *How:* NFR row format: `<agent_name>: max_steps=<N>, cost_ceiling_usd=<X>`.
- *Check:* `agent-spec.md`'s Tool Contracts table cross-references the same step cap; code review confirms the cap is enforced, not advisory.

### Interface / contract specification

**`SPEC-018` — Specify every tool/API contract with name, schema, example, and error conditions before Stage 3** · `MUST`
`agent-spec.md`'s Tool Contracts table entries are complete (not stubbed) before Stage 3 code generation begins: `name, description (written as a prompt), input_schema, output_schema, example_call, error_conditions, risk_tier, idempotent (y/n)`.
- *Why:* incomplete tool contracts force Claude to guess schema shape during code generation, reintroducing the ambiguity the spec exists to remove.
- *How:* reference the tool-contract standard's (TOOL prefix) template for the row shape; do not redefine it here.
- *Check:* no Tool Contracts row has an empty `input_schema` or `error_conditions` cell at Stage 2 exit.

**`SPEC-019` — Specify every external-facing API route's contract in the Technical Spec** · `MUST`
Any Next.js API route or server action exposed to the client app is listed in `technical-spec.md` with method, path, request/response Zod schema reference, and auth requirement.
- *Why:* keeps the interface boundary explicit and reviewable independent of implementation detail.
- *How:* table format: `method, path, request_schema_ref, response_schema_ref, auth_required (y/n)`.
- *Check:* every route implemented in `app/` at Stage 4 has a matching row from Stage 2.

### Assumption and open-question registers

**`SPEC-020` — Carry forward unresolved research assumptions into the Risk Register** · `MUST`
Any row in the Stage 1 Unknowns & Assumptions register (see [02 — Research Brief](./02-research-brief.md) · BRIEF-011) still unresolved at Stage 2 must appear as a row in `risk-register.md`'s Risk Inventory.
- *Why:* an assumption that silently disappears between Stage 1 and Stage 2 is a governance gap, not a resolved question.
- *How:* Risk Inventory row cites the originating assumption by its Stage 1 register row.
- *Check:* every `impact-if-wrong: high` row from the Stage 1 register has a corresponding Risk Inventory row.

**`SPEC-021` — Log new open questions discovered during spec authoring to the shared register** · `MUST`
Any question that arises while writing specs (not answerable from the accepted research brief) goes to `docs/open-questions.md`, tagged with the spec file/section that raised it — it does not get silently resolved by guessing.
- *Why:* keeps the open-question surface visible lifecycle-wide, consistent with [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-008.
- *How:* `docs/open-questions.md` row format: `question, raised_in, status (open/resolved), resolution`.
- *Check:* no spec section contains an inline "(TBD)" or "(assume X)" without a corresponding open-questions row.

### Change control and versioning

**`SPEC-022` — Version every spec file independently in frontmatter** · `MUST`
Each of the seven spec files has its own `version: X.Y` in frontmatter, bumped on every accepted change (minor for clarification, major for scope/behavior change).
- *Why:* independent versioning lets a reviewer see exactly which document changed and when, without inferring it from git blame alone.
- *How:* bump version and `last_reviewed` date together whenever `status: accepted` is re-applied after an edit.
- *Check:* `docs/changelog.md` entry exists for every version bump, citing the triggering `REQ-###` or open-question resolution.

**`SPEC-023` — Any accepted-spec change after Stage 3 has started triggers a re-baseline check** · `MUST`
If a spec file's major version bumps after Stage 3 code generation has begun, evaluate against [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-009 to determine whether re-baselining is required.
- *Why:* keeps spec changes from silently diverging from in-flight code generation.
- *How:* changelog entry for a post-Stage-3 major bump must explicitly state "re-baseline: yes/no" with justification.
- *Check:* reviewer confirms the re-baseline determination is logged, not skipped.

### Spec authority over generated code

**`SPEC-024` — Specs are authoritative; code that diverges from spec must trigger a spec edit in the same change** · `MUST`
If Claude-generated or Replit-Agent-generated code implements behavior that differs from the accepted spec (including improvements the agent believes are better), the corresponding spec section must be updated in the same PR/commit, not left to silently diverge.
- *Why:* otherwise the spec becomes documentation theater instead of the source of truth downstream reviewers and future engineers rely on — this is the direct code-side enforcement of [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-012.
- *How:* PR template includes a required field: "Does this change any accepted spec section? If yes, link the spec diff."
- *Check:* reviewer rejects any PR that changes observable behavior without a corresponding spec file diff.

**`SPEC-025` — Claude/Replit Agent MUST NOT treat an ambiguous spec as license to invent behavior** · `MUST NOT`
When a spec section is ambiguous or silent on a case the agent encounters, the agent must flag it to `docs/open-questions.md` and choose the most conservative/reversible behavior, not invent and ship a plausible-sounding resolution.
- *Why:* this is the direct mechanism preventing the named failure mode of generative tools "helpfully" filling spec gaps with unreviewed scope, extending [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-007 into the spec-interpretation layer specifically.
- *How:* include this instruction verbatim in the Stage 3/4 handoff prompt (see Handoff notes).
- *Check:* adversarial review (`LIFE-018`) checks any behavior not traceable to an explicit spec line against this rule.

## Reference implementation

### Requirement ID and traceability example

```markdown
docs/requirements-register.md
| req_id  | sub_type_id | description                          | status   |
|---------|-------------|----------------------------------------|----------|
| REQ-014 | FR-014      | Agent proposes invoice match for review | accepted |
| REQ-014 | NFR-014a    | Match proposal returned within 3s p95  | accepted |
```

### Gherkin scenario + eval fixture pairing

```gherkin
Feature: Reconcile monthly invoice
  # FR-014
  Scenario: Happy path, low autonomy
    Given the user is in "assist" mode
    When the agent finds a matching invoice
    Then the agent proposes the match and waits for user confirmation

  # FR-015
  Scenario: Escalation - amount exceeds threshold
    Given the invoice amount exceeds $1000
    When the agent completes matching
    Then the agent creates a pending_approval row and notifies a human reviewer
    And the workflow resumes automatically once approved or expires per SLA
```

```json
{"scenario_id": "FR-014", "input": {"mode": "assist", "invoice_id": "inv_101"}, "expected_outcome_or_trajectory": "propose_match_then_wait", "rubric_or_assertion": "tool_call=propose_match; no auto-commit"}
{"scenario_id": "FR-015", "input": {"mode": "autopilot", "invoice_amount": 1500}, "expected_outcome_or_trajectory": "pending_approval_created", "rubric_or_assertion": "row exists in pending_approvals; notification sent"}
```

### Default NFR budget table

| Category | Default budget | Escape hatch |
|---|---|---|
| Latency | p50 ≤ 2s, p95 ≤ 6s per user-facing request; LLM call timeout 45s, tool call 15s, DB query 5s, total request 120s | Longer-running background jobs use async job status polling instead of a synchronous budget |
| Cost per task | Declared per job type in `agent-spec.md`; default ceiling $0.50/job unless overridden with client sign-off | Research-heavy sub-agent tasks may exceed with documented justification |
| Availability | 99% uptime for Autoscale demo deployments; 99.5% for Reserved VM production-leaning prototypes | — |
| Accessibility | WCAG 2.2 AA baseline for all client-facing UI; WCAG 2.2 AA mandatory for gov/citizen-facing (`SPEC-016`) | — |
| Security | TLS in transit, AES-256 at rest, Secrets via Replit Secrets/equivalent, least-privilege tool scoping | Client-mandated stricter posture (e.g., dedicated tenancy) documented in Risk Register |

### Spec document frontmatter template

```markdown
---
doc: functional-spec        # product-brief | functional-spec | technical-spec | data-spec | agent-spec | eval-plan | risk-register
engagement: <client-name>
version: 1.0
status: draft               # draft | accepted | deprecated
last_reviewed: <date>
---
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Inventing a per-engagement spec structure ("this client's specs are different") | Breaks cross-engagement QA/traceability and confuses engineers rotating between projects | Enforce `SPEC-001`: exactly seven documents, fixed sections |
| Writing functional requirements as prose paragraphs | Can't be mechanically converted into eval fixtures | Enforce `SPEC-012`/`SPEC-014`: Gherkin scenarios only |
| Leaving NFR table cells as "TBD" | Agentic loops silently balloon cost/latency with no budget to catch it | Enforce `SPEC-015`: fixed default budgets, deviations justified inline |
| Letting Replit Agent "fix" ambiguous spec by picking a sensible-sounding default | Ships unreviewed behavior with no traceability | Enforce `SPEC-025`: flag ambiguity to open-questions, choose conservative default, never invent silently |
| Updating code behavior without updating the spec section it contradicts | Spec becomes stale documentation, no longer authoritative | Enforce `SPEC-024`: spec edit required in the same change as any behavior divergence |
| Renumbering requirement IDs to "clean up" the register | Breaks every downstream reference (traceability matrix, eval dataset, code comments) | Enforce `SPEC-011`: IDs are immutable, deprecate instead |

## Definition of Done

- [ ] All seven spec documents exist at their canonical paths with `status: accepted` (SPEC-001).
- [ ] Product Brief sections match the accepted `docs/research-brief.md` with no unexplained divergence (SPEC-002).
- [ ] Every job type in Functional Spec has ≥3 Gherkin scenarios (happy/ambiguous/failure) tagged with `FR-###` (SPEC-012).
- [ ] Every Gherkin scenario has a matching row in `evals/datasets/<job-type>.jsonl` (SPEC-013).
- [ ] NFR table has no empty/TBD cell across latency, cost, availability, accessibility, security (SPEC-015).
- [ ] Every tool contract in Agent Spec has complete schema, example call, and error conditions (SPEC-018).
- [ ] `specs/traceability-matrix.md` has a populated `spec_section` for every in-scope `REQ-###` (SPEC-010).
- [ ] Risk Register carries forward every unresolved high-impact assumption from Stage 1 (SPEC-020).
- [ ] No spec section contains an inline TBD/assumption without a corresponding `docs/open-questions.md` row (SPEC-021).

## Handoff notes

- When handing Stage 3 code generation to Claude, paste `technical-spec.md`, `agent-spec.md`, and `data-spec.md` in full, plus the instruction from `SPEC-025` verbatim: flag ambiguity to open-questions, do not invent behavior.
- When handing off to Replit Agent for Stage 4, include `functional-spec.md`'s Gherkin scenarios so Plan mode can map its task breakdown directly to `FR-###` IDs.
- Always attach the current `specs/traceability-matrix.md` so the receiving agent/reviewer can verify no requirement is being silently dropped or exceeded.
- If any NFR budget was overridden from the default table, call it out explicitly in the handoff — Claude/Replit Agent should not assume defaults apply.

## Sources

- [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) — self-contained specs naming files/interfaces, out-of-scope statement, end-to-end verification step.
- [arXiv — Understanding Specification-Driven Code Generation with LLMs](https://arxiv.org/html/2601.03878v1) — specification → tests → generated function workflow improving LLM code-generation reliability.
- research file [01-standards-areas.md](../../research/01-standards-areas.md), section A2 — spec taxonomy, traceability IDs, explore/plan/implement/commit workflow.
- research file [03-journeys-and-agents.md](../../research/03-journeys-and-agents.md), section A.8 — Gherkin scenarios doubling as eval fixtures, state machine as control-flow contract.
- research file [05-regulated.md](../../research/05-regulated.md) — data classification/residency requirements feeding the Data Spec and Risk Register, WCAG 2.2 AA accessibility floor.
