---
id: replit-deployment
domain: Engineering, Repo & Delivery Conventions
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [implementation, qa]
last_reviewed: 2026-07-27
---

# 20. Replit & Deployment

> **Purpose.** Guarantee every prototype is deployed on the correct Replit primitive, with no in-memory state, no leaked secrets, and a documented, low-friction path to migrate to client-controlled in-region cloud when residency or scale demands it.
> **Read this when.** Deployment-type selection, Replit Agent implementation sessions, pre-demo go-live checklist, migration-trigger review.

## Scope

- In scope: Autoscale/Reserved VM/Scheduled Deployment decision table, `.replit` config conventions, Secrets handling/rotation, Replit Postgres and connection pooling, background workers with `pg-boss`, cron via Scheduled Deployments, the no-in-memory-state rule, how to drive Replit Agent effectively, staging vs. demo environments, custom domains/access control, region/residency limitations and migration triggers, and the portability checklist.
- Out of scope: data classification and residency legal basis (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)), repo folder structure and env schema (see [19 — Repository & Stack Conventions](./19-repo-conventions.md)), observability instrumentation (see [16 — Observability & Cost](./16-observability-cost.md)), auth provider selection (see [13 — Security & Authorization](./13-security-authz.md)).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Stateless web app | Autoscale | Variable-traffic demo usage; scales to zero between client sessions ([Replit Docs, About Deployments](https://docs.replit.com/cloud-services/deployments/about-deployments)) |
| Always-on service (bot, webhook, in-memory cache, long-lived connection) | Reserved VM | Predictable pricing/performance for always-on workloads |
| Time-triggered job (retention deletion, nightly digest) | Scheduled Deployment | Purpose-built cron primitive; no need for a always-on worker just to run hourly |
| App state persistence | Postgres only — never in-process memory | Autoscale instances do not persist in-memory state across requests |
| Secrets | Replit Secrets (AES-256 at rest, TLS in transit), never hardcoded | ([Replit Docs, Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)) |
| Default hosting region for regulated data | Not Replit — migrate to Azure UAE/AWS Bahrain-UAE/Oracle UAE before real Confidential/Restricted data is processed | Replit's core infra is US-based with an optional India region; no UAE/GCC region exists ([Replit docs, Information Security](https://docs.replit.com/teams/information-security/overview)) |
| Git | Every project connected to a private GitHub/GitLab remote from day one | Prevents code living only inside Replit; required for portability ([Replit docs, Enterprise Privacy Settings](https://docs.replit.com/teams/enterprise-privacy-settings)) |

## Rules

### Deployment-type decision

**`DEP-001` — Select deployment type from the decision table before writing any infrastructure code** · `MUST`
Choose Autoscale, Reserved VM, Static, or Scheduled Deployment based on the app's traffic pattern and state requirements, recorded explicitly in the technical spec.
- *Why:* Choosing Static for an app needing secrets/backend logic, or Reserved VM for a bursty demo, wastes cost or breaks functionality ([Replit Docs, About Deployments](https://docs.replit.com/cloud-services/deployments/about-deployments)).
- *How:* Use the table below; document the choice and rationale in `docs/specs/` under a "Deployment" heading.
- *Check:* Reviewer confirms the deployment-type line in the spec matches the app's actual traffic/state profile before first deploy.

| App shape | Deployment type | Notes |
|---|---|---|
| Interactive demo UI, bursty/unpredictable traffic | Autoscale | Scales to zero; Secrets available; no in-memory state survives between requests |
| Pure static frontend, no backend, no user-data transfer | Static | Cheapest; Secrets unavailable — factor this into architecture decisions |
| Always-on bot, webhook receiver, or service needing long-lived connections/in-memory cache | Reserved VM | Predictable pricing/performance; state may live in-process but must still be reconciled against Postgres on restart |
| Time-triggered batch job (retention deletion, nightly report, reminder digest) | Scheduled Deployment | Do not build a Reserved VM + custom cron loop when this primitive exists |

**`DEP-002` — Never choose Static Deployment for anything requiring Secrets** · `MUST NOT`
Do not deploy an app needing API keys, database credentials, or any Secret-backed configuration as a Static Deployment.
- *Why:* Secrets are unavailable for Static Deployments ([Replit Docs, Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)).
- *How:* Confirm at spec time whether the app is a pure static asset bundle; if it calls any API requiring a key, it is not a Static Deployment candidate.
- *Check:* Deployment-type review flags any Static Deployment configuration that imports `env.ts` (see [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-013).

### `.replit` and config conventions

**`DEP-003` — Keep `.replit` and `replit.nix` non-load-bearing for application logic** · `MUST`
Use `.replit`/`replit.nix` only for run/build commands and environment bootstrapping; never encode business logic, routing, or feature flags there.
- *Why:* Portability to client cloud (Azure/AWS/Oracle) requires the application to run correctly without these Replit-specific files.
- *How:* `.replit` `run` command should invoke the same `npm run start` script that works identically outside Replit.
- *Check:* A local (non-Replit) `docker run` of the built image succeeds using only `package.json` scripts, with no `.replit`/`replit.nix` present.

**`DEP-004` — Maintain complete, explicit dependency manifests; do not rely on Replit's auto-detection** · `MUST`
Keep `package.json` fully explicit for all dependencies and versions; do not depend on Replit's Nix-based auto-detection to resolve missing packages at runtime.
- *Why:* Auto-detected dependencies are invisible to a target-cloud build pipeline and break portability ([VP0, Does Replit Agent Export Clean Code to GitHub?](https://vp0.com/blogs/does-replit-agent-export-clean-code-to-github)).
- *How:* Run `npm ci` (not `npm install`) in CI to fail on any manifest/lockfile mismatch.
- *Check:* CI job runs `npm ci` from a clean checkout and fails on missing lockfile entries.

**`DEP-005` — Bind to `process.env.PORT`; never hardcode a port number** · `MUST`
Read the listen port from `process.env.PORT` with a local-dev fallback, never a literal port in source.
- *Why:* Replit assigns ports dynamically; hardcoding breaks both Replit deployment and portability to a target cloud's container runtime.
- *How:* `const port = Number(process.env.PORT) || 3000;`
- *Check:* Grep confirms no literal port number appears in server-startup code outside the fallback default.

### Secrets handling and rotation

**`DEP-006` — Store every credential in Replit Secrets, scoped app-level unless account-level sharing is explicitly justified** · `MUST`
Use Replit's Secrets tool for all API keys, tokens, and connection strings; default to app-level scoping and only use account-level scoping with a documented reason.
- *Why:* AES-256 at rest, TLS in transit, and explicit scoping reduce blast radius of a leaked credential ([Replit Docs, Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)).
- *How:* Secrets tab in the Replit workspace; reference via `process.env.X` validated through `env.ts` (see [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-013).
- *Check:* Repo-wide secret-scan (e.g., `gitleaks`) in CI finds zero hardcoded credentials.

**`DEP-007` — Rotate every credential immediately after any team-member offboarding or suspected exposure, and on a fixed schedule for long-running engagements** · `MUST`
Rotate API keys/DB credentials within 24 hours of an offboarding event or suspected leak; rotate on at least a quarterly schedule for engagements running longer than one quarter.
- *Why:* Credential rotation discipline is a standard procurement-questionnaire ask for bank/government clients (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)).
- *How:* Maintain a rotation log in `docs/compliance/subprocessors.md` or a dedicated `docs/runbooks/secret-rotation.md`.
- *Check:* Rotation log shows a dated entry for every credential at least once per quarter on long-running engagements.

**`DEP-008` — Never echo a Secret value into logs, error messages, or the studio's observability backend** · `MUST NOT`
Ensure error-handling and logging code paths never interpolate a raw Secret value into a log line or trace attribute.
- *Why:* Logs are a common unguarded leak surface, and observability backends (Langfuse/LangSmith) may be less access-controlled than the primary secrets store.
- *How:* Central error-formatting utility strips known secret-shaped strings (API-key patterns) before logging.
- *Check:* Log-export sample scanned by the same PII/secret-scan tool used in DEP-006 returns zero findings.

### Replit Postgres and connection pooling

**`DEP-009` — Use Replit Postgres (or Neon) with a connection pooler; never open unpooled connections from an Autoscale function** · `MUST`
Configure Drizzle's Postgres client through a pooled connection string (PgBouncer-compatible or Neon's pooled endpoint); do not open a raw long-lived connection per Autoscale invocation.
- *Why:* Autoscale instances can spin up many concurrent short-lived processes; unpooled connections rapidly exhaust the database's max-connection limit.
- *How:* Set `DATABASE_URL` to the pooled connection string variant; configure Drizzle's pool size explicitly rather than accepting a driver default.
- *Check:* Load test confirms connection count stays within the configured pool ceiling under simulated concurrent Autoscale traffic.

**`DEP-010` — Maintain a documented `pg_dump`-based backup/restore path** · `MUST`
Keep a working, tested `pg_dump`/`pg_restore` procedure independent of any Replit-proprietary backup mechanism.
- *Why:* Ensures data migrates cleanly to a target cloud's managed Postgres and is not locked into a Replit-specific backup format ([Suffescom Solutions, How to Migrate Replit Hosting to Cloud](https://www.suffescom.com/blog/migrate-replit-to-cloud)).
- *How:* `docs/runbooks/backup-restore.md` documents the exact commands and a tested restore against a scratch database.
- *Check:* Runbook procedure executed successfully at least once before handover, with output attached to the handover pack (see [22 — Handover & IP](./22-handover-ip.md)).

### Background workers and cron

**`DEP-011` — Run background/async work via `pg-boss` on the same Postgres instance, not a separate queue service** · `MUST`
Implement job queues, retries, and async workflows with `pg-boss`, backed by the canonical Postgres instance, rather than introducing Redis or a separate message broker.
- *Why:* Canonical stack default; avoids an extra infrastructure dependency to provision and secure per client engagement (see `_CANON-CONVENTIONS.md`).
- *How:* `pg-boss` worker process runs inside a Reserved VM deployment (workers require persistent process lifetime that Autoscale does not guarantee); Autoscale web instances enqueue jobs only.
- *Check:* Architecture review confirms no Redis/RabbitMQ/SQS dependency exists for a workload `pg-boss` can cover.

**`DEP-012` — Implement all cron/time-triggered work via Replit Scheduled Deployments, not an in-process `setInterval`** · `MUST`
Use Scheduled Deployments for retention-deletion jobs, nightly reports, and reminder digests; never rely on a long-running `setInterval`/`cron` loop inside an Autoscale or Reserved VM process as the sole trigger mechanism.
- *Why:* `setInterval` loops inside Autoscale do not survive scale-to-zero; Scheduled Deployments are the purpose-built primitive.
- *How:* Configure a Scheduled Deployment pointing at a dedicated entrypoint script; log every run to the audit log (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV-014).
- *Check:* Scheduled Deployment run history shows successful executions at the configured cadence.

### No-in-memory-state rule

**`DEP-013` — Assume no in-memory state survives across requests on Autoscale; persist all agent/session state to Postgres** · `MUST`
Store agent conversation state, run status, and any multi-step workflow state in Postgres, never in a process-local variable, module-level cache, or in-memory map, on any Autoscale-deployed service.
- *Why:* Autoscale instances are ephemeral and can be recycled between requests; in-memory state silently disappears, causing intermittent, hard-to-reproduce bugs.
- *How:* All agent-run state modeled as Postgres rows (see [07 — Agent Architecture](./07-agent-architecture.md) memory patterns); any caching layer must be either Postgres-backed or explicitly documented as best-effort/rebuildable.
- *Check:* Load test that recycles the Autoscale instance mid-session confirms no state loss for an in-progress agent run.

**`DEP-014` — Reserved VM in-memory caches must be explicitly documented as non-authoritative and rebuildable from Postgres** · `MUST`
If a Reserved VM process holds an in-memory cache (e.g., a hot-path lookup table), document that Postgres is the source of truth and the cache can be safely dropped/rebuilt at any time.
- *Why:* Prevents an implicit dependency on Reserved VM uptime for correctness, which would break under restart, redeploy, or migration to a target cloud with different scaling behavior.
- *How:* Code comment and a line in the architecture doc naming every in-memory cache and its rebuild path.
- *Check:* Reviewer confirms a restart of the Reserved VM process does not lose any data not also present in Postgres.

### Driving Replit Agent effectively

**`DEP-015` — Use Plan mode before any non-trivial Replit Agent code change** · `MUST`
Invoke Replit Agent's Plan mode to break the incoming Claude-authored spec/code into an ordered task list and get explicit sign-off before execution.
- *Why:* Mirrors the "explore → plan → implement" discipline used upstream in Claude Code and prevents Replit Agent from silently re-deciding architecture already settled in the spec ([Replit Docs, Replit Agent](https://docs.replit.com/replitai/agent); [Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).
- *How:* Populate the Plan-mode task breakdown directly from the referenced `docs/specs/SPEC-###` file's acceptance criteria.
- *Check:* A Plan-mode task list exists and was reviewed before the corresponding PR's commits were made.

**`DEP-016` — Select Replit Agent mode by task size/risk, defaulting to Economy** · `MUST`
Use Lite for small visual tweaks/bug fixes, Economy as the default for most builds, Power (or Turbo) for harder problems, and the High-effort toggle only for the most complex tasks.
- *Why:* Defaulting to Power/Turbo for trivial changes wastes spend; defaulting to Lite for complex changes produces shallow, incorrect output.
- *How:* Document the mode-selection guide in the project's `AGENTS.md` (see [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-006).
- *Check:* Spot-check of recent Agent sessions confirms mode choice roughly matches task complexity.

**`DEP-017` — Treat Replit Agent's automatic checkpoints as a complement to git, never a replacement** · `MUST`
Commit to git at every meaningful milestone regardless of Replit Agent's own checkpoint history; do not rely solely on Agent checkpoints for rollback.
- *Why:* Agent checkpoints are tool-specific and do not guarantee the same portability/audit trail as git history.
- *How:* Require a git commit after every Agent session that produces mergeable output, referencing the spec ID per [19 — Repository & Stack Conventions](./19-repo-conventions.md) REPO-016.
- *Check:* Git log shows a commit corresponding to each significant Agent session; no multi-day gap without a commit during active development.

**`DEP-018` — Hand-edit instead of re-prompting when Agent output diverges from spec on a narrow, well-understood fix** · `SHOULD`
For small, precisely diagnosed deviations (a wrong variable name, an off-by-one, a missed null check), hand-edit directly rather than issuing another Agent prompt cycle.
- *Why:* Vague "fix it" re-prompts on narrow issues cost more time and context than a direct edit, and risk the Agent making unrelated changes.
- *How:* Use the `edit`/direct-file-edit path in the Replit workspace for single-line/small-block fixes; reserve Agent re-prompts for changes needing broader context or multi-file coordination.
- *Check:* PR diff review confirms narrow fixes are minimal, targeted diffs rather than broad re-generated blocks.

**`DEP-019` — When Agent output diverges from spec on anything non-trivial, describe the specific deviation, not a vague "fix it"** · `MUST`
State exactly what differs from the spec's acceptance criteria (expected vs. actual behavior, file/line if known) when re-prompting Replit Agent.
- *Why:* Echoes Claude Code's "be specific" prompting guidance; vague feedback produces vague, often wrong, corrections ([Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).
- *How:* Template the re-prompt as "Expected: <X per SPEC-### criterion N>. Actual: <Y>. File: <path>."
- *Check:* Session transcript review confirms re-prompts reference the specific spec criterion, not a generic complaint.

### Staging vs. demo environments

**`DEP-020` — Maintain at least two distinct Replit deployments per client engagement: staging and demo** · `MUST`
Deploy a `staging` environment for active development/testing and a separate `demo` environment that is only updated deliberately before a client-facing session.
- *Why:* Prevents an in-progress, broken change from appearing in front of a client mid-development.
- *How:* Two separate Replit Deployments (or two Autoscale deployment slots) with distinct URLs and, where used, distinct Postgres databases seeded independently.
- *Check:* Deployment inventory in the handover pack names both URLs and their update cadence.

**`DEP-021` — Freeze the demo environment's data and code at least a few hours before any live client session** · `MUST`
Do not push untested changes to the `demo` deployment within the window immediately preceding a scheduled client demo.
- *Why:* Reduces risk of a last-minute regression surfacing live in front of the client.
- *How:* Document a "demo freeze" cutoff time in the demo runbook (see [22 — Handover & IP](./22-handover-ip.md)).
- *Check:* Deployment history shows no `demo` environment pushes within the documented freeze window before the actual demo timestamp.

### Custom domains and access control

**`DEP-022` — Require authenticated access for any demo environment touching real or realistic client data; never leave a demo publicly reachable without auth** · `MUST`
Gate every demo deployment behind authentication (Replit Auth for internal/quick demos, Clerk/Auth.js + client IdP for client-branded or higher-stakes demos) unless the content is fully public and synthetic.
- *Why:* Non-negotiable compliance-ready-prototype item — no public/anonymous access to anything touching real or realistic data (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV items and [13 — Security & Authorization](./13-security-authz.md)).
- *How:* Enable Replit's "Require Private Development URLs" / invite-only access controls for Teams/Enterprise, or app-level auth middleware for anything beyond a trivial internal check.
- *Check:* Unauthenticated request to the demo URL is verified to receive a 401/redirect, not app content.

**`DEP-023` — Use a client-branded custom domain for client-facing demos, not the default Replit subdomain, when the engagement is client-branded** · `SHOULD`
Configure a custom domain (e.g., `demo.clientname-pilot.cognirise.com`) for demos presented directly to client stakeholders.
- *Why:* Improves perceived professionalism and avoids exposing the studio's internal Replit project naming to the client.
- *How:* DNS CNAME to the Replit Deployment per Replit's custom-domain configuration flow.
- *Check:* Demo runbook records the custom domain used for the most recent client session.

### Region/residency limitations and migration triggers

**`DEP-024` — Flag Replit's US/India-only hosting as a residency risk explicitly, in writing, for any engagement with Confidential/Restricted data** · `MUST`
State in the data-classification and residency statement (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV-003) that Replit hosting is US-based (or opted-in India) and not UAE/GCC in-region.
- *Why:* Building/prototyping on Replit's default infrastructure with real regulated data is a data-residency and cross-border-transfer risk that must be disclosed even at prototype stage ([Replit docs, Information Security](https://docs.replit.com/teams/information-security/overview)).
- *How:* Standard disclosure paragraph included in every regulated-client statement of work.
- *Check:* Residency statement contains this disclosure for every CBUAE/government/DIFC-Restricted-data engagement.

**`DEP-025` — Migrate off Replit at any of the five documented trigger points** · `MUST`
Move the workload to client-controlled or in-region infrastructure when: (1) the prototype transitions from synthetic/demo data to real personal/financial/citizen data of any volume; (2) the client is a CBUAE-regulated bank/fintech requiring outsourcing due diligence on exact processing locations; (3) the client is a UAE federal/emirate government department with data classified sensitive under the National Cloud Security Policy; (4) the engagement moves from prototype/pilot to production requiring SLAs, DR, or network-level isolation; (5) a regulatory certification process (e.g., DIFC Regulation 10 System certification) requires infrastructure attestations Replit's shared US-hosted platform cannot satisfy.
- *Why:* These are the documented trigger points beyond which Replit's shared multi-tenant, non-UAE infrastructure will fail client due diligence ([05-regulated.md, §5.3](https://rulebook.centralbank.ae/en/rulebook/outsourcing)).
- *How:* Review these five triggers explicitly at every project-phase gate (prototype → pilot → production); record the decision in the risk register (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV-019).
- *Check:* Risk register shows a dated migration-trigger review at each phase transition.

### Portability practices

**`DEP-026` — Containerize the application as soon as the prototype stabilizes** · `MUST`
Introduce a `Dockerfile` (and `docker-compose.yml` for local multi-service dev) once the core feature set is stable, so the same artifact runs on Replit during iteration and on the target cloud's container runtime without rework.
- *Why:* Enables running on Azure Container Apps/AKS, AWS ECS/EKS, or OCI Container Engine without a rebuild ([Suffescom Solutions, How to Migrate Replit Hosting to Cloud](https://www.suffescom.com/blog/migrate-replit-to-cloud)).
- *How:* Multi-stage `Dockerfile` mirroring the `.replit` run/build commands; test locally with `docker build && docker run`.
- *Check:* `docker build` succeeds and the container serves traffic identically to the Replit deployment for a smoke-test route set.

**`DEP-027` — Externalize file/blob storage to S3-compatible object storage, never the local filesystem** · `MUST`
Store uploaded files, generated documents, and any binary artifact in S3-compatible object storage from the first implementation, not Replit's local filesystem.
- *Why:* Local filesystem storage does not migrate cleanly to Azure Blob/AWS S3/OCI Object Storage and is not durable across Autoscale instance recycling.
- *How:* Use an S3-compatible SDK client configured via `env.ts`; local dev may point at a MinIO container for parity.
- *Check:* Integration test confirms an uploaded file survives an Autoscale instance recycle and is retrievable via the object-storage client.

**`DEP-028` — Separate business logic from platform glue so Replit-specific routing/port-forwarding is never load-bearing** · `MUST`
Structure backend/frontend/database as distinct layers with clear service boundaries (REST/RPC contracts), so no application behavior depends on Replit-specific request-handling quirks.
- *Why:* Ensures the "move-off-Replit" step is a planned infrastructure migration, not an application rewrite.
- *How:* API routes defined by explicit Next.js route handlers with typed contracts, independent of any Replit-injected header/routing behavior.
- *Check:* Same route handler test suite passes when the app is run locally outside the Replit environment.

**`DEP-029` — Maintain a one-page target-state deployment diagram naming the client's actual production cloud/region** · `MUST`
Document, from the start of the engagement, where the system will run in production (e.g., Azure UAE North, AWS Bahrain/UAE, Oracle UAE) even while prototyping on Replit.
- *Why:* Turns the eventual move-off-Replit step into a planned migration rather than a late discovery.
- *How:* One-page diagram in `docs/runbooks/target-architecture.md`, updated whenever the client's infrastructure decision firms up.
- *Check:* Diagram exists and names a specific region/provider before the engagement reaches pilot stage.

## Reference implementation

```text
# .replit — non-load-bearing per DEP-003
run = "npm run start"
entrypoint = "app/page.tsx"

[env]
PORT = "3000"

[deployment]
run = ["npm", "run", "start"]
build = ["npm", "run", "build"]
deploymentTarget = "autoscale"
```

```dockerfile
# Dockerfile — DEP-026, mirrors .replit run/build commands
FROM node:20-slim AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-slim
WORKDIR /app
COPY --from=build /app ./
ENV PORT=3000
EXPOSE 3000
CMD ["npm", "run", "start"]
```

```typescript
// pg-boss worker — DEP-011, runs on Reserved VM, enqueued from Autoscale web
import PgBoss from "pg-boss";
import { env } from "./env";

const boss = new PgBoss(env.DATABASE_URL);

async function startWorker() {
  await boss.start();
  await boss.work("retention-deletion", async (job) => {
    await runRetentionDeletion(job.data as { classification: string });
  });
}

startWorker();
```

```mermaid
flowchart TD
  A[Autoscale web instance] -->|enqueue job| B[(Postgres: pg-boss queue)]
  C[Reserved VM worker] -->|poll & process| B
  D[Scheduled Deployment: nightly cron] -->|direct run| E[Retention deletion job]
  E --> F[(Postgres: primary data)]
  A --> F
  C --> F
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| In-memory session map on an Autoscale service | State silently lost on instance recycle; intermittent bugs | Persist all session/agent state to Postgres (DEP-013) |
| Hardcoded port number in server startup | Breaks both Replit and target-cloud container runtimes | `process.env.PORT` with local fallback (DEP-005) |
| Real client PII in a `demo` deployment reachable without auth | Non-negotiable compliance failure; public exposure risk | Auth-gate every demo; freeze before sessions (DEP-021/022) |
| Redis/RabbitMQ introduced "for the queue" | Extra infra to provision/secure per client, duplicates `pg-boss` | `pg-boss` on the same Postgres instance (DEP-011) |
| Relying solely on Replit Agent checkpoints for rollback | Tool-specific, not portable, weaker audit trail than git | Commit to git at every meaningful milestone (DEP-017) |
| Building the full production system on Replit for a CBUAE-regulated bank | Fails outsourcing due diligence on processing location | Migrate at the documented trigger points (DEP-025) |
| Local filesystem storage for uploaded files | Not durable across instance recycling; doesn't migrate cleanly | S3-compatible object storage from day one (DEP-027) |

## Definition of Done

- [ ] Deployment type selected and documented per the decision table, matching the app's actual traffic/state profile (DEP-001).
- [ ] No hardcoded secrets found by CI secret-scan; all credentials in Replit Secrets (DEP-006).
- [ ] Connection pooling configured and load-tested under simulated concurrent Autoscale traffic (DEP-009).
- [ ] `pg-boss` used for all background work; no undocumented Redis/queue dependency (DEP-011).
- [ ] Scheduled Deployment configured for every cron/time-triggered job (DEP-012).
- [ ] No in-memory state identified as authoritative on any Autoscale-deployed service (DEP-013).
- [ ] Staging and demo environments exist as separate deployments (DEP-020).
- [ ] Demo environment requires authentication; unauthenticated request verified to fail (DEP-022).
- [ ] Residency disclosure present in the data-classification statement for regulated engagements (DEP-024).
- [ ] `Dockerfile` builds and runs identically to the Replit deployment (DEP-026).
- [ ] Target-state architecture diagram exists naming a specific client cloud/region (DEP-029).
- [ ] Portability checklist (below) fully checked before handover.

## Portability checklist

- [ ] Git-first: project connected to a private GitHub/GitLab remote from day one.
- [ ] `package.json`/lockfile complete and explicit; `npm ci` succeeds from a clean checkout.
- [ ] All configuration via environment variables validated by `env.ts`; no `.replit`-only config is functionally required.
- [ ] Stateful services externalized: Postgres with tested `pg_dump`/`pg_restore`; object storage S3-compatible, not local filesystem.
- [ ] `Dockerfile`/`docker-compose.yml` present and verified to build/run outside Replit.
- [ ] Business logic separated from platform glue; route handlers pass their test suite outside the Replit environment.
- [ ] Audit-field pattern (`created_at/by`, `updated_at/by`, `deleted_at/by`) present on all mutable tables from first commit.
- [ ] Target-state deployment diagram exists naming the client's actual production cloud/region.

## Handoff notes

- Paste the deployment-type decision table directly into any spec section covering infrastructure before asking Replit Agent to scaffold deployment config.
- Tell Replit Agent explicitly which environment (staging vs. demo) it is working against before any session that touches data or config.
- Attach the portability checklist to the handover pack (see [22 — Handover & IP](./22-handover-ip.md)) so the client's own engineers can verify migration readiness independently.
- Flag any of the five migration triggers (DEP-025) to the parent agent/delivery lead immediately if observed mid-engagement — do not wait for the next scheduled review.

## Sources

- [Replit Docs, About Deployments](https://docs.replit.com/cloud-services/deployments/about-deployments) — Autoscale/Static/Reserved VM/Scheduled deployment types.
- [Replit Docs, Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets) — Secrets tool, AES-256/TLS, Static Deployment limitation.
- [Replit Docs, Replit Agent](https://docs.replit.com/replitai/agent) — Plan mode, mode selection, checkpoint behavior.
- [Replit Docs, Auth](https://docs.replit.com/learn/projects-and-artifacts/auth) — Replit Auth vs. Clerk decision.
- [Replit docs, Information Security](https://docs.replit.com/teams/information-security/overview) — US/India hosting regions, SOC 2 Type II attestation.
- [Replit docs, Enterprise Privacy Settings](https://docs.replit.com/teams/enterprise-privacy-settings) — private deployments, Git remote requirements.
- [Replit docs, Private Deployments](https://docs.replit.com/features/publishing/private-deployments) — invite-only/password-protected access controls.
- [Anthropic, Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) — plan/implement discipline, specific-feedback prompting.
- [VP0, Does Replit Agent Export Clean Code to GitHub?](https://vp0.com/blogs/does-replit-agent-export-clean-code-to-github) — portability of Replit-generated code.
- [Suffescom Solutions, How to Migrate Replit Hosting to Cloud](https://www.suffescom.com/blog/migrate-replit-to-cloud) — containerization and backup/restore migration practices.
- [CBUAE Rulebook, Outsourcing](https://rulebook.centralbank.ae/en/rulebook/outsourcing) — outsourcing due diligence trigger for regulated banks.
