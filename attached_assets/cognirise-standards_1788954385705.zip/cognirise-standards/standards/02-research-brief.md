---
id: research-brief
domain: Discovery & Spec
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec]
last_reviewed: 2026-07-27
---

# 02. Research Brief

> **Purpose.** Define what a Cognirise research brief must contain and how Perplexity's research output must be structured, so Stage 2 specification can consume it directly without re-deriving missing context.
> **Read this when.** Authoring the Stage 1 brief, running the Perplexity research pass, or reviewing a research output before it enters Stage 2.

## Scope
- In scope: mandatory brief sections, question-scoping rules for structurally reusable output, the required research output schema, source-quality rules, competitor/analogue scanning, domain-vocabulary capture, evidence table format, and the unknowns/assumptions register.
- In scope: Stage 1 exit acceptance criteria.
- Out of scope: how research findings get turned into Functional/Technical Spec sections — see [03 — Specification](./03-specification.md) · SPEC-001. Out of scope: overall stage sequencing — see [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-013.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Brief format | Single `docs/research-brief.md` with fixed frontmatter + fixed section order | Perplexity and Claude both consume the same file without reformatting |
| Question scoping | Every research question tagged `researchable` or `client-only` before running | Prevents wasted research cycles on questions only the client can answer |
| Output schema | Fixed markdown structure with evidence tables, not free prose | Makes research output parseable by Claude at Stage 2 without manual restructuring |
| Source tiering | Primary/regulatory sources required for any regulated-client claim | Matches the studio's regulated-client posture (UAE/GCC gov/bank/telco) |
| Unknowns handling | Separate, mandatory "Unknowns & Assumptions" register, never buried in prose | Assumptions must be visible and challengeable, not implicit |
| Stage 1 exit | Checklist-gated (BRIEF-020), not a subjective "looks thorough" call | Matches [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-013 |

## Rules

### Mandatory brief sections

**`BRIEF-001` — Include all nine mandatory sections in the brief** · `MUST`
`docs/research-brief.md` must contain, in order: Business Goal, Target Users/Personas, Success Metrics, Known Constraints, Competitive/Prior-Art Pointers, Explicit Non-Goals, Prototype-vs-Production Statement, Research Question Backlog, Unknowns & Assumptions.
- *Why:* an unstructured brief is the highest-leverage source of downstream ambiguity, since specs, code, and demos all inherit its gaps.
- *How:* scaffold from the studio's `BRIEF.md` template at Stage 0→1 handoff.
- *Check:* reviewer confirms all nine `##` headings are present and non-empty.

**`BRIEF-002` — State success metrics as both business and model-quality metrics** · `MUST`
Success Metrics must list at least one business metric (e.g., time-to-resolution reduced by X%) and at least one model-quality metric (e.g., tool-call accuracy ≥ Y%) before the brief is accepted.
- *Why:* without a model-quality metric defined upfront, there is no way to evaluate "success" at demo time.
- *How:* two labeled sub-lists under Success Metrics: `business_metrics` and `model_quality_metrics`.
- *Check:* both sub-lists have at least one entry with a numeric or binary target.

**`BRIEF-003` — State the prototype-vs-production boundary explicitly** · `MUST`
The brief must state, in one paragraph, what "prototype" means for this engagement (what may be stubbed, what data is synthetic, what is deferred) versus what would be required for production.
- *Why:* this line is what keeps client expectations calibrated and lets Stage 5 accept known, disclosed gaps rather than hide them — see the regulated-client "compliance-ready prototype" bar in [05-regulated.md](../../research/05-regulated.md).
- *How:* dedicated `## Prototype vs. Production` section, cross-referencing the deferrable-gap list if the client is regulated.
- *Check:* section exists and names at least one explicitly deferred item.

**`BRIEF-004` — Record explicit non-goals** · `MUST`
List at least two explicit non-goals — capabilities intentionally out of scope for this engagement.
- *Why:* non-goals are what prevent scope creep from vague goals during Stage 2/3.
- *How:* `## Non-Goals` bullet list, each non-goal phrased as "This engagement will NOT ...".
- *Check:* section has ≥2 bullets, none of which duplicate an item in the Success Metrics or Business Goal sections.

### Deterministic-vs-agentic decision gate

**`BRIEF-005` — Include a problem-fit rubric before defaulting to an agent** · `MUST`
The brief must record whether the underlying need requires an agent (open-ended, unpredictable steps, nuanced judgment) or is better served by a deterministic workflow, using the decision criteria from the agent-architecture standard.
- *Why:* teams reflexively reach for agents when a deterministic workflow suffices, per [OpenAI's guidance on when to build an agent](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) and [Google's PAIR pattern](https://codelabs.developers.google.com/codelabs/pair-guidebook) requiring confirmation that "AI adds unique value" before building.
- *How:* `## Problem-Fit Assessment` subsection with a filled-in yes/no answer to each of: "steps unpredictable ahead of time?", "requires nuanced/ambiguous judgment?", "rule-based system would be unmaintainable?".
- *Check:* subsection present with all three questions answered; if all three are "no," flag for Stage 0 re-qualification rather than proceeding to an agent build.

### Scoping questions for reusable output

**`BRIEF-006` — Tag every research question as researchable or client-only** · `MUST`
Each item in the Research Question Backlog carries a tag: `[researchable]` (Perplexity can answer from public/primary sources) or `[client-only]` (must be validated directly with the client, not researched).
- *Why:* prevents Perplexity cycles being spent on questions no public source can answer (e.g., "what is the client's internal budget ceiling").
- *How:* backlog is a markdown checklist, one line per question, tag as a prefix.
- *Check:* no backlog line lacks a tag; `client-only` items are cross-listed in `docs/open-questions.md`.

**`BRIEF-007` — Phrase each researchable question so its answer maps to one evidence-table row** · `MUST`
Write questions narrowly enough that Perplexity's answer is a bounded fact, list, or comparison — not an open essay prompt.
- *Why:* narrow questions produce structurally reusable output; broad questions produce prose Claude must re-parse by hand.
- *How:* question template: "What is/are the <specific fact/list/comparison> for <specific entity/scope>, as of <recency window>?"
- *Check:* reviewer can point to the exact evidence-table row(s) in the research output answering each researchable question.

**`BRIEF-008` — Scope one question per atomic fact or comparison, not compound questions** · `MUST NOT`
Do not combine unrelated facts into a single research question (e.g., "what are competitor pricing models AND what accessibility laws apply").
- *Why:* compound questions produce answers that mix unrelated evidence in one block, breaking the one-question-to-one-evidence-row mapping.
- *How:* split into separate backlog lines; group only by shared sub-heading, not by shared question.
- *Check:* each backlog line addresses exactly one fact/list/comparison.

### Required output schema

**`BRIEF-009` — Perplexity research output follows the fixed schema** · `MUST`
The research output document uses this section order: Executive Summary, Domain Vocabulary, Evidence Tables (grouped by backlog theme), Competitor/Analogue Scan, Regulatory & Compliance Notes (if applicable), Unknowns & Assumptions, Source List.
- *Why:* a predictable structure is what lets Claude consume the file directly at Stage 2 without manual reformatting, mirroring the studio's general requirement that research seed specs without added translation work.
- *How:* provide this schema as a literal template appended to the Perplexity prompt.
- *Check:* output document has all seven `##` sections in this order.

**`BRIEF-010` — Executive Summary is bullet-only and under 150 words** · `MUST`
No prose paragraphs in the Executive Summary; state the top 5–8 findings as bullets.
- *Why:* consultants and Claude both need a fast top-line scan before descending into evidence tables.
- *How:* enforce via template with a bullet-list placeholder.
- *Check:* section contains only list items, word count under 150.

**`BRIEF-011` — Maintain a standing Unknowns & Assumptions register, separate from findings** · `MUST`
Every claim the research could not verify, or had to assume, is logged as a row in a dedicated table: `assumption, confidence (low/med/high), impact-if-wrong, validation-owner`.
- *Why:* burying assumptions inside prose findings makes them invisible to Stage 2 spec authors and to the client.
- *How:* table lives both in the research output and is copied into `docs/open-questions.md` for lifecycle-wide visibility (see [01 — Delivery Lifecycle](./01-delivery-lifecycle.md)).
- *Check:* every row has a non-empty `validation-owner`; rows with `impact-if-wrong: high` block Stage 1 exit until a plan exists to validate before Stage 2 relies on them.

### Source-quality rules

**`BRIEF-012` — Prefer primary sources over secondary summaries** · `MUST`
Cite the vendor/standards-body/regulator's own documentation (e.g., Anthropic's own engineering blog, the actual regulation text) over a third-party blog restating it, whenever a primary source exists.
- *Why:* secondary summaries introduce compounding inaccuracy and go stale faster than primary docs.
- *How:* evidence-table `source_type` column marked `primary` or `secondary`; secondary sources require a documented reason (e.g., "no primary source publishes this benchmark").
- *Check:* reviewer spot-checks that any `secondary` row has a stated reason.

**`BRIEF-013` — Enforce recency windows on time-sensitive claims** · `MUST`
Any claim about pricing, model capability, regulatory deadline, or competitor feature must cite a source dated within the last 12 months, or be explicitly flagged as historical/foundational (e.g., a stable engineering principle).
- *Why:* AI product/regulatory landscape moves fast enough that stale sources actively mislead.
- *How:* evidence-table `date` column mandatory; flag rows older than 12 months with `[dated]`.
- *Check:* no undated row exists for a pricing/capability/regulatory claim.

**`BRIEF-014` — Use regulatory-body primary sources for gov/bank/telco clients** · `MUST`
For UAE/GCC government, bank, or telco engagements, regulatory claims must cite the issuing authority directly (e.g., UAE Legislation, DIFC, CBUAE, TDRA, European Commission) rather than a law-firm summary, with the law-firm summary added only as a secondary corroborating citation.
- *Why:* regulated clients and their own compliance/legal teams will check primary sourcing; a studio citing only secondary legal commentary undermines credibility exactly where it matters most, per the regulated-client research (see [05-regulated.md](../../research/05-regulated.md)).
- *How:* `## Regulatory & Compliance Notes` evidence rows require a primary-source citation column populated.
- *Check:* every regulatory claim row has at least one citation matching a `.gov`, regulator, or standards-body domain (e.g., `uaelegislation.gov.ae`, `digital-strategy.ec.europa.eu`, `nist.gov`, `iso.org`, `owasp.org`).

**`BRIEF-015` — Do not assert a fact found only in training-data memory** · `MUST NOT`
Perplexity output must not include claims without an attached citation; any unsourced claim is moved to Unknowns & Assumptions instead.
- *Why:* uncited claims cannot be checked and erode the reliability of the whole evidence table.
- *How:* evidence-table schema makes the `source_url` column mandatory; empty cells fail the template.
- *Check:* no evidence-table row has an empty `source_url`.

### Competitor/analogue scanning

**`BRIEF-016` — Run a competitor/analogue scan for every engagement, sector-appropriate** · `MUST`
Identify at least 3 competitor products or cross-sector analogues (a comparable agentic pattern from an unrelated sector counts) relevant to the client's job-to-be-done.
- *Why:* prevents reinventing a pattern the market has already validated or already knows fails.
- *How:* `## Competitor/Analogue Scan` table: `name, sector, relevant capability, source, what to borrow, what to avoid`.
- *Check:* table has ≥3 rows, each with a populated `source` column.

### Domain vocabulary capture

**`BRIEF-017` — Capture domain vocabulary as a standing glossary** · `MUST`
Extract client/sector-specific terms (e.g., regulatory acronyms, internal process names, local-market terms) into a `## Domain Vocabulary` glossary: `term, definition, source, first-used-in-spec-section (filled at Stage 2)`.
- *Why:* domain vocabulary gaps cause Claude-generated specs/UI copy to use generic or wrong terminology, especially in Arabic/English bilingual government or bank contexts.
- *How:* glossary table populated during research; Stage 2 spec authors add the `first-used-in-spec-section` column value when consuming it.
- *Check:* glossary has ≥1 row for any engagement with sector-specific terminology (gov/bank/telco engagements should have ≥8).

### Evidence table format

**`BRIEF-018` — Use the fixed evidence table schema for every finding** · `MUST`
Evidence tables use exactly these columns: `finding, source_name, source_url, date, source_type (primary/secondary), confidence (low/med/high), relevant_req_or_question`.
- *Why:* a fixed schema is what makes evidence machine-parseable by Claude at Stage 2 without reformatting, and lets a reviewer audit sourcing quality in one pass.
- *How:* provide the table header as a literal template in the Perplexity prompt.
- *Check:* every evidence table in the output uses this exact column set and order.

**`BRIEF-019` — Group evidence tables by research-backlog theme, not chronologically** · `MUST`
Evidence tables are grouped under `###` sub-headings matching the Research Question Backlog's themes, so each backlog question's answer is locatable by heading, not by scanning.
- *Why:* thematic grouping is what makes the output structurally reusable — Claude and consultants can jump straight to the relevant section.
- *How:* sub-heading text matches the backlog theme label verbatim.
- *Check:* every backlog theme has a corresponding evidence-table sub-heading.

### Stage 1 acceptance criteria

**`BRIEF-020` — Research output must pass all seven acceptance checks before Stage 2 opens** · `MUST`
Before `docs/research-brief.md` and its research output are marked `status: accepted`, confirm: (1) all nine brief sections present (BRIEF-001), (2) success metrics include both business and model-quality types (BRIEF-002), (3) output schema followed exactly (BRIEF-009), (4) no evidence row lacks a `source_url` (BRIEF-015), (5) Unknowns & Assumptions register has no unresolved `impact-if-wrong: high` row without a validation plan (BRIEF-011), (6) competitor/analogue scan has ≥3 rows (BRIEF-016), (7) regulatory claims (if any) cite a primary regulatory source (BRIEF-014).
- *Why:* this is the mechanical, non-subjective gate referenced by [01 — Delivery Lifecycle](./01-delivery-lifecycle.md) · LIFE-013.
- *How:* Stage 1 exit checklist in `docs/lifecycle-status.md` lists these seven items verbatim.
- *Check:* reviewer checks each of the seven items against the actual file content before flipping `status: accepted`.

## Reference implementation

### `docs/research-brief.md` skeleton

```markdown
---
client: <client-name>
sector: <gov | bank | telco | b2b-enterprise>
status: draft            # draft | accepted
last_reviewed: <date>
---

# Research Brief — <client-name>

## Business Goal
<one paragraph>

## Target Users / Personas
- Persona A: ...
- Persona B: ...

## Success Metrics
### business_metrics
- ...
### model_quality_metrics
- ...

## Known Constraints
- Compliance: ...
- Data residency: ...
- Budget/timeline: ...

## Competitive / Prior-Art Pointers
(seed list; full scan lives in the research output, see below)

## Non-Goals
- This engagement will NOT ...
- This engagement will NOT ...

## Prototype vs. Production
<one paragraph: what's stubbed, what's synthetic, what's deferred>

## Problem-Fit Assessment
- Steps unpredictable ahead of time? <yes/no + why>
- Requires nuanced/ambiguous judgment? <yes/no + why>
- Rule-based system would be unmaintainable? <yes/no + why>

## Research Question Backlog
- [researchable] What is ... ?
- [client-only] What is the client's internal ... ?

## Unknowns & Assumptions
| assumption | confidence | impact-if-wrong | validation-owner |
|---|---|---|---|
```

### Perplexity research output skeleton

```markdown
# Research Output — <client-name> / <backlog-theme-set>

## Executive Summary
- finding 1
- finding 2
(bullets only, <150 words)

## Domain Vocabulary
| term | definition | source | first-used-in-spec-section |
|---|---|---|---|

## Evidence Tables

### <backlog theme 1>
| finding | source_name | source_url | date | source_type | confidence | relevant_req_or_question |
|---|---|---|---|---|---|---|

### <backlog theme 2>
| finding | source_name | source_url | date | source_type | confidence | relevant_req_or_question |
|---|---|---|---|---|---|---|

## Competitor / Analogue Scan
| name | sector | relevant capability | source | what to borrow | what to avoid |
|---|---|---|---|---|---|

## Regulatory & Compliance Notes
(omit heading content, keep heading, if not applicable — state "Not applicable: <reason>")
| requirement | citing authority | primary source | secondary corroboration | studio implication |
|---|---|---|---|---|

## Unknowns & Assumptions
| assumption | confidence | impact-if-wrong | validation-owner |
|---|---|---|---|

## Source List
- [Source name](https://...) — 3–10 word note on what it supports
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Free-prose research report with no tables | Claude must re-parse unstructured prose at Stage 2, reintroducing ambiguity | Enforce `BRIEF-009`: fixed schema with evidence tables |
| Asking Perplexity a compound question ("pricing and compliance and UX trends") | Produces mixed-topic answers that don't map to one evidence row | Enforce `BRIEF-008`: one atomic fact/comparison per question |
| Citing only law-firm blog posts for a DIFC Regulation 10 claim | Undermines credibility with a regulated client's own compliance team | Enforce `BRIEF-014`: primary regulator source required, secondary as corroboration only |
| Leaving assumptions implicit in Executive Summary prose | Assumptions become invisible and unchallenged going into Stage 2 | Enforce `BRIEF-011`: dedicated Unknowns & Assumptions table |
| Treating "client-only" questions as researchable and inventing an answer | Produces a confidently wrong assumption presented as fact | Enforce `BRIEF-006`: tag and route client-only questions to `docs/open-questions.md`, never answer them from research |
| Skipping the competitor scan because "we know this space" | Misses validated patterns or known failure modes from adjacent sectors | Enforce `BRIEF-016`: minimum 3-row competitor/analogue scan on every engagement |

## Definition of Done

- [ ] `docs/research-brief.md` has all nine mandatory sections populated (BRIEF-001).
- [ ] Success Metrics lists both business and model-quality metrics (BRIEF-002).
- [ ] Research Question Backlog has every item tagged `researchable` or `client-only` (BRIEF-006).
- [ ] Research output follows the fixed seven-section schema in order (BRIEF-009).
- [ ] Every evidence-table row has a non-empty `source_url` (BRIEF-015).
- [ ] Unknowns & Assumptions register exists with no unresolved `high`-impact row lacking a validation owner (BRIEF-011).
- [ ] Competitor/analogue scan has at least 3 rows with sources (BRIEF-016).
- [ ] Regulatory claims (if applicable) cite a primary regulatory source (BRIEF-014).
- [ ] All seven Stage 1 acceptance checks (BRIEF-020) pass and `status: accepted` is set.

## Handoff notes

- Paste the entire `docs/research-brief.md` (not a summary) into the Perplexity research prompt, followed by the fixed output schema from the Reference implementation.
- When handing the completed research output to Claude for Stage 2, include both the brief and the research output — Claude needs the Problem-Fit Assessment and Non-Goals sections as much as the evidence tables.
- Flag any `impact-if-wrong: high` row in Unknowns & Assumptions explicitly in the Stage 2 handoff message so Claude does not silently treat an assumption as settled fact.
- For gov/bank/telco clients, attach the Regulatory & Compliance Notes section prominently — Stage 2's Risk Register (see [03 — Specification](./03-specification.md) · SPEC-001) depends on it.

## Sources

- [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) — deterministic-vs-agentic decision criteria underlying the problem-fit rubric.
- [Google PAIR Guidebook Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook) — confirming AI adds unique value before building.
- [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents) — "start simple" principle informing the problem-fit gate.
- research file [01-standards-areas.md](../../research/01-standards-areas.md), section A1 — required brief sections and problem-fit checklist rationale.
- research file [05-regulated.md](../../research/05-regulated.md) — primary regulatory sourcing rule and compliance-ready prototype framing for gov/bank/telco engagements.
