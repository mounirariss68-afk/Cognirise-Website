---
id: ux-ui
domain: UX/UI
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [research-brief, spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 05. UX/UI

> **Purpose.** Give every Cognirise prototype a single, implementable UX contract for agentic surfaces — so trust, control, latency, and failure states are built the same way in every client engagement, on shadcn/ui + Vercel AI SDK.
> **Read this when.** Design and implementation stages, for every screen that shows agent output, agent activity, or agent-affecting controls.

## Scope

- In scope: surface selection, progressive disclosure of reasoning, trust calibration UI, human-in-the-loop UI surfaces, streaming/latency UX, error/refusal/empty states, multi-agent/multi-run UX, onboarding and discovery, feedback capture, cost/permission transparency, enterprise platform surfaces, banned anti-patterns, measurable quality criteria.
- Out of scope: the underlying HITL approval-gate mechanics (state machine, SLA enforcement) — see [04 — Journey Design](./04-journey-design.md) · JRN-007–JRN-013 and the HITL standard. Token/design-token values and component visual styling — see [06 — Design System](./06-design-system.md). Accessibility/RTL normative rules beyond what is cited inline — see the A11Y standard.

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Default surface | Match surface to task shape via the decision table (UX-001); chat is a fallback, not the default | Forcing structured tasks through chat adds conversational overhead users didn't ask for |
| Reasoning disclosure | Collapsed summary by default; full trace ≤1 click away | Prevents overwhelming users while preserving debuggability/trust |
| Confidence display | Label + color band, never a bare percentage | Numeric scores read as false precision |
| Irreversible actions | Explicit approval gate or a declared pre-approval policy — never silent execution | Matches Anthropic/OpenAI checkpoint guidance; see JRN-007–JRN-010 |
| Streaming scroll behavior | Never force-autoscroll once the user has scrolled up | NN/g finding: autoscroll fights the user's reading position |
| Long-running tasks (>15–30s) | Become a trackable background job with a visible status affordance, not a blocking spinner | Matches async/Devin-style session UX |
| Every AI output | Carries a reachable feedback control tied to a trace/run ID | Feeds eval-set construction, not just CSAT |
| Component library | shadcn/ui (Radix) + Vercel AI SDK typed message `parts` | Canonical stack; typed parts give 1:1 UI-state mapping |

## Rules

### 1. Surface selection

**`UX-001` — Select the surface from task shape, not habit** · `MUST`
Use the decision table below before defaulting to chat. Do not ship two competing, undifferentiated chat entry points on the same product surface.

| Surface | Best for | Reference products | shadcn/ui + AI SDK building blocks |
|---|---|---|---|
| **Chat** | Ambiguous/exploratory intent, multi-turn clarification, conversational Q&A | ChatGPT, Claude, Perplexity | `useChat`, `<ScrollArea>`, message `parts` renderer |
| **Canvas / Artifacts** | One evolving artifact (doc, code, diagram) iterated on alongside conversation | Claude Artifacts, ChatGPT Canvas | `<ResizablePanelGroup>` split pane, `useObject` for structured streaming, version history in a `<Sheet>` |
| **Inline / embedded** | Assistance inside an existing structured surface (form field, table cell) | Notion AI, Linear inline rewrite | `<Popover>`/`<HoverCard>` anchored to the field, inline diff overlay |
| **Workflow builder** | Repeatable multi-step automations the user inspects/edits/re-runs deterministically | Node-graph automation builders | Custom node canvas + `<Dialog>` per-node config, typed step schema |
| **Dashboard** | Monitoring status/KPIs/run history/cost across many runs — read-heavy | Agent-platform admin/observability panels | `<Table>` + `<Card>` KPI grid, `<Tabs>` for time ranges |
| **Generative UI (system-generated)** | Agent renders a bespoke form/chart/calculator to reduce back-and-forth | Emerging pattern per NN/g | `useObject`-driven dynamic component registry keyed by schema `type` |
| **"Vibe coding" (user-directed generation)** | User explicitly asks the agent to build the interface itself | v0, Lovable, Replit Agent | Full canvas + live preview pane |

- *Why:* "users turn to site-specific chatbots for quick answers, not a conversation," and generative-UI research argues for outcome-oriented design over funneling every interaction through text.
- *How:* record the surface decision in the job's spec (cross-reference [04 — Journey Design](./04-journey-design.md) job type) before implementation begins; one surface decision per job type, not per screen.
- *Check:* design review confirms no structured/repeatable task routes through open-ended chat by default; no more than one ambiguous chat entry point exists per product area without explicit differentiation.

**`UX-002` — Persist a floating, consistently-positioned chat entry point across any flow it spans** · `MUST`
If a chat surface is available at all on a multi-page flow, keep it visible and in the same position on every page of that flow.
- *Why:* a disappearing chat entry point across steps of a flow is a documented failure case that frustrates users mid-task.
- *How:* mount the chat trigger in a persistent layout shell (Next.js root layout), not per-page.
- *Check:* navigating through every step of a flow, the chat entry point never disappears or moves.

**`UX-003` — Canvases and artifacts are independently addressable and versioned** · `MUST`
Any surface producing one evolving artifact renders it in a canvas/artifact pane with its own URL/ID and version history, not buried in chat scrollback.
- *Why:* avoids the "artifact buried in scroll" problem and enables diffing/versioning as first-class operations.
- *How:* `<ResizablePanelGroup>` with the artifact pane bound to `/jobs/[jobId]/artifacts/[artifactId]`; version list in a `<Sheet>` or sidebar.
- *Check:* reloading the artifact's URL directly (without replaying the chat) renders the current artifact state.

### 2. Progressive disclosure of plans, steps, tool calls, traces

**`UX-004` — Default to a collapsed activity summary; never dump full traces into primary chat flow** · `MUST`
Render a persistent, single-line status strip ("Searching docs → Reading 3 files → Drafting patch") that updates as steps complete. Clicking it expands an activity-timeline panel. Default view never exceeds ~3 visible process lines before requiring an explicit expand action.
- *Why:* full chain-of-thought or tool-call logs overwhelm users and slow comprehension; hiding all process kills debuggability. Microsoft HAX guideline 10 and PAIR's explainability chapter both call for layered, on-demand explanation.
- *How:* build a `<StatusStrip>` component bound to AI SDK message `parts`; each `tool-*` part with `state` in `input-streaming | input-available | output-available | output-error` renders as one collapsed line, expandable to a `<Collapsible>` showing the full input/output payload.
- *Check:* default DOM never renders more than 3 visible process lines per turn; every tool call's full payload is reachable in ≤1 click; long traces are virtualized (e.g., `@tanstack/react-virtual`), not fully mounted.

**`UX-005` — Represent every step as a typed card with a machine-readable status** · `MUST`
Each plan step or tool call renders as a card: verb + target + status icon (queued/running/done/failed), collapsed by default, expandable to inputs/outputs.
- *Why:* mirrors the AI SDK's typed tool-part state model, giving a 1:1 mapping between backend state and UI affordance so new tool types render consistently without bespoke UI.
- *How:* build a `<ToolCallCard>` component keyed on `part.type` (`tool-call`, `tool-result`, `step-start`) per the AI SDK chatbot tool-usage pattern; use `step-start` boundaries rendered as `<Separator>` rules to chunk multi-step sequences without new messages.
- *Check:* every tool call in the product renders through `<ToolCallCard>`; no bespoke one-off tool UI exists outside the typed component.

**`UX-006` — Offer plan review as a structured, editable artifact before execution, not prose** · `MUST`
Render the agent's plan as a checklist or structured markdown the user can edit before clicking "Run," modeled on Cursor's Plan Mode: research → draft plan artifact → block execution until reviewed/edited.
- *Why:* prose-only plans can't be safely edited piecemeal; structured plans let a human intervene precisely instead of accepting/rejecting the whole plan.
- *How:* render `plan_steps` (see [04 — Journey Design](./04-journey-design.md) · JRN-002) as an editable `<Checklist>`/markdown editor component; edits write back to `plan_steps` before the "Run" action is enabled.
- *Check:* a user can delete, reorder, or edit an individual plan step and have that change reflected in execution — verified by an integration test.

### 3. Trust calibration

**`UX-007` — Attach an inline, clickable citation chip to every grounded claim** · `MUST`
Place a numbered or favicon-badge citation chip immediately after the claim it supports; clicking opens a source-preview panel without navigating away.
- *Why:* Perplexity's citation-first design reduces tab-hopping and hallucination anxiety by keeping claim and source in the same viewport.
- *How:* build a `<CitationChip>` shadcn `<HoverCard>` component bound to the AI SDK `source` message part; render inline in the streamed markdown renderer.
- *Check:* 100% of factual claims sourced from retrieval carry a visible, clickable citation within the same viewport; provenance for any claim reachable in ≤2 clicks.

**`UX-008` — Show confidence as a label + color band, never a bare percentage, never color alone** · `MUST NOT` (rendering raw numeric confidence as the primary signal)
Use a discrete low/medium/high label plus color; always pair color with a text label or icon.
- *Why:* numeric scores read as false precision; label+color outperforms raw percentages for lay users, and color-only signaling fails colorblind and screen-reader users (WCAG 1.4.11 non-text contrast).
- *How:* build a `<ConfidenceLabel>` component with three fixed variants (`low`/`medium`/`high`) each carrying a `Badge` color token and a text string — see [06 — Design System](./06-design-system.md) for the token values.
- *Check:* no UI surface renders a raw percentage as the primary confidence signal; every confidence badge has a text label distinguishable without color.

**`UX-009` — Use ambient, persistent disclaimers, never modal interrupts, for standing AI-output caveats** · `MUST NOT` (using a dismissible modal for a standing disclaimer)
Render "AI-generated — verify before use" as persistent footer/microcopy, not a modal.
- *Why:* modals get reflexively dismissed and stop conveying information after the first dismissal.
- *How:* a fixed `<Callout variant="muted">` in the response footer, styled per the design system's ambient-disclaimer token.
- *Check:* no AI-output caveat is implemented as a `<Dialog>`/`<AlertDialog>` requiring dismissal.

**`UX-010` — Expose transparent, per-document operation history distinguishing AI-authored from human-edited content** · `MUST`
A collapsible timeline per document/session shows which spans were AI-authored, which were human-edited, and the prompt that produced each change.
- *Why:* provenance at the edit level, not just the claim level, is required for audit-sensitive clients and mirrors Linear's inline-AI undo pattern.
- *How:* an `<EditHistoryTimeline>` component reading from a `document_revisions` table tagging each revision's `author_type` (`agent`/`human`) and `source_prompt`.
- *Check:* for any AI-editable document, the edit history is reachable from the document view and correctly attributes every revision.

**`UX-011` — Visually distinguish grounded from ungrounded/inferred claims** · `MUST`
Claims with a citation render as plain text with a citation chip; claims without one (generated/inferred) carry a distinct visual flag (dotted underline or badge).
- *Why:* conflating grounded and generated claims visually is the default failure mode that produces confidently-worded wrong answers.
- *How:* the markdown/streaming renderer checks for an attached `source` part per claim span; absence renders the `ungrounded` text-decoration token.
- *Check:* a claim with no retrieval source never renders identically to a cited claim.

**`UX-012` — Never let sponsored or promoted content share visual treatment with organic citations** · `MUST NOT`
Sponsored/promoted suggestions must carry a clear, persistent visual distinction from organic results at all times.
- *Why:* conflating paid and organic content is deceptive and erodes trust once discovered.
- *How:* a dedicated `<SponsoredBadge>` token distinct from `<CitationChip>`; never reuse the citation component for promoted content.
- *Check:* design review confirms zero shared visual treatment between sponsored and organic result components.

### 4. Human-in-the-loop UI

*Cross-reference: the approval-gate state machine, risk tiers, and SLA enforcement are defined in [04 — Journey Design](./04-journey-design.md) · JRN-007–JRN-013 and the HITL standard. This section covers only the UI surfaces for those mechanics.*

**`UX-013` — Render proposed changes as a diff before applying, never as a describe-then-trust prose summary** · `MUST`
Present file/data changes as an added/removed/changed diff prior to execution.
- *Why:* Cursor's "Diffs & Review" pattern — "inspect diffs, run checks, and catch problems before you merge" — is the standard for reviewable agent output; prose summaries hide exactly what changed.
- *How:* a `<DiffView>` component (unified or side-by-side) rendering the AI SDK tool-part's proposed `before`/`after` payload before the approval action is enabled.
- *Check:* every content-mutating tool call has a diff rendered prior to its approval action being clickable.

**`UX-014` — Surface the typed approval state machine directly in the UI, including which gates were automatic** · `MUST`
Render tool-call approval as `approval-requested → approval-responded (approved/denied) → output-available/output-denied`, and visibly flag when a gate was skipped by policy (`part.approval.isAutomatic`).
- *Why:* users need to see which gates were skipped by policy, not just which were shown to them, to calibrate trust in the autonomy tier they're in (see [04 — Journey Design](./04-journey-design.md) · JRN-008).
- *How:* an `<ApprovalBar>` component bound to the AI SDK approval state; when `isAutomatic` is true, render a muted "auto-approved by policy" tag instead of hiding the step.
- *Check:* every executed tool call, automatic or manual, has a visible state trace; no silently-skipped gates.

**`UX-015` — Default destructive or expensive operations to dry-run/preview** · `MUST`
Show a simulated preview ("would delete 12 rows") with a separate, explicit action required to commit.
- *Why:* prevents irreversible action from executing on a single ambiguous confirmation click.
- *How:* a `<DryRunPreview>` card rendered before the `<ApprovalBar>` for any tool tagged `risk_tier: high` in `tool_policies` (see [04 — Journey Design](./04-journey-design.md) · JRN-004).
- *Check:* every high-risk tool call renders a dry-run preview distinct from the commit action.

**`UX-016` — Provide a visible Stop/Pause control at all times during execution, with mid-run steering** · `MUST`
A "Stop"/"Pause" control is always reachable during a run; the user can inject new instructions without discarding partial progress.
- *Why:* HAX guidelines 13–16 require efficient interruption and correction as first-class control, not a last resort.
- *How:* a persistent `<RunControlBar>` fixed to the run's viewport with `Stop`, `Pause`, and an inline instruction input that posts to the running job without a full restart.
- *Check:* time from clicking Stop to the run halting is under 2 seconds, with partial results preserved, verified in an E2E test.

**`UX-017` — Attach a one-click undo adjacent to every AI-applied change; prefer versioned checkpoints for multi-step runs** · `MUST`
Undo/revert affordance sits next to the change itself, never in a settings menu; multi-step runs get versioned checkpoints rather than a single-level undo.
- *Why:* "if undo is buried, users disengage from using AI at all"; single-level undo is insufficient once a run spans multiple mutations.
- *How:* an `<UndoAffordance>` inline button per mutation, backed by the `document_revisions`/checkpoint table from UX-010; multi-step runs expose a version picker, not just "undo last."
- *Check:* every AI-applied change has a discoverable undo within the same session, reachable in ≤1 click.

**`UX-018` — Let users pre-approve scoped classes of low-risk actions distinct from high-risk ones** · `SHOULD`
Provide an explicit autonomy-scope settings surface (e.g., "always allow read-only tools") separate from high-risk action approval.
- *Why:* reduces approval friction for low-risk repeat actions while keeping high-risk actions gated, echoing sandbox/guardrail recommendations.
- *How:* a `<ScopedAutonomySettings>` panel mapping directly to `tool_policies` rows (see [04 — Journey Design](./04-journey-design.md) · JRN-007); changes here are themselves logged as `agent_actions` overrides.
- *Check:* % of low-risk tool calls requiring a modal interruption trends toward the minimum achievable via pre-approval policy, tracked over time.

### 5. Streaming and latency UX

**`UX-019` — Stream tokens as they arrive; never show a blank or frozen screen during model latency** · `MUST`
Render partial assistant messages incrementally via SSE/streaming rather than waiting for full completion.
- *Why:* perceived performance is driven more by continuous feedback than by raw speed; LLM latency is highly variable (sub-second to minutes).
- *How:* `useChat` from the Vercel AI SDK for token streaming; render `message.parts` as they arrive.
- *Check:* time-to-first-visible-token/content is under 1 second via streaming or a skeleton — never a blank container.

**`UX-020` — Never force-autoscroll during streaming once the user has scrolled up** · `MUST NOT`
Preserve the user's reading position; offer a "Jump to latest" affordance instead of moving their scroll position.
- *Why:* NN/g's chatbot study found autoscroll-to-bottom during streaming actively fights the user's reading position.
- *How:* track scroll position with an `IntersectionObserver` on the last message; only auto-scroll if the user was already at the bottom before the new content arrived; show a floating `<JumpToLatestButton>` otherwise.
- *Check:* automated test scrolls up mid-stream and asserts scroll position is not force-moved; the jump-to-latest control appears instead.

**`UX-021` — Use skeletons shaped like the final content, never a generic spinner, for structured output** · `MUST`
Card skeletons for card results, table skeletons for tabular output, paragraph skeletons for prose.
- *Why:* shape-matched skeletons reduce perceived latency and prevent layout shift on load; a centered spinner gives no information about what's coming.
- *How:* a `<Skeleton>` component variant per output shape, selected by the expected response schema before the first token arrives.
- *Check:* no structured-output surface renders a generic centered spinner; skeleton shape matches final layout with no post-load reflow.

**`UX-022` — Use optimistic UI for actions the agent is very likely to fulfill** · `SHOULD`
Show the sent message immediately; show a provisional "queued" state for a tool call while reconciling with actual state once confirmed.
- *Why:* removes perceived latency for the common case without waiting on round-trip confirmation.
- *How:* optimistic message insertion in the `useChat` local state, reconciled against the server-confirmed message on response.
- *Check:* user-sent messages appear in the UI within one animation frame of submission, before server acknowledgment.

**`UX-023` — Treat any task expected to exceed 15–30 seconds as a trackable background job** · `MUST`
Let the user navigate away; surface a persistent job indicator (toast, notification-center entry, nav badge); notify on completion.
- *Why:* modeled on Devin/async coding-agent sessions where work continues off-screen; blocking spinners for long tasks force users to babysit the UI.
- *How:* a `<JobStatusBadge>` in the nav bar bound to the `jobs` table status (see [04 — Journey Design](./04-journey-design.md) · JRN-001); in-app/push/email notification on `status = 'done'`.
- *Check:* any task exceeding 30 seconds in QA testing has a named, trackable job with a visible status affordance outside the immediate chat turn.

**`UX-024` — Make sessions and runs resumable after reload or disconnect** · `MUST`
Reconstitute in-progress runs from server-persisted state on reload; never lose an in-flight stream to a refresh.
- *Why:* durable execution is a design requirement for agentic products, not a nice-to-have; losing state on refresh is a top source of user distrust.
- *How:* on mount, check for an active `job_id` in the URL/session and reconnect to the run's stream or poll its latest `plan_steps` state.
- *Check:* reloading the page mid-run resumes rather than discards the in-progress run, verified by an E2E test.

**`UX-025` — Use `useObject` for streamed structured/JSON payloads driving generative UI** · `MUST`
Do not parse an all-or-nothing JSON blob for generative UI; use a dedicated structured-streaming hook so partial JSON can drive incremental rendering.
- *Why:* generative UI needs to render before the full payload has arrived; all-or-nothing parsing defeats streaming's latency benefit.
- *How:* `useObject` from the Vercel AI SDK bound to a Zod schema; render the dynamic component tree from the partial object as fields become available.
- *Check:* a generative-UI surface shows partial content before the full object streams in, verified visually.

### 6. Error, refusal, empty, partial-failure, and hallucination-recovery states

**`UX-026` — Design distinct states for no-results, tool failure, partial completion, refusal, and suspected hallucination** · `MUST`
Never use a generic "Something went wrong" for any of these; each state names the failure and offers ≥1 concrete next action.
- *Why:* HAX's "when wrong" phase treats failure as first-class, not an edge case; generic/irrelevant answers damage trust more than an honest, specific "I can't help with that."
- *How:* a `<StateBanner>` component with five typed variants (`empty`, `tool-error`, `partial-failure`, `refusal`, `hallucination-flag`), each requiring a `reason` and `nextAction` prop at the type level so a variant cannot ship without them.
- *Check:* every error state in the product names the failure and offers a concrete next action (retry, escalate, edit, undo); code review rejects any `<StateBanner>` usage missing `reason`/`nextAction`.

**`UX-027` — Show per-step success/failure for multi-step runs, never an aggregate pass/fail** · `MUST NOT` (rolling up a partial failure into a single failure banner)
When steps 1–3 of 5 succeed and step 4 fails, show completed steps as done, the failed step with error detail, and remaining steps as blocked/skipped.
- *Why:* a rolled-up single failure banner hides the successes and blocks targeted recovery; mirrors the AI SDK's per-tool `output-error` state with `errorText`.
- *How:* render each `<ToolCallCard>` (UX-005) independently; default to a masked generic message for security, with an opt-in "show details" for `errorText`.
- *Check:* multi-step run QA fixture with a mid-run failure shows 3 done + 1 failed + 1 blocked, never one aggregate banner.

**`UX-028` — State a reason category on every refusal and offer an alternative path** · `MUST`
Explain why (policy, missing capability, missing data) and offer escalate-to-human, rephrase, or narrower-scope as next actions.
- *Why:* a bare "I can't do that" gives the user no path forward and reads as arbitrary.
- *How:* refusal responses carry a `refusal_reason` enum surfaced in the `<StateBanner variant="refusal">`.
- *Check:* 100% of refusal states include a reason category, not just a decline.

**`UX-029` — Pair every generated claim capable of being wrong with a low-friction correction affordance** · `MUST`
Offer "this doesn't look right" / inline edit rather than requiring full regenerate-from-scratch; provide "regenerate with more sources" as an escalation path.
- *Why:* low-friction correction captures richer signal than a binary vote and avoids forcing users to discard an otherwise-good response over one wrong claim.
- *How:* an inline `<CorrectionAffordance>` anchored to the claim span, wired to the feedback pipeline (UX-034).
- *Check:* every generated factual claim has a reachable correction control without needing a full regenerate.

**`UX-030` — Degrade gracefully and say so when a tool/API is down** · `MUST`
State that the dependency is unavailable and offer a manual fallback rather than silently returning a worse answer.
- *Why:* silent degradation is indistinguishable from a wrong answer and is more damaging than an honest outage notice.
- *How:* wrap tool calls in the resilience layer (circuit breaker/fallback chain per the agent-architecture standard) and surface a `<StateBanner variant="tool-error">` naming the specific dependency.
- *Check:* simulated dependency outage in QA produces a named degradation notice, not a silently worse answer.

**`UX-031` — Announce injected error/status text via correct ARIA live regions** · `MUST`
Use `role="alert"`/`aria-live="assertive"` for errors and critical interruptions; the container must exist in the DOM at page load for reliable announcement.
- *Why:* screen readers only announce dynamically injected content living inside a properly configured live region present in the DOM at load.
- *How:* a persistent, empty `<div aria-live="assertive" role="alert">` mounted at layout level; error text is written into it, not created fresh per error.
- *Check:* all programmatically-injected error/status text is exposed via ARIA live regions and tested with a screen reader (NVDA/JAWS/VoiceOver).

### 7. Multi-run and multi-agent UX

**`UX-032` — Treat every agent invocation as a durable, addressable "run," not an ephemeral chat exchange** · `MUST`
Every run has a stable URL/ID, a status (running/succeeded/failed/needs-approval), start time, and duration, and remains inspectable after completion.
- *Why:* as agents move to asynchronous, long-running, multi-agent execution, the unit of work shifts from a chat turn to a run that outlives the immediate UI.
- *How:* a `<RunHistoryTable>` (dashboard surface, UX-001) listing `jobs` rows; each row links to `/jobs/[jobId]` which remains valid after completion.
- *Check:* every run is addressable by a stable URL and remains inspectable after completion; navigating to a completed run's URL renders its full timeline and artifacts.

**`UX-033` — Provide a persisted activity timeline and a separate artifacts pane per run** · `MUST`
The activity timeline (chronological steps/tool calls/decisions) is separate from the artifacts pane (durable outputs: files changed, documents created). Both are re-openable after the run completes.
- *Why:* conflating process log and output list forces users to hunt through a timeline for durable outputs; separating them lets each be diffed/reviewed independently.
- *How:* `<ActivityTimeline>` and `<ArtifactsPane>` as sibling panels in the run detail view; artifacts default to diff view (UX-013) where applicable.
- *Check:* diffs are available for any file/document-mutating step from the artifacts pane, not only a final summary.

**`UX-034` — Attribute every step/output to the specific agent or tool that produced it in multi-agent runs** · `MUST`
When multiple sub-agents or specialized tool-agents contribute to one task, visually attribute each step to its source rather than using a single undifferentiated "AI" voice.
- *Why:* consistent with orchestration guidance to split tasks across multiple agents as complexity grows; users need to know which specialist produced which output to calibrate trust per agent.
- *How:* `<ToolCallCard>` (UX-005) carries an `agentName`/`agentAvatar` field, rendered distinctly per contributing agent.
- *Check:* a multi-agent run's timeline shows a distinct visual identity per contributing agent, verifiable by inspection.

**`UX-035` — Name the accountable human alongside the acting agent in any delegation UI** · `MUST`
When work is assigned to an agent instead of a human, keep a visible, permanent record of who delegated and who remains accountable.
- *Why:* mirrors the delegation-not-full-handoff model; accountability must survive delegation for audit and regulated-sector review.
- *How:* a `delegated_by`/`accountable_owner` field rendered in the run header, sourced from the job record.
- *Check:* delegation UI always names the accountable human alongside the acting agent; no run exists with an agent actor and no named accountable human.

### 8. Onboarding, capability discovery, prompt affordances, mode/model pickers

**`UX-036` — Show capability through concrete, contextual examples at first contact** · `MUST NOT` (a blank input with a generic "Ask me anything" greeting)
Name 2–4 concrete task categories the agent handles, tailored to the current page/context, as clickable suggested-prompt buttons.
- *Why:* vague greetings set expectations the system can't meet; contextual example prompts (e.g., different on a homepage vs. a product page) is the documented success case.
- *How:* a `<SuggestedPrompts>` component reading a context-scoped prompt registry keyed by route/page.
- *Check:* first-run empty state always shows ≥2 concrete, clickable example actions relevant to current context; 100% of first-run suggestions are context-specific, not generic.

**`UX-037` — Adapt suggested follow-ups to conversation state; never repeat a twice-declined suggestion** · `MUST`
Refresh suggestions based on conversation state rather than repeating already-declined suggestions.
- *Why:* repeating a declined follow-up feels pushy/inattentive and damages trust.
- *How:* track declined suggestions per session; filter the suggestion registry against the declined set before rendering.
- *Check:* no suggestion is shown a third time after being ignored twice in the same session.

**`UX-038` — Reveal advanced capabilities just-in-time, not via a single onboarding tour** · `SHOULD`
Introduce file upload, voice input, tool integrations via affordances near first relevant use.
- *Why:* front-loading every capability in one tour gets forgotten; sequencing disclosure matches task progression.
- *How:* contextual `<Tooltip>`/inline callout triggered the first time a relevant context appears (e.g., first file-attachable message).
- *Check:* no onboarding tour attempts to introduce more than 2–3 capabilities in a single pass.

**`UX-039` — Provide a mode/model picker with a plain-language tradeoff, defaulting to the best general-purpose option** · `MUST`
Expose Fast vs. Thinking, or Ask vs. Agent vs. Plan mode, with a one-line description of the tradeoff; default so novice users never must choose correctly to succeed.
- *Why:* mode/model choice must be legible but not a burden for casual users.
- *How:* a `<ModePicker>` segmented control with a `<Tooltip>` per option stating the tradeoff in plain language (speed vs. depth); default value pre-selected.
- *Check:* mode/model pickers include a plain-language tradeoff description, not just a label; a novice user completing the default flow never needs to open the picker.

**`UX-040` — Support voice input as an accessibility and convenience affordance** · `SHOULD`
Provide voice input particularly on mobile or for users with motor impairments.
- *Why:* reduces typing burden, especially for non-native-script input methods relevant to bilingual Arabic/English users.
- *How:* a `<VoiceInputButton>` using the Web Speech API or a provider STT endpoint, positioned adjacent to the text input.
- *Check:* voice input is available and functional on the primary conversational input across supported browsers.

### 9. Feedback capture tied to trace IDs

**`UX-041` — Attach a one-click feedback control to every discrete AI output, linked to its trace/run ID** · `MUST`
Thumbs up/down positioned adjacent to the content; down-vote optionally prompts a 1-line reason (factual error, tone, irrelevant, unsafe). Feedback is linked to the underlying trace ID, not just an aggregate CSAT number.
- *Why:* structured human feedback tied to specific outputs/traces enables eval-driven development; a satisfaction metric alone is not actionable at the trace level.
- *How:* a `<FeedbackControl>` component posting `{ traceId, runId, rating, reasonCategory }` to a feedback endpoint; store alongside the observability standard's span/trace schema.
- *Check:* feedback control is reachable in 1 click/tap from any AI-generated output; down-votes capture a structured reason category; feedback rows are queryable by trace ID.

**`UX-042` — Capture inline corrections as implicit feedback** · `SHOULD`
When a user edits AI-generated content directly, capture the diff between original and edited as a feedback signal richer than a binary vote.
- *Why:* edit diffs carry more actionable signal than thumbs alone.
- *How:* on save of an inline edit, compute and store the diff against the pre-edit content, tagged with the same trace ID.
- *Check:* edited AI outputs produce a stored diff record distinct from the explicit thumbs feedback table.

**`UX-043` — Provide a dedicated annotation mode for internal reviewers, separate from end-user chat** · `SHOULD`
A reviewer UI labels spans/traces with structured scores and free-text explanations tied to the trace ID, for eval-set construction.
- *Why:* annotation for eval-driven development needs a different information density and permission model than end-user feedback.
- *How:* an internal `/admin/annotate` route rendering trace spans with a scoring rubric form; write-access gated to reviewer roles (see UX-047).
- *Check:* an admin/reviewer can label a trace with a structured score and explanation without leaving the annotation surface.

**`UX-044` — Surface aggregate feedback trends to admins, and close the loop when feedback drives a change** · `SHOULD`
Show trends (e.g., % thumbs-down by feature/prompt-template) in an internal dashboard; indicate to power users/admins when feedback led to a change.
- *Why:* reinforcing that feedback is acted on increases future participation.
- *How:* an admin dashboard `<Card>` grid aggregating `FeedbackControl` rows by feature/template; a changelog entry linkable from a feedback record once addressed.
- *Check:* an admin can see feedback trend by feature; at least one changelog-linked feedback resolution exists once the product is in active iteration.

### 10. Cost/usage and permission transparency

**`UX-045` — Provide a persistent, inspectable permission/scope panel with per-source revoke controls** · `MUST`
List the data sources/tools the agent is authorized to use in the current context (e.g., "Connected: Google Drive (read-only)"), with revoke controls per source.
- *Why:* users and admins must see, at any time, what data the agent can access — a baseline transparency and privacy commitment.
- *How:* a `<PermissionsPanel>` reading the session's tool/data-source grants; each row has a `Revoke` action calling the underlying connector's disconnect endpoint.
- *Check:* users can view current data/tool access grants without contacting support; revoke actions take effect immediately and are logged.

**`UX-046` — Show per-answer data provenance distinct from citations — what was actually accessed, not just cited** · `MUST`
Especially for RAG-based enterprise assistants, show which specific documents/records were retrieved and used for a given response.
- *Why:* access transparency is a distinct requirement from sourcing transparency; a user needs to know what the system touched, not only what it referenced.
- *How:* a `<DataAccessedPanel>` populated from the retrieval step's actual document IDs, separate from the `<CitationChip>` rendering.
- *Check:* for any RAG-grounded response, the specific retrieved records are listed and distinguishable from the inline citation list.

**`UX-047` — Expose real-time cost/usage meters for usage-priced products; distinguish query-time data use from training-data retention** · `MUST`
A running counter or budget bar for token/request/run cost, visible before or immediately after execution for cost-sensitive actions. Training-data opt-in/opt-out is a separate, explicit control from feature/data-access permissions.
- *Why:* agentic workflows can spawn many sub-calls silently; a surprise invoice erodes trust, and conflating training-data consent with feature consent reduces informed choice.
- *How:* a `<UsageMeter>` bound to `jobs`/trace-level token-usage aggregation (see the observability standard); a separate `<TrainingDataToggle>` distinct from any feature-access consent flow.
- *Check:* every billable agent run exposes an estimated or actual cost/usage figure before or immediately after execution; training-data consent is never bundled with a feature-access checkbox.

**`UX-048` — Provide per-user/per-team usage dashboards with admin-configurable caps and alerts** · `SHOULD`
Admin view of consumption breakdowns with alert/cap configuration.
- *Why:* enterprise buyers require budget governance across teams, not just per-run visibility.
- *How:* `<UsageDashboard>` aggregating `jobs`/trace cost by user/team with `<AlertThresholdConfig>`.
- *Check:* an admin can configure a usage cap and receive an alert when a team approaches it, verified in a staging run.

### 11. Enterprise platform surfaces

**`UX-049` — Ship an admin surface with a discoverable agent catalogue declaring capabilities and scopes before install** · `MUST`
An admin-curated list of installed/available agents per workspace, each with declared capabilities, connected tools, and installing admin.
- *Why:* agent identity and capability disclosure are enterprise governance requirements, not optional platform polish.
- *How:* `<AgentCatalogue>` page listing agent cards with a `<CapabilityDisclosure>` modal shown before install.
- *Check:* agent catalogue entries disclose the tools/data scopes an agent requests before installation; no agent installs silently.

**`UX-050` — Provide an immutable, searchable audit log UI attributing every action to a specific agent identity** · `MUST`
Export-capable audit log of who/what triggered an action, what it did, what it touched.
- *Why:* every agent action must be attributable to a scoped, auditable identity distinct from a shared credential.
- *How:* `<AuditLogTable>` with filters by agent identity, action type, and date range, backed by the append-only audit table (see the governance standard); export to CSV/JSON.
- *Check:* every agent action in the audit log is attributable to a unique agent identity and the human/policy that authorized it; 100% of agent actions are logged.

**`UX-051` — Support tenant switching with visibly scoped context; never let cross-tenant state leak into the UI** · `MUST`
A tenant switcher clearly indicates the active tenant at all times; switching tenants fully resets agent memory/context scope shown in the UI.
- *Why:* cross-tenant data leakage via shared agent memory/UI state is a critical failure mode for regulated multi-tenant clients.
- *How:* `<TenantSwitcher>` in the global nav bound to `session.tenantId`; all data-fetching hooks scope queries by tenant ID server-side, not just filter client-side.
- *Check:* switching tenants in the UI never displays a prior tenant's data, even momentarily, verified with a tenant-isolation E2E test.

**`UX-052` — Support custom, granular roles beyond owner/admin/member/viewer** · `MUST`
At minimum, support read-only-audit and agent-management as separable permissions from full admin.
- *Why:* fixed role buckets don't map to enterprise functional needs (e.g., a compliance analyst needing read-only audit access without agent-modification rights).
- *How:* a `<RoleEditor>` supporting custom permission-set composition, checked server-side per route/action.
- *Check:* a role can be created with read-only audit access and no agent-modification rights, verified by attempting a blocked action.

**`UX-053` — Provide suspend/uninstall controls for agents that preserve history for incident response** · `SHOULD`
Admins can suspend or remove an agent's access without deleting its history.
- *Why:* incident response requires the ability to stop an agent immediately while preserving the audit trail for post-mortem.
- *How:* a `Suspend`/`Uninstall` action on `<AgentCatalogue>` cards that flips an `active` flag rather than deleting rows.
- *Check:* suspending an agent stops new actions immediately while its historical audit log remains fully queryable.

### 12. Accessibility and bilingual/RTL specifics for agentic surfaces

*Full normative WCAG 2.2 mapping lives in the A11Y standard; the rules below are the agentic-surface-specific application, drawing on the [regulated-sector research](../../research/05-regulated.md) requirement that government/citizen-facing UAE surfaces meet WCAG 2.2 AA with full Arabic/RTL parity.*

**`UX-054` — Use `aria-live="polite"` for streaming responses; reserve `assertive`/`role="alert"` for errors only** · `MUST`
Wrap the streaming container in a polite live region so screen readers announce new content without cutting off current reading; batch updates or announce completed sentences rather than re-announcing the whole growing message on every token.
- *Why:* re-announcing the entire message on every token makes a screen reader re-read from the start repeatedly, which is unusable.
- *How:* a debounced live-region update strategy that flushes on sentence boundaries, not per token.
- *Check:* streaming responses use `aria-live="polite"` by default; error/interrupt states use assertive/alert regions; verified with a screen reader test.

**`UX-055` — Use auto-resizing containers and budget 30–40% extra space for Arabic/RTL and translated strings** · `MUST`
Chat bubbles, buttons, and labels must not clip or overlap at pseudo-localized (+40%) string length; mirror layout correctly in RTL, not just flip text direction.
- *Why:* multilingual AI UX faces text-expansion and layout-mirroring issues a chat/agent interface must specifically accommodate; UAE government/bank clients require Arabic as a first-class locale, not an afterthought.
- *How:* `next-intl` with `dir="rtl"` at the document root for Arabic locale; test every AI-surface component (status strip, approval bar, citation chip) with pseudo-localized strings before ship.
- *Check:* UI layout does not clip or truncate text at 40% string-length expansion in any supported locale; RTL rendering mirrors icon/control order correctly (e.g., Stop/Pause control order, approval bar button order).

**`UX-056` — Meet WCAG 2.2 AA target sizes and focus visibility on every approval/control surface** · `MUST`
Approve/Deny, thumbs up/down, and Stop/Pause controls meet the 24×24 CSS px minimum target size with adequate spacing; approval-gate dialogs are never obscured by a sticky streaming-response footer when focused via keyboard.
- *Why:* these are frequent, high-stakes taps; WCAG 2.2 added Target Size (2.5.8) and Focus Not Obscured (2.4.11) specifically because agent control surfaces are exactly this kind of frequent, consequential control.
- *How:* apply the design system's control-size tokens (see [06 — Design System](./06-design-system.md)) to every `<ApprovalBar>`/`<RunControlBar>` button; test keyboard focus order against sticky elements.
- *Check:* all approval/control buttons meet the 24×24 CSS px minimum target size with adequate spacing; keyboard-focused approval controls are never visually obscured.

## Reference implementation

### Typed message-part renderer (Vercel AI SDK + shadcn/ui)

```tsx
// components/agent/message-parts.tsx
import { UIMessage } from "ai";
import { ToolCallCard } from "./tool-call-card";
import { CitationChip } from "./citation-chip";
import { ConfidenceLabel } from "./confidence-label";
import { Separator } from "@/components/ui/separator";

export function MessageParts({ message }: { message: UIMessage }) {
  return (
    <div className="space-y-2">
      {message.parts.map((part, i) => {
        switch (part.type) {
          case "text":
            return <RenderedMarkdown key={i} text={part.text} />;
          case "step-start":
            return <Separator key={i} className="my-2" />;
          case "source":
            return <CitationChip key={i} source={part.source} />;
          default:
            if (part.type.startsWith("tool-")) {
              return <ToolCallCard key={i} part={part} />;
            }
            return null;
        }
      })}
    </div>
  );
}
```

### Approval bar with automatic-gate disclosure

```tsx
// components/agent/approval-bar.tsx
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type ApprovalState =
  | "approval-requested"
  | "approved"
  | "denied"
  | "output-available"
  | "output-denied";

export function ApprovalBar({
  state,
  isAutomatic,
  onApprove,
  onDeny,
}: {
  state: ApprovalState;
  isAutomatic: boolean;
  onApprove: () => void;
  onDeny: () => void;
}) {
  if (isAutomatic) {
    return <Badge variant="secondary">Auto-approved by policy</Badge>;
  }
  if (state === "approval-requested") {
    return (
      <div className="flex gap-2" role="group" aria-label="Approval required">
        <Button size="sm" className="min-h-[24px] min-w-[24px]" onClick={onApprove}>
          Approve
        </Button>
        <Button size="sm" variant="destructive" className="min-h-[24px] min-w-[24px]" onClick={onDeny}>
          Deny
        </Button>
      </div>
    );
  }
  return <Badge>{state}</Badge>;
}
```

### Streaming container with polite live region and scroll-position preservation

```tsx
// components/agent/streaming-region.tsx
import { useEffect, useRef, useState } from "react";

export function StreamingRegion({ children }: { children: React.ReactNode }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [userScrolledUp, setUserScrolledUp] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onScroll = () => {
      const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 32;
      setUserScrolledUp(!atBottom);
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div ref={containerRef} aria-live="polite" className="overflow-y-auto">
      {children}
      {userScrolledUp && <JumpToLatestButton onClick={() => containerRef.current?.scrollTo(0, 1e9)} />}
    </div>
  );
}

function JumpToLatestButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-20 right-6 rounded-full px-4 py-2 shadow-lg bg-primary text-primary-foreground"
    >
      Jump to latest
    </button>
  );
}
```

### Surface decision table lookup (design-time artifact, not runtime code)

Use the table in UX-001 directly in the spec; do not re-derive it per feature.

## Anti-patterns

| Anti-pattern | Why it's banned | Correct alternative |
|---|---|---|
| Blank/generic "Ask me anything" opening message | Sets expectations the system can't meet | Contextual capability examples as clickable prompts (UX-036) |
| Autoscrolling the user to the bottom of a streaming response | Disorients readers who started mid-stream | Preserve scroll position; "Jump to latest" (UX-020) |
| Multiple overlapping, undifferentiated chatbots on one surface | Confuses users about which bot can do what | One consolidated entry point or clearly differentiated bots (UX-001) |
| Modal disclaimers on every AI output | Gets reflexively dismissed, stops conveying information | Ambient, persistent microcopy (UX-009) |
| Full chain-of-thought dumped into the main chat by default | Overwhelms users, buries the answer | Collapsed summary + expandable trace (UX-004) |
| Executing irreversible actions with no approval gate or preview | Violates checkpoint guidance; see [04 — Journey Design](./04-journey-design.md) · JRN-010 | Diff-first review + dry-run + explicit approval (UX-013, UX-015) |
| Numeric-only confidence scores presented as precise probabilities | False precision misleads users | Label + color confidence bands (UX-008) |
| Sponsored/paid suggestions styled identically to organic ones | Deceptive; erodes trust once discovered | Distinct, persistent visual treatment (UX-012) |
| Silent failure or generic "Something went wrong" for multi-step runs | Hides which steps succeeded; blocks recovery | Per-step status with specific error and next action (UX-027) |
| Re-requesting information the user already provided earlier in the flow | Violates WCAG 3.3.7; wastes user effort | Persist and reuse prior inputs across the flow |
| Repeating a declined follow-up suggestion | Feels pushy/inattentive, damages trust | Adapt suggestions to what's already declined (UX-037) |
| Burying undo/rollback in a settings menu | Users disengage from AI features if correction is costly | One-click undo adjacent to the change (UX-017) |
| Using color alone to signal confidence/status | Fails colorblind and screen-reader users | Pair color with text/icon labels (UX-008) |
| Shared/unscoped credentials for agent actions | Breaks attribution and audit; security risk | Distinct, scoped, revocable per-agent identity (UX-050) |
| Treating chat as the default surface for every task | Forces conversational overhead onto structured tasks | Match surface to task shape (UX-001) |
| Training-data opt-in bundled with basic feature/data-access consent | Conflates unrelated consents, reduces informed choice | Separate, explicit toggle for training-data use (UX-047) |
| Tenant switcher that leaves prior tenant's data momentarily visible | Cross-tenant leak; critical failure for regulated multi-tenant clients | Server-side tenant-scoped queries, never client-side filter only (UX-051) |

## Measurable UX quality criteria

| Dimension | Metric | Target/benchmark |
|---|---|---|
| Time-to-first-feedback | Time from user submit to first visible token/skeleton | < 1s |
| Trace/plan discoverability | Clicks to reach full reasoning trace from a summary | ≤ 1 click |
| Provenance discoverability | Clicks to find source for any claim | ≤ 2 clicks (0 clicks to see the marker) |
| Correction cost | Actions required to fix/undo an AI output | ≤ 1 click for undo; ≤ 1 short instruction for edit-in-place |
| Approval friction (low-risk actions) | % of low-risk tool calls requiring modal interruption | Minimize via scoped pre-approval policy (UX-018) |
| Interruptibility | Time from "Stop" click to run halting | < 2s, with partial results preserved |
| Error legibility | % of error states with a named cause + next action | 100% |
| Feedback capture rate | % of AI outputs with a reachable feedback control | 100% present; track opt-in rate over time |
| Accessibility conformance | WCAG 2.2 AA success-criteria pass rate on AI surfaces | 100% of applicable AA criteria |
| Live-region correctness | Streaming/error announcements correctly voiced | Verified with NVDA/JAWS/VoiceOver |
| Localization robustness | UI integrity at +40% string length (pseudo-localization) | No clipping/overlap, including Arabic/RTL |
| Cost transparency | % of billable agent runs showing cost/usage before or immediately after execution | 100% |
| Audit completeness | % of agent actions attributable to a specific identity in logs | 100% |
| Onboarding relevance | % of first-run suggested prompts that are context-specific | 100% |
| Tenant isolation | Cross-tenant data visibility incidents in isolation testing | 0 |

## Definition of Done

- [ ] Every screen showing agent output has been mapped to a surface per the UX-001 decision table, recorded in the spec.
- [ ] Every tool call renders through the typed `<ToolCallCard>` component; no bespoke one-off tool UI exists (UX-005).
- [ ] Every grounded claim has a citation chip; confidence never renders as a bare percentage or color-only signal (UX-007, UX-008).
- [ ] Diff-first review, dry-run preview, and a visible Stop control are implemented for every risk-tiered tool call (UX-013, UX-015, UX-016).
- [ ] Streaming never force-autoscrolls; skeletons match final content shape; long tasks become trackable background jobs (UX-020, UX-021, UX-023).
- [ ] All five error/refusal/empty/partial-failure/hallucination states are implemented with named causes and next actions (UX-026).
- [ ] Every run is addressable, timelined, and artifact-paneled independently of chat scrollback (UX-032, UX-033).
- [ ] Feedback controls are reachable in 1 click from every AI output and linked to trace IDs (UX-041).
- [ ] Permission, cost, and audit-log surfaces are implemented for any enterprise/admin deployment (UX-045, UX-047, UX-050).
- [ ] All measurable UX quality criteria in the table above have been checked against the current build before client demo.
- [ ] Arabic/RTL pseudo-localization pass shows no clipping/overlap; approval and control surfaces meet WCAG 2.2 AA target sizes (UX-055, UX-056).

## Handoff notes

- Attach the surface decision table (UX-001) and the specific job type's journey artifacts (see [04 — Journey Design](./04-journey-design.md)) together — the UX layer implements the control-flow contract the journey layer defines.
- Name which risk tier each tool in the feature carries before asking Claude/Replit Agent to implement approval UI — UX-013 through UX-018 depend on that classification already existing.
- If the client is a regulated UAE/GCC entity, attach the [regulated-sector research brief](../../research/05-regulated.md) alongside this file so Arabic/RTL and WCAG 2.2 AA requirements are treated as ship-blocking, not phase-2.
- Specify explicitly which of the five HITL UI patterns (approval bar, diff view, dry-run, stop/steer, undo) apply to each mutating tool — do not leave this to be inferred from the tool's name.

## Sources

- [Google PAIR Guidebook — Patterns](https://pair.withgoogle.com/guidebook/patterns) — explainability, trust calibration, onboarding chapters
- [Guidelines for Human-AI Interaction (Microsoft HAX Toolkit)](https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/) — 18 evidence-based interaction guidelines
- [Guidelines for Human-AI Interaction, CHI 2019 (Microsoft Research)](https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/) — phase-based guideline structure
- [IBM Everyday Ethics for AI](https://www.ibm.com/watson/assets/duo/pdf/everydayethics.pdf) — transparency/privacy pillars for permission UI
- [Nielsen Norman Group — AI topic hub](https://www.nngroup.com/topic/ai/) — generative UI, outcome-oriented design
- [10 Guidelines for Designing Your Site's AI Chatbots (NN/g)](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/) — autoscroll, suggested prompts, single-entry-point findings
- [Generative UI and Outcome-Oriented Design (NN/g)](https://www.nngroup.com/articles/generative-ui/) — surface selection rationale
- [AI SDK UI Overview (Vercel)](https://sdk.vercel.ai/docs/ai-sdk-ui/overview) — `useChat`/`useObject` streaming patterns
- [Chatbot Tool Usage (Vercel AI SDK)](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage) — typed tool-part state model
- [Building Effective Agents (Anthropic)](https://www.anthropic.com/engineering/building-effective-agents) — checkpoint/transparency design principles
- [A Practical Guide to Building Agents (OpenAI)](https://openai.com/business/guides-and-resources/a-practical-guide-to-building-ai-agents/) — guardrails and stopping conditions
- [What's New in WCAG 2.2 (W3C WAI)](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) — target size, focus visibility, redundant entry criteria
- [ARIA19: Using role=alert or Live Regions to Identify Errors (W3C)](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19) — live-region announcement mechanics
- [Cursor Plan Mode](https://www.learncursor.dev/learn/cursor-agents/agent-plan-mode) — editable plan-before-execution pattern
- [Cursor Docs — Diffs & Review](https://docs.cursor.com/agent/review) — diff-first review pattern
- [AI Agents – Linear Docs](https://linear.app/docs/agents-in-linear) — delegation model, agent catalogue/directory
- [UX Teardown: Perplexity AI's Citations & Follow-Up Experience](https://assets.nextleap.app/submissions/UX_teardown-3a359c8e-53c8-4d93-8e85-f63f5ae18856.pdf) — citation-first design pattern
- [Designing Trust in AI Outputs: 7 UX Patterns for Uncertainty (Creative Alive)](https://creativealive.com/designing-trust-ai-outputs-ux-patterns-uncertainty/) — confidence label+color, undo discoverability
- [AI Agent Governance for Enterprises (Praesidia)](https://praesidia.ai/blog/ai-agent-governance-for-enterprises) — agent identity, roles, audit requirements
- [Using Human Annotations for Eval Driven Development (Arize)](https://arize.com/docs/phoenix/cookbook/human-in-the-loop-workflows-annotations/using-human-annotations-for-eval-driven-development) — feedback-to-eval pipeline
- [5 Challenges in Multilingual AI UX Design (DeveloperUX)](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/) — text-expansion, RTL budget
- [Creating a Skeleton UI Loading Animation (ProtoPie)](https://www.protopie.io/blog/how-to-create-a-skeleton-ui-loading-animation) — shape-matched skeletons
- [Regulated-sector readiness research brief](../../research/05-regulated.md) — WCAG 2.2 AA baseline and Arabic/RTL parity requirement for UAE government/citizen-facing surfaces
