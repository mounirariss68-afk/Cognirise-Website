---
id: tool-contracts
domain: Agent Architecture & Orchestration
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [spec, design, implementation, qa]
last_reviewed: 2026-07-27
---

# 08. Tool Contracts

> **Purpose.** Prevent unreliable tool use — wrong tool selection, silent failures, unbounded token spend, and double-executed side effects — by fixing naming, schema, error, idempotency, and risk-classification conventions for every tool an agent can call.
> **Read this when.** Designing or reviewing any tool/function the model can call; any integration with an internal API, external API, or MCP server.

## Scope
- In scope: tool naming, description writing, Zod schema design, idempotency, pagination, structured error returns, side-effect risk classification, tool budgets/rate limits, namespacing and catalogue registration, versioning, MCP-vs-in-process decision, and the canonical tool definition template.
- Out of scope: the orchestration pattern that calls the tool (prompt chaining, ReAct, etc.) — see [07 — Agent Architecture](./07-agent-architecture.md); approval workflows triggered by risk tier — see the HITL standard; guardrail-layer input/output validation not specific to tool contracts — see the guardrails standard (GRD).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Schema language | Zod, at every tool boundary | One source of truth for validation and the JSON Schema sent to the model; canonical stack requirement |
| Naming convention | `domain_noun_verb` (snake_case) | Prevents collisions, clusters related tools alphabetically |
| Free-form vs. enum | Enum for any closed set; never enum for free text, IDs, or arbitrary numbers | Forces the model into a decidable choice where one exists; avoids false constraints where it doesn't |
| Mutating tools | MUST accept an idempotency key | Retries under `07 — Agent Architecture` resilience defaults must never double-execute |
| Integration default | In-process/direct SDK tool registration | MCP is reserved for governance-at-scale or third-party consumption, not the default for a single app's own tools |
| Tool granularity | Decompose tools with 8+ parameters or multiple intents; bundle 3+ commonly co-occurring calls into one coarse workflow tool | Matches observed agent failure patterns around ambiguous, oversized tools |

## Rules

### Naming and description

**`TOOL-001` — Name every tool `domain_noun_verb` in snake_case** · `MUST`
Example: `invoice_reconciliation_create`, `ticket_status_update`, `customer_record_read`.
- *Why:* This convention prevents collisions across domains and lets alphabetical tool listings cluster related tools, aiding both human review and model disambiguation ([AWS Prescriptive Guidance on MCP strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf)).
- *How:* Lint tool registration code with a naming-convention check (regex `^[a-z]+(_[a-z]+)*_(create|read|update|delete|list|search)$` or domain-specific verb set).
- *Check:* CI fails if a registered tool name does not match the convention regex.

**`TOOL-002` — Write tool descriptions as prompts, not as API reference comments** · `MUST`
Every description states: what the tool does, *when* to use it, what parameters it takes with example real values, prerequisites/sequencing, authentication/authorization requirements, and error conditions.
- *Why:* "Tool descriptions as prompts" is the explicit framing in [AWS Prescriptive Guidance on MCP strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf); Anthropic notes "a common failure mode is bloated tool sets that cover too much functionality or create ambiguous decision points" and that "if a human engineer can't definitively say which tool should be used in a given situation, an AI agent can't be expected to do better" ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:*
```typescript
const invoiceReconciliationCreate = {
  description: `Creates a reconciliation record linking a bank transaction to an invoice.
Use this ONLY after confirming both the transaction and invoice exist and their amounts match within tolerance.
Do NOT use for partial matches — use invoice_reconciliation_flag_partial instead.
Requires the caller to hold the 'finance:write' permission scope.
Example: invoice_reconciliation_create({ invoiceId: "inv_8827", transactionId: "txn_1193", matchedAmountCents: 450000 })
Returns an error if the invoice is already reconciled (see error code ALREADY_RECONCILED) or if the amounts differ by more than 1 cent.`,
  // ...
};
```
- *Check:* Reviewer can answer "which tool applies here" for every pair of similarly-named tools using only the descriptions, with no ambiguity.

**`TOOL-003` — Prefer absolute identifiers over relative or ambiguous ones in every parameter** · `MUST`
Parameters representing files, records, or resources MUST use unambiguous, absolute identifiers (full paths, UUIDs, fully-qualified names) rather than relative or context-dependent references.
- *Why:* Forcing absolute file paths "eliminated a whole class of agent errors" in Anthropic's own SWE-bench tool work — a poka-yoke design principle applied to parameter design generally ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:* Reject relative paths/ambiguous names at the schema level (Zod `.refine()` checking for absolute-path shape or UUID format) rather than relying on the model to always supply the right form.
- *Check:* Unit test passes a relative path/ambiguous name to the schema and confirms validation fails before the tool body executes.

### Zod schema design

**`TOOL-004` — Define every tool's input and output as a Zod schema; this schema is the single source of truth** · `MUST`
The same schema validates runtime input, generates the JSON Schema sent to the model, and documents the contract — no separate hand-written JSON Schema may exist alongside it.
- *Why:* Canonical stack rule (`_CANON-CONVENTIONS.md` §2): "Zod at every boundary (tool args, API routes, LLM structured output, env)." A single source of truth eliminates drift between validation code and the schema the model sees.
- *How:*
```typescript
import { z } from "zod";
import { tool } from "ai";

const InvoiceReconciliationCreateInput = z.object({
  invoiceId: z.string().uuid().describe("UUID of the invoice, e.g. '8827c1e0-...'"),
  transactionId: z.string().uuid().describe("UUID of the bank transaction"),
  matchedAmountCents: z.number().int().positive().describe("Amount matched, in cents"),
  idempotencyKey: z.string().uuid().describe("Client-generated UUID; identical retries must reuse the same key"),
});

const InvoiceReconciliationCreateOutput = z.object({
  reconciliationId: z.string().uuid(),
  status: z.enum(["matched", "already_reconciled"]),
});

export const invoiceReconciliationCreate = tool({
  description: "Creates a reconciliation record linking a bank transaction to an invoice...",
  inputSchema: InvoiceReconciliationCreateInput,
  execute: async (input) => { /* ... */ },
});
```
- *Check:* `inputSchema.parse(malformedInput)` throws for every documented invalid case in the tool's test suite.

**`TOOL-005` — Always provide sensible defaults so the model is never forced to guess** · `MUST`
Optional parameters MUST specify a `.default()` in the schema; the description states what happens when the default is used.
- *Why:* Reduces ambiguous decision points and the chance the model invents a value ([AWS Prescriptive Guidance on MCP strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf)).
- *How:* `pageSize: z.number().int().min(1).max(100).default(20).describe("Rows per page; defaults to 20")`.
- *Check:* Calling the tool with the optional parameter omitted produces the documented default behavior in a test.

**`TOOL-006` — Use enums only for genuinely closed sets; never for free text, IDs, or arbitrary numbers** · `MUST` / `MUST NOT`
Use `z.enum([...])` for closed sets (status values, categories, risk tiers). Do not use enums to constrain free-form text, identifiers, or numeric ranges — use clear descriptions and examples instead.
- *Why:* Directly stated in the source research: "use enums for closed sets (never enums for free-form text, IDs, or arbitrary numbers — use clear descriptions/examples instead)."
- *How:* `status: z.enum(["pending", "approved", "rejected"])` is correct; `invoiceId: z.enum([...])` is incorrect — use `z.string().uuid()` with a description instead.
- *Check:* Schema review flags any enum whose value set would need to change when new data is added (a sign it should not be an enum).

### Idempotency, pagination, and token efficiency

**`TOOL-007` — Every mutating tool MUST accept and enforce an idempotency key** · `MUST`
Action tools that create, update, delete, refund, or send MUST accept an `idempotencyKey` parameter, backed by a Postgres unique constraint on `(tool_name, idempotency_key)`.
- *Why:* Retries under the resilience defaults in [07 — Agent Architecture](./07-agent-architecture.md) · AGT-022 must never double-execute a side effect.
- *How:*
```sql
CREATE TABLE executed_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tool_name TEXT NOT NULL,
  idempotency_key UUID NOT NULL,
  result JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tool_name, idempotency_key)
);
```
```typescript
async function executeIdempotent(toolName: string, idempotencyKey: string, fn: () => Promise<unknown>) {
  const existing = await db.query.executedActions.findFirst({
    where: (t, { and, eq }) => and(eq(t.toolName, toolName), eq(t.idempotencyKey, idempotencyKey)),
  });
  if (existing) return existing.result; // safe replay, no re-execution
  const result = await fn();
  await db.insert(executedActions).values({ toolName, idempotencyKey, result });
  return result;
}
```
- *Check:* Call the same tool twice with an identical idempotency key; confirm the underlying side effect (e.g., a row insert, an email send) occurs exactly once.

**`TOOL-008` — Classify every tool by side-effect tier: read, write, or irreversible** · `MUST`
Store `risk_tier` (`low | medium | high`) and a `side_effect` classification (`read | write | irreversible`) alongside every tool definition. Irreversible tools MUST default to requiring approval regardless of autonomy mode, unless explicitly whitelisted per the HITL standard.
- *Why:* "Encode the 'line of agency' directly in code as a per-tool `risk_tier` attribute... high-risk tools require a checkpoint row inserted into a `pending_approvals` Postgres table before execution" (source research, Part A.2); OpenAI's taxonomy of data/action/orchestration tools maps directly onto read/write/irreversible ([OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- *How:*
```typescript
export const toolRegistry = {
  invoice_record_read: { sideEffect: "read", riskTier: "low" },
  invoice_reconciliation_create: { sideEffect: "write", riskTier: "medium" },
  refund_issue: { sideEffect: "irreversible", riskTier: "high" },
} as const;
```
- *Check:* Every tool in the catalogue (`TOOL-012`) has a non-null `sideEffect` and `riskTier`; CI fails registration of an unclassified tool.

**`TOOL-009` — Cap default page size and return an explicit cursor; never return unbounded lists** · `MUST`
Paginated data tools return a small default page (studio default: 20 rows) plus a `next_cursor` field. The model may never request "all rows" without an explicit, tool-enforced upper bound.
- *Why:* Controls token spend and prevents a single tool call from flooding the context window (source research, tool design best practices).
- *How:*
```typescript
const ListInvoicesInput = z.object({
  cursor: z.string().optional().describe("Opaque pagination cursor from a prior call's next_cursor"),
  pageSize: z.number().int().min(1).max(50).default(20),
});
const ListInvoicesOutput = z.object({
  invoices: z.array(InvoiceSummary),
  nextCursor: z.string().nullable(),
});
```
- *Check:* Attempt to request `pageSize: 10000`; confirm the schema clamps or rejects it rather than the tool executing an unbounded query.

**`TOOL-010` — Return only what the model needs for its next decision; summarize, do not dump records** · `MUST`
Tool outputs MUST exclude fields irrelevant to the calling context; large payloads MUST be summarized or truncated with an explicit note on what was omitted.
- *Why:* Token-efficient returns are named directly in the source research as a required tool design property, and align with the context-engineering principle of "the smallest possible set of high-signal tokens" ([Anthropic, Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).
- *How:* Define a narrow `OutputSchema` distinct from the full database row shape; project only needed fields in the query itself, not in application code after fetching everything.
- *Check:* Compare average tool-output token count in traces against a target ceiling per tool (documented in the tool's spec entry); flag outliers in the observability review.

### Structured error returns

**`TOOL-011` — Every tool error is a structured, schema-validated object that teaches the model how to recover** · `MUST`
Errors MUST NOT be raw exceptions or unstructured strings surfaced to the model. Every error includes: a stable `code` (enum), a human-readable `message`, and a `recoverySuggestion` field telling the model what to try next.
- *Why:* "Make errors part of the contract, not an afterthought — document error conditions in the tool description itself so the model can self-correct" (source research, tool design best practices).
- *How:*
```typescript
const ToolErrorSchema = z.object({
  code: z.enum(["ALREADY_RECONCILED", "AMOUNT_MISMATCH", "NOT_FOUND", "PERMISSION_DENIED", "RATE_LIMITED"]),
  message: z.string(),
  recoverySuggestion: z.string(),
});

// inside execute():
if (invoice.status === "reconciled") {
  return {
    error: {
      code: "ALREADY_RECONCILED" as const,
      message: `Invoice ${input.invoiceId} is already reconciled.`,
      recoverySuggestion: "Call invoice_record_read to check current status before retrying, or use invoice_reconciliation_get to fetch the existing reconciliation.",
    },
  };
}
```
- *Check:* Every `code` enum value referenced in the tool description appears in a test case that triggers it and asserts the `recoverySuggestion` is present and non-empty.

**`TOOL-012` — Register every tool, its schema, risk tier, and version in a single catalogue** · `MUST`
Maintain one `tool-catalogue.ts` (or equivalent) file per app that imports and re-exports every tool with its namespace, version, and risk classification — no tool may be registered with the model SDK without appearing in this catalogue.
- *Why:* Prevents duplicated, undocumented, or unreviewed tools accumulating ad hoc across a codebase — directly extends the "minimal, non-overlapping tool set" principle to a governance mechanism ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- *How:*
```typescript
// lib/tools/tool-catalogue.ts
export const toolCatalogue = {
  "invoice.reconciliation.create": { tool: invoiceReconciliationCreate, version: "1.2.0", riskTier: "medium", sideEffect: "write" },
  "invoice.record.read": { tool: invoiceRecordRead, version: "1.0.0", riskTier: "low", sideEffect: "read" },
  "refund.issue": { tool: refundIssue, version: "2.0.0", riskTier: "high", sideEffect: "irreversible" },
} as const;
```
- *Check:* A CI script diffs the set of tools passed to the model SDK against `Object.keys(toolCatalogue)`; any mismatch fails the build.

### MCP vs. in-process; versioning

**`TOOL-013` — Default to in-process/direct SDK tool registration; adopt MCP only under specific triggers** · `MUST` / `SHOULD NOT`
Do not stand up an MCP server for a single app's own first-party tools. Adopt MCP when: centralized governance over multiple enterprise/external systems is required, developers are duplicating custom integrations across projects, or the studio needs to expose its own tools to external agent consumers through a governed interface. Prefer existing, well-maintained MCP servers over building custom ones.
- *Why:* "In many cases, pre-existing MCP servers are sufficient... custom servers are reserved for specialized functionality, domain expertise, or compliance needs" ([AWS Prescriptive Guidance on MCP strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf)). Running an MCP server adds operational surface area with no benefit for a single-container Replit deployment talking to its own database.
- *How:* For a single Replit app with first-party tools, register tools directly with the Vercel AI SDK's `tool()` function. Only run an MCP *client* inside the existing process when consuming a third-party vendor's published MCP server (e.g., GitHub, Slack); only host an MCP *server* when external agent consumers must call the studio's own tools.
- *Check:* Spec review confirms an MCP server is proposed only when one of the three named triggers is documented; otherwise in-process registration is mandatory.

**`TOOL-014` — Version every tool with semantic versioning; breaking changes require a new major version and a migration note** · `MUST`
Tool schema changes that remove/rename a required field, change a type, or alter behavior in a way that breaks existing prompts require a major version bump. Additive, backward-compatible changes (new optional field, new enum value) are minor.
- *Why:* "Treat prompts as code artifacts: version-controlled, reviewed, diffable" extends directly to tool schemas — both are consequential, agent-facing contracts that need bisectable history (source research, F5 Versioning & Change Control).
- *How:* Record version in the tool catalogue (`TOOL-012`); maintain a `CHANGELOG.md` per tool namespace noting the version, date, and nature of the change; run the eval suite against both old and new prompt/tool versions before removing the old one.
- *Check:* `git log` on the tool's schema file shows a version bump commit for every schema change; the changelog entry exists for each bump.

### Tool budgets, rate limits, and granularity

**`TOOL-015` — Enforce per-run and per-tool call budgets** · `MUST`
Cap the number of times a single tool may be called within one run (studio default: 10 calls per tool per run, escalate on breach) independent of the overall step cap in [07 — Agent Architecture](./07-agent-architecture.md) · AGT-022.
- *Why:* Prevents a single tool from silently consuming the entire step/token budget through repeated legitimate-looking calls that never converge.
- *How:* Increment a per-tool counter on the `runs` row (or a `run_tool_calls` join table); check before each invocation.
- *Check:* Force a test scenario where a tool is called 11 times in one run; confirm the 11th call is blocked and the run escalates.

**`TOOL-016` — Implement a token-bucket rate limiter for every external API-backed tool; honor `Retry-After`** · `MUST`
- *Why:* Prevents provider-side 429s from cascading into retry storms; named directly in the source research resilience section.
- *How:* Wrap external HTTP-backed tools in a token-bucket limiter keyed by provider; on a 429 response, read `Retry-After` and delay the next attempt accordingly rather than using the default backoff schedule.
- *Check:* Fault-inject a 429 with `Retry-After: 5` and confirm the next attempt is delayed by at least 5 seconds, not the default backoff value.

**`TOOL-017` — Decompose tools with 8+ parameters or multiple distinct intents; separate read and write into different tools** · `MUST`
Bundle 3+ commonly co-occurring API calls into a single coarse-grained workflow tool rather than forcing the model to chain many granular calls itself.
- *Why:* Directly stated in [AWS Prescriptive Guidance on MCP strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf); OpenAI's guide confirms splitting across tools (or agents) is the recommended lever as tool complexity grows ([OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- *How:* Count parameters at schema-review time; any tool exceeding 8 top-level parameters or handling more than one verb (e.g., "get-or-create") must be split. Conversely, if the agent chains `get_customer` → `get_orders` → `get_invoices` in nearly every run, bundle into `customer_full_context_read`.
- *Check:* Schema linter flags tools with 8+ parameters; trace review over the last 100 runs identifies any 3+-call sequence occurring in over 80% of runs as a bundling candidate.

## Reference implementation

Canonical tool definition template (copy for every new tool):
```typescript
// tools/<domain>/<noun>-<verb>.ts
import { tool } from "ai";
import { z } from "zod";
import { db } from "@/lib/db";
import { executeIdempotent } from "@/lib/tools/idempotency";

export const InputSchema = z.object({
  // ... typed, described, defaulted parameters
  idempotencyKey: z.string().uuid().describe("Required for any write/irreversible tool"),
});

export const OutputSchema = z.union([
  z.object({ success: z.literal(true), data: z.object({ /* narrow, token-efficient shape */ }) }),
  z.object({
    success: z.literal(false),
    error: z.object({
      code: z.enum([/* stable error codes */]),
      message: z.string(),
      recoverySuggestion: z.string(),
    }),
  }),
]);

export const meta = {
  namespace: "domain.noun.verb",
  version: "1.0.0",
  sideEffect: "write" as const, // read | write | irreversible
  riskTier: "medium" as const,  // low | medium | high
  maxCallsPerRun: 10,
};

export const domainNounVerb = tool({
  description: `
    What this tool does.
    When to use it (and when NOT to — name the alternative tool).
    Example call: domainNounVerb({ ... real example values ... })
    Prerequisites/sequencing: what must be true/called first.
    Auth: required permission scope.
    Errors: list each error code and what it means.
  `,
  inputSchema: InputSchema,
  execute: async (input) => executeIdempotent(meta.namespace, input.idempotencyKey, async () => {
    // deterministic validation, then the side effect, then return OutputSchema-shaped data
  }),
});
```

Tool catalogue entry point:
```typescript
// lib/tools/tool-catalogue.ts
import { domainNounVerb, meta as domainNounVerbMeta } from "@/tools/domain/noun-verb";

export const toolCatalogue = {
  [domainNounVerbMeta.namespace]: { tool: domainNounVerb, ...domainNounVerbMeta },
  // one entry per tool, no exceptions
} as const;
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| Tool description written like an API reference ("Creates a record.") | Gives the model no guidance on *when* to use it vs. similar tools | Write as a prompt: purpose, when-to-use, example call, prerequisites, errors (`TOOL-002`) |
| Enum used to constrain an ID or free-text field | Breaks the moment new data appears; forces schema edits for data changes | Use `z.string()` with format validation and a description (`TOOL-006`) |
| Mutating tool with no idempotency key | A retry after a timeout double-executes the side effect | Require `idempotencyKey` + unique constraint (`TOOL-007`) |
| Returning full database rows from a list tool | Floods the context window, wastes tokens, slows every downstream decision | Return a narrow, summarized `OutputSchema` with pagination (`TOOL-009`, `TOOL-010`) |
| Raising a raw exception string as a tool error | Model cannot parse or act on it, often retries blindly | Structured `{code, message, recoverySuggestion}` error object (`TOOL-011`) |
| Building an MCP server for a single app's own tools | Adds a protocol/transport layer and a process to operate for no governance benefit | Register tools directly with the model SDK (`TOOL-013`) |
| A 12-parameter tool that both creates and updates depending on a flag | Ambiguous decision point; the model cannot reliably choose the right mode | Split into two named tools, each under 8 parameters (`TOOL-017`) |

## Definition of Done

- [ ] Every tool name matches the `domain_noun_verb` convention (`TOOL-001`).
- [ ] Every tool description includes purpose, when-to-use, example call, prerequisites, auth, and error conditions (`TOOL-002`).
- [ ] Every tool has a Zod input and output schema with no parallel hand-written JSON Schema (`TOOL-004`).
- [ ] No enum is used for a free-text, ID, or arbitrary-numeric field (`TOOL-006`).
- [ ] Every mutating tool accepts and enforces an idempotency key against a unique constraint (`TOOL-007`).
- [ ] Every tool is classified with a `sideEffect` and `riskTier` in the catalogue (`TOOL-008`).
- [ ] Every paginated tool caps default page size and returns a cursor (`TOOL-009`).
- [ ] Every tool error is a structured object with `code`, `message`, `recoverySuggestion` (`TOOL-011`).
- [ ] Every tool appears in the single tool catalogue with a version (`TOOL-012`, `TOOL-014`).
- [ ] No tool exceeds 8 parameters or handles multiple intents without a documented exception (`TOOL-017`).
- [ ] MCP is used only where one of the three named triggers is documented (`TOOL-013`).

## Handoff notes

- Paste the canonical tool definition template verbatim into the implementation prompt so Claude generates every tool against the same shape.
- Attach the tool catalogue file and its current contents so new tools are added, not duplicated under a slightly different name.
- State explicitly which tools are `irreversible` risk tier so the HITL approval gating is wired correctly before first run.
- If MCP is in scope for this project, name which of the three triggers (`TOOL-013`) applies — do not let Replit Agent default to standing up a server "for consistency."

## Sources

- [AWS Prescriptive Guidance, Model Context Protocol (MCP) strategies (PDF)](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf) — naming, description-as-prompt, granularity, MCP adoption triggers
- [Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents) — minimal non-overlapping tool set, poka-yoke absolute-path design, bloated-tool-set failure mode
- [Anthropic, Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents) — token-efficient return rationale
- [OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) — data/action/orchestration tool taxonomy, split-when-overloaded guidance
