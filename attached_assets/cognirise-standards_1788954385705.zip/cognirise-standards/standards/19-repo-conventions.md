---
id: repo-conventions
domain: Engineering, Repo & Delivery Conventions
version: 1.0
status: canonical
owner: Cognirise Delivery
applies_to: [spec, implementation, qa]
last_reviewed: 2026-07-27
---

# 19. Repository & Stack Conventions

> **Purpose.** Guarantee every client repo has an identical, predictable shape so Claude, Replit Agent, and any engineer can be productive on day one without rediscovering structure.
> **Read this when.** Project scaffolding, spec-to-code handoff, PR review, engineer onboarding to an existing client repo.

## Scope

- In scope: folder tree, naming conventions, TypeScript strictness, the `CLAUDE.md`/`AGENTS.md` contract, docs/specs/evals layout, environment variable schema, commit/branch conventions, PR template and AI-generated-code review rules, dependency/abstraction discipline, code ownership, and the spec-traceability rejection rule.
- Out of scope: agent architecture/orchestration choices (see [07 — Agent Architecture](./07-agent-architecture.md)), Replit deployment specifics (see [20 — Replit & Deployment](./20-replit-deployment.md)), eval harness internals (see [15 — Evaluation](./15-evaluation.md)), spec content/taxonomy itself (see [03 — Specification](./03-specification.md)).

## Core decisions

| Decision | Default | Why |
|---|---|---|
| Language | TypeScript, `strict: true` everywhere | Canonical stack; Python sidecar only for ML/parsing libs with no TS equivalent |
| Contract files | Both `CLAUDE.md` and `AGENTS.md` required in every repo root | Two of the three reader personas (Claude, Replit Agent) consume these directly |
| Env var validation | Zod schema at `env.ts`, imported everywhere `process.env` is touched | Fails fast on missing/malformed config instead of at runtime deep in a request |
| Spec-to-code traceability | No merged code without a referenced spec section | Prevents undocumented, unreviewable AI-generated behavior |
| Dependency default | Prefer AI SDK + existing canonical stack over adding a new framework | Reduces abstraction layers the client's future engineers must learn (see [F4 in 01-standards-areas.md]) |
| Ownership | Every top-level folder has a named owner in `CODEOWNERS` | AI-generated code still needs a human accountable for review |

## Rules

### Folder tree and naming

**`REPO-001` — Use the canonical top-level folder tree for every client repo** · `MUST`
Scaffold every new repo with the exact structure in the Reference implementation below; do not invent an alternate top-level layout per client.
- *Why:* Consistent structure lets any engineer or agent navigate an unfamiliar client repo immediately.
- *How:* Copy from the studio's repo template repository at project kickoff.
- *Check:* A `scripts/verify-structure.sh` check (or CI job) diffs the repo's top-level folders against the canonical list and fails on drift.

**`REPO-002` — Name files and folders in kebab-case; name React components in PascalCase; name functions/variables in camelCase** · `MUST`
Apply kebab-case to file/folder names (`agent-runner.ts`, `tool-contracts/`), PascalCase to component files and exported component names (`ApprovalGate.tsx`), camelCase to functions/variables/hooks (`useAgentRun`).
- *Why:* Consistent naming lets generated code from Claude and Replit Agent be visually distinguished from misnamed drift at a glance.
- *How:* Enforce via ESLint `unicorn/filename-case` plus a Prettier config committed to the repo.
- *Check:* Lint CI job fails on any filename or identifier violating the case convention.

**`REPO-003` — Route-level Next.js files follow App Router conventions exactly; no legacy Pages Router files** · `MUST`
Use `app/` directory routing exclusively (`page.tsx`, `layout.tsx`, `route.ts`), never `pages/`.
- *Why:* Canonical stack mandates Next.js App Router; mixing routers creates two mental models in one repo.
- *How:* `.eslintrc` rule or a pre-commit check blocking any new file under `pages/`.
- *Check:* CI grep confirms no `pages/` directory exists outside a documented legacy-migration exception.

### TypeScript strictness

**`REPO-004` — Enable `strict: true` and ban `any` without an explicit suppression comment** · `MUST`
Set `"strict": true` in every `tsconfig.json`; any use of `any` requires an inline `// eslint-disable-next-line @typescript-eslint/no-explicit-any -- <reason>` comment.
- *Why:* AI-generated code defaults to loose typing under time pressure; strictness catches contract mismatches between spec and implementation early.
- *How:* Base `tsconfig.json` template ships with `strict`, `noUncheckedIndexedAccess`, and `exactOptionalPropertyTypes` all set to `true`.
- *Check:* `tsc --noEmit` runs clean in CI; ESLint fails on unsuppressed `any`.

**`REPO-005` — Validate every external boundary with Zod, never with a bare TypeScript type assertion** · `MUST`
Parse all API route inputs, tool-call arguments, LLM structured outputs, and environment variables through a Zod schema before use; never `as SomeType` cast untrusted data.
- *Why:* TypeScript types are erased at runtime; only runtime validation catches malformed data from an LLM, a client request, or a misconfigured environment.
- *How:* Co-locate a `*.schema.ts` file next to every API route/tool definition; import the inferred type via `z.infer<typeof schema>`.
- *Check:* Code review rejects any PR introducing an `as` cast on data crossing a network, LLM, or environment boundary without an accompanying Zod parse.

### The CLAUDE.md and AGENTS.md contract

**`REPO-006` — Every repo root MUST contain both `CLAUDE.md` and `AGENTS.md`** · `MUST`
Ship both files at repo root from the first commit; keep them synchronized in substance (they may differ in tool-specific syntax but not in the rules they state).
- *Why:* Claude Code and Replit Agent (and other AGENTS.md-compatible tools) are both readers per the studio's audience model; omitting either degrades that tool's output quality.
- *How:* Generate both from a single source template at scaffold time; treat divergence between them as a lint failure.
- *Check:* A CI script diffs the rule content of both files (ignoring tool-specific frontmatter) and fails on semantic divergence.

**`REPO-007` — `CLAUDE.md`/`AGENTS.md` MUST contain only what the agent cannot infer from reading the code** · `MUST`
Include: bash commands the agent can't guess, style rules that differ from language/framework defaults, testing instructions and preferred runners, repo etiquette (branch naming, PR conventions), project-specific architectural decisions, required environment variables and where they're documented, and known gotchas. Exclude: anything inferable from reading the code, standard-language tutorials, frequently-changing information, and generic "write clean code" platitudes.
- *Why:* Bloated, low-signal contract files cause the agent to ignore the real instructions buried inside them.
- *How:* Apply the "would removing this line cause the agent to make a mistake?" test to every line before merging an edit to either file.
- *Check:* Reviewer runs the removal test on any PR that adds more than 5 lines to either file.

**`REPO-008` — Compose shared fragments via `@path/to/import`, not copy-paste, across multiple `CLAUDE.md` files** · `SHOULD`
When a studio-wide convention (e.g., git etiquette) applies unchanged across projects, reference it via import syntax rather than duplicating the text in every repo.
- *Why:* Prevents drift where one repo's copy of a shared rule goes stale relative to the studio-wide original.
- *How:* `@docs/git-instructions.md` import at the top of the project's `CLAUDE.md`, resolved by Claude Code's file-composition support.
- *Check:* Grep for duplicated multi-line blocks across `CLAUDE.md` files in the studio's repo fleet; flag exact-duplicate blocks longer than 5 lines as import candidates.

**`REPO-009` — Keep personal/local notes out of the committed contract files** · `MUST NOT`
Do not commit individual engineer preferences or session-specific scratch notes into `CLAUDE.md`/`AGENTS.md`; use a `.gitignore`d `CLAUDE.local.md` instead.
- *Why:* Keeps the shared contract file authoritative and reviewable, separate from personal working notes.
- *How:* `.gitignore` includes `CLAUDE.local.md` from repo scaffold time.
- *Check:* Pre-commit hook blocks any commit touching a filename matching `*.local.md`.

### Docs, specs, and evals layout

**`REPO-010` — Store specs under `docs/specs/`, one file per traceable unit, named with a stable ID** · `MUST`
Place every functional/technical spec under `docs/specs/<spec-id>-<slug>.md` (e.g., `docs/specs/SPEC-003-agent-escalation.md`); do not scatter specs in READMEs or chat history.
- *Why:* Traceability from requirement to code to test depends on a stable, discoverable spec ID (see [03 — Specification](./03-specification.md)).
- *How:* Spec IDs assigned sequentially per project at brief-approval time.
- *Check:* Every PR description references at least one `docs/specs/` file by ID (see REPO-018).

**`REPO-011` — Store eval datasets and reports under `evals/`, separated from application code** · `MUST`
Place eval datasets in `evals/datasets/`, eval run configs in `evals/config/`, and generated reports in `evals/reports/` (gitignored except for the latest baseline).
- *Why:* Keeps the eval harness (see [15 — Evaluation](./15-evaluation.md)) portable and reviewable independent of application code changes.
- *How:* `promptfoo` and Vitest eval configs both resolve dataset paths relative to `evals/datasets/`.
- *Check:* CI job confirms no eval dataset file exists outside `evals/`.

**`REPO-012` — Store compliance artifacts under `docs/compliance/`** · `MUST`
Keep the data-classification statement, model/system card, subprocessor register, DPIA/AIA draft, and risk register (see [17 — Data Governance & Compliance](./17-data-governance-compliance.md)) together under `docs/compliance/`.
- *Why:* A single, predictable location for the artifacts a client compliance reviewer or auditor will ask for.
- *How:* Scaffold template includes empty placeholder files at project creation.
- *Check:* Handover checklist (see [22 — Handover & IP](./22-handover-ip.md)) verifies all required files exist in this folder before delivery.

### Environment variables

**`REPO-013` — Validate all environment variables through a single Zod schema at `env.ts`** · `MUST`
Define one `envSchema` covering every environment variable the app uses; import the parsed, typed `env` object everywhere instead of reading `process.env` directly.
- *Why:* Centralizes validation, gives a single fail-fast error at boot instead of a runtime crash mid-request, and self-documents required configuration.
- *How:* See Reference implementation below; call `envSchema.parse(process.env)` once at app startup (or via Next.js instrumentation hook).
- *Check:* ESLint custom rule (or grep) bans direct `process.env.X` access outside `env.ts`.

**`REPO-014` — Document every environment variable's purpose and required/optional status in `.env.example`** · `MUST`
Maintain a `.env.example` with every variable name, a one-line comment on purpose, and whether it is required or optional — never real values.
- *Why:* This is the environment-variable inventory referenced in the handover pack and portability checklist (see [20 — Replit & Deployment](./20-replit-deployment.md)).
- *How:* Generate `.env.example` keys from the Zod schema's key list to prevent drift.
- *Check:* CI script confirms every key in `envSchema` has a corresponding line in `.env.example`.

### Commit, branch, and PR conventions

**`REPO-015` — Use Conventional Commits for every commit message** · `MUST`
Format commits as `<type>(<scope>): <description>` (`feat`, `fix`, `docs`, `refactor`, `test`, `chore`); scope names a top-level folder or spec ID.
- *Why:* Enables automated changelog generation and makes AI-generated commit history scannable during review.
- *How:* `commitlint` with the conventional-commits config, enforced via a pre-commit hook.
- *Check:* CI commit-lint job rejects non-conforming messages on PR branches.

**`REPO-016` — Name branches `<type>/<spec-id>-<slug>`** · `MUST`
Use the pattern `feat/SPEC-003-agent-escalation` or `fix/SPEC-011-citation-render`; never generic branch names like `update` or `wip`.
- *Why:* Ties every branch back to a traceable spec unit (REPO-010) from the branch name alone.
- *How:* Document in `CLAUDE.md`/`AGENTS.md` under repo etiquette so agents name branches correctly when creating them.
- *Check:* Branch-protection rule or CI check on PR open validates the branch name pattern.

**`REPO-017` — Every PR uses the studio PR template and completes all required sections** · `MUST`
Fill in: spec section(s) referenced, summary of change, eval suite run and result delta, screenshots/recording for UI changes, and a manual test checklist.
- *Why:* Standardizes what a human reviewer checks regardless of who (or what) authored the diff.
- *How:* `.github/pull_request_template.md` committed at repo scaffold; CI blocks merge if required sections are empty.
- *Check:* PR-template-completeness bot comments and blocks merge on any unchecked required section.

**`REPO-018` — Reject any PR whose changed code has no corresponding spec section reference** · `MUST`
Every PR must cite at least one `docs/specs/<spec-id>` file justifying the change; PRs introducing new agent behavior, tool, or UI surface with no spec reference are rejected outright.
- *Why:* This is the studio's core traceability guarantee — undocumented AI-generated behavior is unreviewable and unmaintainable.
- *How:* PR template (REPO-017) has a mandatory "Spec reference" field; CI checks the field is non-empty and matches an existing file under `docs/specs/`.
- *Check:* CI job fails the PR if the spec-reference field is empty or references a non-existent file.

**`REPO-019` — Every PR containing AI-generated code discloses which tool generated it and under which model** · `MUST`
Note in the PR description whether Claude, Replit Agent, or a human authored each meaningfully-sized diff hunk, and which model version if known.
- *Why:* Supports the provenance record required by the IP/licensing standard (see [22 — Handover & IP](./22-handover-ip.md)) and helps reviewers calibrate scrutiny.
- *How:* PR template field: "Generated by: [Claude / Replit Agent / human] — model: [...]".
- *Check:* Reviewer confirms the field is filled before approving.

**`REPO-020` — Require at least one human review approval before merge to the default branch; AI-authored review does not count** · `MUST`
Configure branch protection so a human reviewer (not an AI reviewer bot alone) must approve every PR before merge.
- *Why:* Keeps a human accountable for every change reaching the default branch, consistent with the human-accountability principle in [17 — Data Governance & Compliance](./17-data-governance-compliance.md).
- *How:* GitHub/GitLab branch protection rule requiring 1 human CODEOWNERS approval.
- *Check:* Branch protection settings audit confirms the rule is active and cannot be bypassed by the PR author.

### Dependency policy and abstraction discipline

**`REPO-021` — Do not add a new framework or library where the canonical stack (notably the AI SDK) already suffices** · `MUST NOT`
Reject any dependency addition that duplicates functionality already provided by the canonical stack (Vercel AI SDK, Drizzle, next-intl, etc.) without a documented escape-hatch justification.
- *Why:* Every extra framework is an abstraction the client's future engineering team must also learn; canonical-stack discipline keeps handover legible (see [22 — Handover & IP](./22-handover-ip.md)).
- *How:* Any new dependency addition to `package.json` requires a one-line justification comment in the PR description referencing why the canonical stack does not cover the need.
- *Check:* Reviewer rejects a PR adding a new agent-orchestration, state-management, or streaming library without an explicit escape-hatch note citing the canonical stack table in `_CANON-CONVENTIONS.md`.

**`REPO-022` — Run a dependency license check before introducing any new package** · `MUST`
Verify the license of any new dependency (including transitive ones with independent risk, e.g., GPL) is compatible with client delivery before merging.
- *Why:* Prevents shipping a client a copyleft-licensed dependency that conflicts with their commercial distribution plans.
- *How:* `license-checker` (or equivalent) run in CI against an allowlist (MIT, Apache-2.0, BSD, ISC) and a denylist (GPL, AGPL) unless explicitly waived.
- *Check:* CI license-check job fails the build on a denylisted license without a recorded waiver.

**`REPO-023` — Reduce abstraction layers as the project matures toward handover** · `SHOULD`
Run an "abstraction audit" before final handover: remove any framework/wrapper introduced for prototyping speed that is no longer earning its complexity cost.
- *Why:* Final delivered code should be maximally legible to the client's own future engineers, many of whom will not use the studio's framework of choice.
- *How:* Checklist item in the handover Definition of Done (see [22 — Handover & IP](./22-handover-ip.md)).
- *Check:* Handover reviewer confirms the abstraction audit was run and documented.

### Code ownership

**`REPO-024` — Maintain a `CODEOWNERS` file mapping every top-level folder to a named owner** · `MUST`
Assign an individual (not a team alias) as owner for each of `app/`, `lib/`, `docs/`, `evals/`, `db/`, and any client-specific top-level folder.
- *Why:* AI-generated code still requires a human accountable for its correctness and maintenance, consistent with the named-accountable-owner principle in [17 — Data Governance & Compliance](./17-data-governance-compliance.md).
- *How:* `.github/CODEOWNERS` file generated at project scaffold and updated whenever ownership changes.
- *Check:* CI validates every top-level folder has a matching `CODEOWNERS` entry.

## Reference implementation

```text
client-project/
├── .github/
│   ├── CODEOWNERS
│   ├── pull_request_template.md
│   └── workflows/ci.yml
├── app/                        # Next.js App Router
│   ├── [locale]/
│   │   ├── layout.tsx
│   │   └── page.tsx
│   └── api/
├── lib/
│   ├── agents/                 # agent definitions, tool contracts
│   ├── db/                     # Drizzle schema, migrations
│   ├── guardrails/
│   └── observability/
├── components/
│   └── ui/                     # shadcn/ui-based shared components
├── docs/
│   ├── specs/                  # SPEC-001-*.md, traceable spec units
│   ├── compliance/             # model card, DPIA, risk register, subprocessors
│   └── runbooks/
├── evals/
│   ├── datasets/
│   ├── config/
│   └── reports/
├── db/
│   └── drizzle/
├── CLAUDE.md
├── AGENTS.md
├── env.ts
├── .env.example
├── tsconfig.json
├── package.json
└── README.md
```

```typescript
// env.ts — REPO-013
import { z } from "zod";

const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  ANTHROPIC_API_KEY: z.string().min(1),
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  NEXT_PUBLIC_APP_LOCALE_DEFAULT: z.enum(["en", "ar"]).default("en"),
});

export const env = envSchema.parse(process.env);
export type Env = z.infer<typeof envSchema>;
```

```markdown
<!-- .github/pull_request_template.md — REPO-017/018/019 -->
## Spec reference
<!-- REQUIRED: link to docs/specs/SPEC-###-slug.md -->

## Summary


## Generated by
<!-- Claude / Replit Agent / human — model version if known -->

## Eval suite run and result
<!-- promptfoo/Vitest run output or "N/A — no agent-behavior change" -->

## Manual test checklist
- [ ] Ran locally against the acceptance criteria in the referenced spec
- [ ] Accessibility spot-check (if UI changed)
- [ ] No hardcoded secrets introduced
```

```markdown
<!-- CODEOWNERS -->
/app/            @lead-engineer
/lib/agents/     @agent-architect
/lib/db/         @lead-engineer
/docs/compliance/ @delivery-lead
/evals/          @qa-lead
```

## Anti-patterns

| Anti-pattern | Why it fails | Do this instead |
|---|---|---|
| One giant `CLAUDE.md` with every possible instruction | Bloat causes the agent to ignore real instructions | Apply the removal test; import shared fragments (REPO-007/008) |
| Reading `process.env.X` inline across the codebase | No single point of validation; runtime crashes on missing config | Central `env.ts` with Zod schema (REPO-013) |
| Merging AI-generated code with no spec reference | Unreviewable, unmaintainable, untraceable behavior | Reject at PR gate (REPO-018) |
| Adding LangGraph/Redux/a new state library "just in case" | Extra abstraction the client's team must also learn | Canonical stack first; escape hatch requires documented trigger (REPO-021) |
| `pages/` and `app/` directories coexisting | Two routing mental models in one repo | App Router only (REPO-003) |
| Personal preferences committed into `CLAUDE.md` | Pollutes the shared contract file for the whole team | `.gitignore`d `CLAUDE.local.md` (REPO-009) |

## Definition of Done

- [ ] Repo structure matches the canonical tree; `verify-structure.sh` passes (REPO-001).
- [ ] `tsc --noEmit` and lint pass with `strict: true` and zero unsuppressed `any` (REPO-004).
- [ ] Both `CLAUDE.md` and `AGENTS.md` exist, pass the removal test, and are semantically synchronized (REPO-006/007).
- [ ] `env.ts` Zod schema exists; `.env.example` key-complete against it (REPO-013/014).
- [ ] `CODEOWNERS` covers every top-level folder (REPO-024).
- [ ] Commit-lint and branch-name CI checks are active (REPO-015/016).
- [ ] PR template enforced with spec-reference and generated-by fields required (REPO-017/018/019).
- [ ] Branch protection requires ≥1 human approval (REPO-020).
- [ ] Dependency license-check CI job active with allow/deny lists (REPO-022).

## Handoff notes

- Paste this file's Reference implementation folder tree verbatim into the first Claude Code session scaffolding a new client repo.
- Give Replit Agent the `env.ts` schema and `.env.example` before asking it to wire any new integration, so it never invents an ungoverned `process.env` read.
- When reviewing a Replit-Agent-authored PR, check the "Generated by" and "Spec reference" fields first — reject immediately if either is missing.
- Cross-reference [17 — Data Governance & Compliance](./17-data-governance-compliance.md) GOV-016/017 when scaffolding `docs/compliance/`.

## Sources

- `_CANON-CONVENTIONS.md` — canonical stack table (TypeScript strict, Next.js App Router, Zod, Drizzle, AI SDK) is the binding baseline this file extends into concrete repo rules.
