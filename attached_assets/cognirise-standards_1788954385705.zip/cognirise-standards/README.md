# Cognirise Delivery Canon

Version 1.0 · 27 July 2026 · Owner: Cognirise Delivery

The canonical standards, templates and prompts for designing and building agentic apps and platforms for Cognirise clients — government departments, banks, telcos and B2B enterprises in the UAE and GCC.

**These files are context, not documentation.** They are written to be attached to Claude and Replit Agent, not read once and forgotten. A standard nobody pastes into a model is decoration.

---

## Start here

| If you are… | Read |
|---|---|
| Deciding whether to adopt this | [Standards proposal](./proposal/00-STANDARDS-PROPOSAL.md) |
| Starting a new engagement | [01 — Delivery Lifecycle](./standards/01-delivery-lifecycle.md), then the Stage 0 template |
| Writing a research brief | [02 — Research Brief](./standards/02-research-brief.md) + [Prompt 01](./prompts/01-perplexity-research-brief.md) |
| Writing specs with Claude | [03 — Specification](./standards/03-specification.md) + [Prompt 02](./prompts/02-claude-specification.md) |
| Designing the product | [04](./standards/04-journey-design.md), [05](./standards/05-ux-ui.md), [06](./standards/06-design-system.md) + [Prompt 03](./prompts/03-claude-journeys-and-design.md) |
| Building it | [Prompt 04](./prompts/04-claude-implementation.md), then [Prompt 05](./prompts/05-replit-build.md) |
| Reviewing before a demo | [21 — QA & Definition of Done](./standards/21-qa-definition-of-done.md) + [Prompt 06](./prompts/06-canon-audit.md) |
| Inheriting an existing prototype | [Prompt 06 — Canon Audit](./prompts/06-canon-audit.md) |

---

## The lifecycle

```
Stage 0  Qualify        engagement one-pager, data classification
Stage 1  Research       Perplexity research pack                     [02]
Stage 2  Spec & Design  spec set, journeys, UX, agent + RAG specs     [03 04 05 06 07 10]
Stage 3  Code gen       repo scaffolded to canon, prompts as files    [11 19]
Stage 4  Implement      instrumented prototype on Replit             [12 13 14 16 20]
Stage 5  Verify         eval report, security / a11y / bilingual      [15 18 21]
Stage 6  Handover       demo, handover pack, gap register             [17 22]
```

Each stage has entry criteria, fixed artifact filenames, and an exit gate. Gates fail loudly; deviations are recorded as dated waivers in `docs/gaps-and-waivers.md`. Silent deviation is the only real violation.

---

## The standards

### A. Discovery, specification, traceability
- [01 — Delivery Lifecycle](./standards/01-delivery-lifecycle.md) · `LIFE`
- [02 — Research Brief](./standards/02-research-brief.md) · `BRIEF`
- [03 — Specification](./standards/03-specification.md) · `SPEC`

### B. Journey, UX, design
- [04 — Journey Design](./standards/04-journey-design.md) · `JRN`
- [05 — UI/UX for Agentic Apps](./standards/05-ux-ui.md) · `UX`
- [06 — Design System](./standards/06-design-system.md) · `DS`

### C. Agent architecture
- [07 — Agent Architecture](./standards/07-agent-architecture.md) · `AGT`
- [08 — Tool Contracts](./standards/08-tool-contracts.md) · `TOOL`
- [09 — Memory](./standards/09-memory.md) · `MEM`
- [11 — Prompt & Context Engineering](./standards/11-prompt-context-engineering.md) · `CTX`

### D. Retrieval
- [10 — Retrieval & RAG](./standards/10-rag.md) · `RAG`

### E. Safety, security, assurance
- [12 — Guardrails & Safety](./standards/12-guardrails-safety.md) · `GRD`
- [13 — Security & Authorization](./standards/13-security-authz.md) · `SEC`
- [14 — Human-in-the-Loop & Escalation](./standards/14-hitl-escalation.md) · `HITL`
- [15 — Evaluation](./standards/15-evaluation.md) · `EVAL`
- [16 — Observability & Cost](./standards/16-observability-cost.md) · `OBS`

### F. Governance and engineering
- [17 — Data Governance & Compliance](./standards/17-data-governance-compliance.md) · `GOV`
- [18 — Accessibility & Bilingual](./standards/18-accessibility-i18n.md) · `A11Y`
- [19 — Repository & Stack Conventions](./standards/19-repo-conventions.md) · `REPO`
- [20 — Replit & Deployment](./standards/20-replit-deployment.md) · `DEP`

### G. Delivery and handover
- [21 — QA & Definition of Done](./standards/21-qa-definition-of-done.md) · `QA`
- [22 — Handover & IP](./standards/22-handover-ip.md) · `HAND`

Every rule has a stable ID (`UX-014`, `RAG-027`, `SEC-009`). Cite rule IDs in reviews, waivers and audits — they are the shared vocabulary.

---

## Templates

Fill-in artifacts in [`templates/`](./templates/), one per governed deliverable: engagement one-pager, research brief, product brief, functional / technical / data / agent / RAG / journey specs, eval plan, model card, risk register, gaps-and-waivers log, Definition of Done checklist, handover pack, demo script.

## Prompts

The five stage prompts plus the audit prompt in [`prompts/`](./prompts/). Replace the `<<placeholders>>`, attach the named standards files, and do not paraphrase standards into the prompt — attach them.

## Repo template

[`repo-template/CLAUDE.md`](./repo-template/CLAUDE.md) and [`repo-template/AGENTS.md`](./repo-template/AGENTS.md) go at the root of every client repo from the first commit. Copy `standards/` into the client repo as `docs/standards/` so the `@` imports resolve.

---

## Canonical stack

TypeScript (`strict`) · Next.js App Router · Tailwind + shadcn/ui · Vercel AI SDK (LangGraph JS only when durable multi-step orchestration or interrupt-based HITL is required) · Zod at every boundary · Postgres + Drizzle + pgvector · pg-boss for background work · Replit Autoscale / Reserved VM / Scheduled Deployments · OpenTelemetry GenAI → Langfuse · promptfoo + Vitest + Playwright · next-intl with Arabic as a first-class RTL locale.

Deviations are allowed. Undocumented deviations are not.

---

## Governing the canon

- Semantic versioning on the pack; one named owner.
- Quarterly review, plus an out-of-cycle review when a major model, the AI SDK, or a relevant regulation changes materially.
- Amendments are proposed with the rule ID being changed and the evidence for the change. Project waivers that recur across three engagements are a signal the canon is wrong, not the projects.
