# Journey Design & Agent Architecture for AI-Agent Products (2025–2026)
### Constrained to what is implementable on Replit (Node/TypeScript or Python, Replit Deployments, Replit Postgres/Neon, Secrets, background workers, cron)

This document synthesizes current (2025–2026) best practices for (A) designing user journeys / service experiences for non-deterministic agent products, and (B) designing and implementing the underlying agent architecture. Every practice includes: **the rule**, **the rationale**, and a **concrete Replit-implementable pattern**. Anything not viable on Replit is flagged with a workaround.

---

## PART A — Journey Design for Agentic Products

### A.1 Job-to-be-Done (JTBD) framing for agent products

**Rule:** Frame the product around the job the user is "hiring" the agent to do, not around the agent's feature list or its autonomy level. Journeys should be organized by outcome milestones ("get my invoice reconciled," "get my support ticket resolved") rather than by screen flows, because the agent's internal path to that outcome is variable and non-deterministic.

**Rationale:** In deterministic software, a journey is a fixed sequence of screens; in agentic software, the *path* the system takes to the job is different every run. JTBD keeps the north-star ("get the job done, reliably, with appropriate trust") stable even while implementation paths vary. This is the modeling primitive that lets you write acceptance criteria for a non-deterministic system: you assert against the *outcome* and key checkpoints, not the exact conversational trace.

**Replit-implementable pattern:**
- Store "job" as a first-class entity in Postgres — a `jobs` table with `job_type`, `desired_outcome`, `success_criteria` (JSONB), `status` (enum: `not_started | in_progress | needs_human | done | failed`), separate from the raw `messages`/`events` log. Track journey progress against the job record, not the conversation transcript.
- Write BDD-style acceptance criteria per job type (see A.6) and store them alongside the job definition so both the agent's prompt and your CI eval suite reference the same source of truth.

---

### A.2 Service blueprints for human + agent handoffs

**Rule:** Use a service blueprint with an explicit **line of visibility** separating what the user sees (frontstage) from agent reasoning/tool calls (backstage), plus a new **line of agency** marking which actions the agent may take autonomously vs. which require a human (support agent or the end user) to approve. Map customer actions, frontstage actions, backstage agent/tool actions, and support processes across time, exactly as in classical service design, then annotate each backstage step with which actor (agent vs. human) owns it.

**Rationale:** The service blueprint is one of the most widely used tools in service design precisely because it forces explicit mapping of frontstage/backstage/support-process responsibility and physical evidence at each step — this generalizes directly to agent systems by adding "agent" as a new kind of backstage/frontstage actor ([Wikipedia: Service blueprint](https://en.wikipedia.org/wiki/Service_blueprint)). Applied to AI, teams are already extending blueprints with an AI agent that ingests journeys, SOPs, and system diagrams to propose blueprint stages, link frontstage actions to backstage technology, and flag ownership gaps ([InnoEdge AI Service Blueprint Builder](https://www.innoedge.com.hk/ai-design-thinking-and-innovation-agents-service-blueprint-builder/)).

**Replit-implementable pattern:**
- Maintain the blueprint as a living Markdown/Mermaid artifact in the repo (`docs/service-blueprint.md`) with a Mermaid flowchart per job type, using swimlanes for User / Agent (frontstage) / Agent (backstage: tool calls) / Human-in-the-loop / External system.
- Encode the "line of agency" directly in code as a per-tool `risk_tier` attribute (`low | medium | high`) stored alongside tool definitions; high-risk tools require a checkpoint row inserted into a `pending_approvals` Postgres table before execution.

---

### A.3 Task decomposition strategies

**Rule:** Choose decomposition granularity deliberately: **flat decomposition** (a handful of independent subtasks run in parallel) for jobs with low interdependency; **hierarchical decomposition** (goal → sub-goals → sub-sub-goals, delegated to sub-agents) for complex, ambiguous jobs. Avoid single giant subtasks (no better than no plan) and avoid over-decomposition into micro-tasks (context-window and orchestration overhead).

**Rationale:** "A plan with one giant sub-task is no better than no plan at all. A plan with twenty micro-tasks overwhelms the context window and adds overhead" ([Planning & Task Decomposition notes](https://www.max-gherman.dev/design/anatomy-of-ai-agent/planning-and-task-decomposition/)). This mirrors Anthropic's guidance that the orchestrator-workers pattern is "well-suited for complex tasks where you can't predict the subtasks needed," while flat parallelization/sectioning suits tasks that decompose cleanly and independently up front ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).

**Replit-implementable pattern:**
- Implement a `plan` step that emits a structured JSON list of subtasks with `id`, `description`, `depends_on[]`, persisted to a `plan_steps` table (one row per subtask, status tracked independently). This becomes your durable execution ledger (see B.8) and your journey-progress source of truth simultaneously — the user-facing "progress" UI can just render `plan_steps` grouped by job.

---

### A.4 Trust-building arcs: first-run vs. steady-state

**Rule:** Design two distinct experience modes. **First-run**: over-explain, show reasoning/plan before acting, default to lower autonomy, seek explicit confirmation before any consequential action, and demonstrate value on a low-risk task quickly. **Steady-state**: once trust is calibrated (via explicit user promotion or observed accept-rate of agent actions), reduce friction, batch confirmations, and surface only exceptions.

**Rationale:** UX literature on agentive AI in 2025 emphasizes that "the scaffolding of user understanding will have to go on purpose, machine agency will have to be presented as collaborative, system behavior will be truthful with users" and that trust calibration and feedback loops are core design primitives distinct from prior reactive-assistant UX ([Palwe, "UX strategies for agentive AI in 2025 and beyond"](https://www.computersciencejournals.com/ijcai/article/189/6-2-40-536.pdf)). Onboarding-specific guidance similarly stresses progressive trust-building protocols, adaptive capability communication by user type, and value demonstration before expanding scope ([gptme agent onboarding framework](https://smithery.ai/skills/gptme/agent-onboarding)).

**Replit-implementable pattern:**
- Add a `trust_level` column (int 0–3) per `user_id` in Postgres, incremented by an explicit "promote to autopilot" user action or by a rolling accept-rate computed from an `agent_actions` table (`accepted`, `rejected`, `modified` outcomes). Gate autonomy-slider defaults (A.5) off this column at session start.
- First-run mode = force `autonomy=assist` regardless of stored `trust_level` for a user's first N jobs; store `first_run_complete` boolean per user.

---

### A.5 Autonomy sliders and progressive automation (assist → co-pilot → autopilot)

**Rule:** Expose autonomy as an explicit, user-controllable and system-suggested setting with (at minimum) three tiers:
- **Assist**: agent drafts/suggests, human performs the action.
- **Co-pilot**: agent performs reversible/low-risk actions automatically, but every medium/high-risk action pauses for approval (a "checkpoint," not an "escape hatch" — see A.6).
- **Autopilot**: agent executes end-to-end for a bounded, pre-approved scope, with post-hoc audit rather than pre-approval, and automatic escalation the moment it leaves that scope.

**Rationale:** Analysis of 240 production LLM/agent deployments found **40.4% used human-in-the-loop patterns** as a deliberate design choice, not a failure fallback, and that well-designed systems route only **10–15% of queries** to a human while 85–90% flow through autonomously ([Applied AI, "Human-in-the-Loop as Architecture," citing ZenML 2025 LLMOps Database Analysis](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/)). Microsoft's Azure architecture guidance recommends scoping human-in-the-loop "gates" to *specific tool invocations rather than full agent outputs so orchestration can proceed autonomously for low-risk actions" — i.e., autonomy should be tool-scoped, not global ([Azure Architecture Center, AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)). OpenAI's guidance likewise ties human intervention to two triggers — failure-threshold breaches and high-risk actions — rather than a blanket setting ([OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).

**Replit-implementable pattern:**
- Model autonomy per-tool, not just per-session: a `tool_policies` table with columns `tool_name`, `min_autonomy_tier`, `risk_tier`. At execution time, check `user.trust_level`/selected `autonomy_mode` against `tool_policies.min_autonomy_tier`; if the tool's risk exceeds what the current mode allows, insert a row into `pending_approvals` and pause the run (see B.7 for the checkpoint/interrupt mechanism — this maps directly onto LangGraph's `interrupt()` or an equivalent hand-rolled pause-and-resume loop backed by Postgres).
- Ship the slider as a simple UI control (3-state radio/segmented control) bound to a `sessions.autonomy_mode` column; log every override the user makes, since override frequency is itself the steady-state trust signal from A.4.

---

### A.6 Failure and escalation paths; human handoff SLAs

**Rule:** Distinguish an **escape hatch** (agent hits uncertainty → hands off completely → workflow ends) from a **checkpoint** (agent pauses, human decides, agent resumes with guidance). Default to checkpoints for anything reversible; use escape hatches only for terminal failures. Define escalation triggers *systemically*, not by asking the agent to self-assess confusion: threshold-based (confidence below a cutoff), domain-based (dollar amount, data sensitivity), pattern-based (novel/unusual input), and regulatory (anything requiring an audit trail). On escalation, hand the human **rich context** — original request, actions already taken, data retrieved, and the specific decision needed — so they don't start from scratch. Build graceful-degradation for the human queue itself: priority tiers, timeout-with-safe-default policies, and backlog visibility.

**Rationale:** "The agent does not decide whether it is confused. The system defines when human review is required" — self-assessed uncertainty is an unreliable escalation trigger; deterministic/threshold triggers are more auditable and more consistent ([Applied AI, "Human-in-the-Loop as Architecture"](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/)). The same analysis found framework-level escalation-accuracy benchmarks ranging from 75% (native/CrewAI) to 92% (LangGraph) on a customer-support benchmark, and that logging checkpoint decisions and refining escalation criteria monthly shrank the human-review share from 10–15% down to 8–10% over time — escalation policy should be treated as a tunable, monitored system, not a one-time prompt instruction. Concretely effective HITL implementation patterns identified: **Approval** (propose → human approves/rejects → execute; used for irreversible ops), **Guidance** (agent presents options at an ambiguous decision point, human picks), and **Validation** (agent completes the action, human reviews before it's finalized; used for anything representing the organization, e.g., customer-facing content).

**Replit-implementable pattern:**
- `pending_approvals` table: `id, job_id, tool_call_json, risk_tier, created_at, sla_deadline, status (pending|approved|rejected|expired), resolved_by, resolution_note`.
- A **Scheduled Deployment** (cron, e.g., every 5 minutes) sweeps this table for rows past `sla_deadline` and applies the pre-configured safe default (auto-reject high-risk / auto-approve-with-flag for low-risk-but-stale), then notifies (email/Slack via a connector, or webhook) — this is the SLA enforcement mechanism, and it is directly buildable with [Replit Scheduled Deployments](https://docs.replit.com/features/publishing/deployment-types), which run a command on a schedule expressed in plain language and stop until the next run.
- When escalating, populate a `handoff_context` JSONB column with the full trajectory snapshot (see B.13 memory/state) so the human reviewer sees the same "rich context handoff" pattern recommended above without re-querying the agent.

---

### A.7 Journey-mapping artifacts adapted for agents

**Rule:** Traditional journey maps (linear, screen-by-screen) under-represent branching and non-determinism. Use a small artifact set instead:
1. **Service blueprint** (A.2) for the human/agent/system swimlane view.
2. **State machine diagram** (Mermaid `stateDiagram-v2`) for the agent's own control-flow (idle → planning → executing → awaiting-approval → done/failed), which doubles as the literal implementation contract.
3. **Sequence diagram** (Mermaid `sequenceDiagram`) per job type, showing exact message/tool-call order between User, Agent, Tools, and Human-reviewer — useful because it is unambiguous about *who* calls *whom* and *when a pause occurs*.
4. **Event storming board** (can be run as a virtual sticky-note session) to identify domain events, commands, and aggregates before deciding agent boundaries — particularly valuable for multi-agent systems where "agent boundaries" should follow bounded contexts, not org chart.

**Rationale:** Event storming is described as "a collaborative workshop-based method... particularly useful for business process modeling," and applying Domain-Driven Design plus Event Storming to multi-agent systems is a documented 2025 pattern for defining "agent roles, boundaries, and scalable architectures... aligned with business needs" — identifying domain events/commands/aggregates before deciding how many agents you need and what each owns ([DZone, "Designing Scalable Multi-Agent AI Systems"](https://dzone.com/articles/multi-agent-ai-ddd-event-storming)). Mermaid is widely adopted specifically because it is text-based ("diagrams as code"), embeds directly in Markdown/specs, and is easy for an LLM to both read and generate/update on request ([Awesome Testing, "Mermaid diagrams: When AI Meets Documentation"](https://www.awesome-testing.com/2025/09/mermaid-diagrams)).

**Replit-implementable pattern:**
- Keep all four artifacts as Markdown files with fenced Mermaid blocks inside the repo (`docs/journeys/<job-type>.md`). Because they're plain text, they are directly diff-able in git, directly readable by the coding LLM that will implement the feature, and directly renderable in the Replit file viewer or any Markdown renderer — no extra tooling needed.
- Keep the state-machine diagram and the actual application state machine (an enum + transition table in code, or an `xstate` config) in lockstep: generate one from the other in CI, or at minimum add a unit test asserting all states in the Mermaid diagram exist in code and vice versa.

---

### A.8 Expressing journeys in a spec an LLM can implement

**Rule:** Write journeys as **executable-style specifications** that an LLM code-generator can consume directly, combining three formats:
- **Gherkin-style Given/When/Then scenarios** per job, covering the happy path, at least one ambiguous/needs-clarification path, and at least one failure/escalation path.
- **A state machine definition** (Mermaid `stateDiagram-v2`, or a JSON/YAML transition table consumable by a library like XState) as the canonical control-flow contract.
- **Mermaid sequence diagrams** per scenario showing exact actor-to-actor calls, including the pause/resume point for human checkpoints.

**Rationale:** Specification-driven, test-first workflows measurably improve LLM code-generation reliability: a human-in-the-loop three-phase workflow (specification → tests → generated function, verified against the test suite) is an active 2025–2026 research pattern for constraining LLM-generated code to match intent ([arXiv, "Understanding Specification-Driven Code Generation with LLMs"](https://arxiv.org/html/2601.03878v1)). Gherkin's Given/When/Then structure is a natural fit because it already expresses conditional, branching behavior in structured natural language, which both a human product reviewer and an LLM implementer can parse unambiguously — extending it to non-happy-path and escalation scenarios covers exactly the branching cases a deterministic screen-flow spec would miss. Mermaid's status as a promptable, text-based diagram format ("describe an architecture in natural language, get Mermaid markup back") means diagrams-as-code can be generated, validated, and regenerated in the same LLM-based pipeline building the feature ([Awesome Testing, 2025](https://www.awesome-testing.com/2025/09/mermaid-diagrams)).

**Replit-implementable pattern:**
- Store one `.feature`-style Markdown file per job type with Gherkin scenarios; even without a full Cucumber/Gherkin runner, this format is directly usable as (a) the prompt context for the coding LLM building the feature, and (b) the acceptance-criteria source for your eval harness (B.14) — translate each scenario into a row in your offline eval JSONL (expected trajectory / expected outcome).
- Example minimal structure to include in the repo:
  ```gherkin
  Feature: Reconcile monthly invoice
    Scenario: Happy path, low autonomy
      Given the user is in "assist" mode
      When the agent finds a matching invoice
      Then the agent proposes the match and waits for user confirmation

    Scenario: Escalation - amount exceeds threshold
      Given the invoice amount exceeds $1000
      When the agent completes matching
      Then the agent creates a pending_approval row and notifies a human reviewer
      And the workflow resumes automatically once approved or expires per SLA
  ```
- Pair with a Mermaid `stateDiagram-v2` for the same job in the same file for a single source of truth that is both human-readable and LLM-parseable.

---

## PART B — Agent Design and Implementation

### B.1 Workflows vs. agents — choosing the right level of autonomy

**Rule:** Default to the simplest solution — often a single, well-tuned LLM call with retrieval and in-context examples. Reach for a **workflow** (predefined code paths orchestrating LLM calls) when the task is well-defined and predictability matters. Reach for an **agent** (LLM dynamically directs its own tool use and control flow) only when the task is open-ended, the number of steps can't be predicted, and you have both a stopping condition and sufficient trust in the model's decision-making for the environment.

**Rationale:** Anthropic explicitly recommends "finding the simplest solution possible, and only increasing complexity when needed... this might mean not building agentic systems at all," because "agentic systems often trade latency and cost for better task performance" ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)). OpenAI's guide similarly frames an agent as a system that "recognizes when a workflow is complete and can proactively correct its actions if needed... in case of failure, it can halt execution and transfer control back to the user" — distinct from "simple chatbots, single-turn LLMs, or sentiment classifiers," which are not agents at all ([OpenAI, A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).

**Replit-implementable pattern:**
- Start every new feature as a plain function chain (a workflow) in TypeScript/Python. Only introduce a model-driven loop (`while` loop calling the LLM until an exit condition) once you've proven the fixed pipeline can't handle the task's variability. This keeps the Replit app debuggable and cheap to run on Autoscale/Reserved VM before you invest in agent loop infrastructure (state machine, checkpointing, guardrails).

---

### B.2 The five canonical workflow patterns

| Pattern | Definition | When to use | Replit implementation |
|---|---|---|---|
| **Prompt chaining** | Sequence of LLM calls, each processing the prior output, with optional programmatic "gate" checks between steps | Task cleanly decomposes into fixed subtasks (e.g., outline → validate → write) | Plain async function pipeline; persist intermediate outputs to Postgres per step for resumability |
| **Routing** | Classify input, direct to a specialized downstream prompt/tool/model | Distinct input categories better handled separately; also used to route easy queries to cheap models and hard ones to capable models | A classifier LLM call or lightweight model returns a `route` enum; `switch` in code selects the downstream handler |
| **Parallelization (sectioning/voting)** | Independent subtasks run concurrently and aggregated programmatically | Subtasks are independent (sectioning) or you need multiple attempts/perspectives for confidence (voting) | `Promise.all` / `asyncio.gather` across LLM calls; aggregate with code, not another LLM call, when possible |
| **Orchestrator–workers** | Central LLM dynamically breaks down the task and delegates to worker LLM calls, then synthesizes | Subtasks can't be predicted ahead of time (e.g., multi-file code edits, open-ended research) | Orchestrator persists a `plan_steps` table (A.3); workers are stateless function calls; orchestrator polls/aggregates results |
| **Evaluator–optimizer** | One LLM generates, another evaluates/critiques in a loop | Clear evaluation criteria exist and iterative refinement demonstrably helps (e.g., translation, complex search) | Loop with a hard iteration cap (B.9) stored in code, not left to the model to self-terminate |

All five patterns and their selection criteria are documented in [Anthropic's Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents), and restated in a technology-agnostic form (sequential, concurrent, group chat/debate, handoff, magentic/dynamic-planning) by [Microsoft's Azure Architecture Center AI Agent Orchestration Patterns guide](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns), which additionally documents **group chat** (roundtable/debate, best limited to ≤3 agents to keep control tractable) and **magentic** (dynamic task-ledger orchestration for open-ended problems with no predetermined solution path — the most flexible but slowest-to-converge and most prone to stalling).

**Rule for choosing among Azure's five named patterns:** use **sequential** for linear pipelines with clear dependencies; **concurrent** for independent-perspective/latency-sensitive fan-out; **group chat** for consensus-building/maker-checker QA (cap at 3 agents, mandatory iteration cap and fallback behavior); **handoff** for triage where the right specialist only becomes clear at runtime (cap handoff depth to prevent infinite bouncing); **magentic** only for genuinely open-ended problems, since it is explicitly flagged as slow to converge and prone to stalling on ambiguous goals.

**Replit-implementable pattern:** Google's Agent Development Kit (ADK) offers built-in `SequentialAgent`, `ParallelAgent`, and `LoopAgent` primitives with deterministic (non-LLM-mediated) control flow and an `output_key` mechanism where each sub-agent writes results into shared session state for the next to read — this maps directly onto a hand-rolled equivalent in TypeScript/Python on Replit: a shared `session_state` JSONB column in Postgres that each pipeline step reads/writes, with the pipeline order defined in code, not by the model ([Google ADK docs, Workflow Agents](https://google.github.io/adk-docs/agents/workflow-agents/)).

---

### B.3 Context engineering

**Rule:** Treat context management as an explicit engineering discipline distinct from prompt wording. Key techniques: (1) write system prompts at the "right altitude" — specific enough to guide behavior, flexible enough not to be brittle; organize with clear sections (XML tags or Markdown headers); (2) curate a **minimal, non-overlapping tool set** — if a human engineer can't say which tool applies in a given situation, the model can't either; (3) use **few-shot examples** (canonical, diverse) rather than exhaustive edge-case lists; (4) manage message history via **compaction** — summarize and re-initiate context near the window limit, preserving architectural decisions/unresolved issues while discarding redundant tool output; (5) use **structured note-taking** (agentic memory, e.g., a persisted `NOTES.md`/to-do list) for cross-context continuity; (6) use **sub-agent architectures** for parallelizable research/exploration, where each sub-agent burns tens of thousands of tokens internally but returns only a 1,000–2,000 token distilled summary to the lead agent.

**Rationale:** All six techniques, definitions, and tradeoffs are drawn directly from [Anthropic's "Effective context engineering for AI agents"](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents), which frames context engineering as "the art and science of curating what will go into the limited context window from [a] constantly evolving universe of possible information." The guide states explicitly that compaction suits tasks needing extensive back-and-forth conversational flow, note-taking excels for iterative development with clear milestones, and multi-agent architectures handle complex research/analysis where parallel exploration pays off — i.e., these are not competing techniques but complementary ones selected per task shape.

**Replit-implementable pattern:**
- Store the system prompt as a versioned file/template (not hardcoded string) with named `{{policy_variables}}`, matching OpenAI's guidance to "use a single flexible base prompt that accepts policy variables instead of maintaining numerous individual prompts" ([OpenAI, Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Implement compaction as a scheduled or triggered function: once conversation token count (tracked via provider usage metadata) crosses a threshold, call the model once more with a "summarize and compress" prompt, store the summary in a `session_summaries` table, and truncate/replace the working message array with `[summary, last_k_messages]`.
- Implement structured note-taking as a simple `scratchpad` TEXT/JSONB column per job, updated by a dedicated tool call (`update_notes`) the agent invokes — this is a Postgres row, not a separate memory service, keeping the whole thing inside your existing database.

---

### B.4 Tool design best practices

**Rule:**
- **Naming:** use a `domain-noun-verb` convention (e.g., `invoice_reconciliation_create`) to prevent collisions and let alphabetical listing cluster related tools.
- **Descriptions:** write as prompts — state what the tool does, *when* to use it, what parameters it takes, example calls with real values, prerequisites/sequencing, and error conditions. Include authentication/authorization requirements directly in the description.
- **Schemas:** follow the tool-call/MCP specification shape (`name`, `description`, `inputSchema`, `outputSchema`); in Python, use Pydantic models for inline field documentation, type validation, and enums for closed sets (never enums for free-form text, IDs, or arbitrary numbers — use clear descriptions/examples instead); always provide sensible defaults so the model isn't forced to guess.
- **Error messages:** make errors part of the contract, not an afterthought — document error conditions in the tool description itself so the model can self-correct.
- **Token-efficient returns:** tools should return only what's needed for the next decision; avoid dumping entire records/pages when a summary suffices.
- **Idempotency:** action tools that mutate state (create/refund/send) should accept an idempotency key so retries (B.8) don't double-execute.
- **Pagination:** paginated data tools should return a small default page plus an explicit cursor/token, not an unbounded list, to control token spend.
- **Granularity:** decompose tools with 8+ parameters or that handle multiple distinct intents; separate read and write operations into different tools; bundle 3+ commonly co-occurring API calls into a single coarse-grained "workflow tool" rather than forcing the model to chain many granular calls itself; prefer deterministic code for anything that can be made deterministic, and reserve free agent tool-calling for genuinely dynamic decisions.

**Rationale:** Naming, description, schema, and granularity guidance is drawn directly from [AWS Prescriptive Guidance on MCP strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf), which frames tool descriptions as prompts and recommends decomposing tools with 8+ parameters or multiple intents. Anthropic reinforces that "a common failure mode is bloated tool sets that cover too much functionality or create ambiguous decision points" and that "if a human engineer can't definitively say which tool should be used in a given situation, an AI agent can't be expected to do better," recommending a minimal, non-overlapping tool set and "poka-yoke"-style tool design (e.g., forcing absolute file paths eliminated a whole class of agent errors in Anthropic's own SWE-bench work) ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)). OpenAI's guide independently confirms the three-category tool taxonomy (data/action/orchestration tools) and states that as tool count grows, splitting across multiple agents (rather than one bloated tool set) is the recommended lever ([OpenAI, Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).

**Replit-implementable pattern:**
- Define tools as TypeScript functions with Zod schemas (or Python functions with Pydantic models) that double as both runtime validators and the JSON Schema sent to the model — one source of truth, no drift between validation code and tool schema.
- Add an `idempotency_key` parameter to every mutating tool, backed by a Postgres unique constraint on `(tool_name, idempotency_key)` in an `executed_actions` table; check-and-insert before executing the underlying side effect.
- For paginated data tools, cap default page size (e.g., 20 rows) and return a `next_cursor` field; never let the model request "all rows" without an explicit, tool-enforced upper bound.

---

### B.5 Model Context Protocol (MCP) — when to use it

**Rule:** Use MCP when you need centralized governance over how agents access multiple enterprise/external systems, when developers are duplicating custom integrations across projects, or when you want to expose your own tools/data to external agent consumers through a standardized, governed interface. Do **not** reach for MCP by default for a single, simple, in-app tool — a directly registered function/tool call is simpler and has no protocol/transport overhead. Prefer existing, well-maintained MCP servers where available; only build custom MCP servers when you need domain-specific workflows, golden-path abstractions, or compliance/security guarantees a generic server can't provide.

**Rationale:** "MCP likely becomes part of your strategy when: you need centralized governance... developers spend too much time writing custom integrations that are not consistent... you have duplicated tools that could serve common capabilities... you want to offer your proprietary tools or data to external consumers... through standardized, governed MCP interfaces" — but also, "in many cases, pre-existing MCP servers are sufficient," and custom servers are reserved for specialized functionality, domain expertise, or compliance needs ([AWS Prescriptive Guidance, MCP Strategies](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf)). Anthropic frames MCP as the mechanism that lets "developers integrate with a growing ecosystem of third-party tools with a simple client implementation" as part of the augmented-LLM building block ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).

**Replit-implementable pattern:**
- For a single Replit app talking to its own database and a handful of first-party APIs, skip MCP entirely — register tools directly with the model SDK (Anthropic/OpenAI SDK tool-calling). This avoids running/managing a separate MCP server process, which adds operational surface area on a single-container Reserved VM deployment.
- Adopt MCP only when the app needs to consume multiple *third-party* MCP servers already published by vendors (e.g., a GitHub or Slack MCP server) — in that case, run the MCP client inside your existing Node/Python process; you generally do not need to host your own MCP *server* on Replit unless you intend to expose your app's own tools to external agent consumers.

---

### B.6 Multi-agent handoff and subagent patterns

**Rule:** Prefer a single agent with a well-curated tool set until you hit a concrete wall — either instruction complexity (many conditional branches) or tool-set overload/ambiguity. When you do split, choose between:
- **Manager pattern (agents-as-tools):** a central agent keeps control and calls specialist agents as tools, synthesizing results itself — best when one agent should retain the user relationship and orchestration control.
- **Decentralized/handoff pattern:** agents transfer full control to one another (a one-way handoff, optionally with a return path) — best for triage-style flows (e.g., support routing) where no single agent needs to retain synthesis responsibility.
- **Sub-agent-for-context-isolation pattern:** spin up sub-agents purely to isolate large amounts of exploratory context (e.g., research, code search), returning only a distilled summary to the lead agent, rather than to divide business logic.

**Rationale:** OpenAI explicitly recommends maximizing a single agent's capabilities first, splitting only "when prompts contain many conditional statements... or tool overload" — noting that the problem is tool *similarity/overlap*, not raw count (some production systems manage 15+ distinct tools fine; others struggle with fewer than 10 overlapping ones) ([OpenAI, Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)). The same source defines the manager pattern (edges = tool calls) versus decentralized/handoff pattern (edges = one-way control transfers) as the two multi-agent topologies, modeled as a graph. Anthropic separately documents the context-isolation motive for sub-agents (not a business-logic split, but a token/attention-isolation technique), citing "How we built our multi-agent research system" as showing substantial improvement over single-agent systems on complex research tasks ([Anthropic, Effective context engineering](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).

**Replit-implementable pattern:**
- Implement handoff as a typed function call (`transfer_to(agent_name, context_payload)`) that swaps the active system prompt/tool set for the next turn while carrying forward the conversation state row in Postgres — no special infrastructure needed beyond a `current_agent` column on the session record.
- Implement the manager pattern by literally registering other agents as callable tools (`spanish_agent`, `refund_agent`) from the manager's tool list — this works identically to any other tool call in your existing SDK integration.
- Always set a maximum handoff-chain depth (e.g., 5) and log every transfer to prevent infinite bounce loops, per Azure's explicit warning that handoff orchestration risks "infinite handoff loops" and "unpredictable routing paths" ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

---

### B.7 Human-in-the-loop implementation patterns

**Rule:** Implement three concrete HITL patterns as needed: **Approval** (agent proposes, human approves/rejects before execution — for irreversible/high-impact actions), **Guidance** (agent surfaces an ambiguous decision with options, human picks a direction — for routing/priority judgment calls), and **Validation** (agent completes the action, human reviews/edits before it's finalized — for anything customer-facing or brand-representing). Scope HITL gates to specific tool invocations, not whole agent turns, so low-risk work continues autonomously around a paused high-risk action.

**Rationale:** These three patterns, and their measured effectiveness (e.g., an "Approval"-pattern implementation blocked 100% of dangerous operations while allowing 100% of legitimate ones in one production DevOps-remediation deployment; a "Guidance"-pattern implementation on LangGraph achieved 92% escalation accuracy) are documented in [Applied AI's "Human-in-the-Loop as Architecture"](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/). Microsoft's Azure guidance adds the specific implementation detail that "mandatory gates make the orchestration synchronous at that step, so persist state at these checkpoints to resume operation without a replay of prior agent work" and recommends scoping gates to tool invocations for exactly this reason ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Replit-implementable pattern:**
- Use LangGraph's `interrupt()` primitive if using LangGraph: it pauses graph execution, persists exact graph state via the checkpointer, and resumes via `Command` re-invocation keyed by `thread_id` — this requires a durable (non-in-memory) checkpointer in production ([LangGraph Interrupts docs](https://docs.langchain.com/oss/python/langgraph/interrupts); [LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)).
- If not using LangGraph, hand-roll the same pattern: on a high-risk tool call, write a row to `pending_approvals` with the full tool-call payload and the current `plan_steps`/session state snapshot, then return/stop the current process invocation. A Reserved VM background worker or a webhook-triggered resume endpoint picks the job back up once `pending_approvals.status` changes to `approved`.
- **Critical Replit-specific note:** `MemorySaver`/in-memory checkpointers lose all state on process restart, which happens routinely on Autoscale (scale-to-zero) deployments. **Use `PostgresSaver`-equivalent durable persistence (Replit's built-in Postgres) for any HITL flow that must survive longer than a single request lifecycle** ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)).

---

### B.8 State persistence, durable execution, and checkpointing

**Rule:** Separate **short-term, thread-scoped state** (the current run's checkpoint — messages, plan steps, tool-call results) from **long-term, cross-thread state** (facts, preferences, and shared knowledge that outlive a single job). Persist both in a durable store, never in-process memory, for anything that must survive a restart, a long-running pause (e.g., awaiting human approval), or a deploy. Prune/retire old checkpoints on a schedule to bound storage and query latency growth.

**Rationale:** LangGraph's persistence model draws exactly this distinction: **checkpointers** persist thread-scoped graph state for "conversation continuity, human-in-the-loop workflows, time travel, and fault tolerance," while **stores** persist cross-thread data for "user preferences, facts, and shared knowledge" ([LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)). The same documentation explicitly warns that `MemorySaver`/`InMemorySaver` "store checkpoints in RAM… When the process restarts, all checkpoints are lost," and recommends `PostgresSaver` for production, along with a scheduled pruning job since "checkpoints growing unboundedly… can increase latency and storage costs." Azure's guidance reinforces this at the multi-agent level: "for orchestrations spanning multiple user interactions or long-running tasks, persist shared state externally rather than relying only on in-memory context… scope persisted state to the minimum necessary information" to control token overhead and privacy risk ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Replit-implementable pattern:**
- Use **Replit's built-in Postgres database** (20GB free storage per app, accessed via an environment-variable connection string, with schema/ORM setup available through Replit Agent) as both the LangGraph checkpointer backend (if using LangGraph's `PostgresSaver`/`AsyncPostgresSaver`) and/or your own hand-rolled `checkpoints` + `long_term_memory` tables if not using a framework ([Replit Database docs](https://docs.replit.com/cloud-services/storage-and-databases/sql-database)). Alternatively, connect an external Neon project directly by placing its connection string in a `DATABASE_URL` Secret — teams do this specifically to keep production data separate from Replit's default development database.
- If using `PostgresSaver`, keep `thread_id` under 255 characters (use a UUID) since the underlying column has a length limit; call `checkpointer.setup()` once to create tables/indexes.
- Add a **Scheduled Deployment** cron job (e.g., nightly) that deletes checkpoints/approval rows older than N days per your retention policy — this is the direct Replit implementation of LangGraph's documented pruning recommendation.
- Store secrets (API keys, `DATABASE_URL`, model provider keys) exclusively via **Replit Secrets**, which are AES-256-encrypted at rest, TLS-encrypted in transit, exposed to the app as environment variables, and shareable at the app or account level with collaborators ([Replit Secrets docs](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)) — never hardcode credentials in source.

---

### B.9 Retries, timeouts, circuit breakers, budget/step caps, and loop prevention

**Rule:**
- **Retries:** use exponential backoff with jitter for transient failures (rate limits, timeouts, connection errors) — jitter prevents a "thundering herd" of synchronized retries when a service recovers. Cap `max_attempts` (2–3 is typical) and `max_delay`.
- **Timeouts:** set *different* timeouts per operation type — LLM calls need more time than tool calls, which need more time than database queries — plus one overall request-level timeout as a backstop. For streaming, timeout on time-to-first-token rather than total duration, and add a mid-stream stall/heartbeat check.
- **Circuit breakers:** track failures in a rolling window; after a failure threshold, "open" the circuit and reject calls immediately (no wasted attempt) for a recovery period, then allow a small number of trial calls in a "half-open" state before fully closing again.
- **Fallback chains:** for both models (primary model → cheaper/alternate fallback model) and tools (e.g., search provider A → provider B → cached result), attempt each in order and only fail the whole operation if all fail.
- **Budget/step caps and loop prevention:** every agent loop must have a hard maximum iteration/step count and, ideally, a token/cost budget per job, checked in code — never left to the model to self-terminate.
- **Graceful degradation:** define explicit service levels (full / degraded / minimal / offline) so the system serves *something* — even a rule-based canned response — rather than failing outright when a dependency is down.

**Rationale:** With five sequential 99%-reliable tool calls, the probability all five succeed is only 95.1% — meaning roughly 1 in 20 requests hits at least one failure absent resilience patterns; proper retries, circuit breakers, and fallbacks can push effective reliability back above 99.9% ([CallSphere, "Building Resilient AI Agents"](https://callsphere.ai/blog/building-resilient-ai-agents-circuit-breakers-retries-graceful-degradation)). The same source gives concrete parameter defaults worth adopting directly: retry `max_attempts=3`, `base_delay=1.0s`, `max_delay=30–60s`, full jitter; circuit breaker `failure_threshold=5`, `recovery_timeout=30–60s`, `half_open_max_calls=3`, `success_threshold=2`; timeout tiers of `LLM_CALL=45s`, `TOOL_EXECUTION=15s`, `WEB_SEARCH=10s`, `DATABASE_QUERY=5s`, `TOTAL_REQUEST=120s`. Anthropic's agent definition explicitly builds in a stopping condition as a design requirement: "it's also common to include stopping conditions such as a maximum number of iterations to maintain control" ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)), and Azure's guardrails section separately recommends circuit-breaker patterns for agent dependencies plus iteration limits specifically to guard against infinite tool-call loops in single-agent-with-tools scenarios ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Replit-implementable pattern:**
- Implement retry/circuit-breaker/timeout logic as small, dependency-free utility modules (no need for a heavyweight resilience framework) — a `RetryConfig` dataclass/class plus a decorator, and a `CircuitBreaker` class with `CLOSED/OPEN/HALF_OPEN` state, are both straightforward to hand-write in TypeScript or Python and run fine inside a Replit Reserved VM or Autoscale process.
- Track per-service circuit-breaker state in-process (per running instance) is sufficient for a single Reserved VM; if running on Autoscale with multiple instances, persist breaker state (or at least failure counters) in Postgres/Redis-equivalent so breakers are shared across instances — otherwise each new instance "forgets" an open circuit.
- Enforce the step cap as a simple counter check inside the agent's `while` loop (`if steps > MAX_STEPS: halt_and_escalate()`), and enforce a cost budget by summing `usage.total_tokens` (or provider cost estimate) per job in the `jobs` table, checked before every new LLM call.
- Rate limits: implement a token-bucket limiter in code to stay under provider limits, honor `Retry-After` from 429 responses, and — if using multiple provider API keys — round-robin across Secrets-stored keys.

---

### B.10 Guardrails — input/output validation, structured outputs, moderation, PII, sandboxing

**Rule:** Treat guardrails as a **layered defense**, not a single check: (1) rules-based filters (regex, blocklists, length limits) for known threats — cheap and deterministic; (2) a relevance classifier to keep responses in scope; (3) a safety/jailbreak classifier for prompt-injection attempts; (4) a moderation API pass on both input and output; (5) a PII filter on output before it's shown/stored; (6) **structured outputs / constrained decoding** (JSON Schema-validated generation) wherever the output feeds another system, since this eliminates a whole class of parse failures by construction, not just after the fact; (7) tool-call risk rating (low/medium/high, by reversibility and financial/data impact) gating whether execution proceeds automatically or is queued for approval; (8) sandboxed execution for any agent-generated code.

**Rationale:** OpenAI frames guardrails explicitly as layered and risk-scoped: "guardrails should address risks already identified for the use case and layer in additional ones as new vulnerabilities are uncovered… using multiple, specialized guardrails together creates more resilient agents," listing relevance classifiers, safety classifiers, PII filters, moderation, rules-based protections, and tool safeguards rated by risk tier as the concrete guardrail types, plus an "optimistic execution" model where guardrails run concurrently with generation and raise a "tripwire" exception if violated ([OpenAI, Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)). Structured outputs work by constraining the decoding process itself — "a token mask… at every decoding step, a finite-state machine or grammar tracks which tokens are legal… illegal tokens get their probability zeroed before sampling," which eliminates parse failures but not semantic errors, meaning schema validation must still be paired with semantic/business-logic checks ([IoT Digital Twin PLM, "LLM Output Validation: Structured Outputs & Guardrails"](https://iotdigitaltwinplm.com/llm-output-validation-structured-outputs-guardrails-2026/), referencing [OpenAI's Structured Outputs documentation]). Content-moderation guidance stresses that moderation is necessary but not sufficient for security: "content moderation is not a complete prompt-injection defense… agent security is broader — it includes prompt injection, tool permissions, data access, human approvals, structured outputs, evals, logging, and workflow design," and recommends the pipeline `input moderation → model/agent reasoning → tool-call validation → output moderation → allow/review/block`, citing OWASP's treatment of prompt injection as a distinct LLM security risk ([EvoLink, "Chatbot Content Moderation"](https://evolink.ai/blog/chatbot-content-moderation-api)).

**Replit-implementable pattern:**
- Use your model provider's native structured-output/JSON-Schema mode (constrained decoding) for every tool call and every machine-consumed response; validate the returned JSON again server-side with the same Zod/Pydantic schema used for the tool definition (defense in depth against edge cases the constrained decoder still gets wrong).
- Implement the moderation pass as a fast, separate LLM call or provider moderation endpoint that runs **in parallel** with the main generation (Anthropic's "sectioning" parallelization pattern, B.2) rather than folding it into the main agent's single call — "this tends to perform better than having the same LLM call handle both guardrails and the core response" ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- For PII redaction, run a regex/NER-based scrubber on both inbound user data before it's logged/persisted and outbound model responses before display — implementable as a plain utility function; Postgres columns storing raw conversation history should have redaction applied before writing, not only before display, if compliance requires it.
- **Sandboxing agent-generated code:** Replit's own workspace/deployment containers are not designed as a secure sandbox *for arbitrary code the agent itself generates and executes at runtime* (as opposed to your own app code). **This is a gap to flag explicitly:** if your product needs to execute untrusted, model-generated code as part of a tool (e.g., a "run this Python snippet" tool), do not `exec()`/`eval()` it directly inside your main Replit app process. Workaround: call out to a dedicated sandboxing service (e.g., a container-per-execution service, a WASM-based sandbox, or a provider-hosted code-execution API) over HTTP from your Replit app, treating it as just another external tool call with its own timeout/circuit breaker (B.9) — keep the sandbox execution *outside* the main app process/deployment.

---

### B.11 Memory architecture — short-term, long-term, semantic vs. episodic

**Rule:** Choose a memory architecture based on the *retrieval question* you need answered, not by defaulting to a framework:
- If the question is **"what did this user tell me?"** — vector-similarity retrieval works well.
- If it's **"what's the most recent/current fact about this entity?"** (temporal reasoning, contradiction resolution) — vector-only retrieval is weak; use a temporal/graph-aware store or decay-weighted retrieval.
- If it's **"what should the agent actively remember vs. archive?"** — use a tiered, agent-managed memory model (core/working vs. archival vs. recall), where the agent itself decides what to promote/demote.

Structure memory into three conceptual types regardless of backing store: **episodic** (past interactions/events), **semantic** (facts, preferences, beliefs), and **procedural** (instructions the agent can use to update its own operating behavior).

**Rationale:** Benchmark data on the LongMemEval benchmark shows a wide spread (49%–~95%) depending on architecture: vector-first systems (LangMem-style) score only 49–55% on temporal-reasoning subtasks because "vector search has no native concept of time," while a temporal-graph approach (Zep's Graphiti engine, storing fact-validity windows rather than timestamped snapshots) scores 63.8%, and a well-engineered RAG-only system (Mastra's Observational Memory) achieved a reported 94.87% — demonstrating architecture and engineering effort matter far more than which "off-the-shelf" category (framework vs. custom RAG) you start from ([AgentMarketCap, "Agent Memory Architecture Wars: LangMem vs Letta vs Custom RAG"](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production)). The same source documents LangMem's three memory types (episodic/semantic/procedural, each produced by an LLM-based "Memory Manager" from conversation transcripts) and Letta's alternative three-tier, OS-inspired model (**Core Memory** = RAM, always in context, size-limited; **Archival Memory** = disk, searchable long-term store; **Recall Memory** = cache, queryable conversation history) where the *agent itself* — via tool calls — decides what moves between tiers, at the cost of added latency/token overhead per memory operation.

**Replit-implementable pattern:**
- For most Replit-hosted apps, a **custom, Postgres-native memory store is the most practical default**: use `pgvector` (available as a Postgres extension) for semantic/episodic memory embeddings, plus plain relational tables for structured facts/preferences (semantic memory) and a `procedural_notes` table the agent can read/update (mirroring LangMem's procedural-memory concept without needing the SDK). This avoids standing up a separate vector database service and keeps memory in the same Postgres instance as your checkpoints/jobs data, simplifying backup and operational surface area on a single Replit deployment.
- Add simple temporal-decay/conflict-resolution logic in your read path (e.g., prefer the most recently written row for a given `(user_id, fact_key)`, or store an explicit `valid_from`/`superseded_by` pair) to address the documented weakness of pure vector-similarity retrieval on "my preference changed" queries — this closes most of the gap to Zep/graph-based approaches without adopting a new framework.
- If the app is built on LangGraph already, LangGraph's **Store** abstraction (cross-thread, long-term) is the natural home for semantic/episodic memory, backed by the same Postgres instance as your checkpointer (B.8) — see [LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence).
- Reserve a Letta-style agent-managed tiered memory only if the product genuinely needs long-running (weeks/months), autonomously self-managing agents (e.g., a persistent assistant); otherwise the added tool-call latency/token cost is not justified for typical bounded-job Replit apps.

---

### B.12 Evaluation — offline eval sets, LLM-as-judge, trajectory evals, CI regression gates

**Rule:** Evaluate **trajectories**, not just final outputs — an agent eval is a function from the full trajectory (system prompt, user input, reasoning, every tool call with arguments/return values, retrieval results, final response) to a score, not a simple `(input, output)` comparison. Score on multiple independent dimensions — at minimum: tool selection, argument extraction, result utilization/groundedness, error recovery, plan coherence, and task completion — and gate CI **per-dimension**, never on an aggregate alone, since an aggregate score can hide a bad dimension behind good ones. Maintain a versioned, continuously-refreshed offline dataset (promote real failing production traces into it regularly) rather than a static eval set that goes stale.

**Rationale:** "An LLM eval is a function from (input, output) to a score. An agent eval is a function from trajectory to a score" — this reframing, and the six-dimension rubric (tool selection, argument extraction, result utilization, error recovery, plan coherence, task completion), plus the explicit warning that "an aggregate 0.85 can hide a 0.62 on argument extraction behind a 0.97 on tool selection," come from [Future AGI's "LLM Agent Evaluation Complete Guide 2026"](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/), which also documents a concrete closed-loop pattern: offline eval → CI gate → production trace eval (attached to live OpenTelemetry spans server-side, no added latency) → clustering of failing traces → promotion of representative failures back into the offline dataset weekly → re-optimization. Azure's guidance independently confirms the core evaluation philosophy for multi-agent systems: "agent outputs are nondeterministic, so use scoring rubrics or language-model-as-judge evaluations rather than exact-match assertions," and recommends designing testable interfaces for individual agents plus integration tests for full multi-agent workflows ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Replit-implementable pattern:**
- Store the offline eval set as a JSONL file in the repo (or a Postgres table) with one row per scenario, each carrying: user goal, system-prompt version, expected tool sequence (where deterministic), realized trajectory fields, and an outcome label — directly derivable from the Gherkin scenarios written in A.8.
- Use cheap, local/code-based checks first (schema validation, exact tool-name match, argument-schema validation) and reserve an actual LLM-as-judge call for genuinely semantic dimensions (groundedness, plan coherence, task completion) — this keeps eval cost low enough to run on every PR, matching the "re-score the full regression set every PR instead of begging for budget" economics documented in the guide above.
- Wire evals into CI (e.g., GitHub Actions, since Replit apps are typically git-backed) as a script that runs the offline set against the current agent build and exits non-zero on any dimension below its threshold — a lightweight YAML/JSON fixture per project listing dataset path, dimension, evaluator, and per-dimension pass threshold is sufficient; no dedicated eval platform is required to get the core benefit, though hosted options (LangSmith datasets, Langfuse evals) can be added later for team-wide dashboards ([Langfuse vs LangSmith comparison](https://www.youtube.com/watch?v=HH887f9sozs)).

---

### B.13 Observability — OpenTelemetry GenAI semantic conventions and tracing

**Rule:** Instrument every LLM call, tool execution, and agent handoff as a span, using vendor-neutral semantic conventions so traces are portable across observability backends. At minimum, capture per-span: model/provider identity, token usage (input/output/cached), latency, tool name and arguments, and — where evaluation is attached — the eval score/label as span attributes so the trace tree and the quality score live together.

**Rationale:** OpenTelemetry maintains dedicated semantic-convention categories for generative AI: **events** (inputs/outputs), **metrics** (operations), **model spans** (model operation spans), and **agent spans** (agent operation spans), plus technology-specific conventions for Azure AI Inference, OpenAI, and AWS Bedrock — meaning agent instrumentation should target the OTel GenAI spec directly rather than an ad hoc logging format, precisely so traces remain portable across tracing backends ([OpenTelemetry GenAI semantic conventions repository, via GitHub](https://github.com/open-telemetry/semantic-conventions/blob/main/docs/gen-ai/README.md)). The evaluation-guide source above documents the practical integration point: eval scores are written back as span attributes (`gen_ai.evaluation.score.value`, `gen_ai.evaluation.score.label`, `gen_ai.evaluation.explanation`) so "the trace tree and the score live on the same span" ([Future AGI, LLM Agent Evaluation Guide](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)). Azure's guidance similarly instructs teams to "instrument all agent operations and handoffs" and "track performance and resource usage metrics for each agent" as baseline observability practice for multi-agent systems ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Replit-implementable pattern:**
- Use the OpenTelemetry SDK for Node.js or Python (`@opentelemetry/api`/`opentelemetry-sdk`) with an OTLP exporter pointed at a hosted backend (e.g., a managed tracing/observability SaaS reachable over HTTPS from your Reserved VM/Autoscale deployment) — Replit does not need to host the collector itself; exporting over the network to an external OTel-compatible backend is the simplest viable pattern for a Replit app.
- If avoiding an external observability vendor initially, at minimum log structured span-shaped JSON rows (span name, attributes matching the GenAI semconv field names, start/end timestamps) into a Postgres `traces` table — this keeps you forward-compatible with full OTel adoption later, since the field names already match the spec.
- Framework-specific option: if using LangChain/LangGraph, LangSmith gives built-in tracing tightly integrated with that ecosystem; Langfuse is the open, self-hostable alternative that works with any stack (raw API calls, LlamaIndex, LangChain) and supports LLM-as-judge evals natively — either integrates via an SDK call from your existing Replit process without needing a separately hosted collector ([Langfuse vs LangSmith](https://www.youtube.com/watch?v=HH887f9sozs)).

---

### B.14 Cost/latency budgeting, caching, prompt caching, model routing

**Rule:**
- **Model routing:** route easy/common requests to smaller, cheaper models and hard/unusual requests to more capable models, using a lightweight classifier or router step — do not use your most expensive model for every call by default.
- **Prompt caching:** cache large, reused prefixes (system prompts, long reference documents, tool definitions, few-shot examples) across calls; this is now a provider-native feature requiring minimal integration work and delivering large cost/latency wins on repeated-context workloads.
- **Per-agent model assignment in multi-agent systems:** assign cheaper models to classification/extraction/formatting sub-agents and reserve the most capable model for the orchestrator/synthesis step.
- **Budget tracking:** monitor token consumption per agent and per orchestration run so optimization effort targets the actual cost drivers, not guesses.

**Rationale:** Anthropic explicitly recommends "routing easy/common questions to smaller, cost-efficient models like Claude Haiku 4.5 and hard/unusual questions to more capable models like Claude Sonnet 4.5 to optimize for best performance" as a named example of the routing workflow pattern ([Anthropic, Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)). On prompt caching specifically: Anthropic reports up to **90% cost reduction and 85% latency reduction** for long, reused prompts, with cache writes costing 25% more than base input price but cache reads costing only 10% of base input price — concrete example reductions cited include a 100K-token cached "chat with a book" prompt (−90% cost), a 10K-token many-shot prompt (−86%), and a 10-turn conversation with a long system prompt (−53%) ([Anthropic, "Prompt caching with Claude"](https://www.anthropic.com/news/prompt-caching)). OpenAI's prompt caching is automatic on supported models for prompts over 1,024 tokens, offering a 50% discount on cached input tokens with no integration changes required, and caches persist roughly 5–10 minutes of inactivity, cleared within an hour of last use ([OpenAI, "Prompt Caching in the API"](https://openai.com/index/api-prompt-caching/)). Azure's multi-agent guidance independently confirms the per-agent-model-assignment rule: "assign each agent a model that matches the complexity of its task... agents that perform classification, extraction, or formatting can often use smaller, less expensive models without a reduction in overall quality," paired with monitoring "token consumption per agent and per orchestration run" ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Replit-implementable pattern:**
- Structure prompts so the large, static portion (system instructions, tool schemas, reference docs) comes first and the small, variable portion (the actual user turn) comes last — this maximizes the cacheable prefix length for both Anthropic's explicit cache-control blocks and OpenAI's automatic prefix caching.
- Implement routing as a cheap pre-classification call (or even a non-LLM heuristic/keyword check where possible) before dispatching to the main model — store the routing decision alongside the job record so you can audit/tune the split over time.
- Log `usage.input_tokens`, `usage.output_tokens`, and (where available) `usage.cached_tokens`/cache-hit metadata per call into your `traces`/`jobs` tables (B.13) so cost-per-job and cache-hit-rate are queryable directly from Postgres without a separate cost-tracking tool — this is sufficient for a single Replit-hosted app and avoids adding another paid observability integration purely for cost tracking.

---

## Replit-Specific Platform Reference

| Capability | Replit primitive | Notes / fit for agent workloads |
|---|---|---|
| Always-on agent process / background worker | **Reserved VM deployment**, configured as a "background worker" (not web server) | Dedicated VM that never sleeps, fixed monthly cost, consistent performance — the right choice for a long-running agent loop, a queue consumer, or a chat bot that must stay connected ([Replit Deployment types](https://docs.replit.com/features/publishing/deployment-types)) |
| Variable-traffic API/web app fronting the agent | **Autoscale deployment** | Scales to zero when idle, pay-per-request — good for the user-facing API/UI layer, but be aware in-memory state (including in-memory checkpointers) is lost between scale-to-zero cycles; **all durable state must live in Postgres, not process memory**, when using Autoscale |
| SLA sweeps, checkpoint pruning, digest notifications, nightly maintenance | **Scheduled Deployment** (cron, plain-language schedule) | Runs a command on a schedule and stops; has no public URL; ideal for the SLA-timeout sweep (A.6), checkpoint retention pruning (B.8), and periodic memory-consolidation jobs ([Replit Deployment types](https://docs.replit.com/features/publishing/deployment-types)) |
| Durable state: checkpoints, jobs, plan steps, approvals, memory | **Replit PostgreSQL database** (20GB free per app) or an external **Neon** project connected via a `DATABASE_URL` Secret | Native Postgres means LangGraph's `PostgresSaver`, `pgvector` for embeddings, and plain relational tables for jobs/approvals/memory all work without adding a separate database service ([Replit Database docs](https://docs.replit.com/cloud-services/storage-and-databases/sql-database)) |
| Credentials, API keys, DB URLs, model provider keys | **Replit Secrets** | AES-256 at rest, TLS in transit, app-level or account-level scope, exposed as environment variables, shareable with collaborators ([Replit Secrets docs](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)) |
| Background job queue without adding Redis | **pg-boss** (Node.js) on top of Replit Postgres | Uses `SKIP LOCKED` for safe concurrency and ACID guarantees on your existing Postgres — avoids standing up a separate Redis service just for a job queue on a single-instance Replit deployment; BullMQ/Bee-Queue remain options if Redis is already part of the stack |
| Untrusted/agent-generated code execution | **Not natively a secure sandbox inside the main app process** | Flagged gap — do not `exec()` model-generated code in-process; call out to an external sandboxed execution service over HTTP, treated as a normal external tool call with its own timeout/circuit breaker |
| Distributed circuit-breaker/rate-limit state across multiple Autoscale instances | **Not built-in** | Flagged gap — in-process circuit breaker state doesn't share across Autoscale instances; workaround is to persist failure counters/breaker state in Postgres, or accept per-instance breakers as an approximation for lower-traffic apps |

---

## Summary of Explicit "Not Viable on Replit" Flags and Workarounds

1. **In-memory checkpointers / state (`MemorySaver`, in-process breaker state, in-process caches) do not survive Autoscale's scale-to-zero or any redeploy.** Workaround: persist all durable state (checkpoints, approvals, plan steps, memory) in Replit Postgres; use Reserved VM only where a genuinely single, always-running process is required.
2. **Hosting your own MCP server is unnecessary overhead for most single-app Replit projects.** Workaround: register tools directly with the model SDK; only add an MCP client (not necessarily a server) when consuming third-party MCP servers, and only host your own MCP server if externally exposing tools to other agent consumers.
3. **Secure sandboxing of untrusted, agent-generated code execution is not a built-in Replit primitive for your deployed app's own runtime.** Workaround: delegate code execution to an external sandboxing service reached via HTTP tool call, kept outside the main deployment process.
4. **Shared circuit-breaker/rate-limiter state across multiple Autoscale instances isn't automatic.** Workaround: persist breaker/rate-limit counters in Postgres (or accept per-instance approximation for low-traffic apps), rather than relying on in-memory singletons.
5. **Redis-dependent job queues (BullMQ, Bee-Queue) add an extra managed service most simple Replit deployments don't otherwise need.** Workaround: use `pg-boss`, which runs entirely on the Postgres you already have.

---

## Sources

- Anthropic, [Building Effective AI Agents](https://www.anthropic.com/engineering/building-effective-agents)
- Anthropic, [Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)
- Anthropic, [Prompt caching with Claude](https://www.anthropic.com/news/prompt-caching)
- OpenAI, [A practical guide to building agents (PDF)](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)
- OpenAI, [Prompt Caching in the API](https://openai.com/index/api-prompt-caching/)
- Microsoft / Azure Architecture Center, [AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)
- Google, [Agent Development Kit (ADK) — Workflow Agents](https://google.github.io/adk-docs/agents/workflow-agents/)
- LangChain, [LangGraph Persistence docs](https://docs.langchain.com/oss/python/langgraph/persistence)
- LangChain, [LangGraph Interrupts docs](https://docs.langchain.com/oss/python/langgraph/interrupts)
- AWS, [Prescriptive Guidance — Model Context Protocol (MCP) strategies (PDF)](https://docs.aws.amazon.com/pdfs/prescriptive-guidance/latest/mcp-strategies/mcp-strategies.pdf)
- OpenTelemetry, [GenAI semantic conventions repository (GitHub)](https://github.com/open-telemetry/semantic-conventions/blob/main/docs/gen-ai/README.md)
- Applied AI, [Human-in-the-Loop as Architecture](https://www.applied-ai.com/newsletter/issue-09-2025-10-16/) (citing ZenML 2025 LLMOps Database Analysis and Vanishing Gradients podcast)
- Future AGI, [LLM Agent Evaluation Complete Guide 2026](https://futureagi.com/blog/llm-agent-evaluation-complete-guide-2026/)
- CallSphere, [Building Resilient AI Agents: Circuit Breakers, Retries, Graceful Degradation](https://callsphere.ai/blog/building-resilient-ai-agents-circuit-breakers-retries-graceful-degradation)
- AgentMarketCap, [Agent Memory Architecture Wars: LangMem vs Letta vs Custom RAG](https://agentmarketcap.ai/blog/2026/04/05/agent-memory-architecture-langmem-letta-rag-production)
- IoT Digital Twin PLM, [LLM Output Validation: Structured Outputs & Guardrails](https://iotdigitaltwinplm.com/llm-output-validation-structured-outputs-guardrails-2026/)
- EvoLink, [Chatbot Content Moderation: Input, Output, Agent Guardrails](https://evolink.ai/blog/chatbot-content-moderation-api)
- DZone, [Designing Scalable Multi-Agent AI Systems (DDD + Event Storming)](https://dzone.com/articles/multi-agent-ai-ddd-event-storming)
- Wikipedia, [Service blueprint](https://en.wikipedia.org/wiki/Service_blueprint)
- InnoEdge, [AI Agent: AI Service Blueprint Builder](https://www.innoedge.com.hk/ai-design-thinking-and-innovation-agents-service-blueprint-builder/)
- Palwe, [UX strategies for agentive AI in 2025 and beyond (PDF)](https://www.computersciencejournals.com/ijcai/article/189/6-2-40-536.pdf)
- Smithery, [gptme agent onboarding skill/framework](https://smithery.ai/skills/gptme/agent-onboarding)
- Max Gherman, [Planning & Task Decomposition notes](https://www.max-gherman.dev/design/anatomy-of-ai-agent/planning-and-task-decomposition/)
- arXiv, [Understanding Specification-Driven Code Generation with LLMs](https://arxiv.org/html/2601.03878v1)
- Awesome Testing, [Mermaid diagrams: When AI Meets Documentation](https://www.awesome-testing.com/2025/09/mermaid-diagrams)
- PkgPulse, [BullMQ vs Bee-Queue vs pg-boss (2026)](https://www.pkgpulse.com/guides/bullmq-vs-bee-queue-vs-pg-boss-job-queues-nodejs-2026)
- YouTube (Langfuse/LangSmith comparison), [Langfuse vs LangSmith (2025)](https://www.youtube.com/watch?v=HH887f9sozs)
- Replit, [Deployment types](https://docs.replit.com/features/publishing/deployment-types)
- Replit, [Database (PostgreSQL)](https://docs.replit.com/cloud-services/storage-and-databases/sql-database)
- Replit, [Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)
