# Standards Areas Inventory for a Boutique Agentic AI Product Studio

**Context:** This inventory is built for a boutique AI product studio whose pipeline is: **research brief → Perplexity research → Claude (functional/technical specs, user journeys, product design) → Claude generates code → Replit for final implementation**, repeatedly shipping agentic apps and platforms as client prototypes.

Each area below includes: why it matters for this specific pipeline, what a canonical internal standard would contain, concrete artifacts/templates it would produce, common failure modes it prevents, and cited primary sources (2025–2026 where available).

---

## Cluster A — Discovery, Specification & Traceability

### A1. Discovery / Research-Brief Standards
**Why it matters:** The pipeline starts with a "research brief" that seeds Perplexity research and ultimately Claude's specs. If the brief is unstructured, everything downstream — specs, code, demo — inherits ambiguity. Since this studio repeats the same motion across many clients, a standardized brief is the highest-leverage, cheapest artifact to codify.

**What a canonical standard contains:**
- Required brief sections: business goal, target users/personas, success metrics (business + model-quality), known constraints (compliance, data residency, budget, timeline), competitive/prior-art pointers, explicit non-goals, and a "definition of prototype vs. production" statement.
- A rubric for what counts as a "researchable" question vs. an assumption to validate with the client directly.
- Guidance on separating "user needs" from "AI opportunity" so teams don't reflexively reach for agents when a deterministic workflow suffices — directly mirrored in OpenAI's guidance on [when to build an agent](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) and Google's PAIR pattern to confirm "AI adds unique value" before building ([PAIR Guidebook codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook)).

**Artifacts/templates:** `BRIEF.md` template with required frontmatter (client, goal, constraints, success metrics); a "problem-fit checklist" (deterministic vs. agentic decision tree); a research-question backlog format that Perplexity research can consume directly.

**Failure modes prevented:** Scope creep from vague goals; building an agent where a rules engine would do; rediscovering constraints mid-build; inability to evaluate "success" at demo time because no metric was defined upfront.

**Sources:** [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [Google PAIR Guidebook](https://pair.withgoogle.com/guidebook-v2/); [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents) ("start simple," "use agentic systems only when justified").

---

### A2. Spec Taxonomy & Traceability Standard
**Why it matters:** Claude produces functional specs, technical specs, user journeys, and product design from research. Without a fixed taxonomy, each engagement invents its own spec structure, making handoff to Replit implementation inconsistent and QA/traceability (which requirement led to which code / which test) impossible.

**What a canonical standard contains:**
- A layered spec taxonomy: Problem Brief → Functional Spec (user-facing behavior, journeys, acceptance criteria) → Technical Spec (architecture, data model, API/tool contracts, model/routing choices, non-functional requirements) → Implementation Plan (file/interface-level plan, scope boundaries, out-of-scope list, end-to-end verification step).
- Traceability IDs linking requirements → spec sections → code modules → test cases → demo script beats.
- Explicit adoption of Anthropic's own recommended spec workflow: interview-driven `SPEC.md` generation followed by a **fresh session** for implementation so planning context doesn't pollute execution context ([Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)): "the most useful specs are self-contained: they name the files and interfaces involved, state what is out of scope, and end with an end-to-end verification step."

**Artifacts/templates:** `SPEC.md` template (functional + technical sections), traceability matrix spreadsheet, "explore → plan → implement → commit" checklist mapped to Claude Code's four-phase workflow.

**Failure modes prevented:** Specs that can't be verified against acceptance criteria; implementation drifting from the agreed plan; inability to explain to a client why a feature was built a certain way; wasted engineering time re-deriving requirements from chat history.

**Sources:** [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices); [Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents).

---

### A3. User Journeys & Product Design Standard (Agent-Specific)
**Why it matters:** Agentic products have non-linear, multi-turn, sometimes autonomous journeys — very different from static-page UX. A standard is needed for how journeys are documented (happy path, degraded path, escalation path, error path) so design and engineering share one model.

**What a canonical standard contains:**
- Journey templates that explicitly branch on: agent confidence, tool failure, human handoff, and multi-session continuity.
- "Interaction design policies" per Google's PAIR/Gemini design guidance: defining acceptable actions, thresholds of uncertainty, and how the product responds to different model outcomes (from the [People + AI Research symposium reader](https://pair.withgoogle.com/events/SH-404-PAIR-Guidebook-v31-Colour_Spreads.pdf) and [PAIR Guidebook v2](https://pair.withgoogle.com/guidebook-v2/)).
- Explicit mapping of journeys to the six PAIR chapters: User Needs, Data Collection, Mental Models, Explainability + Trust, Feedback + Control, Errors + Graceful Failure.

**Artifacts/templates:** Journey map template with confidence/branch annotations; "mental model onboarding" copy template; error-state journey template.

**Failure modes prevented:** Users surprised by autonomous agent actions; no design for low-confidence states; onboarding that doesn't set correct expectations, leading to over-trust or under-trust.

**Sources:** [Google People + AI Guidebook v2](https://pair.withgoogle.com/guidebook-v2/); [PAIR Guidebook Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook).

---

## Cluster B — Agent Architecture & Orchestration

### B1. Agent-vs-Workflow Decision Standard
**Why it matters:** The single biggest architecture decision — and the one most likely to be skipped under client deadline pressure — is whether the use case even needs an autonomous agent. Anthropic, OpenAI, Google, and Microsoft all converge on this as the first decision gate.

**What a canonical standard contains:**
- A decision tree: direct model call → augmented single LLM call → workflow (fixed code path) → single agent with tools → multi-agent. Choose "the lowest level of complexity that reliably meets your requirements" ([Microsoft Azure Architecture Center — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- Explicit criteria for when agents are justified: complex/nuanced decision-making, unmaintainable rule systems, heavy unstructured data ([OpenAI Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Named workflow patterns to consider before reaching for full autonomy: prompt chaining, routing, parallelization (sectioning/voting), orchestrator-workers, evaluator-optimizer ([Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).

**Artifacts/templates:** One-page architecture decision record (ADR) template with the decision tree pre-filled; a "complexity justification" section required in every technical spec before an agent (vs. workflow) is approved.

**Failure modes prevented:** Over-engineered multi-agent systems for simple deterministic tasks (higher cost, latency, compounding-error risk); under-engineered single prompts for genuinely open-ended tasks that then fail unpredictably in the demo.

**Sources:** [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents); [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [Microsoft Azure — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns); [Google ADK docs](https://google.github.io/adk-docs/).

---

### B2. Multi-Agent Orchestration Pattern Standard
**Why it matters:** Once multi-agent systems are justified, the studio needs a shared vocabulary and pre-vetted pattern library rather than reinventing orchestration per client — critical for reusability across prototypes and for explaining architecture to non-technical client stakeholders.

**What a canonical standard contains:**
- A canonical pattern catalog with naming aligned across vendors: **Sequential/pipeline**, **Concurrent/parallel (fan-out/fan-in)**, **Group chat/roundtable** (including maker-checker/reflection loops), **Handoff/routing/triage**, **Magentic/dynamic/task-ledger planning**, **Manager (agents-as-tools)**, **Decentralized (peer handoff)**, **Network**, **Supervisor**, **Hierarchical (supervisor-of-supervisors)** ([Microsoft Azure AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns); [OpenAI Practical Guide](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [LangGraph Multi-Agent Concepts](https://langchain-ai.github.io/langgraph/concepts/multi_agent/)).
- Guidance on **when to split agents**: complex conditional logic outgrowing prompt templates, or tool-set overload (similarity/overlap among >10-15 tools, not raw count) ([OpenAI Practical Guide](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Anti-pattern list: unnecessary coordination complexity, meaningless specialization, latency from excess hops, mutable shared state in concurrent agents, deterministic patterns misapplied to nondeterministic workflows ([Microsoft Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Artifacts/templates:** Pattern-selection matrix (problem shape → recommended pattern); sequence/architecture diagram templates per pattern; a reusable multi-agent scaffold repo per pattern for fast client bootstrapping.

**Failure modes prevented:** Ad hoc, undocumented agent topologies that can't be debugged; premature multi-agent complexity; runaway coordination overhead; inconsistent terminology across client deliverables.

**Sources:** [Microsoft Azure Architecture Center — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns); [LangGraph Multi-Agent Systems](https://langchain-ai.github.io/langgraph/concepts/multi_agent/); [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [Google ADK docs](https://google.github.io/adk-docs/).

---

### B3. Tool / API Contract Design Standard
**Why it matters:** Agent reliability is dominated by tool design quality, not just prompt quality — Anthropic explicitly says they "spent more time optimizing tools than the overall prompt" for SWE-bench. For a studio generating many client-specific tool integrations, a contract standard prevents each new tool from being a bespoke, under-documented risk.

**What a canonical standard contains:**
- Tool design rules: descriptive, unambiguous parameter names; absolute (not relative) paths/identifiers where ambiguity caused failures; minimal viable tool set to avoid ambiguous decision points; token-efficient return payloads; poka-yoke design so mistakes are structurally hard to make ([Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents); [Anthropic — Effective Context Engineering](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).
- Treating tool specs with the same rigor as prompts — versioned, tested in a workbench against many example inputs, iterated based on observed agent mistakes.
- Tool typing per OpenAI's taxonomy: **Data tools** (retrieval), **Action tools** (writes/side effects), **Orchestration tools** (agents-as-tools) — each requiring different levels of guardrails ([OpenAI Practical Guide](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- MCP-first integration standard: prefer [Model Context Protocol](https://modelcontextprotocol.io/introduction) servers for third-party integrations to standardize discovery (`tools/list`), invocation (`tools/call`), and capability negotiation instead of bespoke per-client glue code ([MCP Architecture](https://modelcontextprotocol.io/docs/concepts/architecture)).

**Artifacts/templates:** Tool-spec template (name, description, input schema, example calls, edge cases, risk tier); MCP server checklist (capability negotiation, OAuth for remote transport, `listChanged` handling); a tool risk-rating rubric (read vs. write, reversibility, financial impact) reused from guardrail design (see D2).

**Failure modes prevented:** Agents picking the wrong tool among overlapping options; silent tool failures with no error surfaced to the agent; security exposure from overly powerful, under-scoped tools; brittle, one-off integrations that can't be reused across client projects.

**Sources:** [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents); [Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents); [Model Context Protocol — Introduction](https://modelcontextprotocol.io/introduction); [MCP Architecture Overview](https://modelcontextprotocol.io/docs/concepts/architecture); [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf).

---

### B4. Model Selection & Routing Standard
**Why it matters:** Client prototypes have wildly different cost/latency/quality tradeoffs. Without a standard, engineers default to "biggest model everywhere," inflating client demo costs and latency, or under-power critical decision points.

**What a canonical standard contains:**
- A three-step selection method: (1) set up evals to establish a baseline, (2) hit the accuracy target with the most capable available model, (3) then optimize cost/latency by downgrading to smaller models where evals hold ([OpenAI Practical Guide](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Routing pattern: cheap/fast models (e.g., Claude Haiku) for classification/simple tasks, capable models (e.g., Claude Sonnet) for hard/ambiguous decisions ([Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- Explicit cost/latency instrumentation tied to the observability standard (see D4) so routing decisions are evidence-based, not guessed.

**Artifacts/templates:** Model routing decision matrix (task type → model tier); eval-gated model swap checklist; per-client model cost dashboard template.

**Failure modes prevented:** Runaway inference costs in always-on demos; latency that breaks the perceived "magic" of a live client demo; using an underpowered model for a high-stakes decision (e.g., refund approval) without evals to catch degraded accuracy.

**Sources:** [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents).

---

### B5. Cost & Latency Budget Standard
**Why it matters:** Agentic loops (multi-step tool calls, sub-agents, retries) can silently balloon cost and response time; without an explicit budget, client demos degrade or run over hosting budget on Replit deployments.

**What a canonical standard contains:**
- Explicit per-request token/cost/latency budgets set at spec time, mapped to AWS Well-Architected guidance to "select cost-optimized models," "engineer prompts for cost," and "optimize vector stores and agent workflows" ([AWS Well-Architected Generative AI Lens](https://docs.aws.amazon.com/wellarchitected/latest/generative-ai-lens/generative-ai-lens.html)).
- Hard stop conditions for agent loops (max turns, max tool calls, timeout) as required in every agent "run" loop definition ([OpenAI Practical Guide](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Guardrails against "Unbounded Consumption" attacks/denial-of-wallet, per [OWASP LLM10:2025](https://genai.owasp.org/llm-top-10/).

**Artifacts/templates:** Budget table in the technical spec (target p50/p95 latency, cost per request, max loop iterations); load-test script; alert thresholds tied to observability dashboards.

**Failure modes prevented:** Demo-day latency spikes; unbounded agent loops burning API budget; "denial-of-wallet" from malicious or accidental repeated invocation.

**Sources:** [AWS Well-Architected Generative AI Lens](https://docs.aws.amazon.com/wellarchitected/latest/generative-ai-lens/generative-ai-lens.html); [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/); [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf).

---

### B6. Memory Architecture Standard
**Why it matters:** Agentic prototypes increasingly need to persist state across sessions (client demos that span multiple meetings, long-running tasks). Memory design is currently ad hoc across most teams and directly affects both cost (context bloat) and reliability (context rot).

**What a canonical standard contains:**
- Explicit distinction between: context-window state (ephemeral), structured note-taking/agentic memory (files like `NOTES.md` persisted outside the context window and re-read later), and platform memory tools (e.g., Claude's file-based memory tool) ([Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).
- Compaction strategy standard: when to summarize + reinitiate context, what must be preserved (architectural decisions, unresolved bugs, key file state) vs. discarded (redundant tool outputs) — modeled directly on Claude Code's own compaction approach.
- Guidance to treat context as a finite, diminishing-return resource — "context rot" awareness baked into every long-horizon agent spec.

**Artifacts/templates:** Memory architecture diagram template (session state vs. persistent store vs. platform memory); `NOTES.md`/state-file schema; compaction policy config block for CLAUDE.md.

**Failure modes prevented:** Agents "forgetting" earlier instructions mid-session; context-window overflow crashes; loss of critical state across a multi-day client engagement; excessive token spend from re-sending full history every turn.

**Sources:** [Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents); [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices); [Google ADK docs](https://google.github.io/adk-docs/) (context filtering, summarization, lazy-loading artifacts).

---

## Cluster C — Prompt & Context Engineering

### C1. Prompt & Context Engineering Standard
**Why it matters:** This is the direct successor discipline to "prompt engineering" that Anthropic itself now names as the core skill for building reliable agents — and it is the connective tissue between the studio's spec-writing (Claude) and code-generation (Claude) steps.

**What a canonical standard contains:**
- Principle: find "the smallest possible set of high-signal tokens" — context is a finite resource with an attention budget and diminishing marginal returns ([Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)).
- System prompt construction rules: extreme clarity, "right altitude" (not too brittle/hardcoded, not too vague), organized sections (e.g., `<background_information>`, `<instructions>`, `## Tool guidance`, `## Output description`), minimal-but-complete content, iterative refinement against observed failure modes.
- Few-shot example curation standard: diverse, canonical examples rather than an exhaustive edge-case list ("examples are the pictures worth a thousand words").
- Retrieval strategy standard: choose between up-front retrieval, just-in-time/progressive disclosure (agent explores via `glob`/`grep`-style primitives), or hybrid — matched to task latency/accuracy tradeoffs.
- OpenAI's complementary prompt-engineering rules of thumb: put instructions first, separate instructions from context with delimiters, be specific about desired format/length/style, show format via examples ([OpenAI — Best Practices for Prompt Engineering](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-openai-api)).

**Artifacts/templates:** System-prompt template with named sections; a prompt review checklist (clarity, altitude, examples, token budget); a "context sources" inventory per agent (system prompt, tools, MCP resources, message history, retrieved docs).

**Failure modes prevented:** Context rot / degraded recall in long sessions; bloated prompts that dilute genuinely important instructions; agents given a "laundry list" of edge cases instead of clear canonical behavior; inconsistent prompt quality across client projects because there's no shared review bar.

**Sources:** [Anthropic — Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents); [OpenAI — Best Practices for Prompt Engineering with the OpenAI API](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-openai-api); [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents).

---

### C2. Model Spec / Behavioral Alignment Standard
**Why it matters:** As the studio's agents act with increasing autonomy on behalf of clients' end users, the team needs a shared reference for "how should the model behave when instructions conflict, when a request is unsafe, or when the user's intent is ambiguous" — otherwise every client project re-litigates these questions informally.

**What a canonical standard contains:**
- Adoption of a "chain of command" mental model (platform > developer/system > user instructions) to structure system prompts and guardrails consistently, referencing model providers' published specs and prompting guidance (e.g., [OpenAI prompt engineering guidance](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-openai-api)).
- A studio-level "behavioral defaults" doc: default refusal/escalation behavior, tone, verbosity, and disclosure obligations (see F3) that individual client system prompts inherit rather than reinvent.

**Artifacts/templates:** Studio "base system prompt" library per model family; conflict-resolution decision table (user vs. developer vs. safety instruction precedence).

**Failure modes prevented:** Inconsistent agent "personality"/policy across client projects; agents that don't know how to prioritize conflicting instructions; reinventing safety boilerplate per project.

**Sources:** [OpenAI — Best Practices for Prompt Engineering](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-openai-api); [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf) (instructions/guardrails sections).

---

## Cluster D — Safety, Security & Governance

### D1. Guardrails & Safety Standard
**Why it matters:** Every client prototype that takes autonomous action needs a layered defense, not a single filter — and this is explicitly one of the most commonly under-built areas in fast-moving prototype work.

**What a canonical standard contains:**
- Layered guardrail taxonomy per OpenAI: **relevance classifier**, **safety classifier** (jailbreak/prompt-injection detection), **PII filter**, **moderation**, and **tool safeguards** rated by risk (read vs. write, reversibility, permission scope, financial impact) ([OpenAI Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Rules-based (deterministic) protections layered under LLM-based ones: blocklists, input length limits, regex filters — "a single guardrail is unlikely to provide sufficient protection."
- Explicit escalation trigger table: failure-threshold triggers (repeated misunderstanding) and high-risk-action triggers (irreversible/financial actions) requiring human intervention (see D-block and E2).
- Reusable, open guardrail tooling reference: OpenAI's open-source [Guardrails library](https://openai.com/index/introducing-agentkit/) for PII masking/jailbreak detection.

**Artifacts/templates:** Guardrail layering diagram (input classifiers → routing → tool risk gate → output validation); tool risk-rating rubric (reused from B3); incident playbook for guardrail breach.

**Failure modes prevented:** Prompt-injection-driven data leaks; brand-damaging off-topic or unsafe outputs in client demos; unchecked high-risk tool calls (e.g., agent issuing a refund or sending an email with no review).

**Sources:** [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [OpenAI — Introducing AgentKit (Guardrails)](https://openai.com/index/introducing-agentkit/); [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/).

---

### D2. Security & Authorization for Agents Standard (incl. Prompt Injection, Least Privilege)
**Why it matters:** Agents that call tools/APIs on behalf of client end-users are a fundamentally new attack surface. The studio ships many quick prototypes; without a repeatable security baseline, each one risks shipping the same class of vulnerability (e.g., excessive agency, prompt injection via untrusted content).

**What a canonical standard contains:**
- Direct mapping to the [OWASP Top 10 for LLM Applications (2025)](https://genai.owasp.org/llm-top-10/): LLM01 Prompt Injection, LLM02 Sensitive Information Disclosure, LLM03 Supply Chain, LLM04 Data and Model Poisoning, LLM05 Improper Output Handling, LLM06 Excessive Agency, LLM07 System Prompt Leakage, LLM08 Vector/Embedding Weaknesses, LLM09 Misinformation, LLM10 Unbounded Consumption ([OWASP GenAI Security Project](https://genai.owasp.org/llm-top-10/); [OWASP LLM Top 10 PDF v2025](https://owasp.org/www-project-top-10-for-large-language-model-applications/assets/PDF/OWASP-Top-10-for-LLMs-v2025.pdf)).
- Mitigations required by standard: constrain model behavior via system prompt scoping; validate/enforce output formats deterministically; segregate and label untrusted external content before it enters the prompt (indirect prompt-injection defense); enforce least-privilege tool access with app-owned API tokens rather than model-held credentials; require human approval for high-risk/irreversible actions; run adversarial/red-team testing treating the model as an untrusted user.
- Emerging agent-specific threat catalog from the [OWASP Agentic Security Initiative — Agentic AI Threats and Mitigations](https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/), plus related resources ([State of Agentic AI Security and Governance](https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/), AIUC-1 crosswalk) — the studio should track this initiative as it matures.
- Zero Trust / defense-in-depth architecture per [AWS Prescriptive Guidance — Securing Generative AI](https://docs.aws.amazon.com/prescriptive-guidance/latest/agentic-ai-security/owasp-top-ten.html): agent scoping, threat modeling, treating prompts as code artifacts (version-controlled, reviewed), adaptive authentication, session isolation, continuous security posture monitoring.

**Artifacts/templates:** Agent threat-model template (STRIDE-style, adapted for prompt injection/excessive agency); least-privilege access matrix per tool; secrets-handling checklist (see F2); red-team test script library (jailbreak/injection payloads).

**Failure modes prevented:** Indirect prompt injection via documents/emails/web content the agent reads; system prompt/secret leakage; an agent with write access to production systems taking an unauthorized irreversible action; supply-chain compromise via an unverified MCP server or model dependency.

**Sources:** [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/); [OWASP LLM Top 10 PDF](https://owasp.org/www-project-top-10-for-large-language-model-applications/assets/PDF/OWASP-Top-10-for-LLMs-v2025.pdf); [OWASP Agentic AI — Threats and Mitigations](https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/); [AWS — Mapping to OWASP Top Ten for LLM Applications](https://docs.aws.amazon.com/prescriptive-guidance/latest/agentic-ai-security/owasp-top-ten.html).

---

### D3. Human-in-the-Loop & Escalation Design Standard
**Why it matters:** Client-facing prototypes need clear rules for when the agent hands off to a human, both for safety and for UX trust — and this is explicitly one of the topics the studio may not have formalized.

**What a canonical standard contains:**
- Trigger taxonomy: failure-threshold triggers (e.g., N failed clarification attempts) and high-risk-action triggers (irreversible, financial, or reputationally sensitive actions) require escalation ([OpenAI Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf)).
- Design for graceful handback: the agent must clearly communicate why it's escalating and preserve all state/context for the human or next session (linking to memory architecture, B6).
- UX guidance from Google PAIR's "Errors + Graceful Failure" and "Feedback + Control" chapters: acknowledge feedback, communicate time-to-impact, give users a way forward rather than a dead end ([People + AI Guidebook](https://pair.withgoogle.com/guidebook-v2/)).
- Framework-level support: LangGraph/Agent Framework "HITL" primitives (approval workflows, `interrupt`), and Microsoft's guidance that orchestration patterns should explicitly support "HITL observers, reviewers, and escalation targets," defining whether human input is optional or mandatory ([Microsoft Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).

**Artifacts/templates:** Escalation trigger table (per client project); handoff UX copy templates ("here's what I tried, here's why I'm looping you in"); HITL checkpoint diagram embedded in the technical spec.

**Failure modes prevented:** Agents that silently fail or loop instead of escalating; users abandoned mid-task with no path forward; irreversible actions taken without any human checkpoint; loss of context when a human takes over.

**Sources:** [OpenAI — A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [Google People + AI Guidebook](https://pair.withgoogle.com/guidebook-v2/); [Microsoft Azure — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns).

---

### D4. Observability, Tracing & Cost Telemetry Standard
**Why it matters:** Multi-step agent behavior is otherwise a black box; without standardized tracing, the studio cannot debug client-reported issues, demonstrate reliability, or control cost. This is explicitly named by the studio as a topic to cover.

**What a canonical standard contains:**
- Adoption of the [OpenTelemetry GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/) (conventions have moved to a dedicated GenAI semantic-conventions repository) as the instrumentation baseline: standardized span types for LLM client calls (`gen_ai.operation.name`, `gen_ai.request.model`, `gen_ai.response.model`, `gen_ai.usage.input_tokens`/`output_tokens`), agent-invocation spans (`invoke_agent`), and tool-execution spans, so traces are portable across vendors and observability backends.
- Every agent operation and handoff must be instrumented; track metrics; design testable interfaces; use LLM-as-judge or rubric-scored integration tests as part of the trace-linked eval loop ([Microsoft Azure — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- Tooling reference stack: [Arize Phoenix](https://arize.com/docs/phoenix) (OpenTelemetry/OpenInference-based open-source tracing + evals), [LangSmith](https://docs.langchain.com/langsmith/evaluation) (dataset-based offline/online evaluation workflow), trace grading and dataset-driven evals in [OpenAI Evals](https://openai.com/index/introducing-agentkit/).
- Cost telemetry as a first-class trace attribute (token usage, model tier, per-request $ cost) tied to the cost/latency budget standard (B5).

**Artifacts/templates:** OTel instrumentation checklist per agent/tool; trace-review dashboard template; per-client cost/latency SLO dashboard; incident postmortem template referencing trace IDs.

**Failure modes prevented:** "Why did the agent do that?" being unanswerable after the fact; cost overruns discovered only at the invoice stage; regressions shipped silently because there's no trace-linked eval gate; vendor lock-in to one observability tool because instrumentation wasn't standards-based.

**Sources:** [OpenTelemetry GenAI Semantic Conventions (moved notice + pointer)](https://opentelemetry.io/docs/specs/semconv/gen-ai/); [Arize Phoenix Docs](https://arize.com/docs/phoenix); [LangSmith Evaluation Docs](https://docs.langchain.com/langsmith/evaluation); [OpenAI — Introducing AgentKit (Evals)](https://openai.com/index/introducing-agentkit/); [Microsoft Azure — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns).

---

### D5. Agent Evaluation & Regression Testing Standard
**Why it matters:** Agentic behavior is nondeterministic; without a standardized eval harness, the studio cannot know whether a prompt/tool/model change improved or broke a client prototype, and cannot make credible reliability claims at handover.

**What a canonical standard contains:**
- A layered eval taxonomy per DeepEval's model: **agentic metrics** (task completion, plan quality, tool-call correctness) for overall execution flow; **RAG metrics** (contextual relevancy/precision/recall on the retriever side; answer relevancy/faithfulness on the generator side, drawing on [Ragas](https://deepeval.com/docs/metrics-introduction) methodology); **multi-turn/conversational metrics** for chatbots; custom **G-Eval**-style LLM-as-judge metrics for bespoke client criteria ([DeepEval — Introduction to LLM Evaluation Metrics](https://deepeval.com/docs/metrics-introduction)).
- Dataset-driven eval workflow: curated datasets built from manually curated cases, historical production traces, or synthetic generation; evaluators can be human, code-based, LLM-as-judge, or pairwise comparison; run experiments and compare for benchmarking/regression/backtesting ([LangSmith Evaluation](https://docs.langchain.com/langsmith/evaluation)).
- Trace-grading and automated prompt optimization loop, as in OpenAI's Evals platform: end-to-end assessment of agentic workflows tied directly to production traces ([OpenAI — Introducing AgentKit](https://openai.com/index/introducing-agentkit/)) — note OpenAI is winding down its own Agent Builder/Evals UI by Nov 30, 2026 in favor of the Agents SDK, so the studio should design for portability across eval backends (Braintrust, LangSmith, Phoenix, DeepEval) rather than one vendor UI.
- Mandatory regression gate: no client-facing prompt/tool/model change ships without re-running the eval suite against the baseline dataset.

**Artifacts/templates:** Eval dataset schema (input, expected/reference output, rubric); eval run report template (score deltas vs. baseline); "eval-gated deploy" checklist wired into the Definition-of-Done (see G4).

**Failure modes prevented:** Silent regressions from prompt/model tweaks; no objective basis for telling a client "this works reliably"; inability to compare model/routing choices empirically; eval debt that makes later hardening (post-prototype → production) far more expensive.

**Sources:** [DeepEval — Introduction to LLM Evaluation Metrics](https://deepeval.com/docs/metrics-introduction); [LangSmith Evaluation Docs](https://docs.langchain.com/langsmith/evaluation); [OpenAI — Introducing AgentKit](https://openai.com/index/introducing-agentkit/); [Arize Phoenix Docs](https://arize.com/docs/phoenix).

---

### D6. Data Governance & PII Standard
**Why it matters:** Client prototypes routinely touch real or realistic customer data during demos; without a standard, PII handling is decided ad hoc by whichever engineer is closest to the code, creating client liability exposure.

**What a canonical standard contains:**
- Explicit PII classification and sanitization pipeline before data reaches prompts, logs, or eval datasets — masking/redaction and tokenization patterns per OWASP LLM02 mitigations ([OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/)).
- Data minimization defaults: only pass the minimum necessary fields into context; never place secrets/API keys/user-role data inside system prompts (LLM07 System Prompt Leakage mitigation) — externalize to systems the model can't directly access.
- Data source vetting: vet third-party data suppliers' T&Cs/privacy policies; audit security posture regularly (OWASP LLM03/LLM04 mitigations).
- Alignment with ISO/IEC 42001 Annex A.7 "Data for AI Systems" control category for any client wanting a governance-mature vendor ([ISO/IEC 42001:2023](https://www.iso.org/standard/42001)).

**Artifacts/templates:** PII data-flow diagram per project; synthetic/sanitized demo-data generation script; data-handling addendum for client contracts.

**Failure modes prevented:** Real client PII leaking into logs, evals, or the model provider's training pipeline; system-prompt leakage of internal role/permission structures; using unvetted third-party data sources in a client-facing demo.

**Sources:** [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/); [ISO/IEC 42001:2023](https://www.iso.org/standard/42001); [AWS Well-Architected Generative AI Lens — Security](https://docs.aws.amazon.com/wellarchitected/latest/generative-ai-lens/generative-ai-lens.html).

---

### D7. Risk Management Framework Alignment (NIST AI RMF)
**Why it matters:** Enterprise clients increasingly expect vendors to speak the language of recognized risk frameworks; adopting NIST AI RMF vocabulary internally makes the studio's ad hoc risk practices auditable and client-presentable without extra overhead.

**What a canonical standard contains:**
- Use of the NIST AI RMF's four core functions — **Govern, Map, Measure, Manage** — as the organizing structure for the studio's own internal risk checklist (applied lightly, proportionate to prototype stakes).
- Explicit reference to the [NIST Generative AI Profile (NIST-AI-600-1)](https://www.nist.gov/itl/ai-risk-management-framework), published July 2024, which identifies risks unique to generative AI and proposes prioritized actions — used as a checklist when a client's use case involves higher-stakes generative AI risk (e.g., decisions with legal/financial consequences).
- Voluntary-use framing: the studio should treat NIST AI RMF as a *lightweight internal governance vocabulary*, not a compliance mandate, but one that can be referenced in client-facing risk documentation.

**Artifacts/templates:** One-page "AI RMF lite" risk checklist per client engagement (Govern/Map/Measure/Manage sections); risk register template referencing the Generative AI Profile's risk categories.

**Failure modes prevented:** No consistent internal vocabulary for discussing AI risk with enterprise clients; ad hoc risk assessment that can't be defended in a security/procurement review.

**Sources:** [NIST — AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework).

---

### D8. Regulatory Disclosure Standard (EU AI Act Transparency)
**Why it matters:** Even boutique studios shipping prototypes for EU-facing clients (or global clients with EU users) need baseline transparency compliance; getting this wrong is a contractual and legal risk the studio can proactively remove via a template.

**What a canonical standard contains:**
- Mandatory disclosure when users interact with a chatbot/AI system: users must be informed they are interacting with a machine, per **AI Act Article 50** transparency obligations — rules come into effect August 2026 ([Shaping Europe's Digital Future — AI Act](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai)).
- Requirement that AI-generated content be identifiable, with certain categories (deep fakes, AI-generated public-interest text) clearly and visibly labeled.
- Baseline documentation practices for any component that could be classified higher-risk: risk assessment/mitigation, dataset quality controls, activity logging for traceability, clear deployer information, human oversight measures.
- A studio-standard "AI disclosure" UI component (e.g., a persistent "You're talking to an AI" banner/footer) that can be dropped into every client prototype by default.

**Artifacts/templates:** AI disclosure UI component library; EU AI Act applicability checklist (used at brief stage, A1, to flag if a client's use case triggers higher-risk obligations); AI-generated-content labeling guideline.

**Failure modes prevented:** Shipping an EU-facing prototype with no AI disclosure; client legal exposure discovered late; missed obligations for higher-risk classifications.

**Sources:** [European Commission — AI Act, Shaping Europe's Digital Future](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai).

---

### D9. AI Management System Standard (ISO/IEC 42001 Alignment)
**Why it matters:** ISO/IEC 42001 is rapidly becoming the de facto AI governance credential in enterprise procurement. Even without pursuing certification, the studio benefits from adopting its lifecycle/control vocabulary so client due-diligence questionnaires can be answered quickly and consistently.

**What a canonical standard contains:**
- Lightweight adoption of the AI system lifecycle model: inception, design and development, verification and validation, deployment, operation and monitoring, retirement — mapped onto the studio's own research→spec→code→Replit→handover pipeline ([ISO/IEC 42001:2023](https://www.iso.org/standard/42001)).
- Use of the Annex A control categories as a menu (not full certification): A.5 Impact Assessments, A.6 AI System Life Cycle, A.7 Data for AI Systems, A.8 Information for Interested Parties, A.9 Use of AI Systems, A.10 Third-Party/Customer Relationships.
- A studio-level "AI system inventory" — every client agent/prototype logged with its role classification (provider/producer/customer) and lifecycle stage, forming the seed of a future certification effort if enterprise clients demand it.

**Artifacts/templates:** AI system inventory spreadsheet (client, system, role, lifecycle stage, risk tier); lightweight AI System Impact Assessment (AISIA) template used for any higher-stakes client engagement.

**Failure modes prevented:** Inability to answer enterprise security/procurement questionnaires quickly; no internal record of what AI systems have been built and where they stand in their lifecycle; ad hoc, non-repeatable governance that undermines the studio's credibility with regulated clients.

**Sources:** [ISO/IEC 42001:2023 — AI management systems](https://www.iso.org/standard/42001).

---

## Cluster E — UX, Design & Human Factors

### E1. AI-Specific UX & Trust Calibration Standard
**Why it matters:** Agentic products break standard UX conventions (non-deterministic output, autonomous action, variable confidence). The studio's designers need a shared, evidence-based playbook rather than improvising per client.

**What a canonical standard contains:**
- Google PAIR's six-chapter model applied as a design review checklist: **User Needs + Defining Success**, **Data Collection + Evaluation**, **Mental Models**, **Explainability + Trust**, **Feedback + Control**, **Errors + Graceful Failure** ([People + AI Guidebook](https://pair.withgoogle.com/guidebook-v2/)).
- Trust-calibration techniques: show what data informed a prediction, reveal cause-effect between user action and system output, provide detailed rationale in low-confidence/high-stakes situations, use N-best classifications or numeric confidence displays where appropriate.
- Nielsen Norman Group's finding that clean, confident, fast chatbot responses train users to *stop verifying* — meaning UX must deliberately counteract over-trust, especially in high-stakes domains (tax, compliance, health) rather than optimizing purely for perceived fluency ([NN/g research on chatbot trust](https://www.nngroup.com/articles/)).
- Generative UI guidance: when the studio's prototype personalizes/generates interface elements dynamically, define "must show / should show / never show" constraints, preserve UI predictability, and account for accessibility gains and privacy risk from the increased personalization data needed ([NN/g — Generative UI and Outcome-Oriented Design](https://www.nngroup.com/articles/generative-ui/)).

**Artifacts/templates:** AI UX review checklist (six PAIR chapters as sections); trust-calibration copy patterns library; GenUI constraint spec template ("must/should/never show").

**Failure modes prevented:** Users over-trusting confident-sounding but wrong output; no path for users to build an accurate mental model of system limits; personalized/generative interfaces that feel erratic or violate expected UI conventions; accessibility regressions from dynamically generated UI.

**Sources:** [Google People + AI Guidebook v2](https://pair.withgoogle.com/guidebook-v2/); [PAIR Guidebook Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook); [Nielsen Norman Group — Articles](https://www.nngroup.com/articles/); [Nielsen Norman Group — Generative UI and Outcome-Oriented Design](https://www.nngroup.com/articles/generative-ui/).

---

### E2. Human-AI Interaction Guidelines Standard (Microsoft HAX)
**Why it matters:** Microsoft's HAX Guidelines are the most systematically validated (20+ years research, peer-reviewed CHI paper) checklist for human-AI interaction and translate directly into design review gates the studio can apply to every client prototype.

**What a canonical standard contains:**
- Adoption of the **18 HAX Guidelines**, organized by interaction phase — *initial interaction*, *during interaction*, *when the AI system is wrong*, and *over time* — as a structured design review pass ([Microsoft HAX Toolkit — Guidelines for Human-AI Interaction](https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/)).
- Use of the **HAX Workbook** exercise with the client/design team to prioritize which guidelines matter most for a given prototype rather than trying to satisfy all 18 equally.
- Use of the **HAX Design Patterns library** — flexible, reusable solutions to recurring human-AI interaction problems, each documented with Problem → Solution → When to use → How to use → User benefits → Common pitfalls ([HAX Toolkit — Design Patterns](https://www.microsoft.com/en-us/haxtoolkit/design-patterns/)).

**Artifacts/templates:** HAX Guidelines checklist mapped to the studio's four-phase agent journey (E1); HAX Workbook session template used once per client project during design phase.

**Failure modes prevented:** Missing well-known failure points in AI UX (e.g., no clear way to dismiss/correct the AI, no indication of what the system can/can't do) that have already been cataloged and solved by prior research — the studio re-learning lessons the field has already codified.

**Sources:** [Microsoft HAX Toolkit — Guidelines for Human-AI Interaction](https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/); [Microsoft HAX Toolkit — Design Patterns](https://www.microsoft.com/en-us/haxtoolkit/design-patterns/).

---

### E3. Error & Fallback UX Standard
**Why it matters:** Agentic systems fail differently than deterministic software (partial completion, tool failure mid-task, low-confidence answers) — a studio-wide standard prevents each client demo from having a different, improvised failure experience.

**What a canonical standard contains:**
- Error taxonomy: user error, system error, context error (per Google PAIR's Errors + Graceful Failure chapter) — each needs a distinct recovery path.
- "Be human, not machine" tone standard for error messaging: acknowledge limits with humility, explain what happened, invite the user to continue forward rather than dead-ending them ([People + AI Guidebook](https://pair.withgoogle.com/guidebook-v2/)).
- Explicit fallback-to-non-AI-option design: define what the deterministic/manual fallback looks like when the agent cannot complete a task, tying directly to the HITL escalation standard (D3).
- Verification-and-evidence pattern from Claude Code best practices generalized to product UX: the agent should be able to *show its work* (what it tried, what happened) rather than just asserting success or silently failing ([Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).

**Artifacts/templates:** Error-state UX pattern library (per error type); fallback flow diagrams; "show your work" transcript component for agent action logs surfaced to end users.

**Failure modes prevented:** Dead-end error states with no recovery path; generic "something went wrong" messages that erode trust; users unable to tell whether the agent's silence means success or failure.

**Sources:** [Google People + AI Guidebook v2](https://pair.withgoogle.com/guidebook-v2/); [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices).

---

### E4. Accessibility Standard
**Why it matters:** Agentic/generative interfaces introduce novel accessibility risks (dynamically generated layouts, AI-written alt text, voice/chat-first interaction) that standard accessibility checklists don't fully cover yet; the studio needs an explicit extension of baseline accessibility practice.

**What a canonical standard contains:**
- Baseline WCAG-aligned accessibility checklist applied to every client prototype (keyboard navigation, screen-reader support, color contrast, focus management) as a non-negotiable QA gate.
- Alt-text guidance extended to AI-generated/dynamic content: distinguish decorative, functional, and informative images and write alt text accordingly, avoiding redundancy with visible page content ([NN/g — Alt Text guidance](https://www.nngroup.com/topic/gui/)).
- Explicit accessibility check for Generative UI features: since GenUI can tailor layouts per user, verify that personalization doesn't inadvertently degrade accessibility for a given user's needs — NN/g notes GenUI has "immense potential to improve accessibility" but this requires deliberate design, not an automatic byproduct ([NN/g — Generative UI and Outcome-Oriented Design](https://www.nngroup.com/articles/generative-ui/)).

**Artifacts/templates:** Accessibility QA checklist (WCAG-aligned + AI-specific additions); alt-text writing guide for AI-generated images; GenUI accessibility regression test.

**Failure modes prevented:** Client prototypes that fail basic accessibility audits; AI-generated alt text that's redundant or unhelpful; personalized interfaces that silently break for users with accessibility needs.

**Sources:** [Nielsen Norman Group — GUI/Accessibility articles](https://www.nngroup.com/topic/gui/); [Nielsen Norman Group — Generative UI and Outcome-Oriented Design](https://www.nngroup.com/articles/generative-ui/).

---

### E5. Design System & Tokens Standard
**Why it matters:** Because Claude generates code directly and Replit implements it, an explicit design-token/design-system standard is what keeps generated UI visually consistent with the studio's brand and reusable across client projects, rather than each Claude-generated prototype inventing its own inconsistent styling.

**What a canonical standard contains:**
- A studio-owned design token set (color, type, spacing, elevation, motion) that is fed into Claude's code-generation prompts as a hard constraint, not left to per-project improvisation.
- Component library conventions (naming, variants, states — including AI-specific states: loading/"thinking," streaming, low-confidence, error, escalation) that generated code must reuse.
- A "never hand-roll base components" rule for Claude-generated code — always resolve to the studio's component library first — reducing review burden and improving consistency across prototypes built in Replit.

**Artifacts/templates:** Design tokens JSON/CSS variables file included in every project scaffold; Figma-to-code component mapping reference; AI-state component kit (loading, streaming, confidence indicator, escalation banner).

**Failure modes prevented:** Visually inconsistent, one-off UI in every client demo; wasted design/engineering time rebuilding basic components each project; generated code that ignores brand/design guidelines because none were given as constraints.

**Sources:** Derived from cross-cutting design-system best practice; complements [Nielsen Norman Group — Generative UI](https://www.nngroup.com/articles/generative-ui/) guidance on preserving predictability and design standards even as interfaces personalize.

---

## Cluster F — Engineering, Repo & Delivery Conventions

### F1. Repo Conventions & CLAUDE.md/AGENTS.md Standard
**Why it matters:** Since Claude both writes specs and generates code, and that code goes into Replit, the studio's single highest-leverage artifact is a consistent `CLAUDE.md` (and equivalent `AGENTS.md`) convention that travels with every client repo and encodes house style once instead of per-project.

**What a canonical standard contains:**
- `CLAUDE.md` inclusion rules: bash commands Claude can't guess, code style rules that differ from language defaults, testing instructions/preferred runners, repo etiquette (branch naming, PR conventions), architectural decisions specific to the project, environment quirks/required env vars, common gotchas — and exclusion rules: nothing Claude can infer from reading code, no standard-language tutorials, no frequently-changing info, no "write clean code"-style platitudes ([Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).
- Placement convention: studio-wide defaults in a home-level file, project-shared conventions in `./CLAUDE.md` checked into git, personal/local notes in `.gitignore`d `CLAUDE.local.md`, and `@path/to/import` composition for shared fragments (e.g., `@docs/git-instructions.md`).
- A parallel **Agent Skills** convention (`SKILL.md` files under `.claude/skills/`) for the studio's own reusable domain knowledge (e.g., "our API conventions," "our Replit deploy checklist") so it loads on demand instead of bloating every `CLAUDE.md` ([Anthropic — Agent Skills docs](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview); [Anthropic — Agent Skills announcement](https://www.anthropic.com/news/agent-skills)).
- Explicit "keep it concise" test: for every line, ask "would removing this cause Claude to make mistakes?" — if not, cut it, since bloated files cause Claude to ignore real instructions.

**Artifacts/templates:** Studio-standard `CLAUDE.md` template (with placeholders for project-specific bash commands, style rules, gotchas); a reusable `.claude/skills/` library (studio conventions, Replit deploy skill, security checklist skill); `AGENTS.md` equivalent for cross-tool compatibility.

**Failure modes prevented:** Claude repeatedly making the same avoidable mistakes across sessions because context wasn't persisted; bloated, ignored CLAUDE.md files; inconsistent conventions between client repos making cross-project engineer rotation harder; tribal knowledge that lives only in one engineer's head.

**Sources:** [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices); [Anthropic — Agent Skills overview](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview); [Anthropic — Agent Skills announcement](https://www.anthropic.com/news/agent-skills).

---

### F2. Environment, Secrets & Deployment Standard (Replit-specific)
**Why it matters:** Every client prototype ends up deployed via Replit; without a fixed standard, secrets handling, environment config, and deployment-type choice are re-decided (often insecurely, under time pressure) for every engagement.

**What a canonical standard contains:**
- Secrets handling: use Replit's Secrets tool (AES-256 at rest, TLS in transit) for all API keys/tokens/connection strings, exposed to code only as environment variables — never hard-coded — with app-level vs. account-level scoping decided explicitly per project ([Replit Docs — Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets)); note Secrets are unavailable for Static Deployments, which must be factored into the deployment-type decision.
- Deployment-type decision standard mapped to the four Replit deployment types: **Autoscale** (variable-traffic apps, e.g., interactive demos with bursty usage), **Static** (no backend/no user-input transfer, e.g., pure front-end visualizations), **Reserved VM** (always-on services like bots/webhooks needing predictable pricing/performance), **Scheduled** (time-triggered jobs) ([Replit Docs — About Deployments](https://docs.replit.com/cloud-services/deployments/about-deployments)).
- Auth decision standard: choose **Replit Auth** (fastest, Replit-branded sign-in, users sign in with existing Replit accounts, zero OAuth setup) for internal/quick demos, vs. **Clerk Auth** (dedicated tenant, custom branding/login methods) for client-branded or production-leaning prototypes ([Replit Docs — Auth](https://docs.replit.com/learn/projects-and-artifacts/auth) via docs.replit.com).
- `.replit` config and Replit DB/Postgres conventions documented per project type so Claude-generated code and Replit's own Agent build against a known, consistent runtime contract.

**Artifacts/templates:** Pre-flight deployment checklist (deployment-type decision tree, secrets audit, auth choice justification); `.replit`/environment config template per common stack; a "go-live" checklist before any client demo link is shared.

**Failure modes prevented:** Hard-coded secrets committed to a client repo; choosing Static deployment for an app that actually needs secrets/backend logic; picking Reserved VM for a bursty demo (cost) or Autoscale for an always-on bot (cold-start/latency issues); auth flows that don't match the client's branding expectations.

**Sources:** [Replit Docs — Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets); [Replit Docs — About Deployments](https://docs.replit.com/cloud-services/deployments/about-deployments); [Replit Docs — Auth](https://docs.replit.com/learn/projects-and-artifacts/auth); [Replit Docs — Replit Agent](https://docs.replit.com/replitai/agent).

---

### F3. Replit Agent Workflow Standard
**Why it matters:** Since the pipeline explicitly hands Claude-generated code to Replit for "final implementation," the studio needs a house standard for how Replit's own Agent is used in that final step so it complements rather than conflicts with the Claude-authored spec/code.

**What a canonical standard contains:**
- Use **Plan mode** in Replit Agent before code changes to break the incoming Claude spec/code into an ordered task list, explore trade-offs, and get sign-off before execution — mirroring the same "explore → plan → implement" discipline used upstream in Claude Code ([Replit Docs — Replit Agent](https://docs.replit.com/replitai/agent); [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).
- Mode selection standard mapped to task size/risk: **Lite** for small visual tweaks/bug fixes, **Economy** as the default for most builds, **Power** (optionally **Turbo**) for harder problems/larger changes, **High effort** toggle for the most complex tasks.
- Checkpoint discipline: rely on Replit Agent's automatic checkpoints for rollback, but treat this as a complement to — not a replacement for — proper git history.
- Feedback loop standard: when Agent's output diverges from the spec, describe the specific deviation rather than vague "fix it" prompts, echoing Claude Code's "be specific" prompting guidance.

**Artifacts/templates:** Replit Agent mode-selection guide (task type → mode); Plan-mode task-breakdown template pre-populated from the upstream `SPEC.md`; a Replit-Agent-to-git checkpoint discipline checklist.

**Failure modes prevented:** Replit Agent silently re-deciding architecture already settled in the Claude-authored spec; wasted spend from defaulting to Power/Turbo mode for trivial changes; losing rollback ability by relying solely on Agent checkpoints instead of git.

**Sources:** [Replit Docs — Replit Agent](https://docs.replit.com/replitai/agent); [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices).

---

### F4. Framework & Abstraction Discipline Standard
**Why it matters:** The studio uses multiple agent frameworks/SDKs across client stacks (Claude Agent SDK, LangGraph, ADK, Agents SDK); an explicit discipline standard prevents each engineer from silently reaching for a different, unreviewed abstraction layer per project.

**What a canonical standard contains:**
- Anthropic's explicit recommendation: start with direct LLM APIs, since "many patterns can be implemented in a few lines of code"; if using a framework, the team must understand the underlying code and not treat it as a black box, because "incorrect assumptions about what's under the hood are a common source of customer error" ([Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)).
- A pre-approved framework shortlist with rationale for each: Claude Agent SDK, LangGraph (for graph-based multi-agent orchestration — [LangGraph Multi-Agent docs](https://langchain-ai.github.io/langgraph/concepts/multi_agent/)), Google ADK (for Google-model-centric or multi-language stacks — [ADK docs](https://google.github.io/adk-docs/)), OpenAI Agents SDK (successor to the deprecated Agent Builder UI — [AgentKit announcement](https://openai.com/index/introducing-agentkit/)), Microsoft Agent Framework ([Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)).
- Rule: reduce abstraction layers as a project matures from spec-generation toward client handover, so the final delivered code is maximally legible to the client's own future engineers (many of whom will not use the studio's framework of choice).

**Artifacts/templates:** Framework selection matrix (use case → recommended framework → rationale); "abstraction audit" checklist run before final handover.

**Failure modes prevented:** Debugging blocked by framework abstraction the team doesn't actually understand; client inheriting a codebase locked into a framework their team has no expertise in; inconsistent framework choices across the studio's portfolio making cross-project staffing harder.

**Sources:** [Anthropic — Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents); [LangGraph Multi-Agent Systems](https://langchain-ai.github.io/langgraph/concepts/multi_agent/); [Google ADK docs](https://google.github.io/adk-docs/); [OpenAI — Introducing AgentKit](https://openai.com/index/introducing-agentkit/); [Microsoft Azure — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns).

---

### F5. Versioning & Change Control Standard
**Why it matters:** Prompts, tool specs, and system instructions are as consequential as source code but are frequently left unversioned, making it impossible to bisect a regression to "which prompt/tool change broke this."

**What a canonical standard contains:**
- "Treat prompts as code artifacts": version-controlled, reviewed, diffable — directly recommended in AWS's agentic security guidance as a control for both quality and prompt-injection defense ([AWS — Mapping to OWASP Top Ten](https://docs.aws.amazon.com/prescriptive-guidance/latest/agentic-ai-security/owasp-top-ten.html)).
- Semantic versioning applied to: system prompts, tool schemas, MCP server contracts, and the eval dataset itself (so eval comparisons remain apples-to-apples across versions).
- A rollback-compatible change log for every agent-facing artifact (prompt, tool, model choice) tied to the eval regression gate (D5).

**Artifacts/templates:** Prompt/tool changelog template; versioned eval-dataset naming convention; PR template requiring "which eval suite did you run" for any agent-behavior change.

**Failure modes prevented:** Untraceable behavior regressions after a prompt tweak; no ability to roll back a bad tool-schema change; eval comparisons invalidated by silent dataset drift.

**Sources:** [AWS — Mapping to OWASP Top Ten for LLM Applications](https://docs.aws.amazon.com/prescriptive-guidance/latest/agentic-ai-security/owasp-top-ten.html); [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) (rewind/checkpoint discipline).

---

## Cluster G — Delivery, QA & Client Handover

### G1. Definition-of-Done & QA Gates Standard
**Why it matters:** "Done" for an agentic prototype is ambiguous unless explicitly defined — the studio needs a gate that combines functional QA with agent-specific reliability/safety checks before any client demo.

**What a canonical standard contains:**
- A composite DoD checklist merging: functional acceptance criteria (from the spec, A2), eval-suite pass thresholds (D5), guardrail/security checklist pass (D1/D2), accessibility checklist pass (E4), observability instrumentation present (D4), and a completed end-to-end verification step as recommended for every spec ("ends with an end-to-end verification step that proves the feature works") ([Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).
- Verification-with-evidence discipline generalized from engineering practice to QA process: every "done" claim must be backed by a runnable check (test output, eval report, screenshot) rather than an assertion.
- Adversarial review step before sign-off: a fresh-context review (subagent or human) checks the diff/build against the spec's stated criteria, flagging only correctness/requirement gaps ([Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)).

**Artifacts/templates:** DoD checklist template (per project, cross-referencing all cluster standards); QA sign-off form; adversarial-review report template.

**Failure modes prevented:** Shipping a "done" demo that hasn't actually been verified against its own spec; skipped safety/accessibility checks under deadline pressure; no shared bar for what "done" means across different client engagements.

**Sources:** [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices).

---

### G2. Client-Facing Demo & Handover Standard
**Why it matters:** The studio's business model depends on client-facing demos landing well; a standard for how demos are structured, what's disclosed, and what's handed over prevents last-minute improvisation and inconsistent client experience.

**What a canonical standard contains:**
- A demo script template that maps directly to the user-journey artifact (A3): happy path, one deliberate "agent handles ambiguity gracefully" beat, one deliberate "agent escalates/fails gracefully" beat (showing off D3/E3 work rather than hiding it).
- A standard handover package: `SPEC.md`, `CLAUDE.md`/`AGENTS.md`, eval report, security/guardrail checklist, accessibility checklist, deployment runbook (Replit config, secrets list *without values*, auth setup), and — critically — a licensing/IP memo (G3).
- AI-disclosure component (from D8) included by default in every demo, both for compliance and to model good practice to clients.

**Artifacts/templates:** Demo script template; handover package checklist/zip structure; client walkthrough deck template.

**Failure modes prevented:** Demos that only show the happy path and collapse under an obvious edge case in front of the client; handover packages missing critical operational knowledge (e.g., how secrets are managed) that block the client's own team from taking over.

**Sources:** Synthesized from [Anthropic — Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) (spec/verification discipline) and [Google People + AI Guidebook](https://pair.withgoogle.com/guidebook-v2/) (explainability/mental-model onboarding, applicable to client demos as well as end users).

---

### G3. Licensing & IP of Generated Code Standard
**Why it matters:** Explicitly flagged by the studio as a topic they may not have thought through — code is now generated by Claude and refined by Replit's Agent; ownership, license compatibility, and provenance need an explicit policy before client contracts are signed, not after.

**What a canonical standard contains:**
- A studio-standard contract clause addressing: ownership of AI-generated code (typically assigned to the client as a work product, per the studio's service agreement, independent of the underlying model vendor's terms); confirmation that generated code review has checked for verbatim reproduction of copyrighted/licensed third-party code; dependency license auditing for any packages Claude/Replit Agent introduces during generation.
- A "no unreviewed dependency" rule: any third-party library pulled in by Claude-generated or Replit-Agent-generated code must pass a lightweight license check (permissive vs. copyleft) before shipping, tying into the software-supply-chain concerns raised in [OWASP LLM03: Supply Chain](https://genai.owasp.org/llm-top-10/).
- Explicit reference in the handover package to which model providers' terms govern the underlying generation (Anthropic's and Replit's respective commercial/API terms), since this affects what warranties the studio can make to the client about code provenance.

**Artifacts/templates:** IP/licensing clause template for client SOWs; dependency license audit checklist; generated-code provenance note template (which tool generated which module, on which date, under which model version).

**Failure modes prevented:** Client disputes over code ownership after project completion; shipping a client a copyleft-licensed dependency that conflicts with their commercial distribution plans; no record of what was AI-generated vs. hand-written when questions arise later.

**Sources:** [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/) (Supply Chain risk category, informing the dependency-audit rationale).

---

### G4. Legal/Compliance Disclosure Standard (Cross-cutting)
**Why it matters:** This consolidates the studio's compliance touchpoints (EU AI Act disclosure, data handling, IP) into a single pre-delivery gate, since compliance failures are typically caught too late when treated as scattered concerns rather than one checklist.

**What a canonical standard contains:**
- A single "compliance gate" checklist run at both spec-approval and pre-demo stages, consolidating: AI Act transparency disclosure (D8), PII/data governance sign-off (D6), IP/licensing sign-off (G3), and — where relevant to the client's sector — a note on NIST AI RMF/ISO 42001 alignment posture (D7/D9) that can be shared with enterprise procurement teams.

**Artifacts/templates:** Single-page compliance gate checklist referenced from the DoD (G1).

**Failure modes prevented:** Compliance treated as an afterthought discovered only when a client's legal team asks a question the studio can't quickly answer.

**Sources:** Consolidates [European Commission — AI Act](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai); [OWASP Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/); [ISO/IEC 42001:2023](https://www.iso.org/standard/42001); [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework).

---

## Summary Table — All Standards Areas at a Glance

| # | Area | Cluster |
|---|---|---|
| A1 | Discovery / Research-Brief Standards | Discovery & Spec |
| A2 | Spec Taxonomy & Traceability | Discovery & Spec |
| A3 | User Journeys & Product Design (agent-specific) | Discovery & Spec |
| B1 | Agent-vs-Workflow Decision Standard | Architecture |
| B2 | Multi-Agent Orchestration Pattern Standard | Architecture |
| B3 | Tool / API Contract Design Standard | Architecture |
| B4 | Model Selection & Routing Standard | Architecture |
| B5 | Cost & Latency Budget Standard | Architecture |
| B6 | Memory Architecture Standard | Architecture |
| C1 | Prompt & Context Engineering Standard | Prompt/Context |
| C2 | Model Spec / Behavioral Alignment Standard | Prompt/Context |
| D1 | Guardrails & Safety Standard | Safety/Security/Governance |
| D2 | Security & Authorization (Prompt Injection, Least Privilege) | Safety/Security/Governance |
| D3 | Human-in-the-Loop & Escalation Design | Safety/Security/Governance |
| D4 | Observability, Tracing & Cost Telemetry | Safety/Security/Governance |
| D5 | Agent Evaluation & Regression Testing | Safety/Security/Governance |
| D6 | Data Governance & PII | Safety/Security/Governance |
| D7 | NIST AI RMF Alignment | Safety/Security/Governance |
| D8 | EU AI Act Transparency Disclosure | Safety/Security/Governance |
| D9 | ISO/IEC 42001 AI Management System Alignment | Safety/Security/Governance |
| E1 | AI-Specific UX & Trust Calibration | UX/Design |
| E2 | Human-AI Interaction Guidelines (Microsoft HAX) | UX/Design |
| E3 | Error & Fallback UX | UX/Design |
| E4 | Accessibility | UX/Design |
| E5 | Design System & Tokens | UX/Design |
| F1 | Repo Conventions & CLAUDE.md/AGENTS.md | Engineering/Repo |
| F2 | Environment, Secrets & Deployment (Replit) | Engineering/Repo |
| F3 | Replit Agent Workflow Standard | Engineering/Repo |
| F4 | Framework & Abstraction Discipline | Engineering/Repo |
| F5 | Versioning & Change Control | Engineering/Repo |
| G1 | Definition-of-Done & QA Gates | Delivery/Handover |
| G2 | Client-Facing Demo & Handover | Delivery/Handover |
| G3 | Licensing & IP of Generated Code | Delivery/Handover |
| G4 | Legal/Compliance Disclosure (cross-cutting gate) | Delivery/Handover |

---

## Primary Sources Consulted

- Anthropic: [Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents); [Effective Context Engineering for AI Agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents); [Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices); [Agent Skills overview](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview); [Agent Skills announcement](https://www.anthropic.com/news/agent-skills)
- Model Context Protocol: [Introduction](https://modelcontextprotocol.io/introduction); [Architecture Overview](https://modelcontextprotocol.io/docs/concepts/architecture)
- OpenAI: [A Practical Guide to Building Agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf); [Introducing AgentKit](https://openai.com/index/introducing-agentkit/); [Best Practices for Prompt Engineering](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-openai-api)
- Google: [Agent Development Kit docs](https://google.github.io/adk-docs/); [People + AI Guidebook v2](https://pair.withgoogle.com/guidebook-v2/); [PAIR Guidebook Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook); [People + AI Research symposium reader](https://pair.withgoogle.com/events/SH-404-PAIR-Guidebook-v31-Colour_Spreads.pdf)
- Microsoft: [Azure Architecture Center — AI Agent Orchestration Patterns](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns); [HAX Toolkit — Guidelines for Human-AI Interaction](https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/); [HAX Toolkit — Design Patterns](https://www.microsoft.com/en-us/haxtoolkit/design-patterns/)
- LangChain/LangGraph: [LangGraph Multi-Agent Systems](https://langchain-ai.github.io/langgraph/concepts/multi_agent/); [LangSmith Evaluation](https://docs.langchain.com/langsmith/evaluation)
- AWS: [Well-Architected Generative AI Lens](https://docs.aws.amazon.com/wellarchitected/latest/generative-ai-lens/generative-ai-lens.html); [Mapping to OWASP Top Ten for LLM Applications](https://docs.aws.amazon.com/prescriptive-guidance/latest/agentic-ai-security/owasp-top-ten.html)
- NIST: [AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
- European Commission: [AI Act — Shaping Europe's Digital Future](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai)
- OWASP: [Top 10 for LLM Applications 2025](https://genai.owasp.org/llm-top-10/); [OWASP LLM Top 10 PDF v2025](https://owasp.org/www-project-top-10-for-large-language-model-applications/assets/PDF/OWASP-Top-10-for-LLMs-v2025.pdf); [Agentic AI — Threats and Mitigations](https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/)
- ISO: [ISO/IEC 42001:2023 — AI management systems](https://www.iso.org/standard/42001)
- Nielsen Norman Group: [Articles index](https://www.nngroup.com/articles/); [Generative UI and Outcome-Oriented Design](https://www.nngroup.com/articles/generative-ui/); [GUI/Accessibility topic](https://www.nngroup.com/topic/gui/)
- Evaluation/observability tooling: [DeepEval — Introduction to LLM Evaluation Metrics](https://deepeval.com/docs/metrics-introduction); [Arize Phoenix docs](https://arize.com/docs/phoenix); [OpenTelemetry GenAI semantic conventions (pointer)](https://opentelemetry.io/docs/specs/semconv/gen-ai/)
- Replit: [Replit Agent](https://docs.replit.com/replitai/agent); [About Deployments](https://docs.replit.com/cloud-services/deployments/about-deployments); [Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets); [Auth](https://docs.replit.com/learn/projects-and-artifacts/auth)
