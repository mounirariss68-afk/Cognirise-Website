# RAG / Retrieval Layer Design for Agentic Applications (2025–2026 Best Practices)

*Scope: practical, implementable guidance for a Replit-hosted app (Node/TypeScript or Python), with a lean default on Postgres/pgvector and a scale-up path to managed vector/RAG services. Every recommendation states the rule, rationale, tradeoffs, and a concrete pattern.*

---

## 0. Executive summary

- **Default architecture for Replit apps in 2026:** Postgres (Replit Postgres, Neon, or Supabase) with the `pgvector` extension, `halfvec` storage, an HNSW index, native full-text search (`tsvector`/BM25-like ranking) fused via Reciprocal Rank Fusion (RRF), a cross-encoder reranker (Cohere or open-source BGE), and contextual-chunk enrichment before embedding — this stack now competes with dedicated vector databases on quality up to tens of millions of vectors ([Tiger Data hybrid search guide](https://www.tigerdata.com/docs/build/examples/hybrid-search); [pgvector GitHub](https://github.com/pgvector/pgvector)).
- **Chunking is the highest-leverage lever.** Anthropic's Contextual Retrieval — prepending a short LLM-generated context blurb to each chunk before embedding and before BM25 indexing — cut retrieval failure rate by 49%, and by 67% combined with reranking, versus naive chunking ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)).
- **Retrieval quality compounds across three independent stages** — chunking/indexing, query-time transformation, and reranking — and each should be evaluated and tuned separately ([Future AGI RAG evaluation guide](https://futureagi.com/blog/rag-evaluation-metrics-2025/); [Crux Digits retrieval quality](https://cruxdigits.nl/blog/rag-evaluation-retrieval-quality/)).
- **Long-context LLMs do not eliminate RAG.** They reduce the need for aggressive chunking and enable larger reranked context windows, but retrieval remains cheaper, more auditable, and more scalable than stuffing entire corpora into context on every call.
- **GraphRAG, agentic/self-querying retrieval, and late-interaction (ColBERT/ColPali) models are 2025's advanced tier** — valuable for multi-hop reasoning, structured filtering, and visually-rich documents respectively, but add operational cost and should be adopted only after a solid baseline pipeline is instrumented and evaluated ([Microsoft GraphRAG docs](https://microsoft.github.io/graphrag/); [jina-embeddings-v4 / late interaction paper](https://aclanthology.org/2025.mrl-main.36.pdf)).
- **Security is not optional at the retrieval layer.** Multi-tenant RAG must enforce isolation at the database level (Postgres Row-Level Security), not just in application filters, and must treat retrieved content as untrusted input vulnerable to prompt injection ([Pradeep Bhandari, pgvector multi-tenancy RLS](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide); [RAG pipeline security hardening](https://www.systemshardening.com/articles/ai-landscape/rag-pipeline-security/)).

---

## 1. Ingestion

### 1.1 Source connectors and crawling

**Rule:** Separate "fetch" (connector/crawler) from "parse" (document understanding) from "load" (chunk + embed + upsert) as distinct, independently retryable pipeline stages, each with its own idempotency key.

**Rationale:** Sources fail independently (rate limits, auth expiry, malformed files) from parsing failures (bad OCR, corrupt PDFs) and from loading failures (DB timeouts, embedding API errors). Coupling them forces a full re-crawl on any downstream error.

**Concrete pattern (Replit-viable):**
- Use per-source connector modules (Google Drive API, Notion API, S3 listing, web crawler) that write raw bytes + source metadata (`source_id`, `source_uri`, `content_hash`, `fetched_at`, `etag`/`last_modified`) into a `raw_documents` staging table or object storage bucket.
- A separate worker polls `raw_documents` for `status = 'pending'`, parses, chunks, embeds, and upserts, updating status transactionally.
- On Replit, use a background worker (Node `cron` package or a scheduled Repl) since Replit's HTTP-triggered compute is not ideal for long-running crawls; offload heavy crawling to a queue (e.g., a Postgres-backed job queue table) processed by a worker process.

### 1.2 File parsing: PDFs, tables, scans, layout

**Rule:** Choose a parser tier based on document complexity and volume, not a single one-size-fits-all library.

| Tool | Best for | Notes |
|---|---|---|
| **Docling** (IBM) | Local/self-hosted layout-aware parsing of PDFs, DOCX, PPTX with table structure | Open source, runs without external API calls — good fit for cost-sensitive or data-residency-constrained Replit apps |
| **Unstructured** (`unstructured` OSS + Unstructured Platform) | General-purpose partitioning of PDFs, HTML, Word, and dozens of formats into typed "elements" (Title, NarrativeText, Table, etc.) | OSS library requires system deps (`poppler-utils`, `tesseract-ocr`, `libreoffice`); hosted Platform adds chunking, embedding, and image/table enrichment via API ([Unstructured GitHub](https://github.com/Unstructured-IO/unstructured)) |
| **LlamaParse** (LlamaIndex/LlamaCloud) | Complex PDFs with mixed tables/text, needs LLM-assisted layout reconstruction | Managed API, strong at markdown-faithful table reconstruction; pairs natively with LlamaIndex retrieval pipelines |
| **Reducto** | High-accuracy production document parsing at scale (finance, healthcare, legal) | Vision-language-model-based "agentic OCR"; reports 99.24% extraction accuracy in healthcare and benchmarks on RD-TableBench for complex/merged-cell tables; provides bounding-box citations per extracted element for traceability ([Reducto Parse API docs](https://llms.reducto.ai/document-parsing-api)) |
| **Vision-model OCR (GPT-4o/Claude/Gemini as OCR)** | Scanned documents, handwriting, non-standard layouts, low volume | Flexible and often more accurate on messy scans than template-based cloud OCR (AWS Textract, Azure Document Intelligence, GCP Document AI), but higher per-page cost and latency; use selectively for pages that fail deterministic parsers |

**Tradeoffs:** Self-hosted/OSS (Docling, Unstructured OSS) minimizes per-page cost and keeps data in-repo but requires more engineering and infrastructure (OCR binaries, table-detection models) and may lag on very messy scanned documents. Managed parsers (Reducto, LlamaParse, cloud OCR) cost per-page but deliver much higher fidelity on tables, merged cells, and rotated/mixed layouts with far less engineering time ([Reducto comparison table: agentic parser vs cloud OCR](https://llms.reducto.ai/document-parsing-api)).

**Concrete pattern:** Route documents by a cheap pre-classifier (page count, presence of scanned-image pages via a quick text-layer check, table density heuristic): digital-native text-heavy PDFs → Docling/Unstructured (free); table-heavy or scanned/low-quality → Reducto or LlamaParse; edge cases that fail structured parsing → vision-model OCR fallback with a retry budget.

### 1.3 Normalization

**Rule:** Normalize whitespace, unicode (NFKC), encoding, and heading/table markup into a consistent markdown-like intermediate representation before chunking.

**Rationale:** Embedding models and BM25 tokenizers are sensitive to inconsistent whitespace and encoding; normalization also makes deduplication hashing reliable.

### 1.4 Deduplication

**Rule:** Deduplicate at two levels — exact (content hash) and near-duplicate (shingling/MinHash or embedding-similarity clustering).

**Concrete pattern:**
- Exact: SHA-256 hash of normalized text; skip re-embedding if hash unchanged since last sync ([dedup at scale guide](https://shayangeek.com/en/deduplicating-documents-at-scale/)).
- Near-duplicate: k-shingling + MinHash/LSH for large corpora, or a cheap embedding cosine-similarity threshold (e.g., >0.97) for smaller corpora, to catch reformatted/re-exported versions of the same document.
- Store `content_hash` per chunk and per source document; use it as the idempotency key for incremental sync.

### 1.5 Incremental sync and change detection

**Rule:** Use source-native change signals (ETags, `modified_time`, webhook/push events, or CDC) rather than full re-crawls; fall back to hash comparison when no native signal exists.

**Concrete pattern:** Maintain a `documents` table with `source_uri`, `content_hash`, `version`, `last_synced_at`. On each sync pass: fetch metadata only (not full content) where the API supports it (e.g., Drive `modifiedTime`, S3 `ETag`), compare against stored hash/version, and only fully re-fetch + re-parse + re-chunk + re-embed changed documents. This bounds both API cost and embedding cost.

### 1.6 Document/version lifecycle and deletes

**Rule:** Treat chunk rows as derived, disposable artifacts of a document version; deletes and updates must cascade.

**Concrete pattern:** Foreign-key chunks to `document_id` with `ON DELETE CASCADE`; when a document changes, delete all chunks for the old version and re-insert (simpler and safer than diffing chunk-by-chunk) inside a transaction, with an index refresh happening asynchronously (HNSW supports incremental inserts natively, so no full rebuild is required for pgvector — see §4).

---

## 2. Chunking

### 2.1 Strategy comparison

| Strategy | How it works | Best for | Tradeoff |
|---|---|---|---|
| **Fixed-size** | Split every N tokens/characters with overlap | Quick baseline, uniform docs | Cuts across semantic boundaries, breaks tables/code |
| **Recursive (structure-first)** | Split on paragraph → sentence → token boundaries recursively until size target met | General text, markdown, code | Good default; still boundary-agnostic to meaning |
| **Semantic chunking** | Split where embedding similarity between adjacent sentences drops below a threshold | Long-form prose, articles | More coherent chunks; costs extra embedding calls at ingest time |
| **Structure-aware** | Split on document structure (headings, sections, table boundaries, code blocks) | Technical docs, contracts, code repos | Requires layout-aware parsing upstream (Docling/Unstructured/LlamaParse) |
| **Late chunking** | Embed the *entire* long document first with a long-context embedding model, then pool token embeddings per chunk *after* the transformer pass, right before mean pooling | Any corpus using long-context embedding models; removes the context-loss problem without an LLM call | Requires a long-context embedding model (8k+ token window); no additional training needed but not all embedding APIs expose token-level pooling ([Late Chunking paper, arXiv:2409.04701](https://arxiv.org/abs/2409.04701)) |

**Rule of thumb for size/overlap:** Start at 400–800 tokens per chunk with 10–15% overlap for prose; use structure-aware boundaries (never split mid-table or mid-code-block) for technical content; validate empirically against your own eval set rather than trusting a universal number, since optimal chunk size is corpus- and query-dependent.

### 2.2 Contextual retrieval / contextual chunk headers (Anthropic)

**Rule:** Prepend a short (50–100 token) LLM-generated context blurb — naming the source document, section, entity, and time period — to each chunk before both embedding and BM25 indexing.

**Rationale:** Naive chunking strips context (e.g., "the company's revenue grew 3%" loses which company, which quarter). This is the single highest-ROI chunking technique documented for 2024–2025.

**Reported results** ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)):

| Technique | Top-20 retrieval failure rate | Improvement vs. baseline |
|---|---:|---:|
| Baseline (naive chunk embeddings) | 5.7% | — |
| + Contextual Embeddings | 3.7% | 35% reduction |
| + Contextual Embeddings + Contextual BM25 | 2.9% | 49% reduction |
| + Reranking (Cohere) on top of both | 1.9% | 67% reduction |

**Cost:** With Claude prompt caching, generating contextualized chunks costs ~$1.02 per million document tokens (one-time, at ingest), with prompt caching cutting latency >2x and cost up to 90% versus uncached generation ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)).

**Concrete pattern:** At ingest time, for each chunk, call a cheap/fast model (e.g., Claude Haiku or GPT-4o-mini) with the full document + the chunk, prompting: "Give a short succinct context (50–100 tokens) situating this chunk within the document, for the purpose of improving search retrieval. Answer only with the context." Prepend the result to the chunk text before embedding and before writing to the full-text index column.

### 2.3 Parent-document / small-to-big retrieval

**Rule:** Embed and search small chunks (high precision for matching), but return the larger parent chunk/section to the LLM (more context for generation).

**Concrete pattern:** Two implementations are standard — (1) small child chunks with a `parent_id` foreign key to a larger stored parent chunk, fetched after the child chunk matches; (2) "sentence window" retrieval, where a single sentence is embedded/matched but a window of N surrounding sentences is returned. Both are supported natively as retriever patterns in LlamaIndex and via custom SQL joins in a Postgres implementation (child chunk table has `parent_chunk_id`, retrieval query does a join after top-k child match).

### 2.4 Propositions

**Rule:** For very high-precision retrieval requirements, decompose text into atomic, self-contained factual propositions (one fact per unit) rather than arbitrary-length chunks, at the cost of an LLM decomposition pass per document and a larger number of stored units.

### 2.5 Table and code handling

**Rule:** Never split a table or code block across chunk boundaries; treat each table as one chunk (or one chunk per logical row-group for very large tables) and preserve markdown/HTML table structure rather than flattening to plain text, since flattening destroys row/column relationships that both embedding models and LLMs need to reason over tabular data. For code, chunk along function/class boundaries using an AST-aware splitter, not fixed token windows.

---

## 3. Embeddings

### 3.1 Model landscape (2025–2026)

| Model | MTEB (approx.) | Dimensions | Notes |
|---|---:|---:|---|
| Gemini Embedding (Google) | ~68.3 | 3072 | Strong multilingual + multimodal, competitively priced |
| Qwen3-Embedding-8B | ~70.6 | 4096 | Open-source (Apache), strong multilingual, self-hostable |
| Jina Embeddings v4 | ~71.7 | 1024–2048 | Multimodal (text+image), single- and multi-vector modes, strong on visually-rich documents ([Jina v4 paper](https://aclanthology.org/2025.mrl-main.36.pdf)) |
| Voyage 3/4 (large) | ~66.8 | 1024–2048 | Strong domain-specific/legal/finance variants; used heavily alongside Anthropic-based stacks |
| Cohere Embed v4 | ~65.2 | 1536 | 128K context, enterprise-oriented, multimodal |
| OpenAI text-embedding-3-large/small | ~64.6 | 3072 / 1536 | Ubiquitous, native Matryoshka truncation support, simple integration |
| BGE-M3 (BAAI) | ~63.0 | 1024 | Open-source, supports dense+sparse+ColBERT-style multi-vector in one model, self-hostable, good multilingual coverage |
| Nomic-embed-text-v1.5 | ~59.4 | 768 | Budget/open option with native Matryoshka support |

*(Scores vary by benchmark snapshot and are directional, not authoritative rankings — always validate against your own retrieval eval set before committing; see [MTEB leaderboard comparison](https://app.ailog.fr/en/blog/guides/choosing-embedding-models).)*

**Rule:** Default to a well-supported hosted model (OpenAI `text-embedding-3-large`, Voyage-3, Cohere Embed v4, or Gemini Embedding) for a lean Replit build — self-hosting embedding models (BGE-M3, Qwen3-Embedding) is viable only once volume justifies the GPU/CPU inference cost and ops burden.

### 3.2 Dimensionality: Matryoshka truncation and quantization

**Rule:** Use Matryoshka Representation Learning (MRL)-trained models (OpenAI v3 models, Nomic, Gemini) to truncate embedding dimensions (e.g., 3072 → 1024 or 512) with minimal quality loss, cutting storage and index build/query cost roughly linearly with dimension.

**Rule:** Use `pgvector`'s `halfvec` type (half-precision floats, 2 bytes/dimension instead of 4) or binary quantization (`bit` type via `binary_quantize()`) to shrink index size further; when using binary quantization, always re-rank the top candidates against full-precision vectors to recover recall lost to quantization ([pgvector GitHub — halfvec and binary quantization](https://github.com/pgvector/pgvector)).

**Tradeoff:** Truncation and quantization trade a small, measurable recall loss for large gains in memory footprint, index build time, and query latency — critical on resource-constrained platforms like Replit-hosted Postgres. Always validate the recall delta on your eval set before shipping a truncated/quantized index in production.

### 3.3 Multilingual and Arabic support

**Rule:** For Arabic or other non-English/mixed-language corpora, prefer models explicitly benchmarked on multilingual retrieval (Gemini Embedding, Qwen3-Embedding, Cohere Embed v4, BGE-M3, Jina v4) over English-centric models; validate with an in-language eval set since MTEB multilingual scores do not guarantee strong Arabic-specific performance. Cohere Embed v4 and BGE-M3 explicitly market multilingual coverage including Arabic; confirm via direct benchmarking against your domain corpus before committing.

### 3.4 Cost and when to fine-tune

**Rule:** Fine-tune embeddings only after establishing that off-the-shelf models plus contextual retrieval and reranking are insufficient on your eval set — fine-tuning requires a labeled query-document relevance dataset and ongoing retraining discipline, and most retrieval quality gaps are actually chunking, hybrid-search, or reranking gaps, not embedding-model gaps.

### 3.5 Late-interaction (ColBERT/ColPali) and multimodal embeddings

**Rule:** Use late-interaction models (ColBERT-style multi-vector token embeddings, or ColPali/ColQwen for document screenshots) when single-vector bi-encoder retrieval underperforms on fine-grained matching (e.g., exact terminology, numeric precision) or on visually-rich documents (charts, forms, scanned pages) where layout carries meaning.

**Rationale:** Late-interaction models compute a "MaxSim"/Chamfer-distance style similarity between every query token and every document token embedding, giving higher precision than a single pooled vector, at the cost of much higher storage (one vector per token, not per chunk) and more complex query-time scoring infrastructure ([Jina v4 / late interaction discussion, ACL 2025](https://aclanthology.org/2025.mrl-main.36.pdf)). ColPali-style models embed document *page images* directly, skipping OCR/parsing entirely for retrieval over screenshots.

**Tradeoff:** Late-interaction and multimodal-screenshot embeddings solve real problems (layout-heavy PDFs, tables, forms) but are not yet well supported by `pgvector` at scale (multi-vector storage and MaxSim scoring are non-trivial in SQL); practical Replit-scale adoption path is to use a managed provider that supports it natively (e.g., Vespa, or Jina's own multi-vector API) rather than hand-rolling it in Postgres.

---

## 4. Indexing and storage

### 4.1 pgvector: HNSW vs IVFFlat

| Parameter | HNSW | IVFFlat |
|---|---|---|
| Build time | Slower, higher memory | Faster, lower memory |
| Query speed/recall tradeoff | Better | Worse |
| Needs pre-existing data to build? | No — can build on empty table | Yes — needs a training pass, better to build after loading data |
| Key parameters | `m` (max connections/layer, default 16), `ef_construction` (candidate list size at build, default 64), `ef_search` (candidate list size at query, default 40) | `lists` (default guidance: `rows/1000` up to 1M rows, `sqrt(rows)` beyond), `probes` (default 1; higher = better recall/slower) |

*(Parameter defaults and guidance per [pgvector official GitHub README](https://github.com/pgvector/pgvector).)*

**Rule:** Default to HNSW for production Replit/Postgres deployments — it has no training-data requirement, supports incremental inserts natively (no re-training needed as data grows), and gives a better speed/recall curve than IVFFlat at the cost of slower index builds and higher RAM. Use IVFFlat only when build time or memory during index creation is the binding constraint (e.g., very large one-time bulk loads on a small instance).

**Concrete pattern:**
```sql
-- Build after initial bulk load for best performance
CREATE INDEX CONCURRENTLY ON chunks
  USING hnsw ((embedding::halfvec(1536)) halfvec_cosine_ops)
  WITH (m = 16, ef_construction = 64);

-- At query time, tune recall/speed:
SET hnsw.ef_search = 100;
```
Use `CREATE INDEX CONCURRENTLY` in production to avoid blocking writes; increase `maintenance_work_mem` so the HNSW graph fits in memory during build (a NOTICE is emitted if it doesn't); vacuum HNSW indexes by reindexing first (`REINDEX INDEX CONCURRENTLY`) since vacuum can be slow otherwise ([pgvector GitHub](https://github.com/pgvector/pgvector)).

### 4.2 Hybrid search: full-text/BM25 + vector, fused with RRF

**Rule:** Combine Postgres native full-text search (`tsvector`/`ts_rank`, or the newer `pg_textsearch` BM25-scoring extension) with vector similarity, fused via Reciprocal Rank Fusion (RRF) rather than relying on either alone.

**Rationale:** Lexical search (BM25/full-text) excels at exact keyword, identifier, and rare-term matches; vector search excels at semantic/paraphrase matches. Fusing both consistently outperforms either alone, and is exactly what Anthropic's contextual retrieval experiments layer on top of ([Tiger Data hybrid search tutorial](https://www.tigerdata.com/docs/build/examples/hybrid-search)).

**Concrete pattern (RRF in SQL):**
```sql
WITH vector_results AS (
  SELECT id, RANK() OVER (ORDER BY embedding <=> $1) AS rank
  FROM chunks ORDER BY embedding <=> $1 LIMIT 50
),
text_results AS (
  SELECT id, RANK() OVER (ORDER BY ts_rank_cd(fts_vector, query) DESC) AS rank
  FROM chunks, plainto_tsquery('english', $2) query
  WHERE fts_vector @@ query LIMIT 50
)
SELECT COALESCE(v.id, t.id) AS id,
       COALESCE(1.0/(60+v.rank), 0) + COALESCE(1.0/(60+t.rank), 0) AS rrf_score
FROM vector_results v FULL OUTER JOIN text_results t ON v.id = t.id
ORDER BY rrf_score DESC LIMIT 20;
```
The constant `k=60` in `1/(k+rank)` is the standard RRF smoothing constant used across most hybrid-search implementations.

### 4.3 Metadata filtering and partitioning

**Rule:** Store filterable metadata (tenant_id, document_type, date, ACL tags) as native Postgres columns (not buried in JSON) and index them (B-tree/GIN) so filters can be pushed into the same query as the vector search, avoiding post-filtering that wastes the ANN index's candidate budget.

**Rule:** For very large multi-tenant corpora, consider table partitioning by `tenant_id` (Postgres declarative partitioning) so per-tenant vector indexes stay small and queries only scan relevant partitions.

### 4.4 Multi-tenancy isolation patterns

**Rule:** Enforce tenant isolation at the database engine level via Postgres Row-Level Security (RLS), not solely in application-layer `WHERE tenant_id = ?` clauses.

**Rationale:** Application-level filtering is bypassable by a bug in any code path (including background workers); RLS makes isolation the database's responsibility so that even a missed `WHERE` clause cannot leak rows across tenants ([Pradeep Bhandari, pgvector multi-tenancy RLS](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide)).

**Concrete pattern:**
```sql
ALTER TABLE chunks ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON chunks
  USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

-- In application code, per request/transaction:
SET LOCAL app.current_tenant_id = '...';
```
This also composes correctly with HNSW: the ANN index scan happens, then RLS filters rows the query planner is allowed to see, so no vector row content ever crosses tenant boundaries — critical to avoid "ghost context" leaks where index internals hint at neighboring tenants' data.

### 4.5 Index maintenance and cost

**Rule:** Monitor index bloat and re-run `ANALYZE`/`VACUUM` on the chunks table after large batch deletes (e.g., full document re-syncs); rebuild HNSW indexes periodically if update volume is very high, since HNSW graphs can degrade slightly with heavy churn.

---

## 5. Query stage

### 5.1 Query rewriting, decomposition, HyDE, multi-query

| Technique | What it does | When to use |
|---|---|---|
| **Query rewriting** | LLM reformulates a vague/conversational query into a retrieval-optimized query | Chat-style agentic apps where user queries are underspecified or reference prior turns |
| **Multi-query** | Generate several paraphrased queries, retrieve for each, merge results | Improves recall when a single phrasing under-matches relevant chunks |
| **Query decomposition** | Split a complex multi-part question into sub-questions, retrieve per sub-question | Multi-hop or comparison questions ("compare X and Y") |
| **HyDE (Hypothetical Document Embeddings)** | LLM generates a hypothetical answer document, embed *that* instead of the raw query, then retrieve by similarity to the hypothetical answer | Useful when queries are short/keyword-like and answers are long-form, since it bridges the query-document semantic gap |
| **Self-querying / structured filter extraction** | LLM extracts structured filters (dates, entities, categories) from natural language and converts them into metadata `WHERE` clauses combined with vector search | Any corpus with strong metadata (dates, authors, tags) where users express filters in natural language ("emails from last March about renewals") |

**Tradeoff:** All of the above add LLM calls (latency + cost) before retrieval even starts. Reserve decomposition/HyDE/multi-query for queries that a query-classifier or router flags as complex; use direct single-query retrieval for simple factual lookups.

### 5.2 Routing between tools/indexes

**Rule:** In agentic applications with multiple retrieval sources (structured DB, vector index, web search, graph), use an explicit router step (LLM function-calling or a lightweight classifier) to select which retrieval tool(s) to invoke per query rather than always querying everything.

### 5.3 Agentic retrieval loops

**Rule:** For complex/ambiguous queries, allow the agent to issue multiple retrieval calls iteratively (retrieve → assess sufficiency → reformulate/retrieve again) rather than a single-shot retrieve-then-generate, bounded by a max iteration count and a token/cost budget to prevent runaway loops.

### 5.4 Reranking

**Rule:** Retrieve a wider candidate set (top 50–150) with the fast bi-encoder/hybrid stage, then rerank down to the top 5–20 with a cross-encoder before passing to the LLM — this two-stage pipeline is now close to universal best practice.

| Reranker | Type | Notes |
|---|---|---|
| Cohere Rerank | Hosted cross-encoder API | Most widely benchmarked; used in Anthropic's own contextual retrieval evaluation, contributing the jump from 49% to 67% failure-rate reduction ([Anthropic, Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)) |
| Voyage Rerank | Hosted cross-encoder API | Comparable quality tier to Cohere; often paired with Voyage embeddings |
| BGE-reranker-v2-m3 | Open-source cross-encoder | Self-hostable, no per-call API cost, good for cost-sensitive or data-residency-constrained deployments |
| Jina Reranker | Hosted API | Competitive pricing/quality, supports multilingual reranking |

*(Comparison summarized from [reranker comparison analysis](https://ianas.fr/en/blog/2026/06/07/reranker-comparatif-cohere-bge-jina-voyage/): bi-encoders trade precision for speed via independent query/document encoding; cross-encoders jointly encode query+document pairs for much higher precision at the cost of being too slow for first-stage retrieval over large corpora — hence the two-stage pipeline.)*

### 5.5 Context assembly and token budgeting

**Rule:** Allocate a fixed token budget for retrieved context per generation call (e.g., 20–40% of the model's context window), fill it in reranked-priority order, and stop rather than truncating mid-chunk; always keep system prompt + user query + citations format instructions inside the same budget accounting.

### 5.6 Deduplication and diversity (MMR)

**Rule:** After reranking, apply Maximal Marginal Relevance (MMR) or a simple near-duplicate filter to avoid feeding the LLM several near-identical chunks (common when a document repeats key facts across sections), trading a small amount of pure relevance for topical diversity in the final context set.

### 5.7 Citation/provenance tracking

**Rule:** Carry `document_id`, `chunk_id`, `source_uri`, and (if available) page/bounding-box or character-offset provenance through every stage of the pipeline so the generation step can attach verifiable citations to its answer, not just a document title.

---

## 6. Generation

### 6.1 Grounding and citation enforcement

**Rule:** Require the generation prompt to (a) answer only from supplied context, (b) attach an explicit citation (chunk/document ID) to every factual claim, and (c) explicitly refuse or hedge when context is insufficient — enforced via prompt instructions plus a post-hoc groundedness check, not prompt instructions alone.

### 6.2 Refusal on insufficient evidence

**Rule:** Include an explicit "insufficient evidence" branch in the generation prompt/schema (e.g., a structured output field `has_sufficient_evidence: boolean`) so the model has a low-cost, well-defined way to decline rather than hallucinating a plausible-sounding answer.

### 6.3 Structured answers with source spans

**Rule:** Use structured output (JSON schema / function-calling) for the answer, with a `claims` array where each claim carries its supporting `chunk_id`(s), rather than free-text answers with citations bolted on afterward — this makes downstream faithfulness checking and UI citation rendering both tractable.

### 6.4 Hallucination mitigation and groundedness checking

**Rule:** Run an automated groundedness/faithfulness check (either a second LLM call as a judge, or a dedicated NLI-style groundedness classifier) on generated answers against their cited chunks before returning to the user, especially in production monitoring — this is the generation-side complement to the retrieval-side recall/precision metrics ([Future AGI RAG evaluation metrics guide](https://futureagi.com/blog/rag-evaluation-metrics-2025/)).

**Concrete definitions** (from the same source):
- **Faithfulness** — does the whole answer avoid fabrication relative to the retrieved context?
- **Groundedness** — is each individual sentence/claim in the answer supported by the context (finer-grained than faithfulness)?
- **Answer relevance** — is the answer actually on-topic for the question asked?

---

## 7. Advanced topics

### 7.1 GraphRAG and knowledge graphs

**What it is:** Microsoft's GraphRAG extracts a knowledge graph (entities, relationships, key claims) from a corpus, performs hierarchical community detection using the Leiden algorithm, generates bottom-up community summaries, and uses these structures — instead of or alongside plain vector search — to answer questions ([Microsoft GraphRAG official docs](https://microsoft.github.io/graphrag/)).

**Query modes:**
- **Global Search** — holistic questions over the whole corpus, using community summaries.
- **Local Search** — questions about specific entities, fanning out to graph neighbors.
- **DRIFT Search** — local search enriched with community context.
- **Basic Search** — falls back to standard top-k vector RAG when graph structure isn't needed.

**Rule:** Adopt GraphRAG only for corpora and query patterns that plain vector/hybrid RAG demonstrably fails on — specifically (a) questions requiring traversal across disparate facts connected by shared entities/attributes, and (b) questions requiring holistic summarization over large document collections — since graph extraction and community summarization add significant ingest-time LLM cost and pipeline complexity versus a vector/hybrid baseline ([Microsoft GraphRAG docs](https://microsoft.github.io/graphrag/)). Note that some third-party "GraphRAG 2.0" performance claims circulating online are not corroborated by Microsoft's own documentation and should be treated with caution; validate any GraphRAG performance claims on your own eval set rather than trusting vendor blog benchmarks.

### 7.2 Memory vs. RAG boundary

**Rule:** Treat "memory" (durable facts about a user/session that should persist and update, like preferences or conversation history) and "RAG" (retrieval over a largely static or slowly-changing external knowledge corpus) as architecturally distinct systems with different write patterns (memory: frequent small upserts scoped to a user/session; RAG: batch ingest scoped to a corpus) even if they share the same underlying vector store — conflating them leads to memory writes polluting the shared knowledge base's relevance signal, and vice versa.

### 7.3 Agentic / deep-research retrieval loops

**Rule:** For "deep research" style agentic workflows, structure the loop explicitly as plan → retrieve → read/synthesize → identify gaps → retrieve again → terminate (on sufficiency or budget), with hard caps on iteration count, total tokens, and wall-clock time to bound cost and latency.

### 7.4 Caching, freshness, and TTL

**Rule:** Layer caching at two levels — exact-match (hash-based) cache for identical queries, and semantic cache (embed the query, match against cached query embeddings above a similarity threshold, typically 0.92–0.97 in 2025–2026 production systems) for paraphrased repeats — always falling through to a fresh LLM/retrieval call on cache miss, and always checking a TTL and prompt/template version on cache hit to avoid serving stale answers after a knowledge base update ([Future AGI semantic caching guide](https://futureagi.com/blog/what-is-semantic-caching-llms-2026/)).

**Concrete numbers:** Exact-match cache hits return in under 5ms; semantic cache hits typically add 8–80ms for the embedding + lookup step; typical hit rates run 5–20% for customer-facing queries and 30–60% for repetitive agent-internal loops ([Future AGI semantic caching guide](https://futureagi.com/blog/what-is-semantic-caching-llms-2026/)).

### 7.5 Long-context vs. RAG tradeoffs

**Rule:** Do not treat long-context windows as a replacement for retrieval. Long context helps in two ways — it reduces the penalty for slightly-too-large chunks, and it lets you pass more reranked candidates into generation — but stuffing an entire corpus into context on every call remains far more expensive (linear token cost per call) and less auditable (no explicit relevance ranking or citation provenance) than retrieval, and quality on "needle in a haystack" tasks still degrades as context length grows for most models. Use RAG as the default; use long-context primarily to widen the *post-retrieval* context budget, not to skip retrieval entirely.

---

## 8. Evaluation

### 8.1 Two-stage evaluation model

A complete RAG evaluation program must track **at least one retrieval-stage metric and at least one generation-stage metric** — tracking only generation hides retrieval regressions, and tracking only retrieval misses fabrication ([Future AGI RAG evaluation metrics guide](https://futureagi.com/blog/rag-evaluation-metrics-2025/)).

| Stage | Metric | What it measures |
|---|---|---|
| Retrieval | **Recall@k** | Of all passages that should have been retrieved, what fraction appeared in the top k? The single most important retrieval metric — if the answer-bearing chunk isn't in top-k, the LLM cannot ground its answer ([Crux Digits retrieval quality guide](https://cruxdigits.nl/blog/rag-evaluation-retrieval-quality/)) |
| Retrieval | **Precision@k** | Of the k retrieved passages, what fraction were actually relevant? Low precision dilutes context with noise |
| Retrieval | **MRR (Mean Reciprocal Rank)** | Rewards ranking the first relevant result as high as possible |
| Retrieval | **nDCG** | Rewards ranking *all* relevant results highly, penalizing relevant results buried low |
| Retrieval (generation-adjacent) | **Context precision / context recall** | Whether the retrieved passages contained everything needed (recall) and whether useful passages were ranked above useless ones (precision) — bridges retrieval and generation evaluation |
| Generation | **Faithfulness** | Whole-answer fabrication vs. context |
| Generation | **Groundedness** | Per-sentence unsupported claims |
| Generation | **Answer relevance** | Off-topic answers |

**Diagnostic pattern:** Strong recall + weak MRR → the right chunk is present but ranked too low → add/tune a reranker. Strong precision + weak recall → retriever is too conservative → improve chunking or add hybrid search ([Crux Digits retrieval quality guide](https://cruxdigits.nl/blog/rag-evaluation-retrieval-quality/)).

### 8.2 Frameworks

| Framework | Focus | Notes |
|---|---|---|
| **Ragas** | RAG-specific metrics (faithfulness, context precision/recall, answer relevancy) | Purpose-built for RAG, widely adopted, integrates with LangChain/LlamaIndex |
| **DeepEval** | Broader LLM eval, pytest-style test integration | Good fit for CI regression gates given its test-runner design |
| **TruLens** | Tracing + evaluation with "feedback functions" | Strong for production observability plus eval |
| **Arize Phoenix** | Open-source LLM observability/tracing + eval | Good for tracing retrieval + generation spans in production |
| **LangSmith** | Tracing, datasets, evaluation, monitoring for LangChain-based apps | Tightly integrated if already using LangChain/LangGraph |

### 8.3 Synthetic test set generation and CI regression gates

**Rule:** Generate a golden question set both manually (from real user queries/support tickets) and synthetically (LLM-generated question-answer-source triples from your corpus), and run retrieval + generation metrics against this set as a CI gate on every pipeline change (chunking strategy, embedding model, reranker swap) — block merges that regress recall@k or faithfulness below a set threshold.

### 8.4 Production monitoring and drift

**Rule:** Continuously sample live production queries and their retrieved/generated outputs into the same evaluation pipeline (via TruLens/Phoenix/LangSmith tracing) to catch drift — corpus growth changing the recall profile, embedding model deprecations, or query distribution shifts — rather than relying solely on a static offline eval set.

---

## 9. Security and governance

### 9.1 Per-user/per-tenant access control

**Rule:** Enforce retrieval-time ACLs via Postgres Row-Level Security (see §4.4) so that vector search, full-text search, and even index internals cannot leak cross-tenant or cross-permission-level content — "ACL-aware retrieval" means the permission check happens *before or during* the similarity search, not as a post-filter on already-returned results ([Pradeep Bhandari, pgvector multi-tenancy](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide)).

### 9.2 PII handling

**Rule:** Classify and redact/mask PII at ingest time (before embedding) where regulatorily required, and tag chunks with a sensitivity level so retrieval can filter by the requesting user's clearance.

### 9.3 Prompt injection via retrieved content

**Rule:** Treat every retrieved chunk as untrusted, attacker-controllable input. RAG pipelines have at least six distinct attack surfaces: the ingestion pipeline (poisoned documents), the vector store (weak access control enabling poisoned inserts or namespace escapes), the retrieval query (embedding inversion / crafted queries forcing retrieval of poisoned chunks), prompt assembly (indirect prompt injection — attacker text interpreted as instructions), LLM inference (model complies with injected instructions or exfiltrates context), and the response (in agentic systems, poisoned output can trigger unwanted tool calls) ([RAG pipeline security hardening guide](https://www.systemshardening.com/articles/ai-landscape/rag-pipeline-security/)).

**Concrete mitigations:** Structurally separate retrieved content from instructions in the prompt (clear delimiters, or dedicated "context" role/field in structured output rather than raw concatenation); strip or neutralize imperative-sounding text patterns from retrieved chunks before insertion; apply the same output-side monitoring used for direct prompt injection; restrict agentic tool-calling triggered by generation to an allow-list that cannot be expanded by retrieved-content instructions alone.

### 9.4 Data residency

**Rule:** For regulated or geo-restricted data, pin the vector database region explicitly (Neon/Supabase/managed vector DBs all support region selection) and verify that any external embedding or reranking API calls do not transit or store data outside the required jurisdiction — self-hosting embedding models (BGE-M3, Qwen3-Embedding) becomes attractive specifically when third-party API data flows are unacceptable.

---

## 10. Managed vector DB / RAG service landscape

| Service | Category | Best fit | Notes |
|---|---|---|---|
| **pgvector (Postgres)** | Extension on existing relational DB | Replit-native default; apps that want one database for everything | No separate infra; RLS gives strong multi-tenancy; scales to tens of millions of vectors with HNSW + halfvec ([pgvector GitHub](https://github.com/pgvector/pgvector)) |
| **Pinecone** | Managed vector DB | Fastest path to managed production RAG | ~$50/mo Standard tier upward; cloud-hosted on AWS/GCP/Azure ([Atlan RAG platforms comparison](https://atlan.com/know/enterprise-rag-platforms-comparison/)) |
| **Qdrant Cloud** | Managed vector DB (also self-hostable OSS) | Teams wanting open-source flexibility with a managed option | Strong filtering and hybrid search support |
| **Weaviate** | Managed/self-hosted vector DB | GraphQL-style querying, built-in hybrid search and modules | Popular in LangChain/LlamaIndex ecosystems |
| **Turbopuffer** | Object-storage-backed vector + full-text search | Very large scale at low cost | Built directly on S3-style object storage with memory/SSD caching; markets ~10x cost reduction vs. traditional in-memory vector DBs; sub-10ms p50 latency at billions of vectors; used in production by Cursor, Anthropic, Notion, Linear ([Turbopuffer](https://turbopuffer.com/)) |
| **Cloudflare Vectorize** | Managed vector DB | Edge-native apps already on Cloudflare Workers | Tight integration with Cloudflare's edge compute stack |
| **LlamaCloud (LlamaParse + LlamaIndex managed)** | Managed ingestion + retrieval pipeline | Teams standardized on LlamaIndex wanting managed parsing/indexing | Strong document parsing (LlamaParse) bundled with retrieval |
| **Vertex AI Search (Google)** | Cloud-native managed RAG | GCP/BigQuery-centric orgs, Gemini users | Zero-ops, per-query + per-unit pricing ([Atlan comparison](https://atlan.com/know/enterprise-rag-platforms-comparison/)) |
| **Azure AI Search** | Cloud-native managed search + RAG | Microsoft-centric, compliance-heavy enterprises | Per-unit + per-query pricing |
| **Amazon Bedrock Knowledge Bases** | Cloud-native managed RAG | AWS-first enterprises | Per-token + storage pricing, tightly integrated with Bedrock models |
| **Ragie / Vectara** | Managed RAG-as-a-service (bundled ingestion+embedding+retrieval+generation) | Fastest time-to-value, least pipeline control needed | Good for teams that want to skip building a retrieval pipeline entirely |
| **Chroma Cloud** | Managed vector DB (OSS-rooted) | Teams starting from open-source Chroma wanting a managed upgrade path | Simple developer experience, growing enterprise feature set |

*(Category groupings and pricing notes per [Atlan Enterprise RAG Platforms Comparison 2026](https://atlan.com/know/enterprise-rag-platforms-comparison/) and [Turbopuffer official site](https://turbopuffer.com/); verify current pricing directly with each vendor before committing, as pricing changes frequently.)*

### 10.1 Decision matrix: pgvector vs. managed vector DB vs. managed end-to-end RAG service

| Situation | Recommendation |
|---|---|
| Early-stage Replit app, <5M chunks, team already using Postgres | **pgvector** — no new infra, RLS for multi-tenancy, HNSW + hybrid search covers most quality needs |
| Need sub-10ms p50 at 100M+ vectors, cost-sensitive at scale | **Turbopuffer** or **Qdrant/Pinecone** — purpose-built ANN infra outperforms Postgres well past the tens-of-millions mark |
| Team wants zero pipeline code, fastest time-to-value, willing to trade control | **Ragie/Vectara** (bundled RAG-as-a-service) or cloud-native (**Bedrock KB**, **Azure AI Search**, **Vertex AI Search**) if already on that cloud |
| Heavy on visually-rich/table-heavy documents needing best-in-class parsing | **LlamaCloud (LlamaParse)** or **Reducto** for ingestion, paired with any vector store |
| Strict data residency / cannot send data to third-party APIs | **pgvector self-hosted** + self-hosted embedding model (BGE-M3/Qwen3-Embedding) on infrastructure you control |
| Need multi-hop reasoning across entity relationships, not just similarity | Add **GraphRAG** on top of a base vector/hybrid pipeline, not as a replacement |
| Already deeply invested in one hyperscaler (AWS/Azure/GCP) | Use that cloud's native managed option (**Bedrock KB** / **Azure AI Search** / **Vertex AI Search**) to minimize integration surface |

---

## 11. Reference architectures

### 11.1 Lean Replit-viable default

**Stack:** Node/TypeScript (or Python) app on Replit → Replit Postgres or Neon (pgvector extension) → OpenAI/Voyage/Cohere embeddings → contextual chunk enrichment via a fast LLM → hybrid search (pgvector HNSW + Postgres full-text) fused with RRF → Cohere/BGE reranker → structured-output generation with citations.

**Key libraries:**
- Node: `pgvector` npm client, `pg` driver, LangChain.js or a thin custom retrieval layer, `unstructured`/Docling via a Python microservice or subprocess for parsing.
- Python: `pgvector` Python client, `psycopg`/`asyncpg`, `langchain`/`llama-index`, `unstructured` or `docling` for parsing, `ragas` for eval.

**DDL (illustrative):**
```sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  source_uri TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  version INT NOT NULL DEFAULT 1,
  metadata JSONB DEFAULT '{}',
  last_synced_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (tenant_id, source_uri)
);

CREATE TABLE chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL,
  parent_chunk_id UUID REFERENCES chunks(id),
  chunk_index INT NOT NULL,
  content TEXT NOT NULL,               -- includes prepended contextual header
  content_hash TEXT NOT NULL,
  embedding halfvec(1536),
  fts_vector TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX ON chunks USING hnsw (embedding halfvec_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX ON chunks USING GIN (fts_vector);
CREATE INDEX ON chunks (tenant_id);
CREATE INDEX ON chunks (document_id);

ALTER TABLE chunks ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON chunks
  USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_docs ON documents
  USING (tenant_id = current_setting('app.current_tenant_id')::uuid);
```

**Scale bound:** This pattern is proven up to roughly tens of millions of chunks on a well-resourced managed Postgres instance; beyond that, query latency and index build/maintenance time become the limiting factor, which is the trigger for the scale-up path.

### 11.2 Scale-up path

1. **Vector store split-off:** Move the `embedding` column workload to a purpose-built vector DB (Turbopuffer for cost-efficient massive scale, Pinecone/Qdrant for managed simplicity) while keeping `documents`/`chunks` metadata and full-text search in Postgres; join results at the application layer by ID.
2. **Ingestion pipeline hardening:** Move parsing to a dedicated service (Reducto/LlamaParse API) and run ingestion as an async queue-driven worker fleet rather than inline Replit compute.
3. **Add reranking and contextual retrieval** if not already present (§2.2, §5.4) — typically the single highest-ROI upgrade before considering GraphRAG or fine-tuning.
4. **Add GraphRAG or agentic multi-hop retrieval** only after the vector/hybrid + rerank baseline is evaluated and found insufficient on multi-hop/holistic queries specifically (§7.1).
5. **Formal eval + CI gates:** Introduce Ragas/DeepEval-based regression testing (§8.3) before any further pipeline changes ship, so scale-up changes don't silently regress quality.
6. **Consider managed end-to-end RAG (Bedrock KB/Azure AI Search/Vertex AI Search/Ragie)** if engineering capacity for pipeline maintenance becomes the bottleneck rather than cost or control.

---

## 12. RAG design checklist and definition-of-done

**Ingestion**
- [ ] Fetch/parse/load are separate, independently retryable stages with idempotency keys
- [ ] Parser tier selected per document complexity (Docling/Unstructured for clean docs, Reducto/LlamaParse for tables/scans, vision-OCR fallback for edge cases)
- [ ] Exact + near-duplicate deduplication in place
- [ ] Incremental sync via native change signals (ETag/modified-time) with hash fallback
- [ ] Deletes/version changes cascade cleanly through chunks and indexes

**Chunking**
- [ ] Chunking strategy chosen and validated against an eval set (not assumed)
- [ ] Contextual chunk headers implemented (Anthropic-style) before embedding and full-text indexing
- [ ] Tables and code never split across chunk boundaries
- [ ] Parent-document/small-to-big retrieval implemented if generation needs more context than optimal retrieval chunk size

**Embeddings**
- [ ] Embedding model chosen and benchmarked on your domain/language (not just MTEB leaderboard)
- [ ] Dimensionality/quantization tuned (Matryoshka truncation, halfvec/binary) with recall validated post-quantization
- [ ] Multilingual/Arabic support explicitly validated if applicable

**Indexing**
- [ ] HNSW (or IVFFlat if build-time constrained) with parameters tuned and documented
- [ ] Hybrid search (vector + full-text) with RRF fusion implemented
- [ ] Metadata filters pushed into the query, not post-filtered
- [ ] Row-Level Security enforced for multi-tenant isolation

**Query & Generation**
- [ ] Query rewriting/HyDE/decomposition available for complex queries, gated by a router/classifier
- [ ] Reranking stage in place (Cohere/Voyage/BGE) between retrieval and generation
- [ ] Token budget for context assembly explicit and enforced
- [ ] Citations/provenance carried through to the final answer with source spans
- [ ] Explicit refusal path for insufficient evidence
- [ ] Automated groundedness/faithfulness check before returning answers

**Advanced**
- [ ] Explicit boundary between memory and RAG subsystems
- [ ] Caching layer (exact + semantic) with TTL and version invalidation
- [ ] GraphRAG/agentic loops added only where baseline demonstrably fails, with cost/latency budgets

**Evaluation**
- [ ] Golden question set (manual + synthetic) covering retrieval and generation metrics
- [ ] Recall@k, precision@k, MRR, nDCG tracked for retrieval
- [ ] Faithfulness, groundedness, answer relevance tracked for generation
- [ ] CI regression gate blocks pipeline changes that regress key metrics
- [ ] Production monitoring/tracing (Phoenix/LangSmith/TruLens) sampling live traffic for drift

**Security & Governance**
- [ ] ACL-aware retrieval enforced at the database layer (RLS), not just application filters
- [ ] PII classified/redacted at ingest per policy
- [ ] Retrieved content treated as untrusted input; prompt-injection mitigations in place
- [ ] Data residency requirements mapped to vector store region and API data flows

**Definition of done:** A RAG layer is production-ready when (1) every item above is implemented or explicitly deferred with a documented reason, (2) retrieval and generation metrics are measured on a golden set and meet an agreed threshold, (3) a CI regression gate prevents silent quality regressions, and (4) multi-tenant access control and prompt-injection mitigations have been reviewed, not just implemented.

---

## Sources

- [Anthropic — Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)
- [Late Chunking: Contextual Chunk Embeddings Using Long-Context Embedding Models (arXiv:2409.04701)](https://arxiv.org/abs/2409.04701)
- [Reducto — Document Parsing API](https://llms.reducto.ai/document-parsing-api)
- [Unstructured-IO/unstructured GitHub](https://github.com/Unstructured-IO/unstructured)
- [pgvector GitHub — official README](https://github.com/pgvector/pgvector)
- [Tiger Data — Build hybrid search with BM25 and vector similarity](https://www.tigerdata.com/docs/build/examples/hybrid-search)
- [Pradeep Bhandari — Hard Multi-Tenancy for pgvector: Securing RAG with Row Level Security](https://pradeepbhandari.com/blog/pgvector-multi-tenancy-postgresql-rls-guide)
- [Reranker for RAG: Cohere, BGE, Jina, Voyage Compared](https://ianas.fr/en/blog/2026/06/07/reranker-comparatif-cohere-bge-jina-voyage/)
- [Universal Embeddings for Multimodal Multilingual Retrieval (jina-embeddings-v4, ACL 2025)](https://aclanthology.org/2025.mrl-main.36.pdf)
- [MTEB Scores & Leaderboard comparison (Ailog)](https://app.ailog.fr/en/blog/guides/choosing-embedding-models)
- [Microsoft GraphRAG — official documentation](https://microsoft.github.io/graphrag/)
- [RAG Pipeline Security: Hardening Retrieval-Augmented Generation](https://www.systemshardening.com/articles/ai-landscape/rag-pipeline-security/)
- [Atlan — Enterprise RAG Platforms Comparison 2026](https://atlan.com/know/enterprise-rag-platforms-comparison/)
- [Turbopuffer — official site](https://turbopuffer.com/)
- [Future AGI — RAG Evaluation Metrics 2026: The Complete Guide](https://futureagi.com/blog/rag-evaluation-metrics-2025/)
- [Crux Digits — From Offline Test Set to Production: RAG Retrieval Quality](https://cruxdigits.nl/blog/rag-evaluation-retrieval-quality/)
- [Future AGI — What Is Semantic Caching for LLMs? A 2026 Guide](https://futureagi.com/blog/what-is-semantic-caching-llms-2026/)
- [Shayan Geek — Deduplicating Documents at Scale](https://shayangeek.com/en/deduplicating-documents-at-scale/)
- [Replit Guides — Website Q&A RAG Chatbot](https://replit.com/guides/a-chatbot-for-website-q-and-a)
