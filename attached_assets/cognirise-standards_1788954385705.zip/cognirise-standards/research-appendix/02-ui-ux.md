# Agentic UI/UX Best Practices (2025–2026)

A synthesis of current best practices for designing AI-powered and agentic applications — the kind a studio would prototype for clients and implement in Replit with React/Next.js. Sources include first-party guidance (Google PAIR, Microsoft HAX, IBM, Apple, Shopify Polaris, Vercel, Anthropic, OpenAI, W3C/WCAG), research (Nielsen Norman Group), and observed product patterns (Claude, ChatGPT, Cursor, Devin, Linear, Notion AI, Perplexity, v0, Lovable).

---

## 0. Foundational frameworks (source overviews)

| Framework | Publisher | Core contribution |
|---|---|---|
| [People + AI Guidebook (PAIR)](https://pair.withgoogle.com/guidebook/patterns) — 2nd edition, via [Google Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook) | Google | Task-oriented navigation across 7 key questions: when to use AI, responsible data practices, trust calibration, onboarding, explainability, control/automation balance, error recovery. Ships a pattern library, case studies, and a workshop kit. |
| [Guidelines for Human-AI Interaction](https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/) (HAX Toolkit) | Microsoft Research | 18 evidence-based guidelines from a [2019 CHI paper](https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/) (Amershi et al.), organized across 4 interaction phases: **Initially, During interaction, When wrong, Over time**. Backed by a Design Library of patterns/examples and a team Workbook. |
| [AI Design Ethics](https://www.ibm.com/design/ai/ethics/) / [Everyday Ethics for AI](https://www.ibm.com/watson/assets/duo/pdf/everydayethics.pdf) | IBM | Five pillars — Explainability, Fairness, Robustness, Transparency, Privacy — plus five daily practices: consider outcomes, align with norms/values, minimize bias, ensure explainability, protect user data. |
| [Human Interface Guidelines: Machine Learning](https://developer.apple.com/design/human-interface-guidelines/machine-learning) | Apple | Platform conventions for on-device ML/generative features (Writing Tools, Apple Intelligence): favor augmentation over automation, preserve user control, degrade gracefully offline, respect platform hierarchy/consistency/harmony. |
| [NN/g AI topic hub](https://www.nngroup.com/topic/ai/) | Nielsen Norman Group | Empirical usability studies on chatbots, generative UI, agents, and enterprise explainability needs. |
| Polaris design system (Shopify) | Shopify | Framework-agnostic web-component system now shipping explicit "Accelerated development with AI" patterns for AI-assisted admin surfaces ([Polaris Goes Stable](https://www.shopify.com/partners/blog/polaris-goes-stable-the-future-of-shopify-app-development-is-here)). |
| [AI SDK UI](https://sdk.vercel.ai/docs/ai-sdk-ui/overview) | Vercel | Reference implementation patterns for streaming chat (`useChat`), structured streaming (`useObject`), and typed tool-call/tool-result rendering via message `parts`. |
| [Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents) | Anthropic | Engineering-and-UX guidance: transparency of planning steps, human checkpoints, tool/ACI design discipline. |
| [A Practical Guide to Building Agents](https://openai.com/business/guides-and-resources/a-practical-guide-to-building-ai-agents/) | OpenAI | Agent architecture (model/tools/instructions), orchestration, guardrails, when NOT to use an agent. |
| [WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) | W3C WAI | 9 new success criteria (focus visibility, target size, dragging alternatives, redundant entry, accessible authentication) directly relevant to agent control surfaces. |
| [ARIA19 live regions technique](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19) | W3C WAI | `aria-live`/`role=alert` patterns for announcing dynamically injected content (errors, streamed output) to assistive tech. |

---

## 1. Progressive disclosure of agent reasoning

**Rule:** Default to a collapsed, glanceable summary of what the agent is doing; let users expand into plans, individual steps, tool calls, and raw traces on demand. Never dump a full reasoning trace or tool-call log into the primary conversational flow by default.

**Rationale:** Full chain-of-thought or step-by-step tool logs overwhelm users and slow comprehension, but hiding all process kills the trust and debuggability that make agents usable for real work. Microsoft's HAX guideline 10, "Make clear why the system did what it did," and the PAIR guidebook's explainability chapter both call for offering explanation as a layered, on-demand affordance rather than a wall of text ([Microsoft HAX](https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/), [Google PAIR Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook)). NN/g independently found that even simple site chatbots need progressive disclosure to prevent runaway-long conversations ([NN/g, 10 Guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/), Guideline 6).

**When it applies:** Any surface where the agent performs multi-step work (research agents, coding agents, workflow automations) — especially where steps include tool calls, file edits, or external API calls.

**Concrete implementation:**
- Render a persistent, single-line **status strip** ("Searching docs → Reading 3 files → Drafting patch") that updates as steps complete; clicking/tapping expands an **activity timeline** panel.
- Represent each step as a card: verb + target + status icon (queued/running/done/failed), collapsed by default, expandable to show inputs/outputs (mirrors Vercel AI SDK's `tool-*` message parts with `state` values `input-streaming → input-available → output-available/output-error`, see [Chatbot Tool Usage](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage)).
- Use `step-start` boundaries (rendered as horizontal rules in AI SDK's pattern) to visually chunk multi-step tool sequences without needing separate messages.
- Offer a "Show reasoning" / "View trace" toggle per message rather than a global settings flag, so disclosure is contextual.
- Cursor's **Plan Mode** is a concrete reference model: agent researches, drafts a plan artifact, and blocks execution until the human reviews/edits it via chat or a markdown plan file ([Cursor Plan Mode](https://www.learncursor.dev/learn/cursor-agents/agent-plan-mode)).

**Acceptance criteria:**
- Default view never exceeds ~3 visible process lines before requiring an explicit expand action.
- Every tool call has a machine-readable state that maps 1:1 to a UI affordance (loading, input shown, output shown, error, denied).
- Users can jump from a summary step to its full input/output payload in ≤1 click.
- Long traces are virtualized/paginated, not rendered in full in the DOM.

---

## 2. Trust calibration: confidence, citations, provenance, uncertainty

**Rule:** Make uncertainty and provenance visible as a first-class, ambient part of the output — not an afterthought, legal disclaimer modal, or hidden tooltip.

**Rationale:** AI blurs the traditional "works or fails" binary; confidently-worded wrong answers are the default failure mode. Making uncertainty legible lets users decide what to verify. Perplexity's citation-first design is the most-cited reference case: inline citation markers tied to individual claims, structured source cards (publisher, headline, favicon), and click-to-verify without losing place in the answer, which reduces "tab-hopping" and hallucination anxiety ([UX Teardown: Perplexity Citations](https://assets.nextleap.app/submissions/UX_teardown-3a359c8e-53c8-4d93-8e85-f63f5ae18856.pdf)). PAIR similarly frames trust as something to be *calibrated*, not maximized — over-trust is as harmful as under-trust ([Google PAIR Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook)). HAX guideline 2, "Make clear how well the system can do what it can do," requires surfacing performance/confidence expectations up front.

**When it applies:** Any factual, generative, or recommendation output; especially RAG/search-grounded answers, enterprise knowledge assistants, and code-generation review surfaces.

**Concrete implementation:**
- **Inline citation chips** (numbered or favicon badges) placed immediately after the supported claim, clickable to open a source preview panel without navigating away.
- **Confidence indicators**: use a discrete low/medium/high label plus a color, not a bare numeric percentage — numeric scores read as false precision. NN/g-style analyses of Claude/ChatGPT variants confirm label+color outperforms raw percentages for lay users ([Designing Trust in AI Outputs](https://creativealive.com/designing-trust-ai-outputs-ux-patterns-uncertainty/)).
- **Ambient disclaimers** ("AI-generated — verify before use") as a persistent footer/microcopy rather than a modal interrupt; modals get dismissed reflexively and stop conveying information.
- **Transparent operation history**: a collapsible per-document/per-session timeline distinguishing AI-authored vs. human-edited content and the prompt that produced each change (referenced against Linear's inline-AI undo pattern).
- Differentiate **grounded** claims (has citation) from **generated/inferred** claims (no citation, flagged) visually — e.g., a dotted underline or distinct badge for ungrounded assertions.
- Never let sponsored/promoted content share the same visual treatment as organic citations (a documented gap in current answer engines).

**Acceptance criteria:**
- 100% of factual claims sourced from retrieval have a visible, clickable citation within the same viewport as the claim.
- Confidence UI never uses color alone (pair with text label/icon for colorblind and screen-reader users, per WCAG 1.4.11 non-text contrast).
- No dark-pattern conflation of paid/sponsored suggestions with organic ones.
- Users can locate "why did it say this" provenance for any claim in ≤2 clicks.

---

## 3. Human-in-the-loop: approval gates, editable plans, undo, dry-run, steering

**Rule:** Any action with real-world side effects (file writes, sends, purchases, deletions, external API calls) requires an explicit approval gate unless the user has pre-authorized a scoped class of actions. Plans must be editable before execution, and in-flight runs must be interruptible.

**Rationale:** Anthropic frames autonomy as a dial, not a switch: agents should pause for feedback "at checkpoints or when encountering blockers," and transparency of planning steps is one of three core design principles ([Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)). OpenAI's guide likewise stresses guardrails and stopping conditions as core agent-architecture components, not bolt-ons ([Practical Guide to Building Agents](https://openai.com/business/guides-and-resources/a-practical-guide-to-building-ai-agents/)). HAX guidelines 13–16 ("support efficient interruption," "correction," "escalation," "recovery") formalize the same requirement from an interaction-design lens.

**When it applies:** Coding agents (file edits, terminal commands), computer-use agents, workflow/automation builders, and any agent with write access to user data or money-moving/communication tools.

**Concrete implementation:**
- **Diff-first review**: present proposed file/data changes as a diff (added/removed/changed) before applying — Cursor's "Diffs & Review" pattern: "Inspect diffs, run checks, and catch problems before you merge" ([Cursor docs](https://docs.cursor.com/agent/review)).
- **Typed approval state machine** for tool calls: `approval-requested → approval-responded (approved/denied) → output-available/output-denied`, exactly as modeled in Vercel AI SDK's tool-part states, including a flag for automatic vs. manual approval (`part.approval.isAutomatic`) so users can see which gates were skipped by policy ([AI SDK Chatbot Tool Usage](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage)).
- **Editable plan artifact**: render the agent's plan as a structured, directly-editable document (checklist or markdown) the user can rewrite before clicking "Run," not just approve/reject as a whole (Cursor Plan Mode).
- **Dry-run / preview mode**: default destructive or expensive operations to a simulated preview (e.g., "would delete 12 rows") with a separate explicit action to commit.
- **Mid-run steering**: expose a visible "Stop" / "Pause" control at all times during execution, plus a way to inject new instructions without discarding partial progress (vs. force-restarting the whole task).
- **Undo/rollback**: every AI-applied edit gets a one-click revert affordance placed adjacent to the change itself, not buried in a menu — "if undo is buried, users disengage from using AI at all" ([Designing Trust in AI Outputs](https://creativealive.com/designing-trust-ai-outputs-ux-patterns-uncertainty/)). Prefer versioned checkpoints over single-level undo for multi-step agent runs.
- **Scoped autonomy settings**: let users pre-approve categories of low-risk actions (e.g., "always allow read-only tools") distinct from high-risk ones, echoing Anthropic's sandbox/guardrail recommendation.

**Acceptance criteria:**
- No irreversible, high-blast-radius action executes without either (a) prior explicit approval or (b) a pre-declared, user-visible autonomy policy covering that action class.
- Every write action has a corresponding, discoverable undo within the same session.
- A running task can be paused/stopped within 1 interaction, with partial results preserved, not discarded.
- Plans are rendered as structured, editable content (not prose-only) before execution begins.

---

## 4. Latency and streaming UX

**Rule:** Never show a blank, frozen screen during model latency. Stream tokens as they arrive; use skeletons that match final content shape; treat multi-minute tasks as background jobs with notifications, not blocking spinners.

**Rationale:** LLM responses and agent runs have highly variable latency (sub-second to many minutes). Perceived performance is driven more by continuous feedback than by raw speed. HAX guideline 3 ("time services based on context") and guideline 6 ("support efficient invocation") both address responsiveness expectations. NN/g's chatbot study found autoscroll-to-bottom during streaming is actively harmful — it fights the user's reading position ([NN/g 10 Guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/), Guideline 7).

**When it applies:** All conversational and generative surfaces; especially long document generation, multi-step agent runs, and code generation.

**Concrete implementation:**
- **Token streaming** via `useChat`/SSE or equivalent: render partial assistant messages as they arrive rather than waiting for completion ([Vercel AI SDK UI Overview](https://sdk.vercel.ai/docs/ai-sdk-ui/overview)).
- **Do not autoscroll to bottom** on new streamed content once the user has scrolled up to read; preserve reading position and show a "Jump to latest" affordance instead (directly from NN/g's MISSI/Turo findings).
- **Skeletons matching final layout** (not generic spinners) for structured outputs — e.g., a card skeleton for a product recommendation, a table skeleton for tabular results — so layout doesn't jump on load.
- **Optimistic UI** for user-initiated actions the agent is very likely to fulfill (e.g., show the sent message immediately, show a provisional "queued" state for a tool call) while reconciling with actual state once confirmed.
- **Background job pattern** for long-running agent tasks (minutes+): let the user navigate away, surface a persistent job indicator (toast, notification-center entry, badge on nav), and notify (in-app, push, email) on completion — modeled on Devin/async coding-agent sessions where work continues off-screen.
- **Resumability**: sessions/tasks must be resumable after reload/disconnect — reconstitute from server-persisted state rather than losing in-flight streams on refresh.
- **Streamed structured data**: for generative UI/JSON payloads, use a dedicated hook (`useObject` in AI SDK) so partial JSON can drive incremental UI rendering instead of an all-or-nothing parse.

**Acceptance criteria:**
- Time-to-first-token/content is surfaced to the user in under ~1s via streaming or a skeleton — never a blank container.
- User's scroll position is never force-moved during streaming.
- Any task expected to exceed ~15–30 seconds gets a named, trackable job with a visible status affordance outside the immediate chat turn.
- Reloading the page/tab resumes rather than discards an in-progress agent run.

---

## 5. Error, refusal, empty, partial-failure, and hallucination-recovery states

**Rule:** Design explicit, distinct states for: no results, tool failure, partial completion, safety refusal, and suspected hallucination — each with a clear next action, not a generic "Something went wrong."

**Rationale:** HAX guidelines 12–16 (the "when wrong" phase) exist precisely because failure is a first-class, expected mode for probabilistic systems, not an edge case ([Microsoft HAX](https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/)). IBM's ethics framework lists Explainability and Robustness as pillars specifically to keep failure legible ([IBM Design for AI Ethics](https://www.ibm.com/design/ai/ethics/)). NN/g documents that generic/irrelevant chatbot answers, when the system can't answer, actively damage trust more than an honest "I can't help with that" ([NN/g 10 Guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/)).

**When it applies:** All AI surfaces; particularly agents with multiple tool calls where one sub-step can fail while others succeed.

**Concrete implementation:**
- **Refusal state**: explain *why* (policy, missing capability, missing data) and offer an alternative path (escalate to human, rephrase, narrower scope) — never a bare "I can't do that."
- **Partial-failure state**: when an agent completes steps 1–3 of 5 and step 4 fails, show completed steps as done, the failed step with error detail, and remaining steps as blocked/skipped — not a rolled-up single failure banner that hides the 3 successes. Mirrors AI SDK's per-tool `output-error` state with `errorText`, while defaulting to a masked generic message for security unless the developer opts into detail ([AI SDK Chatbot Tool Usage](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage)).
- **Empty state**: on first load or no-results, show capability examples/suggested prompts rather than a blank input box (see §8).
- **Hallucination-recovery**: pair every generated claim capable of being wrong with a low-friction correction affordance ("this doesn't look right" / inline edit) rather than requiring a full regenerate-from-scratch; provide "regenerate with more sources" as an escalation path.
- **Graceful degradation**: if a tool/API is down, say so and offer a manual fallback rather than silently returning a worse answer.
- Use `role="alert"` or `aria-live="assertive"` live regions for injected error messages so screen reader users are notified without needing focus to move to the error location — the error container must exist in the DOM at load time for reliable announcement ([W3C ARIA19 Technique](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)).

**Acceptance criteria:**
- Every error state names the failure and offers ≥1 concrete next action (retry, escalate, edit, undo).
- Multi-step runs show per-step success/failure, never a single aggregate pass/fail.
- Refusals include a reason category, not just a decline.
- All programmatically-injected error/status text is exposed via ARIA live regions and tested with a screen reader.

---

## 6. Choosing the right surface: chat vs. canvas vs. inline vs. workflow-builder vs. dashboard

**Rule:** Chat is a fallback interface for ambiguous, conversational, or exploratory tasks — not the default for everything. Match surface to task shape.

**Rationale:** NN/g's direct finding: "Users turn to site-specific chatbots for quick answers, not a conversation" and site chatbots must be direct/scannable rather than defaulting to open-ended dialogue ([Less Chat, More Answer](https://www.nngroup.com/topic/ai/)). Generative UI research argues for "outcome-oriented design" — orchestrating the *right* interface for the goal rather than funneling every interaction through text chat, including dynamically generated widgets to reduce typing/memory load ([NN/g, Generative UI and Outcome-Oriented Design](https://www.nngroup.com/articles/generative-ui/)).

**Surface decision guide:**

| Surface | Best for | Reference products |
|---|---|---|
| **Chat** | Ambiguous/exploratory intent, multi-turn clarification, conversational Q&A, tasks with no stable structured output | ChatGPT, Claude, Perplexity |
| **Canvas / Artifacts** | A single evolving artifact (doc, code file, diagram) the user wants to iterate on visually alongside conversation | Claude Artifacts, ChatGPT Canvas — both render a persistent side-pane document with inline edit affordances and versioning; Claude adds "Try fixing with Claude" and publish/remix; Canvas adds a floating edit-shortcut menu (adjust length, reading level) |
| **Inline / embedded AI** | Assistance inside an existing structured surface (spreadsheet cell, doc paragraph, design canvas) where full context-switch to chat is costly | Notion AI inline generation, Linear's inline AI rewrite-with-undo |
| **Workflow builder** | Repeatable, multi-step automations the user wants to inspect, edit, and re-run deterministically | Agent/automation builders with node graphs and typed steps |
| **Dashboard** | Monitoring status, KPIs, run history, and cost across many past/ongoing agent runs — read-heavy, not conversational | Admin/observability panels for agent platforms |
| **Generative UI (system-generated)** | AI decides to render a bespoke interactive element (form, chart, calculator) in response to inferred need, reducing back-and-forth text | Emerging pattern per [NN/g](https://www.nngroup.com/topic/ai/): "AI chats generate simple UI elements to gather context, reduce typing and memory load" |
| **"Vibe coding" (user-directed generation)** | User explicitly asks the AI to build the interface/app itself | v0, Lovable, Replit Agent |

**Concrete implementation:**
- Don't ship two competing chat entry points on the same product surface with unclear scope boundaries — NN/g's Home Depot case study (Magic Apron vs. Live Chat) shows this actively confuses and frustrates users ([NN/g 10 Guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/), Guideline 1).
- If a task produces one evolving artifact, put it in a canvas/artifact pane, not scrolling chat history — this avoids the "artifact buried in scroll" problem and enables diffing/versioning.
- For structured admin or e-commerce tasks, prefer inline AI actions (a "Rewrite with AI" button on a form field) over routing the user into a general chatbot.
- Persist the chatbot's availability across every page in a multi-step flow if the flow spans pages — a floating, consistently-positioned entry point (NN/g Guideline 2, citing Redfin's disappearing chat as a failure case).

**Acceptance criteria:**
- Any chat surface handling structured, page-aware tasks demonstrates page/context awareness in its opening state (not a generic "Ask me anything").
- No product ships >1 ambiguous chat entry point without explicit differentiation and hand-off between them.
- Artifacts/canvases support versioning and are addressable independent of the chat scrollback.

---

## 7. Multi-agent and multi-session UX: run history, timelines, artifacts, diffs

**Rule:** Treat every agent invocation as a durable, inspectable "run" with its own identity, timeline, and artifacts — not an ephemeral chat exchange.

**Rationale:** As agents move toward asynchronous, long-running, and multi-agent execution (Devin-style sessions, Linear's "app users"), the unit of work shifts from a single chat turn to a run/session that outlives the immediate UI. Linear models agents as first-class workspace entities ("app users") that can be @-mentioned and delegated issues, with the human assignee remaining accountable even after delegation ([Linear Docs: AI Agents](https://linear.app/docs/agents-in-linear)). This requires run-level state, not just message-level state.

**Concrete implementation:**
- **Run/session list**: a dedicated history view of past and active agent runs, each with status (running/succeeded/failed/needs-approval), start time, and duration — analogous to CI build history.
- **Activity timeline per run**: chronological log of steps/tool calls/decisions (see §1), persisted and re-openable after the run completes, not just live-streamed and discarded.
- **Artifacts pane**: separate from the timeline, a list of durable outputs (files changed, documents created, PRs opened) generated by the run, each independently viewable/diffable.
- **Diff views**: for code or document-editing agents, default to unified/side-by-side diff rendering of before/after state rather than requiring users to re-read the whole artifact.
- **Delegation model**: when assigning work to an agent (vs. a human), keep a visible, permanent record of who delegated and who remains accountable, mirroring Linear's "delegation, not full handoff" model.
- **Cross-session continuity**: allow an agent to reference/resume prior runs' context (with user visibility into what's being reused) rather than silently carrying hidden state across sessions.
- **Multi-agent orchestration visibility**: when multiple sub-agents or specialized tool-agents contribute to one task, visually attribute each step/output to the agent/tool that produced it (avoid a single undifferentiated "AI" voice when several distinct agents with different scopes are involved) — consistent with OpenAI's orchestration guidance to split tasks across multiple agents as complexity grows ([Practical Guide to Building Agents](https://openai.com/business/guides-and-resources/a-practical-guide-to-building-ai-agents/)).

**Acceptance criteria:**
- Every run is addressable by a stable URL/ID and remains inspectable after completion.
- Diffs are available for any file/document-mutating step, not just a final summary.
- Delegation UI always names the accountable human alongside the acting agent.

---

## 8. Onboarding, capability discovery, prompt affordances, model/mode pickers

**Rule:** Show capability through concrete, contextual examples at first contact — never a blank input with a generic greeting. Make mode/model choice legible but not a burden for casual users.

**Rationale:** NN/g's core empirical finding: vague greetings ("Ask me anything") set expectations the system can't meet, while specific example prompts tailored to context succeed. Amazon Rufus's contextual prompts (different on homepage vs. product page) is the model case ([NN/g 10 Guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/), Guideline 3). PAIR's onboarding chapter explicitly frames "How do I onboard users to new AI features?" as a distinct guidebook question requiring dedicated pattern work ([Google PAIR Codelab](https://codelabs.developers.google.com/codelabs/pair-guidebook)).

**Concrete implementation:**
- **Contextual suggested prompts as clickable buttons**, not plain text — reduces typing burden and clarifies scope; refresh suggestions based on conversation state rather than repeating already-declined suggestions (NN/g Guideline 4, citing Redfin's annoying repetition failure).
- **Capability-scoped opening message**: name 2–4 concrete task categories the agent handles, tailored to the current page/context, instead of an open-ended invitation.
- **Progressive capability reveal**: introduce advanced features (file upload, voice input, tool integrations) via just-in-time affordances near first relevant use, not a single onboarding tour that's forgotten.
- **Model/mode pickers**: expose a lightweight selector (e.g., Fast vs. Thinking/Reasoning mode, or Ask vs. Agent vs. Plan mode as in Cursor) with a one-line description of the tradeoff (speed vs. depth), defaulting to the best general-purpose option so novice users never must choose correctly to succeed.
- **Voice input** as an accessibility and convenience affordance, particularly on mobile or for users with motor impairments (NN/g Guideline 10).
- Avoid overloading the first-run experience with every capability at once; sequence disclosure to match task progression (PAIR / progressive-disclosure principle applied to onboarding itself).

**Acceptance criteria:**
- First-run empty state always shows ≥2 concrete, clickable example actions relevant to current context.
- Suggested follow-ups adapt to conversation state and never repeat a suggestion the user has already ignored twice.
- Mode/model pickers include a plain-language tradeoff description, not just a label.

---

## 9. Feedback capture loops feeding evals

**Rule:** Make giving feedback nearly free (one click) at the point of output, and route it into a structured evaluation/annotation pipeline — not just a satisfaction metric.

**Rationale:** Continuous product improvement for LLM systems depends on structured human feedback tied to specific outputs/traces, enabling eval-driven development. Tooling like Arize Phoenix explicitly builds custom annotation UIs (including ones prototyped in Lovable) to attach labels/scores/explanations directly to trace spans, which then feed experiments and regression evals ([Arize: Human Annotations for Eval Driven Development](https://arize.com/docs/phoenix/cookbook/human-in-the-loop-workflows-annotations/using-human-annotations-for-eval-driven-development)).

**Concrete implementation:**
- **Thumbs up/down** on every discrete AI output (message, suggestion, generated artifact), positioned adjacent to the content, with down-vote optionally prompting a 1-line reason (factual error, tone, irrelevant, unsafe).
- **Inline correction as feedback**: when a user edits AI-generated content directly, capture the diff between original and edited as implicit feedback — richer signal than a binary vote.
- **Annotation mode for internal/reviewer users**: a dedicated UI (separate from end-user chat) to label spans/traces with structured scores and free-text explanations, tied to the underlying trace ID for later eval-set construction.
- **Aggregate feedback visibility for admins**: surface trends (e.g., % thumbs-down by feature/prompt-template) in an internal dashboard so teams can prioritize fixes.
- Close the loop by showing (at least to power users/admins) when feedback led to a change — reinforces that feedback is acted on, increasing future participation.

**Acceptance criteria:**
- Feedback control is reachable in 1 click/tap from any AI-generated output.
- Down-votes capture a structured reason category, not just a binary signal.
- Feedback data is linked to the underlying trace/run ID so it is usable for eval-set curation, not just aggregate CSAT.

---

## 10. Data/permission transparency, cost and usage visibility

**Rule:** Users (and admins) must be able to see, at any time, what data the agent can access, what it actually accessed for a given answer, and what a given action/run cost.

**Rationale:** IBM's Privacy and Transparency pillars require this as a baseline ethical commitment ([IBM Everyday Ethics for AI](https://www.ibm.com/watson/assets/duo/pdf/everydayethics.pdf)). Enterprise AI governance treatments frame this as an identity-and-policy problem: every agent action must be attributable to a scoped, auditable identity distinct from a shared credential ([Praesidia: AI Agent Governance for Enterprises](https://praesidia.ai/blog/ai-agent-governance-for-enterprises)).

**Concrete implementation:**
- **Permission/scope panel**: a persistent, inspectable list of data sources/tools the agent is authorized to use in the current context (e.g., "Connected: Google Drive (read-only), Calendar (read/write)"), with per-source revoke controls.
- **Per-answer data provenance**: show which specific documents/records were retrieved and used for a given response (distinct from general citations — this is about *access*, not just *sourcing*), especially in RAG-based enterprise assistants.
- **Cost/usage meters**: expose token/request/run cost or quota consumption in real time for usage-priced products — a running counter or budget bar rather than a surprise invoice; particularly important for agentic workflows where a single task can spawn many sub-calls.
- **Usage dashboards for admins**: per-user/per-team consumption breakdowns, with alerts/caps configurable by admins.
- Distinguish clearly between data used to **answer this query** vs. data retained to **improve/train the model**, with separate, explicit opt-in/opt-out controls for the latter.

**Acceptance criteria:**
- Users can view current data/tool access grants without contacting support.
- Every agent run exposes at minimum an estimated or actual cost/usage figure, visible before or immediately after execution for cost-sensitive actions.
- Training-data opt-in/opt-out is a separate, explicit control from feature/data-access permissions.

---

## 11. Enterprise platform concerns: admin, roles, audit logs, workspace/tenant, agent catalogs

**Rule:** Treat agents as first-class identities in the enterprise's existing identity and access model — not an undifferentiated feature toggle.

**Rationale:** Enterprise AI governance requires agents to have distinct, verifiable, scoped, and revocable identities tied into SSO/SCIM, because "an agent is not a user, but it acts on behalf of users and organizations, and its actions need to be attributable" ([Praesidia: AI Agent Governance for Enterprises](https://praesidia.ai/blog/ai-agent-governance-for-enterprises)). Fixed role buckets (owner/admin/member/viewer) don't map to enterprise functional needs (e.g., a compliance analyst needing read-only audit access without agent-modification rights).

**Concrete implementation:**
- **Agent identity & credentials**: each agent gets its own scoped, rotatable, revocable credential — never a shared service account — so every action logs to a specific agent identity.
- **Custom/granular roles**: beyond default buckets, support roles like "can register agents but not modify billing" or "read-only audit access."
- **Agent catalog / directory**: a discoverable, admin-curated list of installed/available agents per workspace, each with declared capabilities, connected tools, and installing admin — modeled on Linear's Integrations Directory + per-team installation scoping ([Linear Docs: AI Agents](https://linear.app/docs/agents-in-linear)).
- **Audit log**: immutable, searchable record of every agent action (who/what triggered it, what it did, what it touched), exportable for compliance review.
- **Workspace/tenant isolation**: agent configuration, memory, and connected-data scope must respect tenant boundaries by default; cross-tenant data leakage via shared agent memory is a critical failure mode to design against.
- **Guidance/policy injection**: allow admins to set organization-wide instructions/guardrails that agents automatically receive (Linear's "Agent guidance" — repo conventions, commit reference format, etc.).
- **Suspend/uninstall controls**: admins can suspend or remove an agent's access without deleting its history, for incident response.

**Acceptance criteria:**
- Every agent action in an audit log is attributable to a unique agent identity and the human/policy that authorized it.
- Roles support at least read-only-audit and agent-management as separable permissions from full admin.
- Agent catalog entries disclose the tools/data scopes an agent requests before installation.
- Tenant data never crosses workspace boundaries via shared agent state without explicit design review.

---

## 12. Accessibility and internationalization specifics for AI surfaces

**Rule:** Streaming, dynamic, and generative content must meet WCAG 2.2 and be announced correctly to assistive technology; layouts must tolerate text expansion and RTL scripts without breaking.

**Rationale:** WCAG 2.2 added criteria directly relevant to agent-heavy UIs (focus visibility during dynamic updates, larger touch targets for approve/deny controls, drag-alternatives for reorderable plan steps, no redundant re-entry of information already provided, accessible authentication) ([W3C: What's New in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/)). Screen readers only announce dynamically injected content if it lives inside a properly configured live region present in the DOM at load ([W3C ARIA19](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)). Multilingual AI UX faces text-expansion, cultural-context, and low-resource-language accuracy issues that a chat/agent interface must specifically accommodate ([DeveloperUX: 5 Challenges in Multilingual AI UX Design](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/)).

**Concrete implementation (WCAG 2.2 mapping):**

| WCAG 2.2 SC | Level | Agentic UI relevance |
|---|---|---|
| [2.4.11 Focus Not Obscured (Minimum)](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) | AA | Approval-gate buttons/dialogs must not be hidden behind a sticky streaming-response footer when focused via keyboard. |
| 2.5.8 Target Size (Minimum) | AA | Approve/Deny, thumbs up/down, and stop-run controls need adequate touch target size — these are frequent, high-stakes taps. |
| 2.5.7 Dragging Movements | AA | If plan steps are reorderable via drag, provide a non-drag (button-based) reorder alternative. |
| 3.3.7 Redundant Entry | A | Don't make users re-enter info the agent already collected earlier in a multi-step flow. |
| 3.3.8/3.3.9 Accessible Authentication | AA/AAA | Avoid CAPTCHA-style puzzles that block agent-assisted or assistive-tech users from authenticating to reach the AI feature. |
| 3.2.6 Consistent Help | A | Keep "how this AI works" / help entry points in the same location across pages. |

- **Live regions for streaming**: wrap the streaming response container in `aria-live="polite"` (not "assertive," which interrupts) so screen readers announce new content without cutting off current reading; use `role="alert"`/`aria-live="assertive"` only for errors and critical interruptions requiring immediate attention, and ensure the container exists in the DOM at page load with `aria-atomic` set appropriately ([W3C ARIA19](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)).
- Avoid re-announcing the entire growing message on every token — batch updates or announce only completed sentences/chunks to prevent a screen reader from re-reading from the start repeatedly.
- **RTL and text expansion**: use auto-resizing containers (not fixed-width) for chat bubbles, buttons, and labels; budget 30–40% extra space for translated UI strings; test with pseudo-localization (artificially expanded strings) before shipping ([DeveloperUX](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/)).
- Support voice input as both an accessibility and localization affordance, since typing burden compounds for non-native-script input methods.
- Ensure confidence/status color coding always pairs with text/icon (not color alone) to satisfy non-text contrast and colorblind accessibility.

**Acceptance criteria:**
- Streaming responses use `aria-live="polite"` by default; error/interrupt states use assertive/alert regions.
- All approval/control buttons meet the 24×24 CSS px minimum target size (WCAG 2.5.8) with adequate spacing.
- UI layout does not clip or truncate text at 40% string-length expansion in any supported locale.
- No information already submitted earlier in a flow is re-requested from the user (3.3.7).

---

## 13. Design system foundations for AI products: tokens, states, motion, density

**Rule:** Extend the base design system with an explicit **AI-state layer** — tokens and motion vocabulary dedicated to agent activity (thinking, streaming, tool-running, blocked, error) — rather than reusing generic loading/spinner tokens for everything.

**Rationale:** Shopify's Polaris system now ships dedicated patterns for "Accelerated development with AI," reflecting an industry shift toward first-class AI states in design systems rather than treating AI as a generic async operation ([Polaris Goes Stable](https://www.shopify.com/partners/blog/polaris-goes-stable-the-future-of-shopify-app-development-is-here)). Skeleton loaders that mirror final content shape (not generic shimmer) reduce perceived latency and layout shift ([Skeleton UI Loading Animation](https://www.protopie.io/blog/how-to-create-a-skeleton-ui-loading-animation)).

**Concrete implementation:**
- **State tokens**: define distinct visual states — `idle`, `thinking`/`planning`, `streaming`, `tool-running`, `awaiting-approval`, `blocked`, `error`, `done` — each with a color/icon/motion signature reused consistently across chat, canvas, and dashboard surfaces.
- **Motion vocabulary for agent activity**: subtle pulsing/shimmer for "thinking," a progress-style animated ellipsis or breathing dot for "streaming," a distinct spinner-with-label for "tool running" (name the tool), and a static icon (no motion) for terminal states (done/error) — motion should map to *activity*, and stop immediately when activity stops, to avoid signaling false liveness.
- **Skeletons shaped like final content**: card skeletons for card results, table skeletons for tabular output, paragraph skeletons for prose — never a generic centered spinner for structured content.
- **Density modes**: support a compact density for high-frequency power-user surfaces (e.g., an ops dashboard showing many concurrent agent runs) and a comfortable density for conversational surfaces — density should be a token-level setting, not a one-off style.
- **Typed message/part components**: build a component library keyed to message-part types (text, tool-call, tool-result, approval-request, step-boundary, citation, error) mirroring the AI SDK's typed `parts` model, so new tool types can render consistently without bespoke one-off UI ([AI SDK Chatbot Tool Usage](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage)).
- **Consistent iconography for trust/provenance** (citation marker, confidence badge, "AI-generated" tag, human-edited tag) reused across every surface so users build a stable mental model.

**Acceptance criteria:**
- A documented state-token set exists covering at minimum idle/thinking/streaming/tool-running/awaiting-approval/error/done, applied consistently across all AI surfaces in the product.
- No generic spinner is used for content with a known final structure — skeletons match layout.
- Motion stops within one frame of the underlying activity stopping (no orphaned looping animations).
- Citation, confidence, and provenance iconography is defined once in the design system and reused, not redrawn per surface.

---

## 14. Anti-patterns to ban

| Anti-pattern | Why it's banned | Correct alternative |
|---|---|---|
| Blank/generic "Ask me anything" opening message | Sets expectations the system can't meet ([NN/g](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/)) | Contextual capability examples as clickable prompts |
| Autoscrolling the user to the bottom of a streaming response | Disorients readers who started reading mid-stream ([NN/g](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/)) | Preserve scroll position; offer "jump to latest" |
| Multiple overlapping, undifferentiated chatbots on one product surface | Confuses users about which bot can do what ([NN/g](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/)) | Single consolidated entry point with clear scope, or clearly differentiated + interlinked bots |
| Modal disclaimers on every AI output | Gets reflexively dismissed, stops conveying information ([Designing Trust in AI Outputs](https://creativealive.com/designing-trust-ai-outputs-ux-patterns-uncertainty/)) | Ambient, persistent microcopy disclaimers |
| Full chain-of-thought dumped into the main chat by default | Overwhelms users, buries the actual answer | Collapsed summary + expandable trace/timeline |
| Executing irreversible actions with no approval gate or preview | Violates HAX "support efficient interruption/correction," Anthropic's checkpoint guidance | Diff/dry-run preview + explicit approval, scoped autonomy settings |
| Numeric-only confidence scores presented as precise probabilities | False precision misleads users | Label + color confidence bands |
| Sponsored/paid suggestions styled identically to organic ones | Deceptive; erodes trust once discovered | Clear, persistent visual distinction for sponsored content |
| Silent failure or generic "Something went wrong" for multi-step runs | Hides which steps succeeded; blocks recovery | Per-step status with specific error and next action |
| Re-requesting information the user already provided earlier in the same flow | Violates WCAG 3.3.7; wastes user effort | Persist and reuse prior inputs across the flow |
| Repeating a declined follow-up suggestion | Feels pushy/inattentive, damages trust ([NN/g](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/)) | Adapt suggestions to what the user has already declined |
| Burying undo/rollback in a settings menu | Users disengage from AI features if correction is costly | One-click undo adjacent to every AI-applied change |
| Using color alone to signal confidence/status | Fails colorblind and screen-reader users | Pair color with text/icon labels |
| Shared/unscoped credentials for agent actions | Breaks attribution and audit; security risk | Distinct, scoped, revocable per-agent identity |
| Treating chat as the default surface for every task | Forces conversational overhead onto structured tasks | Match surface to task shape (see §6) |
| Training-data opt-in bundled with basic feature/data-access consent | Conflates unrelated consents, reduces informed choice | Separate, explicit toggle for training-data use |

---

## 15. Measurable UX quality criteria

| Dimension | Metric | Target/benchmark |
|---|---|---|
| Time-to-first-feedback | Time from user submit to first visible token/skeleton | < 1s |
| Trace/plan discoverability | Clicks to reach full reasoning trace from a summary | ≤ 1 click |
| Provenance discoverability | Clicks to find source for any claim | ≤ 2 clicks (ideally inline, 0 clicks to see marker) |
| Correction cost | Actions required to fix/undo an AI output | ≤ 1 click for undo; ≤ 1 short instruction for edit-in-place |
| Approval friction (low-risk actions) | % of low-risk tool calls requiring modal interruption | Minimize via scoped pre-approval policies |
| Interruptibility | Time from "Stop" click to run halting | < 2s, with partial results preserved |
| Error legibility | % of error states with a named cause + next action | 100% |
| Feedback capture rate | % of AI outputs with a reachable feedback control | 100% (control present), track opt-in rate over time |
| Accessibility conformance | WCAG 2.2 AA success criteria pass rate on AI surfaces | 100% of applicable AA criteria |
| Live-region correctness | Streaming/error announcements correctly voiced by screen reader test | Verified with NVDA/JAWS/VoiceOver |
| Localization robustness | UI integrity at +40% string length (pseudo-localization) | No clipping/overlap |
| Cost transparency | % of billable agent runs showing cost/usage before or immediately after execution | 100% |
| Audit completeness | % of agent actions attributable to a specific identity in logs | 100% |
| Onboarding relevance | % of first-run suggested prompts that are context-specific (not generic) | 100% |

---

## 16. Review checklist (pre-ship gate for an AI/agentic feature)

**Reasoning & transparency**
- [ ] Default view shows a collapsed activity summary; full trace is one click away.
- [ ] Multi-step tool sequences show clear step boundaries and per-step status.
- [ ] Plans are rendered as structured, editable artifacts before execution.

**Trust & provenance**
- [ ] Every grounded claim has an inline, clickable citation.
- [ ] Confidence, if shown, uses label + color, never a bare number or color alone.
- [ ] Sponsored/paid content is visually distinct from organic results.
- [ ] Ambient (not modal) disclaimers are used for standing AI-output caveats.

**Human control**
- [ ] Irreversible/high-risk actions require explicit approval or a declared pre-approval policy.
- [ ] A visible Stop/Pause control is present during any run.
- [ ] Every AI-applied change has an adjacent, one-click undo.
- [ ] Destructive operations default to dry-run/preview.

**Latency & streaming**
- [ ] Responses stream token-by-token or show shape-matched skeletons; nothing renders blank.
- [ ] Scroll position is never force-moved during streaming.
- [ ] Tasks over ~15–30s become trackable background jobs with notification on completion.
- [ ] Sessions/runs resume correctly after reload/disconnect.

**Errors & edge cases**
- [ ] Refusals state a reason and an alternative path.
- [ ] Partial failures show per-step success/failure, not an aggregate failure.
- [ ] Empty/first-run states show concrete example actions.
- [ ] Errors are exposed via correct ARIA live regions.

**Surface fit**
- [ ] The task's surface (chat/canvas/inline/workflow/dashboard) matches its structure — chat is not used by default for structured tasks.
- [ ] No more than one ambiguous chat entry point exists per product area without explicit differentiation.

**Multi-agent/session**
- [ ] Every run has a stable, revisitable identity with timeline and artifacts.
- [ ] Diffs are available for content-mutating steps.
- [ ] Delegation UI names the accountable human.

**Onboarding & discovery**
- [ ] First-run suggestions are contextual, not generic.
- [ ] Suggested follow-ups adapt and don't repeat declined suggestions.
- [ ] Mode/model pickers include a plain-language tradeoff explanation.

**Feedback loops**
- [ ] A feedback control (thumbs, correction capture) is reachable within 1 click of every AI output.
- [ ] Feedback is linked to trace/run IDs for eval-set use.

**Transparency, cost, and enterprise controls**
- [ ] Users can view current data/tool access grants.
- [ ] Costs/usage are visible before or immediately after billable runs.
- [ ] Agent identities are distinct, scoped, and logged in an audit trail.
- [ ] Roles support least-privilege granularity beyond owner/admin/member/viewer.
- [ ] Training-data consent is separate from feature-access consent.

**Accessibility & i18n**
- [ ] WCAG 2.2 AA criteria (focus visibility, target size, dragging alternatives, redundant entry, accessible auth) are met on all AI control surfaces.
- [ ] Streaming/error content is verified with a screen reader.
- [ ] Layouts tolerate 40% text expansion and RTL scripts without breaking.

**Design system**
- [ ] A documented AI-state token set (idle/thinking/streaming/tool-running/awaiting-approval/error/done) is applied consistently.
- [ ] Skeletons match final content shape; no generic spinners for structured content.
- [ ] Citation/confidence/provenance iconography is defined once and reused everywhere.

---

## Sources

- [Google PAIR Guidebook — Patterns](https://pair.withgoogle.com/guidebook/patterns)
- [Building Trusted AI Products with the PAIR Guidebook (Google Codelab)](https://codelabs.developers.google.com/codelabs/pair-guidebook)
- [Guidelines for Human-AI Interaction (Microsoft HAX Toolkit)](https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/)
- [Design Library overview (Microsoft HAX Toolkit)](https://www.microsoft.com/en-us/haxtoolkit/design-library-overview/)
- [Guidelines for Human-AI Interaction — full 18 guidelines (Microsoft Research, CHI 2019)](https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/)
- [IBM Design for AI](https://www.ibm.com/design/ai/)
- [IBM AI design ethics overview](https://www.ibm.com/design/ai/ethics/)
- [Everyday Ethics for Artificial Intelligence (IBM)](https://www.ibm.com/watson/assets/duo/pdf/everydayethics.pdf)
- [Apple Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines)
- [Apple HIG: Machine Learning](https://developer.apple.com/design/human-interface-guidelines/machine-learning)
- [Nielsen Norman Group — Artificial Intelligence topic hub](https://www.nngroup.com/topic/ai/)
- [10 Guidelines for Designing Your Site's AI Chatbots (NN/g)](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/)
- [Generative UI and Outcome-Oriented Design (NN/g)](https://www.nngroup.com/articles/generative-ui/)
- [Polaris Goes Stable — Shopify](https://www.shopify.com/partners/blog/polaris-goes-stable-the-future-of-shopify-app-development-is-here)
- [AI SDK UI Overview (Vercel)](https://sdk.vercel.ai/docs/ai-sdk-ui/overview)
- [Chatbot Tool Usage (Vercel AI SDK)](https://sdk.vercel.ai/docs/ai-sdk-ui/chatbot-tool-usage)
- [Open Source AI Artifacts and Code Execution (Vercel)](https://vercel.com/templates/next.js/open-source-ai-artifacts)
- [Building Effective AI Agents (Anthropic)](https://www.anthropic.com/engineering/building-effective-agents)
- [A Practical Guide to Building Agents (OpenAI)](https://openai.com/business/guides-and-resources/a-practical-guide-to-building-ai-agents/)
- [GPT-4.1 Prompting Guide (OpenAI Cookbook)](https://developers.openai.com/cookbook/examples/gpt4-1_prompting_guide)
- [What's New in WCAG 2.2 (W3C WAI)](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/)
- [ARIA19: Using role=alert or Live Regions to Identify Errors (W3C)](https://www.w3.org/WAI/WCAG22/Techniques/aria/ARIA19)
- [WCAG 2.2 Checklist (GetWCAG)](https://getwcag.com/en/blog/wcag-2-2-checklist)
- [Cursor Plan Mode: Review a Plan Before the Agent Codes](https://www.learncursor.dev/learn/cursor-agents/agent-plan-mode)
- [Cursor Docs — Diffs & Review](https://docs.cursor.com/agent/review)
- [AI Agents – Linear Docs](https://linear.app/docs/agents-in-linear)
- [UX Teardown: Perplexity AI's Citations & Follow-Up Experience](https://assets.nextleap.app/submissions/UX_teardown-3a359c8e-53c8-4d93-8e85-f63f5ae18856.pdf)
- [Designing Trust in AI Outputs: 7 UX Patterns for Uncertainty (Creative Alive)](https://creativealive.com/designing-trust-ai-outputs-ux-patterns-uncertainty/)
- [AI Agent Governance for Enterprises (Praesidia)](https://praesidia.ai/blog/ai-agent-governance-for-enterprises)
- [Using Human Annotations for Eval Driven Development (Arize)](https://arize.com/docs/phoenix/cookbook/human-in-the-loop-workflows-annotations/using-human-annotations-for-eval-driven-development)
- [5 Challenges in Multilingual AI UX Design (DeveloperUX)](https://developerux.com/2025/06/11/5-challenges-in-multilingual-ai-ux-design/)
- [Creating a Skeleton UI Loading Animation (ProtoPie)](https://www.protopie.io/blog/how-to-create-a-skeleton-ui-loading-animation)
