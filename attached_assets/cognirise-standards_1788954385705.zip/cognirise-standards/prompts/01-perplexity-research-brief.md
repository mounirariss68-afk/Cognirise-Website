# Prompt 01 — Perplexity Research Brief (Stage 1)

**Use when** a new engagement has been qualified and you need the research pack that Stage 2 will consume.
**Governed by** `standards/02-research-brief.md`.
**Produces** `docs/01-research-pack.md`.

How to use: copy everything below the line, replace every `<<...>>` placeholder, delete any optional block that does not apply. Do not remove the Output Contract section — it is what makes the result reusable by Claude without reshaping.

---

You are researching the input for an agentic product prototype that Cognirise will design and build. Your output will be consumed directly by another model to write functional and technical specifications, so structure matters as much as content.

## Engagement context

- **Client type:** <<government department | bank | telco | B2B enterprise>>
- **Client / sector:** <<e.g. a UAE federal authority handling citizen service requests>>
- **Jurisdiction:** <<UAE onshore | DIFC | ADGM | other>>
- **Business problem in one sentence:** <<...>>
- **Primary users and their role:** <<e.g. tier-1 contact centre agents; internal compliance reviewers; the public>>
- **Working hypothesis of the solution:** <<e.g. an agentic assistant that drafts responses to citizen enquiries grounded in policy documents>>
- **Languages:** <<Arabic + English | English only>>
- **Known constraints:** <<data cannot leave the UAE | must integrate with SAP | 6-week timeline | ...>>
- **What a successful prototype must demonstrate:** <<...>>

## Research questions

Answer each of the following. Where evidence is thin, say so explicitly rather than generalising.

1. **Domain and process.** How does this process work today in this sector? Map the current end-to-end process, the actors, the decision points, the data and documents involved, the typical volumes and cycle times, and the known pain points. Capture the domain vocabulary precisely — the exact terms practitioners use.
2. **Regulatory and policy constraints.** What rules govern this process and this data in <<jurisdiction>>? Include data protection, sector regulation, record-keeping, and any requirement for human decision-making or explainability. Cite the instrument, not commentary about it.
3. **Analogues and prior art.** What comparable products, government initiatives, or vendor solutions exist regionally and globally? For each: what it does, its approach, its published outcomes, and its visible limitations.
4. **Decision and judgement structure.** Which decisions in this process are rule-based, which are judgement-based, and which are contested or discretionary? This determines what can be automated versus what must stay human.
5. **Data landscape.** What data and document types exist, in what formats, at what quality, with what access controls, and how current are they? Flag anything scanned, tabular, handwritten, or Arabic-language.
6. **Integration surface.** What systems must this touch, and what are their documented integration options?
7. **Success measures.** How is performance measured in this domain today, with real baseline figures where available? These become the prototype's target metrics.
8. **Risks and failure modes.** What goes wrong in this process today, and what would go wrong specifically if an AI system did it badly? Include the reputational and regulatory consequences.
9. <<Optional additional questions specific to the engagement>>

## Source rules

- Prefer primary sources: the regulator, the standards body, the vendor's own documentation, the official statistics agency, peer-reviewed work.
- Do not treat aggregator or content-farm pages as authoritative for facts, figures, or regulatory content. Go to the publisher.
- Prioritise material from the last 18 months for anything technological or regulatory; note publication dates.
- For regional content, actively seek UAE and GCC sources, including Arabic-language ones, rather than defaulting to US/EU material.
- Every non-obvious factual claim carries an inline citation with the source's real name as the link text.

## Output contract

Return a single markdown document with exactly these top-level sections, in this order:

```
# Research Pack — <<engagement name>>
## 1. Executive summary            (10-15 bullets, decision-relevant only)
## 2. Domain model                 (actors, entities with definitions, process stages)
## 3. Current-state process        (numbered steps; Mermaid flowchart)
## 4. Domain glossary              (table: term | definition | Arabic equivalent if applicable | source)
## 5. Regulatory and policy constraints   (table: instrument | requirement | design implication | source)
## 6. Analogues and prior art      (table: solution | approach | outcomes | limitations | source)
## 7. Decision inventory           (table: decision | rule-based / judgement / discretionary | automatable? | required oversight)
## 8. Data landscape               (table: source | format | volume | quality | sensitivity | access control)
## 9. Integration surface          (table: system | purpose | integration options | effort)
## 10. Baseline metrics            (table: metric | current value | source | target implication)
## 11. Risks and failure modes     (table: risk | likelihood | impact | consequence type | mitigation direction)
## 12. Opportunity map             (candidate use cases ranked by value and feasibility, with reasoning)
## 13. Unknowns and assumptions    (table: item | why it matters | how to resolve | owner)
## 14. Sources                     (grouped by section, full URLs)
```

Rules for the output:
- Tables over prose wherever the content is enumerable.
- Never fill a gap with a plausible generalisation. Anything unverified goes in section 13 and nowhere else.
- Quantify wherever a real number exists; write "not published" rather than estimating silently.
- Keep section 1 readable by a client executive; keep sections 2-13 readable by an engineer.
