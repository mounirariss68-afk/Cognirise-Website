# Prompt 05 — Replit Agent: Implementation and Hardening (Stage 4)

**Use when** taking the Claude-generated codebase into Replit for final implementation, wiring and deployment.
**Governed by** `standards/20-replit-deployment.md` and `standards/19-repo-conventions.md`.

**Before you start:** the repo must contain `AGENTS.md` at its root (Replit Agent reads it), the spec set under `specs/`, and the standards under `docs/standards/`. Replit Agent works best on narrow, verifiable increments — do not paste this whole file as one request. Use the section that matches the increment you want, one at a time, and checkpoint between them.

---

## Standing instructions (paste once at the start of a session)

You are working on a Cognirise client prototype. Read `AGENTS.md` and `specs/technical-spec.md` before making changes.

Binding constraints for every change you make:

- The specification in `specs/` is authoritative. Do not add features, pages, models, or dependencies that are not in the spec. If a change seems necessary, propose it and wait.
- Do not modify the database schema, tool contracts, or prompt files without being asked to. Those are governed artifacts.
- No agent or session state in memory — this deploys to Autoscale where any request may hit a fresh instance. State goes to Postgres.
- All secrets come from Replit Secrets via the validated env module. Never hardcode a key, never print a secret, never commit a `.env`.
- Prompts live in `prompts/` as files. Do not inline prompt strings.
- Preserve accessibility and RTL behaviour in every UI change: logical CSS properties, keyboard operability, live-region announcements.
- Run typecheck, lint and tests after each change and report the real output. Do not claim success without running them.
- Work in small increments and checkpoint. Prefer editing existing files over creating parallel implementations.

## Increment prompts

### A. Environment and boot
Get the project running: install dependencies, provision Replit Postgres, run the Drizzle migrations, register every required secret in Replit Secrets (list them from the env schema and tell me which values you need), configure `.replit` for the dev workflow, and confirm the app boots with a health endpoint returning the build SHA and migration state. Report anything the env schema requires that is not yet set.

### B. Persistence and background work
Verify every table in `specs/data-spec.md` exists and matches the schema. Configure connection pooling appropriate to Autoscale. Set up `pg-boss` on the same database for background jobs, with the worker as a separate deployment target, and wire any scheduled work to a Replit Scheduled Deployment. Confirm a job survives a process restart.

### C. Journey wiring
Implement journey `<<name>>` exactly as specified in `docs/03-journeys.md` and `docs/04-ux-spec.md`. Every state in the spec must be reachable and visually correct: empty, loading, streaming, partial, error, refused, escalated, complete. Wire the approval gate as specified, with durable interrupt and resume. Do not simplify the failure paths.

### D. Retrieval layer
Implement the ingestion and query pipeline per `specs/rag-spec.md`. Confirm the pgvector index exists with the specified parameters, hybrid search returns fused results, the reranker is called, and the query path filters by tenant and ACL in SQL before results reach the model. Add the ingestion runbook to `docs/runbook.md`.

### E. Observability and budgets
Wire OpenTelemetry GenAI spans to the configured backend. Ensure every run has a trace ID that is returned to the client and rendered in the UI. Implement per-run cost and token accounting written to the database. Enforce the budget limits from `specs/agent-spec.md` in code and verify by test that exceeding a limit terminates the run cleanly with a user-visible message.

### F. Verification pass
Run the full gate set from `standards/21-qa-definition-of-done.md`: typecheck, lint, unit tests, promptfoo eval suite against the golden set, Playwright journey tests, axe accessibility scan, Arabic/RTL visual pass, and the prompt-injection test set. Report each result with actual numbers. Do not fix and re-report silently — show me what failed first.

### G. Demo readiness
Seed the demo dataset per the spec. Verify the demo script in `docs/demo-script.md` end to end, including the deliberate failure and escalation moments. Configure the deployment (type per `standards/20`), access control for client reviewers, and a custom domain if required. Confirm the gap list in `docs/gaps.md` matches reality — every stub, mock or deferred item must be listed.

## What to escalate to a human rather than solve

- Any change that would alter the database schema, a tool contract, an authorisation rule, or a prompt file.
- Any failing eval or security test — report, do not silently loosen the threshold.
- Any dependency addition, and any suggestion to move off the canonical stack.
- Any point where the spec is silent and the answer materially affects behaviour.
