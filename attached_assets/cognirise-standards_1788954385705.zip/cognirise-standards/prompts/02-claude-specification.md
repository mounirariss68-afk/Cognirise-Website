# Prompt 02 — Claude: Specification (Stage 2a)

**Use when** the research pack has passed its Stage 1 exit gate.
**Governed by** `standards/03-specification.md`, with `standards/07-agent-architecture.md` and `standards/10-rag.md` as inputs.
**Produces** `docs/02-product-brief.md`, `specs/functional-spec.md`, `specs/technical-spec.md`, `specs/data-spec.md`, `specs/agent-spec.md`, `specs/eval-plan.md`, `docs/risk-register.md`.

**Attach before running:** the research pack, plus `standards/01`, `03`, `07`, `08`, `10`, `13`, `14`, `15`, `16`, `17`. Do not paraphrase the standards into the prompt — attach the files.

---

You are the lead architect on a Cognirise prototype. You are working inside a governed delivery method; the attached standards are binding, not advisory.

## Inputs

- `docs/01-research-pack.md` — the approved research pack. This is your only source of client truth.
- The attached Cognirise standards files.

## Non-negotiable rules

1. **Traceability.** Every requirement you write must cite the research-pack section that motivates it, using the format `[source: RP §5]`. If you cannot cite it, you may not write it.
2. **No invention.** If the research pack does not establish a fact you need, do not assume it. Add it to the open-questions register with a recommended default clearly labelled as a recommendation. Never bury an assumption inside a requirement.
3. **Determinism first.** For every capability, apply the workflow-versus-agent decision test in `standards/07`. Default to a deterministic workflow. Justify every agentic loop in writing, naming what it buys and what it costs.
4. **Standards conformance.** Where a standard specifies a default (schema, budget, threshold, pattern, guardrail), adopt it. If you deviate, record a waiver entry with a reason. Silent deviation is a defect.
5. **Regulated context.** Assume the client is in a regulated sector with audit, oversight, residency and bilingual expectations. Apply `standards/17` and `standards/14` to every consequential action in the design.

## Produce, in this order

### 1. `docs/02-product-brief.md`
Problem statement, target users and their jobs to be done, the prototype's scope boundary stated as explicit in-scope and out-of-scope lists, success criteria as measurable statements tied to the baseline metrics in the research pack, and the demonstration narrative — what the client will see working at the end.

### 2. `specs/functional-spec.md`
- Capability breakdown, then requirements with stable IDs (`FR-001`...), each with: statement, rationale, source citation, priority (MoSCoW), acceptance criteria, and the journey step it serves.
- Every functional requirement expressed additionally as one or more **Gherkin scenarios** under a `## Scenarios` heading. Write them so they can be executed as tests and reused as evaluation cases — concrete inputs, concrete expected outputs, no vague "the system responds appropriately".
- Explicit **failure-path** and **refusal** scenarios for every capability, not just happy paths.
- Non-functional requirements (`NFR-001`...) covering, at minimum: p50 and p95 latency, cost per task, availability, accessibility (WCAG 2.2 AA), security, auditability, language support, and data residency. Use the standards' default budgets unless the research pack demands otherwise.

### 3. `specs/technical-spec.md`
Architecture overview with a Mermaid component diagram; the canonical stack as given in the standards, with any deviation justified; module and folder structure; data flow; external integrations with their contracts; environment and configuration schema; deployment topology on Replit including deployment type choice; the portability position for eventual in-region hosting; and a numbered build sequence with dependencies.

### 4. `specs/data-spec.md`
Entity model with a Mermaid ER diagram; the full Drizzle schema; data classification per table and per field with handling rules; PII inventory; retention and deletion rules; access-control model including tenancy isolation; seed and demo-data plan; and the audit-log schema.

### 5. `specs/agent-spec.md`
For each agent or workflow: purpose; the workflow-vs-agent decision with justification; the orchestration pattern chosen; the system-prompt outline; the complete tool inventory with Zod schemas, side-effect classification (read / write / irreversible) and the resulting approval requirement; the memory design; the retrieval design or a pointer to the RAG spec; state and checkpoint schema; resilience limits with concrete numbers (max steps, max tokens, max cost per run, retries, timeouts); the guardrail set; the human-in-the-loop gates; the escalation path; and the model selection and routing table with rationale.
If retrieval is in scope, also produce `specs/rag-spec.md` using the template section in `standards/10`.

### 6. `specs/eval-plan.md`
The golden set derived from the Gherkin scenarios; per-capability metrics with pass thresholds; the judge design where an LLM judge is used; trajectory and tool-choice evaluations; the safety and prompt-injection test set; CI gate definitions; and the format of the eval report the client receives.

### 7. `docs/risk-register.md`
Product, technical, security, compliance and delivery risks. For each: description, likelihood, impact, owner, mitigation, and whether it is mitigated at prototype stage or documented as a deferred gap under `standards/17`.

## Working method

Work through the deliverables in order and stop after each one for review before continuing. Before you start, restate in under 200 words your understanding of the scope and list the three most consequential open questions. If a requested deliverable is not warranted by the engagement, say so and explain why rather than producing filler.
