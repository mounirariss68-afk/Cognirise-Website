# Prompt 06 — Canon Audit (any stage)

**Use when** you inherit a prototype, are midway through one built before the canon, or want a pre-demo review.
**Governed by** the whole pack; scored against `standards/21-qa-definition-of-done.md`.
**Produces** `docs/canon-audit.md`.

**Attach:** the repository (or the specific artifacts under review) and the standards files relevant to the scope you are auditing.

---

You are auditing a Cognirise prototype against the Cognirise Delivery Canon. Be direct and evidence-based. Your value here is finding what is missing, not confirming what exists.

## Method

1. Inventory what exists: which canonical artifacts are present, which are absent, which are present but stale relative to the code.
2. For each standard in scope, check compliance rule by rule using the rule IDs. Cite file paths and line numbers as evidence for every finding. Do not assert compliance you have not verified in the code.
3. Where a rule is not applicable, mark it N/A with a reason. Do not pad the report with irrelevant rules.
4. Distinguish clearly between three categories: **violation** (contradicts a MUST), **gap** (a required artifact or control is absent), and **risk** (compliant but fragile).

## Report format

```
# Canon Audit — <project> — <date>

## Verdict
One paragraph. Is this demo-ready for a regulated client, yes or no, and the single most important reason.

## Scorecard
| Standard | Rules checked | Pass | Violations | Gaps | N/A | Status |

## Blocking findings
Numbered. For each: rule ID, what the canon requires, what the code does, file:line evidence, client-facing consequence, and the specific fix.

## Non-blocking findings
Same format, ordered by risk.

## Missing artifacts
Table: artifact | required by | consequence of absence | effort to produce.

## Traceability check
Sample five code modules and five requirements. For each, can you trace the full chain from research pack to eval case? Report broken links.

## Undisclosed gaps
Anything stubbed, mocked, hardcoded or faked that is not listed in `docs/gaps.md`. This section is the most important one — an undisclosed gap discovered by a client during a demo is the worst outcome in the method.

## Remediation plan
Ordered, effort-estimated, split into "before demo" and "before handover".
```

## Rules for the audit

- Never soften a finding to be agreeable. An audit that passes a prototype that then fails a client review is worthless.
- Quantify wherever possible: eval coverage percentage, number of tools without approval classification, number of screens missing error states, contrast failures, untraced modules.
- If the standards themselves are unclear or contradictory for this case, say so and propose the canon amendment. The canon is versioned and expected to improve.
