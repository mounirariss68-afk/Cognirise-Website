# Prompt 03 — Claude: Journeys, Product Design and UI (Stage 2b)

**Use when** the functional spec is approved.
**Governed by** `standards/04-journey-design.md`, `standards/05-ux-ui.md`, `standards/06-design-system.md`, `standards/18-accessibility-i18n.md`.
**Produces** `docs/03-journeys.md`, `docs/04-ux-spec.md`, `docs/05-design-system.md`, `app/` component inventory.

**Attach before running:** the research pack, product brief, functional spec, agent spec, plus `standards/04`, `05`, `06`, `14`, `18`.

---

You are the product designer and design engineer on a Cognirise prototype. Design an agentic interface for a regulated-sector client. The attached standards are binding.

## Non-negotiable rules

1. **Chat is a choice, not a default.** Select the primary surface using the decision table in `standards/05` and justify it. If a form, table, dashboard or workflow builder serves the job better, design that instead.
2. **Design the failure paths first.** For every journey, specify what the interface does on partial failure, tool error, low confidence, insufficient evidence, refusal, timeout, and user interruption. A design that only covers success is incomplete.
3. **Every consequential action has a gate.** Apply the action classification in `standards/14` and design the corresponding approval, preview, diff or undo affordance.
4. **Provenance is visible.** Any generated claim that derives from retrieved data shows its source inline, per `standards/05`. Confidence is expressed as calibrated labels, never as raw percentages.
5. **Bilingual and accessible by construction.** Arabic is a first-class locale with full RTL support using logical CSS properties. WCAG 2.2 AA is the floor, including live-region announcement of streaming output and errors. Retrofitting either is prohibited.
6. **Use the design system.** Compose from the Cognirise token set and the standard AI component inventory in `standards/06`. Introduce a new component only when no existing one fits, and then add it to the inventory with its states documented.

## Produce, in this order

### 1. `docs/03-journeys.md`
For each primary journey:
- The job to be done, the trigger, and the user's success condition.
- A **service blueprint** with a line of agency showing which steps are user, which are agent, which are system, and which are a handoff. Include backstage steps.
- The **autonomy level per tool** used in the journey (assist / co-pilot / autopilot) with the evidence that justifies it.
- A **Mermaid state machine** of the run lifecycle including every terminal state — completed, refused, escalated, cancelled, failed, timed out.
- A **Mermaid sequence diagram** for the main interaction, showing tool calls and approval gates.
- **Gherkin scenarios** covering the happy path, each failure path, and each escalation path — reusing and extending the scenario IDs from the functional spec so they remain traceable.
- The **escalation design**: systemic trigger conditions (not the model's self-assessment), routing, SLA, what the human sees, and what happens on SLA breach.
- The **first-run versus steady-state** difference in trust and disclosure.

### 2. `docs/04-ux-spec.md`
- Surface selection with justification, plus the information architecture and navigation model.
- Screen-by-screen specification. For each screen: purpose, layout regions, component list, every state (empty, loading, streaming, partial, error, refused, complete, offline), keyboard interaction model, focus and live-region behaviour, and the copy for all system-generated strings in both English and Arabic.
- The reasoning-disclosure design: what is shown by default, what is one click away, what is in the full trace.
- The streaming and long-running task design, including background execution, resumability and notification.
- Feedback capture bound to run and trace IDs so it can flow into the eval set.
- Cost, usage and permission transparency surfaces where the client is a platform operator.
- Admin, roles, audit-log and tenant surfaces where applicable.
- Measurable UX acceptance criteria per screen, using the thresholds in `standards/05`.
- An explicit statement of which banned anti-patterns were at risk here and how the design avoids them.

### 3. `docs/05-design-system.md`
The project's instantiation of the Cognirise design system: the token values as CSS variables with the Tailwind wiring, light and dark modes with verified contrast ratios, the type scale and font choices for Latin and Arabic, the motion vocabulary mapped to agent activity states with reduced-motion fallbacks, and the component inventory with props, variants and states.

### 4. Component scaffold
Produce the React component files for the AI-specific components this project needs, typed, accessible, RTL-safe, composed from shadcn/ui and the Vercel AI SDK, with no business logic embedded. Include a Storybook-style states file or a `/design` route rendering every component in every state so the design can be reviewed without running the full journey.

## Working method

Before designing, restate the primary job to be done in one sentence and name the surface you have chosen with your reasoning. Stop for review after `docs/03-journeys.md` before proceeding. Flag any place where the functional spec is silent on a decision the design forces — do not resolve it silently.
