# Cognirise Delivery Canon — Standards Proposal

**Version** 1.0 · **Date** 27 July 2026 · **Owner** Cognirise Delivery · **Status** for approval

---

## 1. What problem this solves

Cognirise's pipeline — research brief → Perplexity → Claude (specs, journeys, design) → Claude (code) → Replit (implementation) — is fast, and speed is the point. But an LLM-driven pipeline has a specific structural weakness: **every stage will confidently fill gaps you left open.** Where the brief is vague, Claude invents requirements. Where the spec omits non-functionals, the code ships no budgets, no evals, no audit trail. Where design guidance is absent, each prototype gets a different UI language and a different definition of "good".

For clients like government departments, banks and telcos, that variance is the commercial risk. These buyers do not evaluate a prototype only on whether the demo works — they evaluate whether the team behind it has a repeatable, governable method. A prototype that streams beautifully but has no audit log, no human-approval gate, no data-classification statement and no accessibility pass will not survive a bank's second-line review, however good the demo was.

The canon converts your pipeline from a sequence of prompts into a **governed assembly line**: same inputs required, same artifacts produced, same gates passed, same quality floor — at the same speed or faster, because the models stop guessing.

Three principles underpin everything:

1. **Standards are context, not documentation.** A standard nobody pastes into Claude is decoration. Every file in this pack is written to be machine-actionable and is wired into `CLAUDE.md`, the Replit Agent prompt, and a reusable Perplexity skill.
2. **Determinism until proven insufficient.** Most "agents" clients ask for should be workflows. [Anthropic's guidance on building effective agents](https://www.anthropic.com/engineering/building-effective-agents) is explicit that you should find the simplest solution and only add agentic complexity when it demonstrably improves outcomes. The canon makes that a required, documented decision.
3. **Traceability end to end.** Every line of generated code traces back to a spec section, which traces to a requirement, which traces to a journey step, which traces to a client need in the brief. Untraceable code is rejected. This single rule kills most AI-pipeline scope drift.

---

## 2. The operating model

```
Stage 0  Qualify        →  engagement one-pager, data-classification statement
Stage 1  Research       →  Perplexity research pack (structured, cited)      [BRIEF]
Stage 2  Spec & Design  →  spec set, journeys, agent spec, RAG spec, eval plan  [SPEC JRN UX DS AGT RAG]
Stage 3  Code gen       →  repo scaffolded to canon, prompts as files        [REPO CTX TOOL]
Stage 4  Implement      →  working prototype on Replit, instrumented         [DEP OBS SEC GRD HITL]
Stage 5  Verify         →  eval report, security + a11y + bilingual passes   [EVAL QA A11Y]
Stage 6  Handover       →  demo, handover pack, gap register                 [HAND GOV]
```

Each stage has entry criteria, required artifacts with fixed filenames, and an exit gate. Work does not advance on a gate failure without a written, signed waiver.

---

## 3. Proposed standards areas

22 standards in 7 clusters. Items marked **★** are areas you did not ask for and which I recommend adding — they are where regulated-client deals are usually won or lost.

### Cluster A — Discovery, specification and traceability

| # | Standard | Locks in | Why it matters to your pipeline |
|---|---|---|---|
| 01 | **Delivery lifecycle** ★ | Stage gates, artifact filenames, traceability chain | Makes the canon enforceable rather than advisory; gives clients a visible method |
| 02 | **Research brief** | Mandatory brief sections, required output structure, source-quality rules | Perplexity output becomes directly consumable by Claude instead of needing re-shaping every time |
| 03 | **Specification taxonomy** ★ | The seven spec documents, requirement IDs, Gherkin-as-eval-fixture, default non-functional budgets | Removes the biggest failure mode: Claude inventing requirements and non-functionals never being stated |

### Cluster B — Journey, UX and design

| # | Standard | Locks in | Why |
|---|---|---|---|
| 04 | **Journey design** | Service blueprints with a human/agent line of agency, autonomy levels per tool, escalation SLAs, journeys as state machines + Gherkin | Journeys for non-deterministic systems cannot be drawn as happy-path flows; failure paths are the design |
| 05 | **UI/UX for agentic apps** | Surface selection, progressive disclosure of reasoning, trust calibration, streaming/latency UX, error and refusal states, enterprise surfaces | The single highest-leverage file. Grounded in [Google's People + AI Guidebook](https://pair.withgoogle.com/guidebook/), the [Microsoft HAX Toolkit](https://www.microsoft.com/en-us/haxtoolkit/) and [NN/g's AI chatbot guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/) |
| 06 | **Design system** ★ | Tokens, AI-specific components (tool-call card, citation chip, approval bar, trace timeline), motion vocabulary, RTL typography | Every prototype looks like Cognirise built it; Replit stops reinventing components each time |

### Cluster C — Agent architecture

| # | Standard | Locks in | Why |
|---|---|---|---|
| 07 | **Agent architecture** | Workflow-vs-agent decision test, the pattern catalogue, durable run/step/checkpoint schema, resilience defaults with real numbers, model routing, cost and latency budgets | Prevents the two classic failures: over-engineered multi-agent systems, and agents with no step/cost caps |
| 08 | **Tool contracts** ★ | Naming, Zod schemas, idempotency, side-effect classification driving approvals, error returns that teach recovery | Tool quality determines agent quality more than prompt quality does |
| 09 | **Memory architecture** ★ | Four-tier memory model, compaction triggers, write/retrieval policies, deletion for data-subject requests | "Memory" is where prototypes leak PII across sessions and tenants |
| 11 | **Prompt & context engineering** | System-prompt architecture, token budget accounting, prompts as versioned files, structured outputs, caching | Follows [Anthropic's context engineering guidance](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents); ends inline prompt strings scattered through code |

### Cluster D — Retrieval

| # | Standard | Locks in | Why |
|---|---|---|---|
| 10 | **RAG layer** | Full pgvector + Drizzle schema, hybrid search with RRF, contextual chunk headers, reranking, ACL-aware retrieval in SQL, minimum retrieval/faithfulness thresholds, scale-up triggers | Your most repeated technical asset. [Anthropic's contextual retrieval work](https://www.anthropic.com/news/contextual-retrieval) reports large retrieval-failure reductions from a cheap preprocessing step — worth standardising rather than rediscovering |

### Cluster E — Safety, security and assurance

| # | Standard | Locks in | Why |
|---|---|---|---|
| 12 | **Guardrails & safety** ★ | Layered defence at input, retrieval, model, tool and output; the mandatory guardrail set every prototype ships with | A prototype with zero guardrails cannot be demoed to a regulator-facing client |
| 13 | **Security & authorisation** ★ | Agent least privilege, retrieved content is always untrusted, per-project threat table against the [OWASP Top 10 for LLM Applications](https://genai.owasp.org/llm-top-10/), red-team before demo | Prompt injection and confused-deputy issues are the questions bank security teams actually ask |
| 14 | **Human-in-the-loop & escalation** | Action classification by reversibility and impact, approval patterns, durable interrupt/resume, decision logs | Regulated clients buy oversight, not autonomy. [DIFC's Regulation 10](https://www.difc.com/business/registrars-and-commissioners/commissioner-of-data-protection/regulation-10) makes autonomous processing an explicitly regulated category |
| 15 | **Evaluation** ★ | Eval taxonomy, golden set built from the Gherkin scenarios, deterministic assertions before LLM-judge, CI gates, client eval report | Turns "the demo worked when I tried it" into evidence. This is the fastest credibility upgrade available to you |
| 16 | **Observability & cost** ★ | OpenTelemetry GenAI conventions, trace IDs surfaced to the UI, per-run and per-tenant cost accounting, standard dashboards | You cannot quote a production price without token/latency data from the prototype |

### Cluster F — Governance and engineering

| # | Standard | Locks in | Why |
|---|---|---|---|
| 17 | **Data governance & compliance** ★ | Data classification, residency, PII handling, audit trails, model card and DPIA templates, mapping to UAE PDPL, DIFC, ADGM, CBUAE, [EU AI Act](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai), [NIST AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) and ISO/IEC 42001, plus a defined "compliance-ready prototype" bar | This is the cluster that differentiates Cognirise from a generic vibe-coding shop in a government tender |
| 18 | **Accessibility & bilingual** ★ | WCAG 2.2 AA floor, ARIA live regions for streaming output, Arabic as a first-class locale, RTL and logical CSS, [TDRA's UAE Design System](https://tdra.gov.ae/) expectations | Non-negotiable for UAE government work and routinely forgotten in AI UIs |
| 19 | **Repo conventions** | Folder tree, `CLAUDE.md` and `AGENTS.md` contracts, Zod-validated env, PR review rules for AI-generated code | Per [Anthropic's Claude Code best practices](https://www.anthropic.com/engineering/claude-code-best-practices), the repo file is the highest-leverage lever on output quality |
| 20 | **Replit & deployment** | Autoscale vs Reserved VM vs Scheduled Deployments, secrets, no-in-memory-state rule, how to drive Replit Agent, and the portability path off Replit for in-region client hosting | Replit hosts in the US and India, not the GCC — so portability must be designed in from day one, not discovered at handover |

### Cluster G — Delivery and handover

| # | Standard | Locks in | Why |
|---|---|---|---|
| 21 | **QA & Definition of Done** ★ | Four gates, test pyramid for agentic apps, consolidated release checklist, named sign-off | One page that decides whether a prototype is finished |
| 22 | **Handover & IP** ★ | Demo script standard, honest limitation disclosure, handover pack contents, licence review of AI-generated code and model terms, data return and deletion | Protects the relationship and the follow-on production contract |

---

## 4. Areas I recommend you deliberately exclude for now

- **Fine-tuning and model training standards.** Not your value chain at prototype stage; prompt, context and retrieval quality dominate. Revisit only if a client funds it.
- **MLOps / model deployment pipelines.** Out of scope while you consume hosted models.
- **A full ISO/IEC 42001 management system.** Expensive and premature. The canon instead maps to it so you can answer questionnaires and pursue certification later without rework.
- **Multi-cloud IaC standards.** Standard 20's portability rules are sufficient until a client actually funds production hosting.

---

## 5. How the canon gets used (this is the part that determines whether it works)

| Artefact | Consumed by | Mechanism |
|---|---|---|
| `standards/*.md` | Claude, Replit Agent, consultants | Attached as context; the relevant files named per stage |
| `CLAUDE.md` | Claude Code | Committed at repo root; imports the standards that apply to the build |
| `AGENTS.md` | Replit Agent and other coding agents | Committed at repo root; the short operating contract |
| `prompts/*.md` | Consultants | The four canonical stage prompts — research brief, spec, design, implementation — plus an audit prompt |
| `templates/*.md` | Consultants | Fill-in artifacts: brief, spec set, journey spec, agent spec, RAG spec, eval plan, model card, risk register, DoD, handover pack |
| Perplexity skill | Perplexity | Saved skill so every Cognirise research session applies the brief standard automatically |

**Canon governance.** Semantic versioning on the pack. One named owner. Quarterly review, plus an out-of-cycle review whenever a major model, the AI SDK, or a relevant regulation changes materially. Deviations are allowed but must be recorded as a dated waiver in the project's `docs/waivers.md` with a reason — silent deviation is the only actual violation.

---

## 6. Adoption sequence

| Tier | Adopt | Standards | Effort |
|---|---|---|---|
| **P0 — next engagement** | The spine that pays back immediately | 01, 02, 03, 05, 07, 19, 21 | ~1 week to internalise |
| **P1 — within one month** | The credibility layer | 10, 13, 14, 15, 17, 20 | Mostly template + CI setup |
| **P2 — within a quarter** | The polish and scale layer | 04, 06, 08, 09, 11, 12, 16, 18, 22 | Incremental, per project |

Suggested proof: run the next prototype twice through Stage 2 — once as you do today, once with the canon — and compare spec completeness, rework, and demo-review questions. That gives you an internal case study and a client-facing method story.

---

## 7. Decisions I need from you

1. **Waiver authority** — who may sign a gate waiver (you only, or any lead?).
2. **Eval threshold commitment** — I have set defaults (e.g. retrieval recall@10 and faithfulness floors) in standards 10 and 15. Confirm you are willing to hold client demos to them, since they will occasionally block a demo.
3. **Compliance bar** — confirm the "compliance-ready prototype" bar in standard 17 as the Cognirise minimum for government and banking work.
4. **Observability vendor** — Langfuse (self-hostable, cheaper, better for client-hosted) or LangSmith (better DX). Canon currently defaults to Langfuse.
5. **Client-visible version** — whether you want a public-facing 6-page "Cognirise Method" extract of this canon for proposals and tenders. I would recommend it.
