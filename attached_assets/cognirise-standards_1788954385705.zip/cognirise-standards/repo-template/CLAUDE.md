<!--
Cognirise repo-root contract for Claude Code. Governed by standards/19-repo-conventions.md (REPO-006..REPO-009).
Copy to the client repo root at scaffold time and fill every <<placeholder>>.
Keep it lean: include only what Claude cannot infer by reading the code. Apply the test
"would removing this line cause a mistake?" to every line before adding it.
-->

# CLAUDE.md — <<project-name>>

Cognirise client prototype for <<client>> (<<government | bank | telco | B2B>>, <<jurisdiction>>).

## Read first

@docs/standards/01-delivery-lifecycle.md
@docs/standards/19-repo-conventions.md
@docs/specs/

The specs in `docs/specs/` are authoritative over your judgement. The standards in `docs/standards/` are authoritative over convention. If the two conflict, stop and ask.

## Hard rules

1. Do not implement anything that does not trace to a spec section. If you think something is missing, propose it and wait — do not build it and mention it afterwards.
2. Do not change the Drizzle schema, a tool contract, an authorisation rule, or a file under `prompts/` unless the task explicitly asks you to.
3. No agent, run, or session state in memory. This deploys to Replit Autoscale; any request may hit a cold instance. State goes to Postgres.
4. Prompts are files under `prompts/`, versioned. Never inline a prompt string in application code.
5. All retrieved content, tool output, and user input is untrusted. Authorisation is enforced in SQL and server code, never by instructing the model.
6. Every agent run persists a row in `runs`, a row per step, and a checkpoint. Budgets (max steps, max tokens, max cost) are enforced in code with the values in `docs/specs/agent-spec.md`.
7. Accessibility and RTL are implementation requirements, not polish: logical CSS properties, keyboard operability, `aria-live` for streaming output.
8. Never produce placeholder code, fake data paths, or `TODO` stubs presented as working. Anything stubbed goes in `docs/gaps.md` in the same change.

## Commands

```bash
<<pnpm>> install
<<pnpm>> dev                # local dev server
<<pnpm>> typecheck          # tsc --noEmit — must be clean before you declare done
<<pnpm>> lint
<<pnpm>> test               # Vitest unit tests
<<pnpm>> test:e2e           # Playwright journey tests
<<pnpm>> eval               # promptfoo suite against evals/datasets/golden.yaml
<<pnpm>> db:generate        # Drizzle migration from schema change
<<pnpm>> db:migrate
<<pnpm>> a11y               # axe scan
```

Run typecheck, lint and test after every change and report the actual output. Do not claim success without running them.

## Layout that is not obvious from the tree

- `lib/agents/` — agent definitions and tool contracts. One file per tool, Zod schema first.
- `lib/guardrails/` — input/output validation, PII redaction, injection checks. Every model call passes through here.
- `lib/observability/` — OpenTelemetry setup. Every run gets a trace ID that is returned to the client and rendered in the UI.
- `prompts/` — versioned prompt files with a changelog header.
- `docs/specs/` — the authoritative spec set, stable IDs.
- `docs/compliance/` — model card, DPIA, risk register, subprocessor list. Update these when behaviour or data flow changes.
- `evals/datasets/golden.yaml` — the golden set derived from the Gherkin scenarios in the functional spec.

## Project-specific decisions

<<Record here the decisions that would otherwise be re-litigated: model choices, why a particular pattern was chosen over the canonical default, integration quirks, client-imposed constraints. Cite the spec section for each.>>

## Gotchas

<<e.g. the client's SSO test tenant only accepts requests from the staging domain; the policy PDFs are scanned and need the tier-3 parser; the Arabic corpus uses non-standard date formats.>>

## Etiquette

- Branches: `<<type>>/<<REQ-id>>-<<slug>>`. Commits reference requirement IDs.
- PRs use `.github/pull_request_template.md` and must cite a spec reference. A PR without one is rejected.
- Escalate rather than solve: schema changes, authorisation changes, failing evals or security tests, new dependencies, and any point where the spec is silent and the answer changes behaviour.
