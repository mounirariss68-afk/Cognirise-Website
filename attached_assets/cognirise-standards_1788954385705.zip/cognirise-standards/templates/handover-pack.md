<!--
LIFECYCLE STAGE: 6 — Demo & Handover
GOVERNING STANDARD: standards/01-delivery-lifecycle.md (LIFE-020 — handover generated only after Stage 5 exit passes)
OUTPUT FILENAME: docs/handover-pack.md
SIGN-OFF: Cognirise engagement lead + client sponsor
-->

---
doc: handover-pack
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Handover Pack — <<engagement name>>

<!-- This document may only be finalised after Gate 4 in dod-checklist.md has passed. -->

## Contents index

<!-- What is being handed over, and where each piece lives. -->
| Item | Location |
|---|---|
| Repository | <<repo URL>> |
| Specs | `specs/` |
| Journeys | `docs/journeys/` |
| Eval reports | `evals/latest-run-report.md` |
| Runbook | `docs/runbook.md` |
| Model/system card | `docs/model-card.md` |
| Gaps and waivers | `docs/gaps.md` |
| Demo script | `docs/demo-script.md` |

## Repo location and access

- Repository: <<URL>>
- Access granted to: <<names/roles>>
- Deployment environment: <<Replit Autoscale | Reserved VM>> at <<URL>>

## Runbook pointer

<!-- Point to it, do not restate it. -->
Operational runbook (start/stop, migrations, secret rotation, incident response): `docs/runbook.md`

## Cost model

| Item | Basis | Estimate |
|---|---|---|
| Per-run inference cost | From `specs/agent-spec.md` cost/latency budget | <<...>> |
| Infrastructure (Replit plan tier) | <<...>> | <<...>> |
| Third-party API costs | <<...>> | <<...>> |

## Known gaps

<!-- Pointer, not restatement. -->
See `docs/gaps.md` for the full disclosed gap list and waiver log. Most consequential open gap at handover: <<...>>

## Roadmap to production

<!-- What must happen between this prototype and a production deployment. -->
| Item | Owner | Target |
|---|---|---|
| <<e.g. Formal penetration test>> | <<...>> | <<...>> |
| <<e.g. Move to Reserved VM / in-region hosting>> | <<...>> | <<...>> |

## Support boundary

<!-- What Cognirise will and will not support after handover, and for how long. -->
- Support window: <<e.g. 30 days post-handover for defect fixes only>>
- In scope: <<...>>
- Out of scope: <<...>>
- Escalation contact during support window: <<name, contact>>

## Data return and deletion confirmation

<!-- Confirms Cognirise has no residual copy of client data outside the handed-over environment. -->
- [ ] All client data used during the engagement resides only in the handed-over environment or has been deleted
- [ ] Any local/demo copies of client data used by Cognirise staff have been deleted
- [ ] Confirmation recorded by: <<name>>, <<date>>

## Sign-off

Cognirise engagement lead: <<name>> — <<date>>
Client sponsor: <<name>> — <<date>>
