<!--
LIFECYCLE STAGE: All — consolidated Definition of Done, checked at each stage gate
GOVERNING STANDARD: standards/01-delivery-lifecycle.md (stage exit criteria) + Definition of Done sections across all standards
OUTPUT FILENAME: docs/dod-checklist.md
SIGN-OFF: Cognirise lead architect (per gate); final gate additionally requires client sponsor sign-off
-->

---
doc: dod-checklist
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Definition of Done Checklist — <<engagement name>>

<!-- Grouped by gate. Every item must be verifiable by inspection or test — no item that only a feeling can confirm. -->

## Gate 1 — Research Brief exit (Stage 1)

- [ ] `docs/research-brief.md` complete with all 9 mandatory sections
- [ ] `docs/01-research-pack.md` returned with all 14 output-contract sections in order
- [ ] Every research question tagged `[researchable]` has at least one cited finding or is listed in Unknowns & Assumptions
- [ ] Competitor/analogue scan has ≥3 rows
- [ ] Regulatory notes cite a primary source for every requirement row
- [ ] Data classification statement is consistent with `docs/qualification.md`
- [ ] <<any engagement-specific item>>

## Gate 2 — Specification sign-off (Stage 2)

- [ ] All 7 spec docs present: product-brief, functional-spec, technical-spec, data-spec, agent-spec, eval-plan, risk-register
- [ ] `docs/traceability-matrix.md` maps every `REQ-###` to a journey, spec section, and eval case
- [ ] Every FR has ≥1 happy-path, ≥1 ambiguous, ≥1 failure/refusal Gherkin scenario
- [ ] NFR table present with budgets filled (latency, cost, availability, accessibility, security, residency)
- [ ] Every agent/workflow has a documented workflow-vs-agent decision
- [ ] Every tool has a side-effect class, risk tier, and approval requirement
- [ ] Data classification and PII inventory complete for every entity
- [ ] Risk register has a named accountable owner
- [ ] `specs/rag-spec.md` present if retrieval is in scope
- [ ] <<any engagement-specific item>>

## Gate 3 — Implementation complete (Stage 3/4)

- [ ] Every module traces to a spec section; no untraceable code
- [ ] Zod schemas, Drizzle schema, and tool contracts defined before behaviour was implemented
- [ ] No agent state held in process memory; all state persists to Postgres
- [ ] Max steps, max tokens, max cost, timeouts, retries, loop detection implemented and tested, matching agent-spec.md values
- [ ] OpenTelemetry GenAI spans present with run/trace IDs surfaced to the client
- [ ] Input and output validation implemented with a bounded repair path
- [ ] All retrieved/tool-returned content treated as untrusted input in prompts
- [ ] Prompts are versioned files under `prompts/`, not inline strings
- [ ] Vitest, promptfoo, and Playwright suites exist and are wired to CI
- [ ] Accessibility automated checks pass at WCAG 2.2 AA
- [ ] <<any engagement-specific item>>

## Gate 4 — QA & Eval exit (Stage 5)

- [ ] Typecheck, lint, unit tests pass with real reported output
- [ ] promptfoo run against the full golden set meets all thresholds in `specs/eval-plan.md`
- [ ] Playwright journey tests pass for every primary journey
- [ ] axe accessibility scan passes; Arabic/RTL visual pass completed
- [ ] Prompt-injection/safety test set passes
- [ ] `docs/gaps.md` reviewed and matches the actual state of the code — no undisclosed stub
- [ ] `docs/model-card.md` complete and reviewed by a compliance-aware reviewer
- [ ] `docs/demo-script.md` rehearsed end to end, including the deliberate failure/escalation beat
- [ ] Client sponsor sign-off recorded
- [ ] <<any engagement-specific item>>

## Final handover gate (Stage 6)

- [ ] `docs/handover-pack.md` complete and points to a real repo location
- [ ] Support boundary and data return/deletion confirmed in writing
- [ ] Roadmap-to-production items agreed with client
