<!--
LIFECYCLE STAGE: 1 — Research Brief (pre-Perplexity)
GOVERNING STANDARD: standards/02-research-brief.md
OUTPUT FILENAME: docs/research-brief.md
SIGN-OFF: Cognirise engagement lead (before the Perplexity prompt in prompts/01-perplexity-research-brief.md is run)
-->

# Research Brief — <<engagement name>>

<!-- This is the brief the CONSULTANT writes before running prompts/01-perplexity-research-brief.md.
It is not the research output itself. It exists so the Perplexity run has a clear, bounded target
and so Stage 1's exit gate (BRIEF-020) has something concrete to check against. -->

## 1. Business goal

<!-- One paragraph. What changes for the client if this prototype succeeds. -->
<<...>>

## 2. Target users / personas

<!-- One row per persona. Keep it to observable facts, not assumed motivations. -->
| Persona | Current job | Pain point | Technical fluency |
|---|---|---|---|
| Example: Tier-1 contact centre agent | Answers citizen enquiries against policy documents | Manually searches three PDFs per ticket | Low — uses existing CRM only |
| <<...>> | <<...>> | <<...>> | <<...>> |

## 3. Success metrics

<!-- Split explicitly. business_metrics = what the client's leadership cares about.
model_quality_metrics = what the eval plan will later measure. -->

**Business metrics**
- <<e.g. Reduce average handling time from 12 min to 5 min>>

**Model quality metrics**
- <<e.g. ≥90% groundedness on retrieved policy citations (placeholder — finalised in eval-plan.md)>>

## 4. Known constraints

<!-- Carry forward from the engagement one-pager; add anything discovered since. -->
- <<...>>

## 5. Competitive / prior-art pointers

<!-- Named things the consultant already knows about, that the research MUST cover or explain why they don't apply. Not exhaustive — that's what Perplexity is for. -->
- <<e.g. "UAE Government's existing chatbot on the same portal">>

## 6. Explicit non-goals

<!-- What this engagement will NOT attempt, stated so Perplexity does not research it and Stage 2 does not scope it in. -->
- <<e.g. "Not building a case-management system — only the response-drafting assistant">>

## 7. Prototype-vs-production statement

<!-- One paragraph. Confirms this is a bounded prototype, names what "production-ready" would additionally require, and that this brief only targets the prototype. -->
<<...>>

## 8. Research question backlog

<!-- Every line tagged [researchable] (Perplexity can find evidence) or [client-only] (only the client can answer — goes to open-questions.md, not the research prompt). -->
| # | Question | Tag |
|---|---|---|
| 1 | Example: What does UAE PDPL require for storage of citizen enquiry transcripts? | [researchable] |
| 2 | Example: What is the client's actual current average handling time? | [client-only] |
| 3 | <<...>> | <<[researchable] \| [client-only]>> |

## 9. Unknowns & assumptions

<!-- Anything the consultant is assuming in order to write this brief at all. Carried into the research output's own Unknowns & Assumptions section for validation. -->
| Assumption | Confidence | Impact if wrong |
|---|---|---|
| <<...>> | <<high \| medium \| low>> | <<...>> |

## Required output schema reference

<!-- Do not restate the schema here — point to it so the two stay in sync. -->
The Perplexity run against this brief MUST use `prompts/01-perplexity-research-brief.md` and MUST return the 14-section output contract defined there (Executive Summary through Sources), governed by `standards/02-research-brief.md`.
