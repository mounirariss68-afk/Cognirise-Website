<!--
LIFECYCLE STAGE: 5 — QA & Eval Gates (produced before handover)
GOVERNING STANDARD: standards/17-data-governance-compliance.md (GOV-017 model/system card requirement)
OUTPUT FILENAME: docs/model-card.md
SIGN-OFF: Cognirise lead architect + client compliance reviewer
-->

---
doc: model-card
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Model / System Card — <<engagement name>>

<!-- One page. This is the artifact a compliance reviewer reads without reading anything else. -->

## Purpose

<!-- What this system does, in plain language, one paragraph. -->
<<...>>

## Intended uses

- <<e.g. Drafting first-pass responses to routine citizen enquiries for human review>>

## Prohibited uses

<!-- State explicitly what this system must not be used for, even if technically possible. -->
- <<e.g. Must not be used to make a final eligibility decision without human approval>>
- <<e.g. Must not process health or biometric data>>

## Models and providers used

| Component | Model | Provider | Purpose |
|---|---|---|---|
| <<...>> | <<...>> | <<...>> | <<...>> |

## Data flows and residency

<!-- Where data goes, in order, and where it is stored/processed. -->
| Data | Flows to | Residency | Notes |
|---|---|---|---|
| <<e.g. Enquiry text>> | <<model provider API>> | <<region>> | <<e.g. no data used for provider training per contract terms>> |

## Training-data position

<!-- State clearly whether the client's data is used to train/fine-tune any model, and the contractual basis for that answer. -->
<<e.g. "No client data is used to fine-tune or train any third-party model. All models used are pre-trained, called via API under a data-processing agreement that excludes training use.">>

## Human oversight

<!-- Where humans intervene, per the HITL gates in agent-spec.md. -->
- <<e.g. All outbound responses require human approval before sending — see agent-spec.md HITL gates>>

## Known limitations

<!-- Honest, specific. Feeds gaps-and-waivers.md but is written here for the compliance audience. -->
- <<e.g. Grounding accuracy degrades on policy documents updated in the last 30 days pending re-indexing>>

## Evaluation results

<!-- Real numbers from the eval report, not projections. -->
| Dimension | Threshold | Result | Date |
|---|---|---|---|
| <<...>> | <<...>> | <<...>> | <<...>> |

## Monitoring

<!-- What is watched in production/demo and where. -->
- <<e.g. Per-run cost and token accounting via OpenTelemetry GenAI spans → Langfuse dashboard>>

## Contacts

| Role | Name | Contact |
|---|---|---|
| Cognirise engagement lead | <<...>> | <<...>> |
| Client system owner | <<...>> | <<...>> |
| Escalation contact | <<...>> | <<...>> |
