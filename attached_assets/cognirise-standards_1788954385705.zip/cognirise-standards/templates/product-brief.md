<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude)
GOVERNING STANDARD: standards/03-specification.md
OUTPUT FILENAME: docs/02-product-brief.md
SIGN-OFF: Cognirise lead architect + client sponsor
-->

---
doc: product-brief
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Product Brief — <<engagement name>>

## Problem statement

<!-- One paragraph, traceable to the research pack. Cite the section, e.g. [source: RP §1]. -->
<<...>> [source: RP §<<n>>]

## Target users and jobs to be done

<!-- One row per user group. "Job to be done" is the outcome the user is hiring the system for, not a feature. -->
| User | Job to be done | Source |
|---|---|---|
| Example: Tier-1 contact centre agent | Get a policy-grounded draft response in under 30 seconds | [source: RP §2] |
| <<...>> | <<...>> | [source: RP §<<n>>] |

## Scope

**In scope**
- <<...>>

**Out of scope**
<!-- State explicitly, even things that seem obvious — this list is what protects the timeline. -->
- <<...>>

## Success criteria

<!-- Measurable statements tied to the baseline metrics captured in the research pack (RP §10). -->
| # | Success criterion | Baseline (from research pack) | Target |
|---|---|---|---|
| 1 | Example: Average handling time | 12 min (RP §10) | ≤5 min |
| 2 | <<...>> | <<...>> | <<...>> |

## Demonstration narrative

<!-- What the client will see working at the end of the engagement. Written as a short scene, not a feature list. This becomes the seed for demo-script.md later. -->
<<...>>

## Open questions carried forward

<!-- Anything this brief could not resolve from the research pack. Link to docs/open-questions.md rather than duplicating. -->
See `docs/open-questions.md`. Most consequential open item at time of writing: <<...>>
