<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude)
GOVERNING STANDARD: standards/07-agent-architecture.md + standards/08-tool-contracts.md
OUTPUT FILENAME: specs/agent-spec.md
SIGN-OFF: Cognirise lead architect
-->

---
doc: agent-spec
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Agent Spec — <<engagement name>>

<!-- Repeat the "Per agent/workflow" block below once for EACH agent or workflow in scope. -->

## Agent: <<agent or workflow name>>

### Workflow-vs-agent decision

<!-- Answer the 7-question test from standards/07 before any orchestration code is written. Default is workflow. -->
| Question | Answer | Notes |
|---|---|---|
| Are the steps unpredictable in advance? | <<yes/no>> | <<...>> |
| Does the task require nuanced judgement per step? | <<yes/no>> | <<...>> |
| Would a rules engine become unmaintainable? | <<yes/no>> | <<...>> |
| <<...remaining questions from standards/07...>> | <<...>> | <<...>> |

**Decision: <<Deterministic workflow | Agent>>** — <<one to two lines justifying what this buys versus what it costs>>

### Orchestration pattern

<!-- One of: prompt chaining, routing, parallelization, orchestrator-workers, evaluator-optimizer, reflection, ReAct, plan-and-execute. If multi-agent: Sequential / Concurrent / Group chat (≤3 agents) / Handoff (depth ≤5) / Magentic. -->
Pattern: <<...>>
Topology (if multi-agent): <<...>>

### System prompt outline

<!-- Not the full prompt text — the structure it must follow. Actual prompt lives in prompts/ as a file per canon conventions. -->
- Role and scope boundary: <<...>>
- Tools available and when to use each: <<...>>
- Refusal conditions: <<...>>
- Output format contract: <<...>>

### Tool inventory

<!-- One row per tool. Naming: domain_noun_verb, snake_case. Every mutating tool needs an idempotency key. -->
| Tool name | Purpose | Side-effect class | Risk tier | Approval required? |
|---|---|---|---|---|
| *(example)* `enquiry_draft_response` | Drafts a grounded response for review | write | medium | Yes — human reviews before send |
| *(example)* `policy_search_retrieve` | Retrieves candidate policy clauses | read | low | No |
| <<...>> | <<...>> | <<read \| write \| irreversible>> | <<low \| medium \| high>> | <<yes/no + who>> |

### Memory design

<!-- Pointer, not full design — full design lives in a dedicated memory doc if one exists. -->
- Working memory: <<e.g. current run's plan_steps and tool outputs, held in Postgres, not process memory>>
- Long-term memory (if any): <<...>>

### State / checkpoint schema

<!-- Reference the canonical runs/planSteps/checkpoints Drizzle tables; state deviations only. -->
Uses the canonical `runs`, `planSteps`, `checkpoints` tables from `specs/data-spec.md`. Checkpoint reasons in use: <<step_boundary | awaiting_approval | compaction | manual>>.

### Resilience limits

<!-- Defaults below are the Cognirise standard. Override only with justification. -->
| Parameter | Default | Override (if any) |
|---|---|---|
| Retry max attempts | 3, exponential backoff+jitter, base 1.0s, max 30-60s | <<...>> |
| Retry-eligible errors | Rate limits, timeouts, connection errors (never validation errors) | <<...>> |
| Timeout: LLM call | 45s | <<...>> |
| Timeout: tool execution | 15s | <<...>> |
| Timeout: DB query | 5s | <<...>> |
| Timeout: total request | 120s | <<...>> |
| Circuit breaker failure threshold | 5 | <<...>> |
| Circuit breaker recovery timeout | 30-60s | <<...>> |
| Max steps per run | 25 (single agent) / 8 workers, depth 2 (orchestrator-workers) | <<...>> |
| Loop detection | 3 identical consecutive tool calls | <<...>> |

### Guardrail set

<!-- Pull from the mandatory baseline in standards/12; list which apply here. -->
- <<e.g. Input relevance + jailbreak classifier on enquiry text>>
- <<e.g. Output validated against Zod schema, max 2 repair retries>>
- <<e.g. PII redaction before logging>>

### HITL gates

| Trigger | Autonomy tier at trigger | Reviewer role | SLA |
|---|---|---|---|
| <<e.g. Confidence below threshold>> | <<assist \| co-pilot \| autopilot>> | <<...>> | <<...>> |

### Escalation path

<!-- Systemic triggers only — never the model's self-assessment. -->
<<...>>

### Model routing

| Task | Model tier | Rationale |
|---|---|---|
| Classification/routing/extraction | Cheap fast tier | <<model name>> |
| Standard task execution | Mid tier | <<model name>> |
| Synthesis/final answer | Most capable | <<model name>> |
| High-stakes (financial/regulatory/irreversible) | Most capable + baseline eval before downgrade | <<model name>> |

### Cost / latency budget

| Task class | p50 | p95 | Max tokens/run | Max cost/run |
|---|---|---|---|---|
| Simple classification/routing | 500ms | 1.5s | 2,000 | $0.01 |
| Standard single-agent task | 5s | 20s | 30,000 | $0.25 |
| Multi-step orchestrator-workers | 20s | 90s | 150,000 | $2.00 |
| Deep research/magentic | 60s | 300s | 500,000 | $8.00 |

This agent falls into: **<<task class>>**

<!-- Repeat the "## Agent: ..." block above for each additional agent/workflow. -->
