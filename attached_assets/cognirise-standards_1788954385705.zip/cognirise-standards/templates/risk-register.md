<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude); reviewed at every subsequent gate
GOVERNING STANDARD: standards/03-specification.md (Risk Register required sections) + standards/17-data-governance-compliance.md
OUTPUT FILENAME: docs/risk-register.md
SIGN-OFF: Cognirise lead architect + named accountable owner
-->

---
doc: risk-register
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Risk Register — <<engagement name>>

## Risk inventory

<!-- One row per risk, across product, technical, security, compliance, and delivery categories. -->
| ID | Category | Risk | Likelihood | Impact | Mitigation | Owner | Status |
|---|---|---|---|---|---|---|---|
| R-001 *(example)* | Compliance | Draft responses could leak restricted-tier data into logs | Medium | High | PII redaction guardrail before logging; log-access RLS | <<name>> | Prototype-mitigated |
| R-002 *(example)* | Delivery | Client SAP integration credentials arrive late, blocking Stage 4 | Medium | Medium | Use mocked ticketing adapter until credentials arrive, swap before demo | <<name>> | Deferred gap |
| <<...>> | <<Product \| Technical \| Security \| Compliance \| Delivery>> | <<...>> | <<Low \| Medium \| High>> | <<Low \| Medium \| High>> | <<...>> | <<name>> | <<Prototype-mitigated \| Deferred gap>> |

## Regulatory posture statement

<!-- One paragraph naming the applicable frameworks and this engagement's honest posture against them — not a claim of full compliance unless verified. -->
<<e.g. "This prototype is designed with awareness of UAE PDPL and CBUAE guidance. It has not undergone a formal compliance audit; see the Compliance-Ready Prototype Checklist below for the specific gap between prototype and production-ready.">>

Applicable frameworks: <<PDPL | DIFC Regulation 10 | ADGM | CBUAE | EU AI Act | NIST AI RMF | ISO/IEC 42001 | SCA guidance — select those in scope>>

## Compliance-ready prototype checklist

<!-- Split explicitly between what is required even at prototype stage and what can be deferred with a disclosed gap. -->
**Must-have at prototype stage**
- <<e.g. Audit log for every consequential agent action>>
- <<e.g. Human approval gate before any irreversible action>>

**Deferrable, with disclosed gap**
- <<e.g. Formal penetration test — deferred to pre-production hardening, see gaps-and-waivers.md>>

## Named accountable owner

<!-- One person, not a team, per standards convention. -->
Accountable owner for this risk register: **<<name, role>>**
