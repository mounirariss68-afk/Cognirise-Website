<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude)
GOVERNING STANDARD: standards/03-specification.md (Technical Spec required sections)
OUTPUT FILENAME: specs/technical-spec.md
SIGN-OFF: Cognirise lead architect
-->

---
doc: technical-spec
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Technical Spec — <<engagement name>>

## Architecture overview

<!-- State the agent-vs-workflow decision per job type using the 7-question test in standards/07. Default is deterministic workflow; justify any agentic loop. -->
| Job type | Decision | Justification |
|---|---|---|
| <<e.g. Draft enquiry response>> | <<Workflow \| Agent>> | <<one to two lines — what the agent buys here that a fixed pipeline cannot>> |

```mermaid
%% Component diagram — replace with the real architecture
flowchart LR
  User[<<User>>] --> UI[Next.js App Router UI]
  UI --> API[API routes / Server Actions]
  API --> ORCH[<<Orchestration layer — Vercel AI SDK or LangGraph JS>>]
  ORCH --> DB[(Postgres + Drizzle)]
  ORCH --> TOOLS[Tool layer]
  TOOLS --> EXT[<<External systems>>]
```

## Module and folder layout

<!-- Match standards/19 repo conventions if present; otherwise state the layout explicitly. -->
```
app/            <<...>>
specs/          <<...>>
docs/           <<...>>
evals/          <<...>>
.claude/skills/ <<...>>
```

## Integrations

| System | Purpose | Integration method | Auth | Effort |
|---|---|---|---|---|
| <<e.g. Client SAP ticketing>> | <<...>> | <<REST API \| file drop \| DB link>> | <<...>> | <<S \| M \| L>> |

## Environment / configuration schema

<!-- Zod-validated env module. Every value here must appear in the Replit Secrets checklist in handover-pack.md. -->
```ts
// env.ts — example shape, replace with real variables
const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  OPENAI_API_KEY: z.string().min(1),
  <<VARIABLE_NAME>>: z.string().<<...>>(),
});
```

## Deployment topology

| Component | Replit deployment type | Why |
|---|---|---|
| Web app | <<Autoscale \| Reserved VM>> | <<Autoscale unless in-memory state, long-lived connections, or workers are required>> |
| Background worker | <<...>> | <<...>> |
| Scheduled jobs | Replit Scheduled Deployments | Cron-style work per standards/canon conventions |

## Portability position

<!-- Every prototype must state its path to in-region / self-hosted production, even if not built now. -->
<<e.g. "Postgres and pg-boss are portable to any managed Postgres. Vector search stays on pgvector below 10M chunks; migration trigger and target documented in rag-spec.md.">>

## NFR summary

<!-- Cross-reference, do not restate in full. -->
See `specs/functional-spec.md` NFR-001 through NFR-008 for latency, cost, availability, accessibility, security, and residency budgets.

## Out of scope

- <<...>>

## Build sequence

<!-- Numbered, with dependencies. Feeds prompts/04-claude-implementation.md and prompts/05-replit-build.md directly. -->
1. Repo scaffold — TypeScript strict config, lint, formatter, Zod env module, `CLAUDE.md`, `AGENTS.md`.
2. Drizzle schema and migrations (run/step/checkpoint/approval/audit tables).
3. Design tokens, layout shell, AI component inventory, `/design` states route.
4. Tool layer: contracts, implementations, permission checks.
5. Retrieval layer (if in scope): ingestion, chunking, embedding, hybrid search, reranking, ACL-filtered query path.
6. Agent/workflow orchestration: durable state, budgets, guardrails, HITL interrupts.
7. UI journeys: streaming, approval gates, trace surfacing, feedback capture.
8. Observability wiring and standard dashboards.
9. Eval harness, golden set, CI gates.
10. Seed/demo data, then demo script.

## End-to-end verification step

<!-- The single check that proves the whole system works together, not just its parts. -->
<<e.g. "A seeded enquiry runs through UI → agent → retrieval → approval gate → response, with a trace ID visible end to end and matching an audit-log row.">>
