<!--
LIFECYCLE STAGE: 0 — Qualify
GOVERNING STANDARD: standards/01-delivery-lifecycle.md (Stage 0 exit criteria)
OUTPUT FILENAME: docs/qualification.md
SIGN-OFF: Cognirise engagement lead + client sponsor (informal, email or call notes acceptable at this stage)
-->

# Engagement One-Pager — <<client name>>

<!-- One paragraph. Written for someone who was not in the qualification call. -->
<<client name>> — <<one-sentence description of what they do>>. <<one-sentence description of the problem they brought to Cognirise>>.

## Client and jurisdiction

| Field | Value |
|---|---|
| Client name | <<client name>> |
| Sector | <<government \| banking \| telco \| B2B enterprise>> |
| Jurisdiction | <<UAE onshore \| DIFC \| ADGM \| other GCC>> |
| Regulator(s) in scope | <<e.g. Central Bank of the UAE, DIFC Regulation 10>> |
| Client sponsor | <<name, role>> |
| Cognirise engagement lead | <<name>> |

<!-- Example: "Sector: Banking · Jurisdiction: UAE onshore · Regulator(s): CBUAE, UAE PDPL" -->

## Business problem

<!-- One sentence, stated as a business problem, not a solution. Good: "Contact centre agents spend 12 minutes per enquiry manually cross-referencing three policy documents." Bad: "Client needs an AI chatbot." -->
<<...>>

## Primary users

| User group | Role in the process | Approx. volume |
|---|---|---|
| <<e.g. tier-1 contact centre agents>> | <<what they currently do>> | <<e.g. 40 agents, 300 enquiries/day>> |

<!-- Add one row per user group. Include internal reviewers/approvers even if they are not the primary end user. -->

## Data classification statement

<!-- State the highest classification tier of data this engagement will touch, per standards/17-data-governance-compliance.md's 4-tier model (Public / Internal / Confidential / Restricted). Restricted if health, biometric, religious, ethnic, or criminal data is involved. -->
Highest classification tier in scope: **<<Public | Internal | Confidential | Restricted>>**

<<One or two lines naming the specific data types that drive this classification, e.g. "Emirates ID numbers and account balances — Confidential; no health or biometric data in scope.">>

Data residency constraint: <<data must not leave UAE | may use regional cloud | no constraint stated — confirm before Stage 1>>

## Success criteria

<!-- Measurable, not aspirational. Tie to a number or a demonstrable behaviour wherever possible. -->
| # | Criterion | How it will be measured |
|---|---|---|
| 1 | <<e.g. Agent drafts a response to 80% of routine enquiry types without escalation>> | <<e.g. eval set pass rate>> |

## Constraints

<!-- Anything that shapes design before Stage 1 starts: technical, regulatory, organisational, budgetary. -->
- <<e.g. Must integrate with existing SAP ticketing system>>
- <<e.g. No new vendor approvals possible within timeline — must use approved cloud providers only>>

## Timeline

| Milestone | Target date |
|---|---|
| Stage 1 research brief delivered | <<date>> |
| Stage 2 spec sign-off | <<date>> |
| Demo | <<date>> |
| Handover | <<date>> |

## Commercial notes

<!-- Internal only — not shared with client verbatim. Fee structure, risk to the deal, dependencies on client resourcing. -->
<<...>>

## Go / no-go

<!-- The engagement lead's explicit recommendation. A one-pager without this is incomplete. -->
Recommendation: **<<GO | NO-GO | GO WITH CONDITIONS>>**

Conditions (if any): <<...>>

Reasoning: <<one to three lines — what makes this fundable/buildable/deliverable in the timeline, or what makes it not>>
