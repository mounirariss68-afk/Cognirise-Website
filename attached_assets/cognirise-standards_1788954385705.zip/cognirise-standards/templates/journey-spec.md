<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude), journeys sub-stage
GOVERNING STANDARD: standards/04-journey-design.md
OUTPUT FILENAME: docs/journeys/<<job-type>>/journey-map.md (plus sibling files: service-blueprint.md, state-machine.mmd, sequence-<scenario>.mmd, scenarios.feature)
SIGN-OFF: Cognirise lead architect + design reviewer
-->

---
doc: journey-spec
engagement: <<engagement name>>
job_type: <<job-type slug>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Journey Spec — <<job-type name>>

## Job to be done

<!-- The outcome the user hires this journey for, plus what triggers it and what "success" looks like from their side. -->
- Job to be done: <<...>>
- Trigger: <<...>>
- User's success condition: <<...>>

## Service blueprint

<!-- Line of agency separates user-visible action from backstage. Every step is tagged user / agent / system / handoff. -->
| Step | Actor | Action | Line of agency | Autonomy tier (if tool) |
|---|---|---|---|---|
| 1 *(example)* | User | Submits enquiry via portal | Front-stage | — |
| 2 *(example)* | Agent | Retrieves candidate policy clauses | Backstage | Autopilot (read-only, low risk) |
| 3 *(example)* | Agent | Drafts response | Backstage | Co-pilot (pauses for review) |
| 4 *(example)* | Handoff | Reviewer approves or edits draft | Handoff | — |
| 5 *(example)* | System | Sends response, logs audit row | Backstage | — |
| <<n>> | <<user \| agent \| system \| handoff>> | <<...>> | <<front-stage \| backstage \| handoff>> | <<assist \| co-pilot \| autopilot \| —>> |

## Autonomy level per tool

<!-- One row per tool used in this journey, with the evidence that justifies the tier. -->
| Tool | Autonomy tier | Evidence / justification |
|---|---|---|
| <<...>> | <<assist \| co-pilot \| autopilot>> | <<...>> |

## State machine

<!-- Placeholder — real diagram lives in docs/journeys/<job-type>/state-machine.mmd. Must include every terminal state. -->
```mermaid
stateDiagram-v2
  [*] --> InProgress
  InProgress --> AwaitingApproval
  AwaitingApproval --> Completed
  AwaitingApproval --> Escalated
  InProgress --> Refused
  InProgress --> Failed
  InProgress --> TimedOut
  InProgress --> Cancelled
  Completed --> [*]
  Escalated --> [*]
  Refused --> [*]
  Failed --> [*]
  TimedOut --> [*]
  Cancelled --> [*]
```

## Sequence diagram

<!-- Placeholder — real diagram lives in docs/journeys/<job-type>/sequence-<scenario>.mmd. Show tool calls and approval gates explicitly. -->
```mermaid
sequenceDiagram
  participant U as User
  participant UI as UI
  participant A as Agent
  participant T as Tool
  U->>UI: Submit enquiry
  UI->>A: Start run
  A->>T: policy_search_retrieve
  T-->>A: candidate clauses
  A->>UI: Draft ready — awaiting approval
  UI->>U: Show draft + approval gate
  U->>UI: Approve
  UI->>A: Resume run
  A->>UI: Response sent
```

## Gherkin scenarios

<!-- Reuse and extend FR scenario IDs from functional-spec.md so they stay traceable. Cover happy, each failure path, and each escalation path. -->
```gherkin
Feature: <<job-type>>
  # FR-001 — happy path
  Scenario: Standard enquiry resolved without escalation
    Given the user is in "co-pilot" mode
    When the agent produces a high-confidence draft
    Then the draft is shown for approval within the latency budget
    And approval sends the response and logs an audit row

  # FR-002 — escalation path
  Scenario: Escalation on low confidence
    Given retrieval confidence is below the grounding threshold
    When the agent completes its attempt
    Then a pending_approval row is created with a systemic trigger reason
    And a human reviewer is notified per the SLA
```

## Escalation design

| Field | Value |
|---|---|
| Trigger type | <<threshold-based \| domain-based \| pattern-based \| regulatory>> |
| Routing | <<who receives the escalation>> |
| SLA | <<e.g. 4 business hours>> |
| What the human sees | <<handoff_context snapshot: plan_steps, tool results, session state>> |
| On SLA breach | <<safe default action per risk tier>> |

## First-run vs steady-state

<!-- Trust and disclosure differ between a user's first interaction and repeated use. -->
- First run: <<e.g. show full reasoning trace by default, require explicit approval even for low-risk actions>>
- Steady-state: <<e.g. collapse trace behind one click, allow autopilot for previously-approved action types>>
