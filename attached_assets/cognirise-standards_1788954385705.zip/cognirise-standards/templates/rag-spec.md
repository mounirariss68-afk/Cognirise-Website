<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude)
GOVERNING STANDARD: standards/10-rag.md
OUTPUT FILENAME: specs/rag-spec.md
SIGN-OFF: Cognirise lead architect
-->

---
doc: rag-spec
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# RAG Spec — <<engagement name>>

<!-- Only required if retrieval is in scope per specs/agent-spec.md. -->

## Sources

<!-- What gets ingested. -->
| Source | Format | Volume | Update frequency | Sensitivity |
|---|---|---|---|---|
| *(example)* Policy handbook v3 | PDF | 420 pages | Quarterly | Internal |
| <<...>> | <<...>> | <<...>> | <<...>> | <<...>> |

## Parsing tier

<!-- Which parsing approach per source type — scanned docs, tables, Arabic text need explicit handling. -->
| Source | Parsing approach |
|---|---|
| <<e.g. scanned Arabic PDF>> | <<e.g. OCR with Arabic model, layout-aware extraction>> |

## Chunking config

| Parameter | Default | Override |
|---|---|---|
| Chunk size | 400-800 tokens | <<...>> |
| Overlap | 10-15% | <<...>> |
| Contextual header | 50-100 tokens prepended | <<...>> |

## Embedding model

Default: <<OpenAI text-embedding-3-large>> — <<Voyage-3 / Cohere Embed v4 / BGE-M3 if Arabic-heavy corpus>>

## Index config

- Store: Postgres + pgvector
- Type: `halfvec(1536)`
- Index: HNSW (m=16, ef_construction=64)

## Hybrid search config

- HNSW vector search + Postgres full-text search, fused via RRF (k=60)

## Reranker

Default: <<Cohere Rerank>> — <<BGE-reranker-v2-m3 self-hosted if residency-constrained>>

## ACL model

<!-- Multi-tenancy must be enforced in SQL (Postgres RLS), never in application filters. -->
<<e.g. Row-level security keyed on tenant_id and document classification tier>>

## Eval question set

<!-- Golden set: ≥50 questions, ≥30 manual + ≥20 synthetic, English + Arabic subset. -->
| Requirement | Target |
|---|---|
| Total questions | ≥50 |
| Manual | ≥30 |
| Synthetic | ≥20 |
| Arabic subset | <<n>> questions |

## Thresholds

| Stage | Metric | Minimum threshold |
|---|---|---|
| Retrieval | Recall@10 | ≥0.85 |
| Retrieval | Precision@5 | ≥0.60 |
| Retrieval | MRR | ≥0.70 |
| Generation | Faithfulness | ≥0.90 |
| Generation | Groundedness | ≥0.85 |
| Generation | Answer relevance | ≥0.85 |

## Scale-up triggers

| Condition | Action |
|---|---|
| <10M chunks, p50 <300ms | Stay on pgvector |
| >10-20M chunks or p50 >300ms | Plan migration |
| >100M vectors or sub-10ms p50 SLA | Move to Turbopuffer/Qdrant/Pinecone |

Current corpus size: <<n chunks>> — status: <<within pgvector range>>
