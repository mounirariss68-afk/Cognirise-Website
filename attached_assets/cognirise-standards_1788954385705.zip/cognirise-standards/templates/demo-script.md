<!--
LIFECYCLE STAGE: 6 — Demo & Handover
GOVERNING STANDARD: standards/01-delivery-lifecycle.md (LIFE-019 — demo script requires happy_path, ambiguity_beat, escalation_beat sections)
OUTPUT FILENAME: docs/demo-script.md
SIGN-OFF: Cognirise engagement lead (rehearsed before client-facing use)
-->

---
doc: demo-script
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Demo Script — <<engagement name>>

## Audience

<!-- Who is in the room. Shapes how much technical depth to expose. -->
<<e.g. Client sponsor + two technical reviewers from IT security>>

## Environment

| Field | Value |
|---|---|
| URL | <<...>> |
| Deployment type | <<Autoscale | Reserved VM>> |
| Access | <<how reviewers log in>> |
| Language mode | <<English | Arabic | both — state which is shown first>> |

## Seeded data

<!-- What is loaded before the demo starts. Must be synthetic unless explicitly cleared by the client. -->
<<e.g. "20 synthetic enquiries covering routine, ambiguous, and refusal cases — see specs/data-spec.md seed plan. No real citizen data.">>

## Narrative beats

### Happy path

<!-- The core "this works" moment. -->
1. <<...>>
2. <<...>>
3. <<...>>

### Ambiguity beat

<!-- Show the system handling a genuinely unclear case well, not just the easy case. -->
1. <<...>>
2. <<...>>

### Escalation beat (deliberate failure/escalation moment)

<!-- Required. Show a case designed to trigger refusal or human escalation, and show the escalation working correctly. This is what proves the guardrails are real, not theatre. -->
1. <<e.g. Submit an enquiry with confidence deliberately below the grounding threshold>>
2. <<Show the refusal template and the pending_approval row created>>
3. <<Show the reviewer's view of the handoff_context>>

## What not to claim

<!-- Explicit boundaries for the presenter. Cross-reference docs/gaps.md — never claim something listed there as working. -->
- Do not claim: <<e.g. "production-ready" — this is a prototype>>
- Do not claim: <<e.g. live SAP integration — currently mocked, see docs/gaps.md>>
- Do not claim: <<e.g. any specific accuracy number not backed by evals/latest-run-report.md>>

## Fallback plan if something breaks live

<!-- Concrete, not "we'll figure it out". -->
- Primary fallback: <<e.g. switch to a pre-recorded run-through of the same scenario>>
- If the environment is unreachable: <<e.g. show the eval report and Playwright recordings instead>>
- Who drives the fallback: <<name>>

## Rehearsal record

| Rehearsed by | Date | Outcome |
|---|---|---|
| <<name>> | <<date>> | <<pass \| issues found and fixed>> |
