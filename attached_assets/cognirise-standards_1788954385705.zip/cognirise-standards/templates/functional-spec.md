<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude)
GOVERNING STANDARD: standards/03-specification.md
OUTPUT FILENAME: specs/functional-spec.md
SIGN-OFF: Cognirise lead architect + client technical reviewer
-->

---
doc: functional-spec
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Functional Spec — <<engagement name>>

## Capability breakdown

<!-- List the capabilities this prototype delivers, one line each. Requirements below are grouped under these. -->
1. <<e.g. Draft grounded response to routine citizen enquiry>>
2. <<...>>

## Requirements

<!-- FR-### is a global, stable ID — never renumber once referenced elsewhere. Every row must cite a research-pack section. -->
| ID | Statement | Rationale | Source | Priority (MoSCoW) | Acceptance criteria | Journey step |
|---|---|---|---|---|---|---|
| FR-001 *(example)* | The agent MUST draft a response citing the specific policy clause it relied on | Agents currently cannot verify sources manually within SLA | [source: RP §3] | Must | Response includes ≥1 inline citation resolvable to a real document + page/section | journeys/enquiry-response.md → step 3 |
| FR-002 | <<...>> | <<...>> | [source: RP §<<n>>] | <<Must \| Should \| Could \| Won't>> | <<...>> | <<...>> |

## Scenarios

<!-- Every FR needs at least one happy-path, one ambiguous/edge, and one failure or refusal scenario.
Scenario IDs reuse the FR ID they test so eval cases stay traceable. -->

```gherkin
Feature: Draft grounded enquiry response
  # FR-001 — happy path
  Scenario: Agent finds a clear policy match
    Given the enquiry text matches a single policy clause with high retrieval confidence
    When the agent drafts a response
    Then the response cites the matched clause and its source document
    And the response is queued for agent review before sending

  # FR-001 — failure / refusal path
  Scenario: No sufficiently confident match exists
    Given retrieval confidence for all candidate clauses is below the grounding threshold
    When the agent attempts to draft a response
    Then the agent refuses to draft and returns the named refusal template
    And the enquiry is flagged for manual handling
```

<!-- Add one Gherkin block per capability. Keep steps concrete: real thresholds, real states, no "responds appropriately". -->

## Non-functional requirements

<!-- NFR-### ids. Defaults below are the Cognirise standard budgets — keep them unless the research pack or client demands a documented override. -->
| ID | Category | Default budget | Override (if any) | Source |
|---|---|---|---|---|
| NFR-001 | Latency | p50 ≤ 2s, p95 ≤ 6s per user-facing request; LLM call timeout 45s, tool call 15s, DB query 5s, total request 120s | <<none \| stated override>> | standards/03 |
| NFR-002 | Cost per task | Default ceiling $0.50/job unless overridden with client sign-off | <<...>> | standards/03 |
| NFR-003 | Availability | 99% uptime Autoscale demo; 99.5% Reserved VM production-leaning | <<...>> | standards/03 |
| NFR-004 | Accessibility | WCAG 2.2 AA baseline; mandatory for gov/citizen-facing | <<...>> | standards/18 |
| NFR-005 | Security | TLS in transit, AES-256 at rest, Secrets via Replit Secrets, least-privilege tool scoping | <<...>> | standards/13 |
| NFR-006 | Auditability | Every consequential action produces an append-only audit-log row | <<...>> | standards/13 |
| NFR-007 | Language support | <<Arabic + English, full RTL \| English only>> | <<...>> | standards/18 |
| NFR-008 | Data residency | <<UAE-only \| regional \| unconstrained>> | <<...>> | RP §5 |

## Out of scope

<!-- Explicit. Anything a reviewer might reasonably expect but this spec does not cover. -->
- <<...>>

## UI / journey cross-reference

<!-- Point to the journey-spec.md documents that realise these requirements — do not duplicate journey content here. -->
| Requirement(s) | Journey document |
|---|---|
| FR-001, FR-002 | docs/journeys/<<job-type>>/journey-map.md |
