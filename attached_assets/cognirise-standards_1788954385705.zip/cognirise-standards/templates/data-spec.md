<!--
LIFECYCLE STAGE: 2 — Specification & Design (Claude)
GOVERNING STANDARD: standards/03-specification.md (Data Spec required sections) + standards/17-data-governance-compliance.md
OUTPUT FILENAME: specs/data-spec.md
SIGN-OFF: Cognirise lead architect + client data owner
-->

---
doc: data-spec
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Data Spec — <<engagement name>>

## Entity list

<!-- Name every persistent entity. One line each. -->
- <<e.g. Enquiry — a citizen's inbound request>>
- <<...>>

```mermaid
erDiagram
  ENQUIRY ||--o{ DRAFT_RESPONSE : has
  DRAFT_RESPONSE }o--|| POLICY_CLAUSE : cites
```

## Schema (Postgres / Drizzle)

<!-- Real Drizzle syntax. Include the standard run/step/checkpoint/approval/audit tables from standards/07 if agents are in scope. -->
```ts
export const enquiries = pgTable("enquiries", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id").notNull(),
  <<column>>: <<type>>("<<column_name>>").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Example: pending_approvals — required if any HITL gate exists
export const pendingApprovals = pgTable("pending_approvals", {
  id: uuid("id").primaryKey().defaultRandom(),
  runId: uuid("run_id").notNull(),
  riskTier: text("risk_tier").notNull(),
  slaDeadline: timestamp("sla_deadline").notNull(),
  handoffContext: jsonb("handoff_context").notNull(),
  resolutionNote: text("resolution_note"),
});
```

## Data classification

<!-- Every field that touches personal, financial, or sensitive data. Classification tiers per standards/17: public / internal / confidential / restricted. -->
| Field | Entity | Classification | Residency constraint | Retention period |
|---|---|---|---|---|
| *(example)* emiratesId | citizen_profile | restricted | UAE only | 7 years per <<regulation>> |
| <<...>> | <<...>> | <<public \| internal \| confidential \| restricted>> | <<...>> | <<...>> |

## PII inventory

<!-- Subset of the classification table — every field that is personally identifying, isolated for the privacy reviewer. -->
| Field | Entity | PII type | Masking / redaction rule |
|---|---|---|---|
| <<...>> | <<...>> | <<direct identifier \| quasi-identifier \| sensitive category>> | <<e.g. redacted in logs, visible only to authorised role>> |

## Retention & deletion policy

| Data category | Retention period | Deletion mechanism | Legal basis |
|---|---|---|---|
| <<...>> | <<...>> | <<scheduled job \| manual on request \| automatic TTL>> | <<...>> |

## Access control

<!-- Tenancy isolation model. Prefer Postgres RLS over app-level filtering per standards/13. -->
- Isolation mechanism: <<Postgres Row-Level Security keyed on tenant_id>>
- Roles: <<list roles and what each can read/write>>

## Audit log schema

<!-- Append-only, INSERT-only grants, per standards/13. -->
```ts
export const auditLog = pgTable("audit_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  actorId: uuid("actor_id").notNull(),
  actorType: text("actor_type").notNull(), // 'user' | 'agent' | 'system'
  action: text("action").notNull(),
  target: text("target").notNull(),
  outcome: text("outcome").notNull(),
});
```

## Seed / demo data plan

<!-- What gets seeded for the demo, and how it stays clearly synthetic. -->
- <<e.g. 20 synthetic enquiries covering happy path, ambiguous, and refusal cases — no real citizen data used>>
