<!--
LIFECYCLE STAGE: 5 — QA & Eval Gates (maintained continuously from Stage 2 onward)
GOVERNING STANDARD: standards/17-data-governance-compliance.md (gap-disclosure template) + standards/12-guardrails-safety.md (known-gaps.md pattern)
OUTPUT FILENAME: docs/gaps.md
SIGN-OFF: Cognirise lead architect + client sponsor (both must see this before demo)
-->

---
doc: gaps-and-waivers
engagement: <<engagement name>>
version: 0.1
status: draft
last_reviewed: <<YYYY-MM-DD>>
---

# Gaps and Waivers — <<engagement name>>

<!-- This is the single most important document at demo time. Anything stubbed, mocked, hardcoded,
or faked belongs here BEFORE a client discovers it. An undisclosed gap found during a demo
is the worst outcome in the delivery method. -->

## Disclosed gap list

| Control area | Current state | Gap | Risk if unaddressed | Remediation plan | Target milestone | Owner | Disclosed to client on |
|---|---|---|---|---|---|---|---|
| *(example)* Ticketing integration | Mocked adapter returns fixture data | Real SAP credentials not yet provisioned | Demo cannot show live ticket creation | Swap adapter once credentials arrive; integration contract already matches real API | Before handover | <<name>> | <<date>> |
| <<...>> | <<...>> | <<...>> | <<...>> | <<...>> | <<...>> | <<name>> | <<date>> |

## Standards waiver log

<!-- Every place the build deviates from a MUST or a stated default in standards/. Silent deviation is a defect per canon conventions. -->
| Rule ID | Standard | Deviation | Reason | Approver | Date |
|---|---|---|---|---|---|
| *(example)* AGT-0xx | standards/07-agent-architecture.md | Used single-agent pattern where orchestrator-workers was the documented default for this task class | Task volume in prototype does not justify worker fan-out; single agent stays within latency budget | <<name>> | <<date>> |
| <<...>> | <<...>> | <<...>> | <<...>> | <<name>> | <<date>> |

## Stub / mock inventory

<!-- Anything presented as working that is not real end-to-end. Cross-check against prompts/04-claude-implementation.md's rule against unlabelled stubs. -->
| Item | Where in the code | What it fakes | Why | Replacement plan |
|---|---|---|---|---|
| <<...>> | <<file path>> | <<...>> | <<...>> | <<...>> |

## Sign-off

<!-- Both signatures required before this list is considered final for a demo. -->
Cognirise lead architect: <<name>> — <<date>>
Client sponsor acknowledgement: <<name>> — <<date>>
