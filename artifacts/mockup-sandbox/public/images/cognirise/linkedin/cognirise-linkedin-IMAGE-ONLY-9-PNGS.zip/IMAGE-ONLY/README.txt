Cognirise LinkedIn image-only delivery

This archive contains only the nine image-only PNG exports.
Editorial copy and metadata are removed. The approved Cognirise logo remains.
