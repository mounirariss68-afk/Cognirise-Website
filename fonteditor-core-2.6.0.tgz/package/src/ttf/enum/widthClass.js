/**
 * @file 字体宽度度量
 * @author mengke01(kekee000@gmail.com)
 */

export default {
    1: 'Ultra-condensed',
    2: 'Extra-condensed',
    3: 'Condensed',
    4: 'Semi-condensed',
    5: 'Medium (normal)',
    6: 'Semi-expanded',
    7: 'Expanded',
    8: 'Extra-expanded',
    9: 'Ultra-expanded'
};
